// 完整的胸部放大功能测试脚本
async function completeTest() {
  try {
    console.log('开始完整测试...');
    
    // 1. 注册新用户
    console.log('1. 注册新用户...');
    const registerResponse = await fetch('http://127.0.0.1:8787/api/auth/register', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        username: 'testuser_' + Date.now(),
        email: 'testuser_' + Date.now() + '@example.com',
        password: 'testpassword123'
      })
    });
    
    console.log('注册响应状态:', registerResponse.status);
    const registerResult = await registerResponse.json();
    console.log('注册响应:', registerResult);
    
    if (!registerResponse.ok) {
      console.error('注册失败');
      return;
    }
    
    // 2. 登录
    console.log('2. 登录...');
    const loginResponse = await fetch('http://127.0.0.1:8787/api/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        username: registerResult.username || 'testuser_' + Date.now(),
        password: 'testpassword123'
      })
    });
    
    console.log('登录响应状态:', loginResponse.status);
    const loginResult = await loginResponse.json();
    console.log('登录响应:', loginResult);
    
    if (!loginResponse.ok) {
      console.error('登录失败');
      return;
    }
    
    const token = loginResult.token;
    console.log('获取到认证令牌:', token);
    
    // 3. 上传测试图片
    console.log('3. 上传测试图片...');
    // 创建一个简单的测试图像
    const canvas = document.createElement('canvas');
    canvas.width = 200;
    canvas.height = 200;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.fillStyle = 'lightblue';
      ctx.fillRect(0, 0, 200, 200);
      ctx.fillStyle = 'red';
      ctx.fillRect(50, 50, 100, 100);
    }
    
    // 注意：在Node.js环境中无法直接使用canvas.toBlob
    // 这里我们使用一个公共的测试图片URL
    const testImageUrl = 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/47/PNG_transparency_demonstration_1.png/280px-PNG_transparency_demonstration_1.png';
    

  } catch (error) {
    console.error('测试过程中出错:', error);
  }
}

// 运行测试
completeTest();