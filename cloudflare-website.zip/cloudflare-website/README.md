# Cloudflare 无服务器网站

基于 Cloudflare Workers、D1 数据库和 R2 存储构建的全栈无服务器网站系统。

## 功能特性

### 用户系统
- 用户注册、登录、登出
- JWT 认证机制
- 密码加密存储 (Argon2)
- 多级用户权限 (普通用户、管理员、超级管理员)
- 用户级别管理 (会员等级系统)

### 内容管理
- 文章管理 (CRUD)
- 产品管理 (CRUD)
- 多级分类系统
- 内容可见性控制 (公开、认证用户、会员等级)
- 内容收藏功能

### 评论系统
- 文章和产品评论
- 评论审核流程
- 评论状态管理 (待审核、已批准、已拒绝)

### 预设系统 (ComfyUI 插件)
- 预设分类管理
- 预设 CRUD 操作
- 预设收藏功能
- 预设使用统计
- 预设权限控制 (基于用户级别)

### 广告系统
- 网站首页广告管理
- ComfyUI 插件端广告管理
- 广告优先级排序
- 广告状态控制

### 媒体管理
- 图像上传到 R2 存储
- 图像元数据管理
- 图像访问控制

### 留言板系统
- 用户留言功能
- 留言审核机制
- 留言本页面展示与提交

## 技术栈

- **后端**: Cloudflare Workers + Hono 框架
- **数据库**: Cloudflare D1 (SQLite)
- **存储**: Cloudflare R2
- **认证**: JWT (JSON Web Tokens)
- **密码加密**: Argon2
- **开发语言**: TypeScript

## 数据库设计

数据库表包括:
- 用户相关表: Users, UserLevels, UserSessions
- 内容相关表: Articles, Products, ArticleCategories, ProductCategories
- 评论相关表: Comments
- 留言板表: Guestbook
- 收藏相关表: UserFavorites
- 广告相关表: Advertisements, ads
- 预设相关表: categories, presets, user_favorite_presets, preset_access_levels
- 媒体相关表: R2Images, ImageUsage

## 快速开始

### 1. 环境设置

```bash
# 安装依赖
npm install

# 运行设置脚本
npm run setup
```

### 2. 本地开发

```bash
# 启动本地开发服务器
npm run dev
```

### 3. 部署

```bash
# 部署到 Cloudflare
npm run deploy
```

## 前端页面

系统包含以下前端页面：
- 首页 (index.html) - 网站主页，展示内容概览
- 文章列表页 (articles.html) - 展示所有文章列表
- 文章详情页 (article.html) - 展示单篇文章详情，包含评论和收藏功能
- 产品列表页 (products.html) - 展示所有产品列表
- 产品详情页 (product.html) - 展示单个产品详情，包含评论和收藏功能
- 预设列表页 (presets.html) - 展示所有预设列表
- 预设详情页 (preset.html) - 展示单个预设详情，包含收藏和评论功能
- 留言本页面 (guestbook.html) - 用户留言提交和展示页面
- 管理后台登录页 (admin/login.html) - 管理员登录界面
- 管理后台主页 (admin/index.html) - 管理员后台管理界面

## 管理后台系统

系统包含一个完整的管理后台，用于管理网站的所有内容和用户：

### 功能模块
- 仪表板 - 系统概览和统计数据
- 用户管理 - 管理系统用户、角色和权限
- 文章管理 - 管理网站文章内容
- 产品管理 - 管理网站产品信息
- 预设管理 - 管理ComfyUI插件预设
- 网站首页广告管理 - 管理网站首页广告轮播
- 插件端广告管理 - 管理ComfyUI插件端广告
- 评论管理 - 管理用户评论和审核
- 留言管理 - 管理用户留言和审核
- 媒体管理 - 管理上传的图片资源

### 访问方式
管理后台可通过 `/admin/login.html` 访问，使用具有管理员权限的账户登录后可访问 `/admin/index.html` 进行管理操作。

## API 端点

### 认证相关
- `POST /api/auth/register` - 用户注册
- `POST /api/auth/login` - 用户登录
- `POST /api/auth/logout` - 用户登出
- `GET /api/auth/me` - 获取当前用户信息
- `GET /api/auth/users` - 获取用户列表 (管理员)
- `PUT /api/auth/users/:id/role` - 更新用户角色 (超级管理员)
- `PUT /api/auth/users/:id/status` - 启用/禁用用户 (管理员)

### 用户级别管理
- `GET /api/user-levels` - 获取所有用户级别
- `POST /api/user-levels` - 创建用户级别 (超级管理员)
- `PUT /api/user-levels/:level` - 更新用户级别 (超级管理员)
- `DELETE /api/user-levels/:level` - 删除用户级别 (超级管理员)
- `POST /api/user-levels/assign` - 分配用户级别 (管理员)

### 文章管理
- `GET /api/articles` - 获取文章列表
- `GET /api/articles/:id` - 获取文章详情
- `POST /api/articles` - 创建文章 (管理员)
- `PUT /api/articles/:id` - 更新文章 (管理员)
- `DELETE /api/articles/:id` - 删除文章 (管理员)
- `GET /api/articles/categories` - 获取文章分类

### 产品管理
- `GET /api/products` - 获取产品列表
- `GET /api/products/:id` - 获取产品详情
- `POST /api/products` - 创建产品 (管理员)
- `PUT /api/products/:id` - 更新产品 (管理员)
- `DELETE /api/products/:id` - 删除产品 (管理员)
- `GET /api/products/categories` - 获取产品分类

### 预设管理
- `GET /api/presets` - 获取预设列表
- `GET /api/presets/:id` - 获取预设详情
- `POST /api/presets` - 创建预设 (管理员)
- `PUT /api/presets/:id` - 更新预设 (管理员)
- `DELETE /api/presets/:id` - 删除预设 (管理员)
- `POST /api/presets/:id/use` - 记录预设使用
- `POST /api/presets/:id/favorite` - 收藏预设
- `DELETE /api/presets/:id/favorite` - 取消收藏预设
- `GET /api/presets/user/favorites` - 获取用户收藏的预设
- `GET /api/presets/categories` - 获取预设分类

### 广告管理
- `GET /api/ads` - 获取ComfyUI插件端广告
- `POST /api/ads` - 创建ComfyUI插件端广告 (管理员)
- `PUT /api/ads/:id` - 更新ComfyUI插件端广告 (管理员)
- `DELETE /api/ads/:id` - 删除ComfyUI插件端广告 (管理员)
- `GET /api/homepage-ads` - 获取网站首页广告
- `POST /api/homepage-ads` - 创建网站首页广告 (管理员)
- `PUT /api/homepage-ads/:id` - 更新网站首页广告 (管理员)
- `DELETE /api/homepage-ads/:id` - 删除网站首页广告 (管理员)

### 图像管理
- `POST /api/images/upload` - 上传图像 (管理员)
- `GET /api/images` - 获取图像列表 (管理员)
- `DELETE /api/images/:id` - 删除图像 (管理员)
- `GET /api/images/public/:key` - 公共图像访问

### 评论管理
- `GET /api/comments` - 获取评论
- `GET /api/comments/pending` - 获取待审核评论 (管理员)
- `POST /api/comments` - 添加评论 (认证用户)
- `PUT /api/comments/:id` - 更新评论 (作者/管理员)
- `DELETE /api/comments/:id` - 删除评论 (作者/管理员)
- `PUT /api/comments/:id/status` - 审核评论 (管理员)

### 留言板
- `GET /api/guestbook` - 获取留言
- `POST /api/guestbook` - 添加留言 (认证用户)
- `DELETE /api/guestbook/:id` - 删除留言 (作者/管理员)
- `GET /api/guestbook/all` - 获取所有留言（包括未公开的）(管理员)
- `PUT /api/guestbook/:id/public` - 设置留言公开状态 (管理员)

### 收藏管理
- `POST /api/favorites` - 添加收藏
- `DELETE /api/favorites/:type/:id` - 移除收藏
- `GET /api/favorites` - 获取用户收藏
- `GET /api/favorites/stats` - 获取收藏统计

## 部署

1. 安装依赖:
   ```bash
   npm install
   ```

2. 配置 `wrangler.toml` 文件

3. 初始化数据库:
   ```bash
   wrangler d1 execute my-database --file=migrations/init.sql
   ```

4. 部署到 Cloudflare:
   ```bash
   wrangler deploy
   ```

## 开发

### 本地开发
```bash
wrangler dev --assets ./public
```

### 数据库迁移
```bash
# 本地执行
wrangler d1 execute my-database --local --file=migrations/init.sql

# 远程执行
wrangler d1 execute my-database --remote --file=migrations/init.sql
```

## 文档

- [开发指南](DEVELOPMENT.md) - 详细的开发和部署说明
- [使用说明](USAGE.md) - API 使用示例和配置说明
- [测试指南](TESTING.md) - 测试方法和故障排除
- [项目状态](PROJECT_STATUS.md) - 当前项目完成情况和下一步计划
- [项目详细文档](项目详细文档.md) - 完整的项目技术文档

## 预设 API 输出格式

预设 API 现在返回特定格式的数据结构：

### 获取预设列表
返回包含 categories、presets 和 current_category 字段的对象

### 获取预设分类
返回 { [id]: name } 格式的对象