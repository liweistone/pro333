// 插入测试广告数据的脚本
async function insertTestAds() {
  // 由于我们无法直接访问D1数据库，我们将使用wrangler命令行工具来插入测试数据
  // 这个脚本只是说明我们需要插入的数据
  
  console.log('需要插入的Advertisements表测试数据:');
  console.log('1. 首页广告1:');
  console.log('   image_url: https://example.com/homepage-ad1.jpg');
  console.log('   link_url: https://example.com/product1');
  console.log('   title: 首页广告1');
  console.log('   description: 这是第一个首页广告');
  console.log('   sort_order: 1');
  console.log('   is_active: 1');
  console.log('');
  
  console.log('2. 首页广告2:');
  console.log('   image_url: https://example.com/homepage-ad2.jpg');
  console.log('   link_url: https://example.com/product2');
  console.log('   title: 首页广告2');
  console.log('   description: 这是第二个首页广告');
  console.log('   sort_order: 2');
  console.log('   is_active: 1');
  console.log('');
  
  console.log('3. 首页广告3:');
  console.log('   image_url: https://example.com/homepage-ad3.jpg');
  console.log('   link_url: https://example.com/product3');
  console.log('   title: 首页广告3');
  console.log('   description: 这是第三个首页广告');
  console.log('   sort_order: 3');
  console.log('   is_active: 1');
  console.log('');
  
  console.log('需要插入的ads表测试数据:');
  console.log('1. ComfyUI插件广告1:');
  console.log('   title: ComfyUI插件广告1');
  console.log('   image_url: https://example.com/plugin-ad1.jpg');
  console.log('   link_url: https://example.com/plugin1');
  console.log('   description: 这是第一个ComfyUI插件广告');
  console.log('   priority: 1');
  console.log('   is_active: 1');
  console.log('');
  
  console.log('2. ComfyUI插件广告2:');
  console.log('   title: ComfyUI插件广告2');
  console.log('   image_url: https://example.com/plugin-ad2.jpg');
  console.log('   link_url: https://example.com/plugin2');
  console.log('   description: 这是第二个ComfyUI插件广告');
  console.log('   priority: 2');
  console.log('   is_active: 1');
  console.log('');
  
  console.log('3. ComfyUI插件广告3:');
  console.log('   title: ComfyUI插件广告3');
  console.log('   image_url: https://example.com/plugin-ad3.jpg');
  console.log('   link_url: https://example.com/plugin3');
  console.log('   description: 这是第三个ComfyUI插件广告');
  console.log('   priority: 3');
  console.log('   is_active: 1');
}

insertTestAds();