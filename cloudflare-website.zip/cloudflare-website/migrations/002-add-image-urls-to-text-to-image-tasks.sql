-- 为文生图任务记录表添加图像URL字段
ALTER TABLE text_to_image_tasks ADD COLUMN image_urls TEXT;