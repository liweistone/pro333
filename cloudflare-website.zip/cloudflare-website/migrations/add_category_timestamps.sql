-- 为文章分类表添加时间戳字段
ALTER TABLE ArticleCategories ADD COLUMN created_at DATETIME;
ALTER TABLE ArticleCategories ADD COLUMN updated_at DATETIME;