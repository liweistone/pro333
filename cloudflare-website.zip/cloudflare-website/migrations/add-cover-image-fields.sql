-- 为现有的文章表添加封面图片字段
ALTER TABLE Articles ADD COLUMN cover_image TEXT;

-- 为现有的产品表添加封面图片字段
ALTER TABLE Products ADD COLUMN cover_image TEXT;