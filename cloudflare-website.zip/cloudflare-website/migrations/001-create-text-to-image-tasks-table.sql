-- 创建文生图任务记录表
CREATE TABLE IF NOT EXISTS text_to_image_tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    task_id TEXT NOT NULL,
    prompt TEXT NOT NULL,
    status TEXT DEFAULT 'RUNNING',
    image_urls TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    finished_at DATETIME,
    FOREIGN KEY (user_id) REFERENCES Users(id)
);

-- 创建索引以提高查询性能
CREATE INDEX IF NOT EXISTS idx_text_to_image_tasks_user_id ON text_to_image_tasks(user_id);
CREATE INDEX IF NOT EXISTS idx_text_to_image_tasks_created_at ON text_to_image_tasks(created_at);