// 数据库迁移脚本：为评论表添加reviewed_at列
export default {
  /**
   * 应用迁移
   * @param {D1Database} db - D1数据库实例
   */
  async up(db) {
    try {
      console.log('正在检查Comments表是否已存在reviewed_at列...');
      
      // 获取当前表结构
      const schema = await db.prepare("PRAGMA table_info(Comments)").all();
      console.log('当前Comments表结构:', schema.results);
      
      // 检查是否已存在reviewed_at列
      const hasReviewedAtColumn = schema.results.some(column => column.name === 'reviewed_at');
      
      if (hasReviewedAtColumn) {
        console.log('reviewed_at列已存在，跳过添加操作');
        return { success: true, message: 'reviewed_at列已存在' };
      }
      
      console.log('正在添加reviewed_at列...');
      
      // 添加reviewed_at列
      await db.prepare("ALTER TABLE Comments ADD COLUMN reviewed_at DATETIME").run();
      
      console.log('成功添加reviewed_at列');
      return { success: true, message: '成功添加reviewed_at列' };
    } catch (error) {
      // 如果列已存在，会抛出错误
      if (error.message && error.message.includes('duplicate column name')) {
        console.log('reviewed_at列已存在');
        return { success: true, message: 'reviewed_at列已存在' };
      }
      
      console.error('添加reviewed_at列时出错:', error);
      return { success: false, error: error.message };
    }
  },
  
  /**
   * 回滚迁移（可选）
   * @param {D1Database} db - D1数据库实例
   */
  async down(db) {
    // SQLite不支持直接删除列，所以这里留空
    // 在实际应用中，如果需要回滚，可能需要重建表
    console.log('注意：SQLite不支持直接删除列，此操作将跳过');
    return { success: true, message: '跳过回滚操作' };
  }
};