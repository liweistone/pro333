-- 为预设分类表添加缺失的字段
-- 只添加description和parent_id字段，因为created_at和updated_at已经存在
ALTER TABLE categories ADD COLUMN description TEXT;
ALTER TABLE categories ADD COLUMN parent_id TEXT;

-- 为现有记录设置默认时间戳值
UPDATE categories SET created_at = strftime('%s', 'now') WHERE created_at IS NULL;
UPDATE categories SET updated_at = strftime('%s', 'now') WHERE updated_at IS NULL;