-- 为R2Images表添加索引以提高查询性能
CREATE INDEX IF NOT EXISTS idx_r2images_uploaded_at ON R2Images(uploaded_at);
CREATE INDEX IF NOT EXISTS idx_r2images_uploader ON R2Images(uploader_id);
CREATE INDEX IF NOT EXISTS idx_r2images_is_referenced ON R2Images(is_referenced);