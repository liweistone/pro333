-- User表
CREATE TABLE Users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'user',
  membership_level TEXT DEFAULT 'basic',
  profile_image TEXT,
  bio TEXT,
  preferences JSON,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  last_login DATETIME,
  is_active BOOLEAN DEFAULT 1
);

-- 用户级别定义表
CREATE TABLE UserLevels (
  level_name TEXT PRIMARY KEY,
  display_name TEXT NOT NULL,
  min_points INTEGER DEFAULT 0,
  content_access JSON NOT NULL
);

-- 文章主分类表
CREATE TABLE ArticleCategories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  description TEXT,
  parent_id INTEGER DEFAULT NULL,
  FOREIGN KEY (parent_id) REFERENCES ArticleCategories(id)
);

-- 文章表
CREATE TABLE Articles (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  category_id INTEGER NOT NULL,
  author_id INTEGER NOT NULL,
  is_published BOOLEAN DEFAULT 0,
  visibility TEXT DEFAULT 'public',
  view_count INTEGER DEFAULT 0,
  favorite_count INTEGER DEFAULT 0,
  cover_image TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (category_id) REFERENCES ArticleCategories(id),
  FOREIGN KEY (author_id) REFERENCES Users(id)
);

-- 产品主分类表
CREATE TABLE ProductCategories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  description TEXT,
  parent_id INTEGER DEFAULT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (parent_id) REFERENCES ProductCategories(id)
);

-- 产品表
CREATE TABLE Products (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  description TEXT NOT NULL,
  price DECIMAL(10, 2),
  category_id INTEGER NOT NULL,
  features JSON,
  is_available BOOLEAN DEFAULT 1,
  visibility TEXT DEFAULT 'public',
  view_count INTEGER DEFAULT 0,
  favorite_count INTEGER DEFAULT 0,
  cover_image TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (category_id) REFERENCES ProductCategories(id)
);

-- 评论表
CREATE TABLE Comments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  content TEXT NOT NULL,
  user_id INTEGER NOT NULL,
  parent_type TEXT NOT NULL,
  parent_id INTEGER NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  status TEXT DEFAULT 'pending',
  review_reason TEXT,
  FOREIGN KEY (user_id) REFERENCES Users(id)
);

-- 留言板消息表
CREATE TABLE Guestbook (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  message TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  is_public BOOLEAN DEFAULT 1,
  FOREIGN KEY (user_id) REFERENCES Users(id)
);

-- 用户会话表
CREATE TABLE UserSessions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  token_id TEXT NOT NULL,
  expires_at DATETIME NOT NULL,
  FOREIGN KEY (user_id) REFERENCES Users(id)
);

-- 文章阅读计数表
CREATE TABLE ArticleViews (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  article_id INTEGER NOT NULL,
  user_id INTEGER,
  viewed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (article_id) REFERENCES Articles(id),
  FOREIGN KEY (user_id) REFERENCES Users(id)
);

-- 产品查看计数表
CREATE TABLE ProductViews (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  product_id INTEGER NOT NULL,
  user_id INTEGER,
  viewed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (product_id) REFERENCES Products(id),
  FOREIGN KEY (user_id) REFERENCES Users(id)
);

-- 用户收藏表
CREATE TABLE UserFavorites (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  item_type TEXT NOT NULL,
  item_id INTEGER NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(user_id, item_type, item_id),
  FOREIGN KEY (user_id) REFERENCES Users(id)
);

-- 网站首页广告表
CREATE TABLE Advertisements (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  image_url TEXT NOT NULL,
  link_url TEXT,
  title TEXT,
  description TEXT,
  sort_order INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- comfyui插件端预设分类表
CREATE TABLE categories (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  created_at INTEGER DEFAULT (strftime('%s', 'now')),
  updated_at INTEGER DEFAULT (strftime('%s', 'now'))
);

-- comfyui插件端预设表
CREATE TABLE presets (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  category_id TEXT NOT NULL,
  description TEXT,
  positive TEXT NOT NULL,
  negative TEXT,
  image TEXT,
  visibility TEXT DEFAULT 'public',
  preset_type TEXT DEFAULT 'standard',
  view_count INTEGER DEFAULT 0,
  favorite_count INTEGER DEFAULT 0,
  use_count INTEGER DEFAULT 0,
  created_at INTEGER DEFAULT (strftime('%s', 'now')),
  updated_at INTEGER DEFAULT (strftime('%s', 'now')),
  last_used_at INTEGER,
  FOREIGN KEY (category_id) REFERENCES categories (id)
);

-- comfyui插件端广告轮播表
CREATE TABLE ads (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  image_url TEXT NOT NULL,
  link_url TEXT NOT NULL,
  description TEXT,
  priority INTEGER DEFAULT 0,
  is_active INTEGER DEFAULT 1,
  created_at INTEGER DEFAULT (strftime('%s', 'now')),
  updated_at INTEGER DEFAULT (strftime('%s', 'now'))
);

-- 用户收藏预设表
CREATE TABLE user_favorite_presets (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  preset_id TEXT NOT NULL,
  created_at INTEGER DEFAULT (strftime('%s', 'now')),
  FOREIGN KEY (user_id) REFERENCES Users(id),
  FOREIGN KEY (preset_id) REFERENCES presets(id),
  UNIQUE(user_id, preset_id)
);

-- 预设访问级别表
CREATE TABLE preset_access_levels (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  preset_id TEXT NOT NULL,
  membership_level TEXT NOT NULL,
  created_at INTEGER DEFAULT (strftime('%s', 'now')),
  FOREIGN KEY (preset_id) REFERENCES presets(id),
  UNIQUE(preset_id, membership_level)
);

-- R2图像元数据表
CREATE TABLE R2Images (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    object_key TEXT NOT NULL UNIQUE,
    original_name TEXT NOT NULL,
    mime_type TEXT NOT NULL,
    size INTEGER NOT NULL,
    uploader_id INTEGER NOT NULL,
    uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    alt_text TEXT,
    description TEXT,
    is_used BOOLEAN DEFAULT 0,
    usage_count INTEGER DEFAULT 0,
    is_referenced BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (uploader_id) REFERENCES Users(id)
);

-- 图像使用关联表
CREATE TABLE ImageUsage (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    image_id INTEGER NOT NULL,
    used_in_type TEXT NOT NULL,
    used_in_id INTEGER NOT NULL,
    used_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (image_id) REFERENCES R2Images(id)
);

-- 文生图任务记录表
CREATE TABLE text_to_image_tasks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    task_id TEXT NOT NULL,
    prompt TEXT NOT NULL,
    status TEXT DEFAULT 'RUNNING',
    image_urls TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    finished_at DATETIME,
    FOREIGN KEY (user_id) REFERENCES Users(id)
);

-- 性能关键索引
CREATE INDEX idx_articles_visibility ON Articles(visibility);
CREATE INDEX idx_articles_category ON Articles(category_id);
CREATE INDEX idx_products_visibility ON Products(visibility);
CREATE INDEX idx_presets_visibility ON presets(visibility);
CREATE INDEX idx_user_favorites ON UserFavorites(user_id, item_type, item_id);
CREATE INDEX idx_comments_parent ON Comments(parent_type, parent_id);
CREATE INDEX idx_ads_active ON Advertisements(is_active, sort_order);
CREATE INDEX idx_preset_ads_active ON ads(is_active, priority);
CREATE INDEX idx_r2images_uploaded_at ON R2Images(uploaded_at);
CREATE INDEX idx_r2images_uploader ON R2Images(uploader_id);
CREATE INDEX idx_r2images_is_referenced ON R2Images(is_referenced);
CREATE INDEX idx_text_to_image_tasks_user_id ON text_to_image_tasks(user_id);
CREATE INDEX idx_text_to_image_tasks_created_at ON text_to_image_tasks(created_at);