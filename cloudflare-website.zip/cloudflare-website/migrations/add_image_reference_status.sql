-- 为R2Images表添加引用状态字段
ALTER TABLE R2Images ADD COLUMN is_referenced BOOLEAN DEFAULT FALSE;