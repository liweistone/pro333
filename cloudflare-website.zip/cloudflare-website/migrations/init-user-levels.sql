-- 初始化用户等级数据
INSERT INTO UserLevels (level_name, display_name, min_points, content_access) 
VALUES 
  ('basic', '基础用户', 0, '{"can_access_without_watermark": false}'),
  ('vip', 'VIP用户', 1000, '{"can_access_without_watermark": true}'),
  ('premium', '高级用户', 5000, '{"can_access_without_watermark": true}')
ON CONFLICT(level_name) 
DO UPDATE SET 
  display_name = excluded.display_name,
  min_points = excluded.min_points,
  content_access = excluded.content_access;