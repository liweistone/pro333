-- 为评论表添加审核原因列
ALTER TABLE Comments ADD COLUMN review_reason TEXT;