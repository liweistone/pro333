-- 为产品分类表添加时间戳字段
ALTER TABLE ProductCategories ADD COLUMN created_at DATETIME;
ALTER TABLE ProductCategories ADD COLUMN updated_at DATETIME;