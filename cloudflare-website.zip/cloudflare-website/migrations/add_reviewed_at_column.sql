-- 为评论表添加审核时间字段
ALTER TABLE Comments ADD COLUMN reviewed_at DATETIME;