-- 为UserLevels表添加水印访问权限

-- 更新现有用户等级的content_access字段，添加水印权限
UPDATE UserLevels 
SET content_access = '{"can_access_without_watermark": false}' 
WHERE level_name = 'basic';

UPDATE UserLevels 
SET content_access = '{"can_access_without_watermark": true}' 
WHERE level_name = 'vip';

UPDATE UserLevels 
SET content_access = '{"can_access_without_watermark": true}' 
WHERE level_name = 'premium';

-- 如果需要添加新的用户等级，可以使用以下语句：
-- INSERT INTO UserLevels (level_name, display_name, min_points, content_access) 
-- VALUES ('svip', '超级VIP', 5000, '{"can_access_without_watermark": true}');

-- 验证更新结果
SELECT level_name, content_access FROM UserLevels;