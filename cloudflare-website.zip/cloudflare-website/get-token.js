// 获取认证令牌的脚本
async function getToken() {
  try {
    const loginResponse = await fetch('http://127.0.0.1:8787/api/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        username: 'admin',
        password: 'admin123'
      })
    });

    if (!loginResponse.ok) {
      console.log('登录失败:', await loginResponse.text());
      return;
    }

    const loginData = await loginResponse.json();
    console.log('认证令牌:', loginData.token);
  } catch (error) {
    console.error('获取令牌过程中出错:', error);
  }
}

getToken();