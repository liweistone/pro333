# 使用我们自己的图库进行AI试衣测试指南

本文档详细说明了如何使用我们自己的图库中的上装和下装图像进行AI试衣测试，而不是使用阿里云的示例图片。

## 1. 准备工作

### 1.1 确保服务运行
首先确保本地开发服务器正在运行：
```bash
npm run dev
```

### 1.2 登录获取JWT令牌
运行登录脚本获取JWT令牌并保存到文件：
```bash
node login-and-save-token.js
```

### 1.3 上传测试图片
运行上传脚本将测试图片上传到我们的图库：
```bash
node upload-test-images-to-gallery.js
```

## 2. 图库结构说明

我们的AI试衣图库分为以下几类：
- **模特库 (models)**: 存放模特图片
- **上装库 (tops)**: 存放上装图片
- **下装库 (bottoms)**: 存放下装图片
- **连衣裙库 (dresses)**: 存放连衣裙图片

## 3. 前端页面使用

### 3.1 访问AI试衣页面
在浏览器中访问：
```
http://localhost:8787/ai-tryon.html
```

### 3.2 选择图片
1. 在页面左侧的图库区域，点击不同的标签页切换模特、上装、下装图库
2. 从每个图库中选择一张图片（点击图片使其高亮显示）
3. 选择的图片会显示在右侧预览区域

### 3.3 生成试衣效果
1. 确保已选择模特图片和至少一件服装（上装或下装）
2. 可以调整生成参数（分辨率、人脸修复等）
3. 点击"生成试衣效果"按钮开始生成

## 4. 后端API使用

### 4.1 获取图库图片列表
```bash
# 获取模特图片列表
curl -H "Authorization: Bearer YOUR_JWT_TOKEN" \
     http://localhost:8787/api/ai-tryon/gallery/models

# 获取上装图片列表
curl -H "Authorization: Bearer YOUR_JWT_TOKEN" \
     http://localhost:8787/api/ai-tryon/gallery/tops

# 获取下装图片列表
curl -H "Authorization: Bearer YOUR_JWT_TOKEN" \
     http://localhost:8787/api/ai-tryon/gallery/bottoms
```

### 4.2 生成临时访问URL
```bash
# 为图片生成稳定临时URL（用于AI服务访问）
curl -H "Authorization: Bearer YOUR_JWT_TOKEN" \
     http://localhost:8787/api/ai-tryon/stable-temp-public-url/图片KEY
```

### 4.3 创建试衣任务
```bash
curl -X POST \
     -H "Content-Type: application/json" \
     -H "Authorization: Bearer YOUR_JWT_TOKEN" \
     -d '{
           "model_image_url": "模特图片临时URL",
           "top_garment_url": "上装图片临时URL",
           "bottom_garment_url": "下装图片临时URL",
           "resolution": 1.5,
           "restore_face": true,
           "image_count": 1
         }' \
     http://localhost:8787/api/ai-tryon/create
```

### 4.4 查询任务状态
```bash
curl -H "Authorization: Bearer YOUR_JWT_TOKEN" \
     http://localhost:8787/api/ai-tryon/status/任务ID
```

## 5. 自动化测试脚本

### 5.1 完整测试脚本
运行完整测试脚本，测试多种组合：
```bash
node complete-our-gallery-tryon-test.js
```

该脚本会测试以下组合：
1. 模特 + 上装
2. 模特 + 下装
3. 模特 + 上装 + 下装

### 5.2 自定义测试脚本
可以参考 [test-our-own-tryon.js](test-our-own-tryon.js) 创建自定义测试脚本。

## 6. 故障排除

### 6.1 图片无法访问
如果AI服务无法访问图片，请检查：
1. 图片是否成功上传到图库
2. 临时URL是否正确生成
3. 网络连接是否正常

### 6.2 任务失败
如果试衣任务失败，请检查：
1. 图片格式是否正确（JPEG/PNG）
2. 图片尺寸是否符合要求
3. 阿里云API密钥是否配置正确

### 6.3 SSL协议错误
如果出现SSL协议错误，请确保：
1. 使用HTTPS协议访问图片URL
2. 使用direct-image端点而非其他端点
3. 检查Cloudflare Workers配置

## 7. 最佳实践

### 7.1 图片要求
- 格式：JPEG/PNG/GIF/WebP
- 大小：不超过5MB
- 尺寸：建议使用高清图片以获得更好的效果

### 7.2 参数调优
- 分辨率：1.5倍通常能获得较好的效果和性能平衡
- 人脸修复：建议开启以获得更好的人脸效果
- 图片数量：根据需要生成1-4张图片

### 7.3 错误处理
- 实现重试机制以处理临时网络问题
- 检查图片可访问性后再提交任务
- 记录详细的日志以便问题排查