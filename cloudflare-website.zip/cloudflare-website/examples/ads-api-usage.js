// 广告API使用示例

// 1. 获取网站首页广告列表
async function getHomepageAds() {
  try {
    const response = await fetch('/api/ads');
    const ads = await response.json();
    console.log('首页广告列表:', ads);
    return ads;
  } catch (error) {
    console.error('获取首页广告失败:', error);
  }
}

// 2. 创建网站首页广告（需要管理员权限）
async function createHomepageAd(adData, adminToken) {
  try {
    const response = await fetch('/api/ads', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${adminToken}`
      },
      body: JSON.stringify(adData)
    });
    
    if (response.ok) {
      const result = await response.json();
      console.log('广告创建成功:', result);
      return result;
    } else {
      const error = await response.json();
      console.error('广告创建失败:', error);
      return error;
    }
  } catch (error) {
    console.error('广告创建请求失败:', error);
  }
}

// 3. 更新网站首页广告（需要管理员权限）
async function updateHomepageAd(adId, updates, adminToken) {
  try {
    const response = await fetch(`/api/ads/${adId}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${adminToken}`
      },
      body: JSON.stringify(updates)
    });
    
    if (response.ok) {
      const result = await response.json();
      console.log('广告更新成功:', result);
      return result;
    } else {
      const error = await response.json();
      console.error('广告更新失败:', error);
      return error;
    }
  } catch (error) {
    console.error('广告更新请求失败:', error);
  }
}

// 4. 删除网站首页广告（需要管理员权限）
async function deleteHomepageAd(adId, adminToken) {
  try {
    const response = await fetch(`/api/ads/${adId}`, {
      method: 'DELETE',
      headers: {
        'Authorization': `Bearer ${adminToken}`
      }
    });
    
    if (response.ok) {
      const result = await response.json();
      console.log('广告删除成功:', result);
      return result;
    } else {
      const error = await response.json();
      console.error('广告删除失败:', error);
      return error;
    }
  } catch (error) {
    console.error('广告删除请求失败:', error);
  }
}

// 5. 获取ComfyUI插件端广告列表
async function getPresetAds() {
  try {
    const response = await fetch('/api/ads/preset-ads');
    const ads = await response.json();
    console.log('插件端广告列表:', ads);
    return ads;
  } catch (error) {
    console.error('获取插件端广告失败:', error);
  }
}

// 使用示例
async function example() {
  // 获取首页广告
  await getHomepageAds();
  
  // 创建首页广告示例数据
  const newAd = {
    image_url: 'https://example.com/homepage-ad.jpg',
    link_url: 'https://example.com/promotion',
    title: '首页推广广告',
    description: '这是一个首页推广广告',
    sort_order: 1,
    is_active: true
  };
  
  // 注意：实际使用时需要提供有效的管理员JWT token
  const adminToken = 'YOUR_ADMIN_JWT_TOKEN';
  
  // 创建广告（需要管理员权限）
  // await createHomepageAd(newAd, adminToken);
  
  console.log('API使用示例完成');
}

// 运行示例
example();