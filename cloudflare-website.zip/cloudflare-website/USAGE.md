# 使用说明

## 快速开始

### 1. 环境设置

```bash
# 克隆项目后，运行设置脚本
npm run setup
```

### 2. 本地开发

```bash
# 启动本地开发服务器
npm run dev
```

默认情况下，服务器将在 `https://aideator.top` 上运行。

### 3. 部署到 Cloudflare

```bash
# 部署到 Cloudflare
npm run deploy
```

## API 使用示例

### 健康检查

```bash
curl https://aideator.top/health
```

## 完整API端点列表

### 用户认证API

#### 注册
```bash
curl -X POST https://aideator.top/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"username":"testuser","email":"test@example.com","password":"password123"}'
```

#### 登录
```bash
curl -X POST https://aideator.top/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"testuser","password":"password123"}'
```

#### 获取用户信息
```bash
curl https://aideator.top/api/auth/me \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"
```

#### 用户登出
```bash
curl -X POST https://aideator.top/api/auth/logout \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"
```

#### 刷新令牌
```bash
curl -X POST https://aideator.top/api/auth/refresh \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"
```

#### 获取用户列表（管理员权限）
```bash
curl "https://aideator.top/api/auth/users?page=1&limit=10" \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN"
```

#### 获取单个用户信息（管理员权限）
```bash
curl "https://aideator.top/api/auth/users/USER_ID" \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN"
```

#### 创建用户（管理员权限）
```bash
curl -X POST https://aideator.top/api/auth/users \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN" \
  -d '{"username":"newuser","email":"new@example.com","password":"password123","role":"user"}'
```

#### 更新用户信息（管理员权限）
```bash
curl -X PUT https://aideator.top/api/auth/users/USER_ID \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN" \
  -d '{"username":"updateduser","email":"updated@example.com","role":"admin"}'
```

#### 删除用户（超级管理员权限）
```bash
curl -X DELETE https://aideator.top/api/auth/users/USER_ID \
  -H "Authorization: Bearer SUPERADMIN_JWT_TOKEN"
```

#### 更新用户角色（超级管理员权限）
```bash
curl -X PUT https://aideator.top/api/auth/users/USER_ID/role \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer SUPERADMIN_JWT_TOKEN" \
  -d '{"role":"admin"}'
```

#### 启用/禁用用户（管理员权限）
```bash
curl -X PUT https://aideator.top/api/auth/users/USER_ID/status \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN" \
  -d '{"is_active":false}'
```

### 内容管理API

#### 文章管理

##### 获取文章列表
```bash
curl https://aideator.top/api/articles
```

##### 获取文章列表（旧端点，保持兼容性）
```bash
curl https://aideator.top/api/articles/list
```

##### 获取单篇文章
```bash
curl https://aideator.top/api/articles/ARTICLE_ID
```

##### 添加文章（管理员权限）
```bash
curl -X POST https://aideator.top/api/articles/add \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN" \
  -d '{"title":"新文章","content":"文章内容","category_id":1,"is_published":true,"visibility":"public"}'
```

##### 编辑文章（管理员权限）
```bash
curl -X PUT https://aideator.top/api/articles/edit/ARTICLE_ID \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN" \
  -d '{"title":"更新的文章","content":"更新的内容","category_id":1,"is_published":true,"visibility":"public"}'
```

##### 删除文章（管理员权限）
```bash
curl -X DELETE https://aideator.top/api/articles/delete/ARTICLE_ID \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN"
```

#### 产品管理

##### 获取产品分类
```bash
curl https://aideator.top/api/products/categories
```

##### 获取公开产品列表
```bash
curl "https://aideator.top/api/products/public?limit=10"
```

##### 获取单个公开产品详情
```bash
curl https://aideator.top/api/products/public/PRODUCT_ID
```

##### 获取产品列表（管理员权限）
```bash
curl "https://aideator.top/api/products?page=1&limit=10&category_id=CATEGORY_ID" \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN"
```

##### 获取产品详情（管理员权限）
```bash
curl https://aideator.top/api/products/PRODUCT_ID \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN"
```

##### 创建产品（管理员权限）
```bash
curl -X POST https://aideator.top/api/products \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN" \
  -d '{"name":"产品名称","description":"产品描述","price":99.99,"category_id":1,"features":{"color":"red"},"visibility":"public","is_available":true}'
```

##### 更新产品（管理员权限）
```bash
curl -X PUT https://aideator.top/api/products/PRODUCT_ID \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN" \
  -d '{"name":"更新的产品名称","price":89.99}'
```

##### 删除产品（管理员权限）
```bash
curl -X DELETE https://aideator.top/api/products/PRODUCT_ID \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN"
```

#### 预设管理

##### 获取预设分类列表
```bash
curl https://aideator.top/api/presets/categories
```

##### 检查预设分类表结构
```bash
curl https://aideator.top/api/presets/categories/table-info
```

##### 更新预设分类表结构（管理员权限）
```bash
curl -X POST https://aideator.top/api/presets/categories/update-table \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN"
```

##### 获取预设分类列表（管理员权限）
```bash
curl https://aideator.top/api/presets/categories/list \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN"
```

##### 获取单个预设分类（管理员权限）
```bash
curl https://aideator.top/api/presets/categories/CATEGORY_ID \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN"
```

##### 创建预设分类（管理员权限）
```bash
curl -X POST https://aideator.top/api/presets/categories \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN" \
  -d '{"name":"新分类","description":"分类描述"}'
```

##### 更新预设分类（管理员权限）
```bash
curl -X PUT https://aideator.top/api/presets/categories/CATEGORY_ID \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN" \
  -d '{"name":"更新的分类","description":"更新的描述"}'
```

##### 删除预设分类（管理员权限）
```bash
curl -X DELETE https://aideator.top/api/presets/categories/CATEGORY_ID \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN"
```

##### 获取预设列表
```bash
curl "https://aideator.top/api/presets?category_id=CATEGORY_ID&sort=newest&page=1&limit=20"
```

##### 获取单个预设详情
```bash
curl https://aideator.top/api/presets/PRESET_ID
```

##### 获取预设相关效果图
```bash
curl https://aideator.top/api/presets/PRESET_ID/effect-images
```

##### 创建预设（管理员权限）
```bash
curl -X POST https://aideator.top/api/presets \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN" \
  -d '{"title":"新预设","category_id":"CATEGORY_ID","description":"预设描述","positive":"positive prompt","negative":"negative prompt","image":"IMAGE_URL","visibility":"public"}'
```

##### 更新预设（管理员权限）
```bash
curl -X PUT https://aideator.top/api/presets/PRESET_ID \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN" \
  -d '{"title":"更新的预设","positive":"updated positive prompt"}'
```

##### 删除预设（管理员权限）
```bash
curl -X DELETE https://aideator.top/api/presets/PRESET_ID \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN"
```

##### 记录预设使用
```bash
curl -X POST https://aideator.top/api/presets/PRESET_ID/use
```

##### 收藏预设（认证用户）
```bash
curl -X POST https://aideator.top/api/presets/PRESET_ID/favorite \
  -H "Authorization: Bearer USER_JWT_TOKEN"
```

##### 取消收藏（认证用户）
```bash
curl -X DELETE https://aideator.top/api/presets/PRESET_ID/favorite \
  -H "Authorization: Bearer USER_JWT_TOKEN"
```

##### 获取用户收藏的预设（认证用户）
```bash
curl https://aideator.top/api/presets/user/favorites \
  -H "Authorization: Bearer USER_JWT_TOKEN"
```

### 评论系统

#### 获取评论列表（管理后台，管理员权限）
```bash
curl "https://aideator.top/api/comments/list?page=1&limit=20&status=pending&type=article&search=KEYWORD" \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN"
```

#### 获取评论
```bash
curl "https://aideator.top/api/comments?parent_type=article&parent_id=1&page=1&limit=20"
```

#### 获取用户评论（认证用户）
```bash
curl "https://aideator.top/api/comments/user?page=1&limit=20" \
  -H "Authorization: Bearer USER_JWT_TOKEN"
```

#### 获取评论详情
```bash
curl https://aideator.top/api/comments/COMMENT_ID
```

#### 发表评论（认证用户）
```bash
curl -X POST https://aideator.top/api/comments \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer USER_JWT_TOKEN" \
  -d '{"content":"这是一条评论","parent_type":"article","parent_id":1}'
```

#### 更新评论（作者或管理员）
```bash
curl -X PUT https://aideator.top/api/comments/COMMENT_ID \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer USER_JWT_TOKEN" \
  -d '{"content":"更新的评论内容"}'
```

#### 删除评论（作者或管理员）
```bash
curl -X DELETE https://aideator.top/api/comments/COMMENT_ID \
  -H "Authorization: Bearer USER_JWT_TOKEN"
```

#### 审核评论（管理员权限）
```bash
curl -X PUT https://aideator.top/api/comments/COMMENT_ID/status \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN" \
  -d '{"status":"approved","reason":"理由"}'
```

### 收藏系统

#### 添加收藏（认证用户）
```bash
curl -X POST https://aideator.top/api/favorites \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer USER_JWT_TOKEN" \
  -d '{"item_type":"article","item_id":1}'
```

#### 移除收藏（认证用户）
```bash
curl -X DELETE https://aideator.top/api/favorites/article/1 \
  -H "Authorization: Bearer USER_JWT_TOKEN"
```

#### 获取用户收藏（认证用户）
```bash
curl https://aideator.top/api/favorites \
  -H "Authorization: Bearer USER_JWT_TOKEN"
```

#### 获取特定类型收藏统计（认证用户）
```bash
curl https://aideator.top/api/favorites/stats \
  -H "Authorization: Bearer USER_JWT_TOKEN"
```

### 留言板系统

#### 获取留言列表
```bash
curl "https://aideator.top/api/guestbook?page=1&limit=20"
```

#### 提交留言（认证用户）
```bash
curl -X POST https://aideator.top/api/guestbook \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer USER_JWT_TOKEN" \
  -d '{"message":"这是一条留言"}'
```

#### 删除留言（作者或管理员）
```bash
curl -X DELETE https://aideator.top/api/guestbook/MESSAGE_ID \
  -H "Authorization: Bearer USER_JWT_TOKEN"
```

#### 管理员获取所有留言（包括未公开的，仅管理员）
```bash
curl "https://aideator.top/api/guestbook/all?page=1&limit=20&is_public=1&user=USERNAME&search=KEYWORD" \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN"
```

#### 管理员获取单个留言详情（仅管理员）
```bash
curl https://aideator.top/api/guestbook/all/MESSAGE_ID \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN"
```

#### 管理员设置留言公开状态（仅管理员）
```bash
curl -X PUT https://aideator.top/api/guestbook/MESSAGE_ID/public \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN" \
  -d '{"is_public": true}'
```

#### 管理员批量删除留言（仅管理员）
```bash
curl -X DELETE https://aideator.top/api/guestbook/batch \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN" \
  -d '{"ids":[1,2,3]}'
```

#### 管理员批量设置公开状态（仅管理员）
```bash
curl -X PUT https://aideator.top/api/guestbook/batch/public \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN" \
  -d '{"ids":[1,2,3],"is_public":true}'
```

### 广告系统

#### ComfyUI插件端广告管理

##### 获取ComfyUI插件端广告列表
```bash
curl "https://aideator.top/api/ads?limit=10"
```

##### 创建ComfyUI插件端广告（管理员权限）
```bash
curl -X POST https://aideator.top/api/ads \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN" \
  -d '{"title":"广告标题","image_url":"IMAGE_URL","link_url":"LINK_URL","description":"广告描述","priority":0,"is_active":1}'
```

##### 更新ComfyUI插件端广告（管理员权限）
```bash
curl -X PUT https://aideator.top/api/ads/AD_ID \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN" \
  -d '{"title":"更新的广告标题","priority":1}'
```

##### 删除ComfyUI插件端广告（管理员权限）
```bash
curl -X DELETE https://aideator.top/api/ads/AD_ID \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN"
```

##### 获取单个ComfyUI插件端广告详情
```bash
curl https://aideator.top/api/ads/AD_ID
```

#### 网站首页广告管理

##### 获取网站首页广告列表
```bash
curl "https://aideator.top/api/advertisements?limit=10"
```

##### 创建网站首页广告（管理员权限）
```bash
curl -X POST https://aideator.top/api/advertisements \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN" \
  -d '{"title":"广告标题","image_url":"IMAGE_URL","link_url":"LINK_URL","description":"广告描述","sort_order":0,"is_active":1}'
```

##### 更新网站首页广告（管理员权限）
```bash
curl -X PUT https://aideator.top/api/advertisements/AD_ID \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN" \
  -d '{"title":"更新的广告标题","sort_order":1}'
```

##### 删除网站首页广告（管理员权限）
```bash
curl -X DELETE https://aideator.top/api/advertisements/AD_ID \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN"
```

##### 获取单个网站首页广告详情
```bash
curl https://aideator.top/api/advertisements/AD_ID
```

### AI试衣功能API

#### 创建试衣任务（认证用户）
```bash
curl -X POST https://aideator.top/api/ai-tryon/create \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer USER_JWT_TOKEN" \
  -d '{"model_image_url":"MODEL_IMAGE_URL","top_garment_url":"TOP_IMAGE_URL","bottom_garment_url":"BOTTOM_IMAGE_URL","resolution":-1,"restore_face":true,"image_count":1}'
```

#### 查询任务状态（认证用户）
```bash
curl https://aideator.top/api/ai-tryon/status/TASK_ID \
  -H "Authorization: Bearer USER_JWT_TOKEN"
```

#### 获取图库图片列表
```bash
curl "https://aideator.top/api/ai-tryon/gallery/models?page=1&limit=20" \
  -H "Authorization: Bearer USER_JWT_TOKEN"
```

#### 上传图片（认证用户）
```bash
curl -X POST https://aideator.top/api/ai-tryon/upload \
  -H "Authorization: Bearer USER_JWT_TOKEN" \
  -F "file=@image.jpg" \
  -F "type=tops"
```

#### 为AI服务提供临时公开访问URL（认证用户）
```bash
curl https://aideator.top/api/ai-tryon/temp-public-url/IMAGE_KEY \
  -H "Authorization: Bearer USER_JWT_TOKEN"
```

#### 为AI服务提供稳定临时公开访问URL（认证用户）
```bash
curl https://aideator.top/api/ai-tryon/stable-temp-public-url/IMAGE_KEY \
  -H "Authorization: Bearer USER_JWT_TOKEN"
```

#### 为AI服务提供用户上传图片的临时公开访问URL（认证用户）
```bash
curl https://aideator.top/api/ai-tryon/temp-public-user-url/USER_ID/FILENAME \
  -H "Authorization: Bearer USER_JWT_TOKEN"
```

#### 为AI服务提供用户上传图片的稳定临时公开访问URL（认证用户）
```bash
curl https://aideator.top/api/ai-tryon/stable-temp-public-user-url/USER_ID/KEY \
  -H "Authorization: Bearer USER_JWT_TOKEN"
```

### 胸部放大功能API

### 媒体管理API

#### 上传图像（管理员权限）
```bash
curl -X POST https://aideator.top/api/images/upload \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN" \
  -F "file=@image.jpg" \
  -F "alt_text=图片描述" \
  -F "description=图片详细描述"
```

#### 获取图像列表（管理员权限）
```bash
curl "https://aideator.top/api/images?page=1&limit=10&search=KEYWORD&sort=size" \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN"
```

#### 获取单个图像详情（管理员权限）
```bash
curl https://aideator.top/api/images/IMAGE_ID \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN"
```

#### 更新图像信息（管理员权限）
```bash
curl -X PUT https://aideator.top/api/images/IMAGE_ID \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN" \
  -d '{"alt_text":"更新的图片描述","description":"更新的图片详细描述"}'
```

#### 删除图像（管理员权限）
```bash
curl -X DELETE https://aideator.top/api/images/IMAGE_ID \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN"
```

#### 公共图像访问
```bash
curl https://aideator.top/api/images/public/OBJECT_KEY
```

### 管理员功能API

#### 管理员主页（管理员权限）
```bash
curl https://aideator.top/api/admin \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN"
```

#### 文章管理页面（管理员权限）
```bash
curl https://aideator.top/api/admin/articles \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN"
```

#### 获取文章总数（管理员权限）
```bash
curl https://aideator.top/api/admin/articles/count \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN"
```

#### 获取产品总数（管理员权限）
```bash
curl https://aideator.top/api/admin/products/count \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN"
```

#### 获取预设总数（管理员权限）
```bash
curl https://aideator.top/api/admin/presets/count \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN"
```

#### 获取用户总数（管理员权限）
```bash
curl https://aideator.top/api/admin/users/count \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN"
```

#### 获取待审核评论数量（管理员权限）
```bash
curl https://aideator.top/api/admin/comments/pending/count \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN"
```

#### 获取最近文章（管理员权限）
```bash
curl https://aideator.top/api/admin/articles/recent \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN"
```

#### 获取用户列表（管理员权限）
```bash
curl "https://aideator.top/api/admin/users?page=1&limit=10" \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN"
```

#### 获取单个用户详情（管理员权限）
```bash
curl https://aideator.top/api/admin/users/USER_ID \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN"
```

#### 创建用户（管理员权限）
```bash
curl -X POST https://aideator.top/api/admin/users \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN" \
  -d '{"username":"newuser","email":"new@example.com","password":"password123","role":"user","membership_level":"basic","is_active":true}'
```

#### 更新用户信息（管理员权限）
```bash
curl -X PUT https://aideator.top/api/admin/users/USER_ID \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN" \
  -d '{"username":"updateduser","role":"admin","is_active":false}'
```

#### 删除用户（管理员权限）
```bash
curl -X DELETE https://aideator.top/api/admin/users/USER_ID \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN"
```

### 支付系统API

#### 创建支付订单（认证用户）
```bash
curl -X POST https://aideator.top/api/payment/create \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer USER_JWT_TOKEN" \
  -d '{"productName":"VIP会员","amount":"9.90","paymentMethod":"alipay","returnUrl":"http://localhost:8787/api/payment/return","notifyUrl":"http://localhost:8787/api/payment/notify"}'
```

#### 查询支付订单状态
```bash
curl https://aideator.top/api/payment/status/ORDER_ID
```

#### 获取支付订单详情（认证用户）
```bash
curl https://aideator.top/api/payment/order/ORDER_ID \
  -H "Authorization: Bearer USER_JWT_TOKEN"
```

#### 管理员获取支付订单列表（管理员权限）
```bash
curl "https://aideator.top/api/payment/admin/orders?page=1&limit=20&status=paid" \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN"
```

#### 管理员退款（管理员权限）
```bash
curl -X POST https://aideator.top/api/payment/refund/ORDER_ID \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ADMIN_JWT_TOKEN" \
  -d '{"refundAmount":"9.90","reason":"用户申请退款"}'
```

## 数据库初始化

首次运行时需要初始化数据库：

### 本地开发

```bash
wrangler d1 execute my-database --local --file=migrations/init.sql
```

### 生产环境

```bash
wrangler d1 execute my-database --remote --file=migrations/init.sql
```

## 配置说明

### wrangler.toml

确保以下配置正确：

```toml
# 数据库配置
[[d1_databases]]
binding = "DB"
database_name = "my-database"
database_id = "your-actual-database-id"

# R2 存储桶配置
[[r2_buckets]]
binding = "MY_BUCKET"
bucket_name = "my-bucket"

# 环境变量
[vars]
JWT_SECRET = "your-secure-jwt-secret"
```

## 故障排除

### 常见问题

1. **数据库连接失败**
   - 检查数据库 ID 是否正确
   - 确认数据库已创建

2. **JWT 认证失败**
   - 检查 JWT_SECRET 是否配置正确
   - 确认令牌未过期

3. **权限不足**
   - 确认用户角色具有相应权限
   - 检查 API 端点的权限要求

### 日志查看

```bash
# 查看本地开发日志
npm run dev

# 查看生产环境日志
wrangler tail
```

## 预设 API 输出格式

预设 API 现在返回特定格式的数据结构：

### 获取预设列表
```json
{
  "categories": {
    "cat-001": "人像",
    "cat-002": "风景",
    "cat-003": "动物"
  },
  "presets": [
    {
      "id": "preset-1",
      "title": "人像优化预设",
      "description": "专门用于优化人像照片的 ComfyUI 预设",
      "positive": "portrait, high quality, detailed face, sharp eyes",
      "negative": "deformed, mutated hands, bad anatomy",
      "image": "https://example.com/image.jpg",
      "visibility": "public",
      "preset_type": "standard",
      "view_count": 10,
      "favorite_count": 5,
      "use_count": 20,
      "created_at": 1757317493,
      "updated_at": 1757317493,
      "last_used_at": 1757343830
    }
  ],
  "current_category": "cat-001"
}
```

### 获取预设分类
```json
{
  "cat-001": "人像",
  "cat-002": "风景",
  "cat-003": "动物"
}