# 开发指南

## 项目结构

```
.
├── migrations/           # 数据库迁移文件
│   └── init.sql         # 初始数据库结构
├── src/                 # 源代码目录
│   ├── middleware/      # 中间件
│   │   └── auth.ts      # 认证中间件
│   ├── routes/          # 路由模块
│   │   ├── ads.ts       # 广告路由
│   │   ├── articles.ts  # 文章路由
│   │   ├── auth.ts      # 认证路由
│   │   ├── comments.ts  # 评论路由
│   │   ├── favorites.ts # 收藏路由
│   │   ├── guestbook.ts # 留言板路由
│   │   ├── images.ts    # 图像路由
│   │   ├── presets.ts   # 预设路由
│   │   ├── products.ts  # 产品路由
│   │   └── userlevels.ts# 用户级别路由
│   ├── types/           # TypeScript 类型定义
│   │   └── index.ts
│   └── index.ts         # 主应用入口
├── README.md            # 项目说明
├── package.json         # 依赖配置
├── tsconfig.json        # TypeScript 配置
└── wrangler.toml        # Wrangler 配置
```

## 环境设置

### 1. 安装 Wrangler CLI

```bash
npm install -g wrangler
```

### 2. 登录 Cloudflare

```bash
wrangler login
```

### 3. 创建数据库

```bash
wrangler d1 create my-database
```

记录输出中的数据库 ID，用于配置 wrangler.toml。

### 4. 创建 R2 存储桶

```bash
wrangler r2 bucket create my-bucket
```

### 5. 更新配置文件

在 `wrangler.toml` 中填入正确的数据库 ID 和 JWT 密钥：

```toml
name = "cloudflare-website"
compatibility_date = "2024-03-01"

[[d1_databases]]
binding = "DB"
database_name = "my-database"
database_id = "your-actual-database-id-here"

[[r2_buckets]]
binding = "MY_BUCKET"
bucket_name = "my-bucket"

[vars]
JWT_SECRET = "your-secure-jwt-secret-here"
```

## 本地开发

### 启动开发服务器

```bash
wrangler dev --assets ./public
```

这将在本地启动开发服务器，默认端口为 8787。

### 初始化数据库

首次运行需要初始化数据库结构：

```bash
wrangler d1 execute my-database --local --file=migrations/init.sql
```

## 部署

### 部署到 Cloudflare

```bash
wrangler deploy
```

### 远程数据库初始化

如果尚未初始化远程数据库：

```bash
wrangler d1 execute my-database --remote --file=migrations/init.sql
```

## 数据库管理

### 查看数据库表

```bash
wrangler d1 execute my-database --command "SELECT name FROM sqlite_master WHERE type='table';"
```

### 执行自定义 SQL

```bash
wrangler d1 execute my-database --command "YOUR SQL COMMAND HERE"
```

## API 测试

### 用户注册

```
curl -X POST http://localhost:8787/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"username":"testuser","email":"test@example.com","password":"password123"}'
```

### 用户登录

```
curl -X POST http://localhost:8787/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"testuser","password":"password123"}'
```

### 创建文章 (需要管理员权限)

```
curl -X POST http://localhost:8787/api/articles \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -d '{"title":"测试文章","content":"文章内容","category_id":1,"visibility":"public"}'
```

### 提交留言 (需要认证)

```
curl -X POST http://localhost:8787/api/guestbook \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -d '{"message":"这是一条测试留言"}'
```

## 代码规范

### TypeScript 类型

所有新功能都应包含适当的 TypeScript 类型定义。

### 错误处理

所有 API 端点都应包含适当的错误处理和 HTTP 状态码。

### 安全性

1. 始终使用参数化查询防止 SQL 注入
2. 实施适当的 CORS 策略
3. 使用强密码哈希算法 (Argon2)
4. 验证和清理所有用户输入

## 扩展功能

### 添加新路由

1. 在 `src/routes/` 目录下创建新路由文件
2. 在 `src/index.ts` 中导入并注册路由
3. 确保添加适当的中间件和权限检查

### 添加新数据库表

1. 更新 `migrations/init.sql` 文件
2. 在 `src/types/index.ts` 中添加相应的 TypeScript 类型
3. 创建相应的路由来管理新表的数据

## 故障排除

### 数据库连接问题

确保 `wrangler.toml` 中的数据库配置正确，并且数据库已创建。

### 权限错误

检查 JWT 令牌是否有效且未过期，确保用户具有执行操作所需的权限。

### 类型错误

确保所有 TypeScript 类型都正确导入和使用。

## 测试

### 运行测试

```
npm test
```

### 运行集成测试

```
npm run test:integration
```

## 监控

### 查看日志

```
wrangler tail
```