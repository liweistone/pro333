// 更新admin用户密码的脚本
async function hashPassword(password) {
  const encoder = new TextEncoder();
  const data = encoder.encode(password);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

export default {
  async fetch(request, env) {
    try {
      // 计算新密码哈希
      const newPassword = "admin";
      const newPasswordHash = await hashPassword(newPassword);
      
      console.log(`新密码 "${newPassword}" 的哈希值: ${newPasswordHash}`);
      
      // 更新数据库中的admin用户密码
      const result = await env.DB.prepare(
        "UPDATE Users SET password_hash = ? WHERE username = 'admin'"
      ).bind(newPasswordHash).run();
      
      if (result.success) {
        return new Response(JSON.stringify({
          success: true,
          message: 'Admin用户密码已更新',
          newPassword: newPassword,
          newPasswordHash: newPasswordHash
        }), {
          headers: { 'Content-Type': 'application/json' },
          status: 200
        });
      } else {
        return new Response(JSON.stringify({
          success: false,
          message: '更新密码失败'
        }), {
          headers: { 'Content-Type': 'application/json' },
          status: 500
        });
      }
    } catch (error) {
      console.error('更新密码时出错:', error);
      return new Response(JSON.stringify({
        success: false,
        message: '更新密码时出错: ' + error.message
      }), {
        headers: { 'Content-Type': 'application/json' },
        status: 500
      });
    }
  }
};