#!/usr/bin/env node

const { execSync } = require('child_process');
const fs = require('fs');

console.log('测试JWT功能...\n');

try {
  // 从wrangler.toml中读取JWT_SECRET
  console.log('1. 读取JWT_SECRET...');
  const wranglerConfig = fs.readFileSync('./wrangler.toml', 'utf8');
  const jwtSecretMatch = wranglerConfig.match(/JWT_SECRET = "([^"]+)"/);
  
  if (jwtSecretMatch && jwtSecretMatch[1]) {
    const jwtSecret = jwtSecretMatch[1];
    console.log('✅ 成功读取JWT_SECRET');
    console.log('   值长度:', jwtSecret.length, '字符');
    
    // 检查JWT_SECRET强度
    if (jwtSecret.length >= 32) {
      console.log('✅ JWT_SECRET长度符合安全要求');
    } else {
      console.warn('⚠️  JWT_SECRET长度不足32字符');
    }
    
    console.log('\n2. 验证Worker部署状态...');
    try {
      const deploymentsOutput = execSync('wrangler deployments list --json', { encoding: 'utf8' });
      const deployments = JSON.parse(deploymentsOutput);
      if (deployments && deployments.length > 0) {
        console.log('✅ Worker已成功部署');
        console.log('   最新版本:', deployments[0].id);
      } else {
        console.log('❌ 未找到部署的Worker版本');
      }
    } catch (error) {
      console.log('⚠️  无法获取部署信息:', error.message);
    }
    
    console.log('\n3. 验证环境变量绑定...');
    try {
      const versionOutput = execSync('wrangler versions view 5ea606de-5728-46ec-8e3a-2eeea2d4eff4', { encoding: 'utf8' });
      if (versionOutput.includes('JWT_SECRET')) {
        console.log('✅ JWT_SECRET已正确绑定到Worker');
      } else {
        console.log('❌ JWT_SECRET未绑定到Worker');
      }
    } catch (error) {
      console.log('⚠️  无法验证环境变量绑定:', error.message);
    }
    
    console.log('\n4. 测试建议:');
    console.log('   - 访问您的网站并尝试登录');
    console.log('   - 检查浏览器控制台是否有认证相关错误');
    console.log('   - 验证管理后台功能是否正常');
    
  } else {
    console.error('❌ 无法从wrangler.toml中找到JWT_SECRET');
  }
  
} catch (error) {
  console.error('测试过程中出现错误:', error.message);
}