// 测试预设分类API端点的脚本
async function testPresetsCategoriesAPI() {
  try {
    console.log('正在测试预设分类API端点...');
    
    // 测试1: 公开的分类列表接口
    console.log('\n🧪 测试1: 公开的分类列表接口 (/api/presets/categories/list)');
    try {
      const response = await fetch('/api/presets/categories/list');
      console.log('  状态码:', response.status);
      console.log('  状态文本:', response.statusText);
      
      if (response.ok) {
        const data = await response.json();
        console.log('  响应数据:', JSON.stringify(data, null, 2));
        console.log('  ✅ 分类列表接口正常');
      } else {
        const errorText = await response.text();
        console.log('  错误响应:', errorText);
        console.log('  ❌ 分类列表接口异常');
      }
    } catch (error) {
      console.log('  请求失败:', error.message);
      console.log('  ❌ 分类列表接口异常');
    }
    
    // 测试2: 健康检查接口
    console.log('\n🧪 测试2: 健康检查接口 (/health)');
    try {
      const response = await fetch('/health');
      console.log('  状态码:', response.status);
      
      if (response.ok) {
        const data = await response.json();
        console.log('  响应数据:', JSON.stringify(data, null, 2));
        console.log('  ✅ 健康检查接口正常');
      } else {
        console.log('  ❌ 健康检查接口异常');
      }
    } catch (error) {
      console.log('  请求失败:', error.message);
      console.log('  ❌ 健康检查接口异常');
    }
    
    // 测试3: 测试公开API端点
    console.log('\n🧪 测试3: 测试公开API端点 (/test-public)');
    try {
      const response = await fetch('/test-public');
      console.log('  状态码:', response.status);
      
      if (response.ok) {
        const data = await response.json();
        console.log('  响应数据:', JSON.stringify(data, null, 2));
        console.log('  ✅ 测试公开API端点正常');
      } else {
        console.log('  ❌ 测试公开API端点异常');
      }
    } catch (error) {
      console.log('  请求失败:', error.message);
      console.log('  ❌ 测试公开API端点异常');
    }
    
    console.log('\n🎉 API端点测试完成!');
  } catch (error) {
    console.error('测试过程中发生错误:', error);
  }
}

// 如果在浏览器环境中运行
if (typeof window !== 'undefined') {
  testPresetsCategoriesAPI();
}

// 如果在Node.js环境中运行
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { testPresetsCategoriesAPI };
}