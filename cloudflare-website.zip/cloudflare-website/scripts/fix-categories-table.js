// 修复categories表结构的脚本
async function fixCategoriesTable() {
  try {
    console.log('正在修复categories表结构...');
    
    // 检查是否需要添加description字段
    const checkDescriptionQuery = `
      SELECT COUNT(*) as count 
      FROM pragma_table_info('categories') 
      WHERE name = 'description';
    `;
    
    const descriptionResponse = await fetch('/api/debug/query', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ query: checkDescriptionQuery })
    });
    
    if (!descriptionResponse.ok) {
      console.error('检查description字段失败:', await descriptionResponse.text());
      return;
    }
    
    const descriptionResult = await descriptionResponse.json();
    const hasDescription = descriptionResult[0].count > 0;
    
    // 检查是否需要添加parent_id字段
    const checkParentIdQuery = `
      SELECT COUNT(*) as count 
      FROM pragma_table_info('categories') 
      WHERE name = 'parent_id';
    `;
    
    const parentIdResponse = await fetch('/api/debug/query', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ query: checkParentIdQuery })
    });
    
    if (!parentIdResponse.ok) {
      console.error('检查parent_id字段失败:', await parentIdResponse.text());
      return;
    }
    
    const parentIdResult = await parentIdResponse.json();
    const hasParentId = parentIdResult[0].count > 0;
    
    console.log('当前表结构:');
    console.log('- description字段存在:', hasDescription);
    console.log('- parent_id字段存在:', hasParentId);
    
    // 添加缺失的字段
    if (!hasDescription) {
      console.log('正在添加description字段...');
      const addDescriptionQuery = `
        ALTER TABLE categories ADD COLUMN description TEXT;
      `;
      
      const addDescriptionResponse = await fetch('/api/debug/query', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ query: addDescriptionQuery })
      });
      
      if (!addDescriptionResponse.ok) {
        console.error('添加description字段失败:', await addDescriptionResponse.text());
      } else {
        console.log('✅ description字段添加成功');
      }
    }
    
    if (!hasParentId) {
      console.log('正在添加parent_id字段...');
      const addParentIdQuery = `
        ALTER TABLE categories ADD COLUMN parent_id TEXT;
      `;
      
      const addParentIdResponse = await fetch('/api/debug/query', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ query: addParentIdQuery })
      });
      
      if (!addParentIdResponse.ok) {
        console.error('添加parent_id字段失败:', await addParentIdResponse.text());
      } else {
        console.log('✅ parent_id字段添加成功');
      }
    }
    
    // 更新现有记录的默认时间戳值
    console.log('正在更新现有记录的默认时间戳值...');
    const updateTimestampsQuery = `
      UPDATE categories SET created_at = strftime('%s', 'now') WHERE created_at IS NULL;
      UPDATE categories SET updated_at = strftime('%s', 'now') WHERE updated_at IS NULL;
    `;
    
    const updateTimestampsResponse = await fetch('/api/debug/query', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ query: updateTimestampsQuery })
    });
    
    if (!updateTimestampsResponse.ok) {
      console.error('更新时间戳失败:', await updateTimestampsResponse.text());
    } else {
      console.log('✅ 时间戳更新成功');
    }
    
    console.log('categories表结构修复完成!');
  } catch (error) {
    console.error('修复过程中发生错误:', error);
  }
}

// 如果在浏览器环境中运行
if (typeof window !== 'undefined') {
  fixCategoriesTable();
}

// 如果在Node.js环境中运行
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { fixCategoriesTable };
}