#!/usr/bin/env node

const { execSync } = require('child_process');
const fs = require('fs');

console.log('开始部署 Cloudflare 无服务器网站...\n');

try {
  // 1. 检查 wrangler 是否已安装
  console.log('1. 检查 wrangler...');
  execSync('wrangler --version', { stdio: 'inherit' });
  
  // 2. 检查 package.json
  console.log('\n2. 检查依赖...');
  if (!fs.existsSync('./package.json')) {
    throw new Error('找不到 package.json 文件');
  }
  
  // 3. 安装依赖
  console.log('\n3. 安装依赖...');
  execSync('npm install', { stdio: 'inherit' });
  
  // 4. 检查配置文件
  console.log('\n4. 检查配置文件...');
  if (!fs.existsSync('./wrangler.toml')) {
    throw new Error('找不到 wrangler.toml 配置文件');
  }
  
  const config = fs.readFileSync('./wrangler.toml', 'utf8');
  if (config.includes('your-database-id-here') || config.includes('your-jwt-secret-here')) {
    console.warn('警告: 请确保 wrangler.toml 中的配置已正确更新');
  }
  
  // 5. 构建项目
  console.log('\n5. 构建项目...');
  execSync('npm run build', { stdio: 'inherit' });
  
  // 6. 部署到 Cloudflare，包含静态资源
  console.log('\n6. 部署到 Cloudflare...');
  execSync('wrangler deploy --assets ./public', { stdio: 'inherit' });
  
  console.log('\n✅ 部署完成！');
  console.log('\n💡 下一步:');
  console.log('1. 如果是首次部署，请初始化远程数据库:');
  console.log('   wrangler d1 execute my-database --remote --file=migrations/init.sql');
  console.log('2. 访问您的网站 URL 进行测试');
  
} catch (error) {
  console.error('\n❌ 部署失败:', error.message);
  process.exit(1);
}