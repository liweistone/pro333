// 验证数据库结构并应用迁移的脚本
async function verifyAndMigrateDatabase() {
  try {
    console.log('开始验证数据库结构...');
    
    // 1. 检查评论表结构
    console.log('正在检查评论表结构...');
    const schemaResponse = await fetch('/api/debug/comments/schema');
    
    if (!schemaResponse.ok) {
      console.error('检查表结构失败:', await schemaResponse.text());
      return;
    }
    
    const schema = await schemaResponse.json();
    console.log('当前评论表结构:', schema);
    
    // 检查是否已存在reviewed_at列
    const hasReviewedAtColumn = schema.some(column => column.name === 'reviewed_at');
    console.log('是否存在reviewed_at列:', hasReviewedAtColumn);
    
    if (!hasReviewedAtColumn) {
      console.log('reviewed_at列不存在，正在尝试添加...');
      
      // 2. 添加reviewed_at列
      const addColumnResponse = await fetch('/api/debug/add-reviewed-at', {
        method: 'POST'
      });
      
      if (!addColumnResponse.ok) {
        console.error('添加列失败:', await addColumnResponse.text());
        return;
      }
      
      const result = await addColumnResponse.json();
      console.log('添加列结果:', result);
      
      // 再次检查表结构
      const newSchemaResponse = await fetch('/api/debug/comments/schema');
      if (newSchemaResponse.ok) {
        const newSchema = await newSchemaResponse.json();
        console.log('更新后的评论表结构:', newSchema);
      }
    } else {
      console.log('reviewed_at列已存在，无需添加');
    }
    
    console.log('数据库结构验证和迁移完成！');
    
  } catch (error) {
    console.error('验证和迁移过程中出现错误:', error);
  }
}

// 运行验证和迁移脚本
verifyAndMigrateDatabase();