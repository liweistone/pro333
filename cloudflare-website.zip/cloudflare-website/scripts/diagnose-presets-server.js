// 服务器端预设管理诊断脚本
async function diagnosePresetsServer() {
  console.log('开始服务器端预设管理诊断...');
  
  try {
    // 检查环境变量
    console.log('\n1. 检查环境变量...');
    console.log('  JWT_SECRET存在:', typeof process.env.JWT_SECRET !== 'undefined');
    console.log('  DB连接存在:', typeof process.env.DB !== 'undefined');
    
    // 检查路由注册
    console.log('\n2. 检查路由注册...');
    // 这里我们只能检查文件是否存在
    const fs = require('fs');
    const path = require('path');
    
    const routesPath = path.join(__dirname, '..', 'src', 'routes', 'presets.ts');
    if (fs.existsSync(routesPath)) {
      console.log('✓ 预设路由文件存在');
    } else {
      console.log('✗ 预设路由文件不存在');
    }
    
    // 检查中间件
    console.log('\n3. 检查中间件...');
    const authPath = path.join(__dirname, '..', 'src', 'middleware', 'auth.ts');
    if (fs.existsSync(authPath)) {
      console.log('✓ 认证中间件文件存在');
    } else {
      console.log('✗ 认证中间件文件不存在');
    }
    
    // 检查数据库表
    console.log('\n4. 检查数据库表...');
    // 注意：在实际的Cloudflare Workers环境中，我们无法直接访问数据库进行检查
    console.log('  无法在脚本中直接检查数据库表，请手动验证表是否存在');
    
    console.log('\n🎉 服务器端诊断完成。');
  } catch (error) {
    console.error('诊断过程中发生错误:', error);
  }
}

// 运行诊断
diagnosePresetsServer();