#!/usr/bin/env node

const fs = require('fs');
const { execSync } = require('child_process');

console.log('Cloudflare 无服务器网站设置脚本\n');

// 检查是否已安装 Wrangler
try {
  execSync('wrangler --version', { stdio: 'ignore' });
  console.log('✓ Wrangler 已安装');
} catch (error) {
  console.log('✗ 未找到 Wrangler，正在安装...');
  try {
    execSync('npm install -g wrangler', { stdio: 'inherit' });
    console.log('✓ Wrangler 安装成功');
  } catch (installError) {
    console.error('✗ Wrangler 安装失败:', installError.message);
    process.exit(1);
  }
}

// 检查 wrangler.toml 配置文件
if (!fs.existsSync('./wrangler.toml')) {
  console.log('✗ 未找到 wrangler.toml 配置文件');
  process.exit(1);
}

const config = fs.readFileSync('./wrangler.toml', 'utf8');

// 检查配置文件中的占位符
const checks = [
  { placeholder: 'your-database-id-here', message: '数据库 ID' },
  { placeholder: 'your-jwt-secret-here', message: 'JWT 密钥' }
];

let configValid = true;
checks.forEach(check => {
  if (config.includes(check.placeholder)) {
    console.log(`✗ 请配置 ${check.message} 在 wrangler.toml 中`);
    configValid = false;
  }
});

if (!configValid) {
  console.log('\n请按以下步骤操作:');
  console.log('1. 登录 Cloudflare: wrangler login');
  console.log('2. 创建数据库: wrangler d1 create my-database');
  console.log('3. 创建 R2 存储桶: wrangler r2 bucket create my-bucket');
  console.log('4. 更新 wrangler.toml 中的配置信息');
  process.exit(1);
}

console.log('✓ 配置文件检查通过');

// 检查依赖
console.log('\n检查项目依赖...');
try {
  execSync('npm install', { stdio: 'inherit' });
  console.log('✓ 依赖安装完成');
} catch (error) {
  console.error('✗ 依赖安装失败:', error.message);
  process.exit(1);
}

// 编译项目
console.log('\n编译 TypeScript 代码...');
try {
  execSync('npm run build', { stdio: 'inherit' });
  console.log('✓ 代码编译完成');
} catch (error) {
  console.error('✗ 代码编译失败:', error.message);
  process.exit(1);
}

console.log('\n🎉 设置完成！您可以执行以下操作:');
console.log('- 本地开发: npm run dev');
console.log('- 部署到 Cloudflare: npm run deploy');