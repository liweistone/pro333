#!/usr/bin/env node

const fs = require('fs');

console.log('检查生产环境中的JWT_SECRET配置...\n');

try {
  // 检查本地JWT_SECRET（开发环境）
  console.log('1. 检查wrangler.toml中的JWT_SECRET配置...');
  if (fs.existsSync('./wrangler.toml')) {
    const config = fs.readFileSync('./wrangler.toml', 'utf8');
    if (config.includes('JWT_SECRET')) {
      console.log('✅ wrangler.toml中包含JWT_SECRET配置');
    } else {
      console.log('❌ wrangler.toml中未找到JWT_SECRET配置');
    }
  } else {
    console.log('❌ 找不到wrangler.toml文件');
  }
  
  // 检查生产环境JWT_SECRET（通过wrangler secret）
  console.log('\n2. 生产环境JWT_SECRET说明:');
  console.log('   生产环境中的JWT_SECRET应通过以下命令设置:');
  console.log('   wrangler secret put JWT_SECRET');
  console.log('   输入一个至少32字符的随机字符串作为密钥');
  
  console.log('\n3. 部署前建议:');
  console.log('   - 确保生产环境已通过wrangler secret put JWT_SECRET命令设置密钥');
  console.log('   - 开发环境中的JWT_SECRET仅用于本地测试');
  
} catch (error) {
  console.error('检查过程中出现错误:', error.message);
}