const fs = require('fs');

// 生成随机字符串
function randomString(length) {
  const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

// 生成测试预设数据
function generatePresetData(index) {
  const categories = ['风景', '人物', '动物', '建筑', '抽象'];
  const visibilities = ['public', 'authenticated', 'private'];
  
  return {
    title: `测试预设 ${index}`,
    category_id: Math.floor(Math.random() * categories.length) + 1, // 假设有5个分类
    description: `这是第${index}个测试预设的描述信息`,
    positive: `positive prompt for test preset ${index}, detailed description of the desired image`,
    negative: `negative prompt for test preset ${index}, things to avoid in the image`,
    image: null,
    visibility: visibilities[Math.floor(Math.random() * visibilities.length)]
  };
}

// 生成SQL插入语句
function generateSQL() {
  let sql = '';
  
  for (let i = 1; i <= 20; i++) {
    const preset = generatePresetData(i);
    const id = randomString(16);
    const createdAt = Math.floor(Date.now() / 1000) - Math.floor(Math.random() * 3600 * 24 * 30); // 随机创建时间（过去30天内）
    
    sql += `INSERT INTO presets (id, title, category_id, description, positive, negative, image, visibility, created_at, updated_at, use_count, view_count, favorite_count) VALUES ('${id}', '${preset.title}', ${preset.category_id}, '${preset.description}', '${preset.positive}', '${preset.negative}', ${preset.image ? `'${preset.image}'` : 'NULL'}, '${preset.visibility}', ${createdAt}, ${createdAt}, 0, 0, 0);\n`;
  }
  
  return sql;
}

// 生成分类数据（如果需要）
function generateCategorySQL() {
  const categories = ['风景', '人物', '动物', '建筑', '抽象'];
  let sql = '';
  
  for (let i = 0; i < categories.length; i++) {
    const id = i + 1;
    sql += `INSERT OR IGNORE INTO categories (id, name, description) VALUES (${id}, '${categories[i]}', '${categories[i]}分类描述');\n`;
  }
  
  return sql;
}

// 主函数
function main() {
  // 生成分类数据
  const categorySQL = generateCategorySQL();
  
  // 生成预设数据
  const presetSQL = generateSQL();
  
  // 写入文件
  const outputFile = 'test-presets.sql';
  const content = `-- 测试分类数据\n${categorySQL}\n-- 测试预设数据\n${presetSQL}`;
  
  fs.writeFileSync(outputFile, content);
  
  console.log(`已生成测试数据文件: ${outputFile}`);
  console.log('您可以使用以下命令将数据导入数据库:');
  console.log('npx wrangler d1 execute my-database --file=test-presets.sql');
}

main();