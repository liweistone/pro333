// 脚本用于检查数据库中的数据
// 注意：这个脚本只能在Cloudflare Workers环境中运行

export default {
  async fetch(request, env) {
    try {
      // 检查用户表
      const userResults = await env.DB.prepare(
        'SELECT COUNT(*) as count FROM Users'
      ).first();
      
      // 检查文章表
      const articleResults = await env.DB.prepare(
        'SELECT COUNT(*) as count FROM Articles'
      ).first();
      
      // 检查产品表
      const productResults = await env.DB.prepare(
        'SELECT COUNT(*) as count FROM Products'
      ).first();
      
      // 检查预设表
      const presetResults = await env.DB.prepare(
        'SELECT COUNT(*) as count FROM presets'
      ).first();
      
      return new Response(JSON.stringify({
        users: userResults.count,
        articles: articleResults.count,
        products: productResults.count,
        presets: presetResults.count
      }, null, 2), {
        headers: { 'Content-Type': 'application/json' }
      });
    } catch (error) {
      return new Response(JSON.stringify({ error: error.message }, null, 2), {
        headers: { 'Content-Type': 'application/json' },
        status: 500
      });
    }
  }
};