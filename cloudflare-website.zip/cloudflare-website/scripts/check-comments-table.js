// 检查评论表结构的脚本
async function checkCommentsTable() {
  try {
    // 这个脚本需要在Cloudflare Workers环境中运行
    // 我们将创建一个简单的脚本来检查表结构
    console.log('检查评论表结构...');
    
    // 由于我们无法直接在本地环境中访问D1数据库，
    // 我们需要创建一个API端点来检查表结构
    
    // 创建一个临时的API端点代码片段
    const checkSchemaCode = `
      export default {
        async fetch(request, env) {
          try {
            const { results } = await env.DB.prepare(
              "PRAGMA table_info(Comments)"
            ).all();
            
            return new Response(JSON.stringify(results, null, 2), {
              headers: { 'Content-Type': 'application/json' }
            });
          } catch (error) {
            return new Response(JSON.stringify({ error: error.message }, null, 2), {
              headers: { 'Content-Type': 'application/json' },
              status: 500
            });
          }
        }
      };
    `;
    
    console.log('请将以下代码添加到您的Cloudflare Worker中以检查评论表结构:');
    console.log(checkSchemaCode);
    
    // 同时，让我们创建一个更新表结构的迁移脚本
    const migrationCode = `
      export default {
        async fetch(request, env) {
          try {
            // 尝试添加reviewed_at列
            await env.DB.prepare(
              "ALTER TABLE Comments ADD COLUMN reviewed_at DATETIME"
            ).run();
            
            return new Response(JSON.stringify({ 
              success: true, 
              message: '成功添加reviewed_at列' 
            }, null, 2), {
              headers: { 'Content-Type': 'application/json' }
            });
          } catch (error) {
            // 如果列已存在，会抛出错误
            if (error.message.includes('duplicate column name')) {
              return new Response(JSON.stringify({ 
                success: true, 
                message: 'reviewed_at列已存在' 
              }, null, 2), {
                headers: { 'Content-Type': 'application/json' }
              });
            }
            
            return new Response(JSON.stringify({ 
              success: false, 
              error: error.message 
            }, null, 2), {
              headers: { 'Content-Type': 'application/json' },
              status: 500
            });
          }
        }
      };
    `;
    
    console.log('\n请将以下代码添加到您的Cloudflare Worker中以更新表结构:');
    console.log(migrationCode);
    
  } catch (error) {
    console.error('检查表结构时出错:', error);
  }
}

checkCommentsTable();