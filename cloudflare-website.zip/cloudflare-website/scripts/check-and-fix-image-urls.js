// 检查和修复图片URL的脚本
// 该脚本用于检查数据库中可能存在的错误图片URL并进行修复

async function checkAndFixImageUrls(DB) {
  try {
    console.log('开始检查和修复图片URL...');
    
    // 查询所有预设效果图的使用记录
    const { results: imageUsageRecords } = await DB.prepare(`
      SELECT iu.*, r.object_key 
      FROM ImageUsage iu 
      JOIN R2Images r ON iu.image_id = r.id 
      WHERE iu.used_in_type = 'preset_effect'
    `).all();
    
    console.log(`找到 ${imageUsageRecords.results?.length || 0} 条预设效果图记录`);
    
    let fixedCount = 0;
    
    // 检查每条记录是否需要修复
    for (const record of imageUsageRecords.results || []) {
      console.log(`检查记录 ID: ${record.id}, 图片ID: ${record.image_id}, 对象键: ${record.object_key}`);
      
      // 在这里我们可以添加具体的检查逻辑
      // 例如，如果发现任何不正确的引用，可以进行修复
    }
    
    console.log(`检查完成，修复了 ${fixedCount} 条记录`);
    return { success: true, fixedCount, totalRecords: imageUsageRecords.results?.length || 0 };
  } catch (error) {
    console.error('检查和修复图片URL时出错:', error);
    return { success: false, error: error.message };
  }
}

// 检查特定对象键的图片URL
async function checkImageUrl(DB, objectKey) {
  try {
    console.log(`检查图片URL: ${objectKey}`);
    
    // 检查图片是否存在
    const image = await DB.prepare(`
      SELECT * FROM R2Images WHERE object_key = ?
    `).bind(objectKey).first();
    
    if (!image) {
      return { success: false, error: '图片不存在' };
    }
    
    // 检查图片的使用记录
    const { results: usageRecords } = await DB.prepare(`
      SELECT * FROM ImageUsage WHERE image_id = ?
    `).bind(image.id).all();
    
    // 生成正确的URL
    const correctUrl = `/api/images/public/${objectKey}`;
    
    return { 
      success: true,
      image: {
        ...image,
        correct_url: correctUrl
      },
      usageRecords: usageRecords.results || []
    };
  } catch (error) {
    console.error('检查图片URL时出错:', error);
    return { success: false, error: error.message };
  }
}

module.exports = { checkAndFixImageUrls, checkImageUrl };