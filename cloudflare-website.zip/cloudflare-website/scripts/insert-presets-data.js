// 插入预设数据的脚本
const fs = require('fs');
const path = require('path');

// 读取SQL文件
const sqlFilePath = path.join(__dirname, '..', 'insert-presets-data.sql');
const sqlContent = fs.readFileSync(sqlFilePath, 'utf8');

console.log('SQL文件内容:');
console.log(sqlContent);

console.log('\\n请手动执行以下SQL语句来插入预设数据:');
console.log('1. 打开数据库客户端');
console.log('2. 连接到 db.sqlite 数据库');
console.log('3. 执行以下SQL语句:');

// 分割SQL语句并打印
const statements = sqlContent.split(';').filter(stmt => stmt.trim() !== '');
statements.forEach((stmt, index) => {
  console.log(`\\n语句 ${index + 1}:`);
  console.log(stmt.trim() + ';');
});