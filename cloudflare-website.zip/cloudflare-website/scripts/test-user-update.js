#!/usr/bin/env node

const fs = require('fs');

console.log('测试用户更新请求...\n');

try {
  // 1. 检查管理后台用户更新API
  console.log('1. 检查管理后台用户更新API...');
  const adminRoutesPath = './src/routes/admin.ts';
  if (fs.existsSync(adminRoutesPath)) {
    const adminRoutes = fs.readFileSync(adminRoutesPath, 'utf8');
    
    // 查找用户更新API定义
    const updateUserApi = adminRoutes.match(/adminRouter\.put\('\/users\/:id'[^}]+\}/s);
    if (updateUserApi && updateUserApi[0]) {
      console.log('✅ 找到用户更新API定义');
      
      // 检查是否使用了正确的中间件
      if (updateUserApi[0].includes('authMiddleware') && updateUserApi[0].includes('requireAdmin')) {
        console.log('✅ 用户更新API正确使用了认证和权限中间件');
      } else {
        console.log('❌ 用户更新API未正确使用认证和权限中间件');
      }
      
      // 检查是否正确处理请求体
      if (updateUserApi[0].includes('c.req.json()')) {
        console.log('✅ 用户更新API正确处理请求体');
      } else {
        console.log('❌ 用户更新API未正确处理请求体');
      }
    } else {
      console.log('❌ 未找到用户更新API定义');
    }
  } else {
    console.log('❌ 管理后台路由文件不存在');
  }
  
  // 2. 检查前端用户更新请求
  console.log('\n2. 检查前端用户更新请求...');
  const usersHtmlPath = './public/admin/users.html';
  if (fs.existsSync(usersHtmlPath)) {
    const usersHtml = fs.readFileSync(usersHtmlPath, 'utf8');
    
    // 查找保存用户函数
    const saveUserFunction = usersHtml.match(/async function saveUser\(\)[\s\S]*?\}/);
    if (saveUserFunction && saveUserFunction[0]) {
      console.log('✅ 找到保存用户函数');
      
      // 检查API路径
      if (saveUserFunction[0].includes('/api/admin/users/')) {
        console.log('✅ 保存用户函数使用了正确的API路径');
      } else {
        console.log('❌ 保存用户函数未使用正确的API路径');
      }
      
      // 检查请求方法
      if (saveUserFunction[0].includes('PUT')) {
        console.log('✅ 保存用户函数使用了PUT方法');
      } else {
        console.log('❌ 保存用户函数未使用PUT方法');
      }
      
      // 检查请求体
      if (saveUserFunction[0].includes('JSON.stringify')) {
        console.log('✅ 保存用户函数正确序列化请求体');
      } else {
        console.log('❌ 保存用户函数未正确序列化请求体');
      }
    } else {
      console.log('❌ 未找到保存用户函数');
    }
  } else {
    console.log('❌ 用户管理页面文件不存在');
  }
  
  // 3. 检查认证中间件日志
  console.log('\n3. 检查认证中间件日志...');
  const authMiddlewarePath = './src/middleware/auth.ts';
  if (fs.existsSync(authMiddlewarePath)) {
    const authMiddleware = fs.readFileSync(authMiddlewarePath, 'utf8');
    
    // 检查是否有足够的日志输出
    const logStatements = (authMiddleware.match(/console\.log/g) || []).length;
    if (logStatements >= 5) {
      console.log('✅ 认证中间件包含足够的日志输出');
    } else {
      console.log('⚠️  认证中间件日志输出较少，建议增加调试信息');
    }
  }
  
  console.log('\n✅ 用户更新请求测试完成!');
  console.log('\n建议:');
  console.log('1. 检查浏览器控制台中的日志输出');
  console.log('2. 确认认证中间件是否正确处理了请求');
  console.log('3. 验证用户是否有管理员权限');
  
} catch (error) {
  console.error('测试过程中出现错误:', error.message);
}