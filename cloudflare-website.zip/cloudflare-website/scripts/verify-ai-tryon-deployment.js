#!/usr/bin/env node

const https = require('https');

console.log('开始验证 AI 试衣功能部署...\n');

// 测试 URL
const testUrls = [
  {
    name: 'AI试衣页面',
    url: 'https://aideator.top/ai-tryon',
    expectedStatus: 200
  },
  {
    name: 'AI试衣API创建端点',
    url: 'https://aideator.top/api/ai-tryon/create',
    expectedStatus: 401 // 未认证状态，因为需要JWT令牌
  },
  {
    name: 'AI试衣API状态查询端点',
    url: 'https://aideator.top/api/ai-tryon/status/test-task-id',
    expectedStatus: 401 // 未认证状态，因为需要JWT令牌
  }
];

async function testUrl(urlInfo) {
  return new Promise((resolve) => {
    console.log(`测试 ${urlInfo.name}...`);
    
    const url = new URL(urlInfo.url);
    const options = {
      hostname: url.hostname,
      port: 443,
      path: url.pathname,
      method: 'GET',
      headers: {
        'User-Agent': 'Deployment-Verification-Script/1.0'
      }
    };
    
    const req = https.request(options, (res) => {
      console.log(`  状态码: ${res.statusCode}`);
      
      if (res.statusCode === urlInfo.expectedStatus) {
        console.log(`  ✅ ${urlInfo.name} 测试通过\n`);
        resolve(true);
      } else {
        console.log(`  ❌ ${urlInfo.name} 测试失败 (期望状态: ${urlInfo.expectedStatus})\n`);
        resolve(false);
      }
      
      // 消费响应数据以释放内存
      res.on('data', () => {});
    });
    
    req.on('error', (error) => {
      console.log(`  ❌ ${urlInfo.name} 请求失败: ${error.message}\n`);
      resolve(false);
    });
    
    req.end();
  });
}

async function verifyDeployment() {
  console.log('🔍 验证部署...\n');
  
  let allPassed = true;
  
  for (const urlInfo of testUrls) {
    const passed = await testUrl(urlInfo);
    if (!passed) {
      allPassed = false;
    }
  }
  
  console.log('📋 验证结果:');
  if (allPassed) {
    console.log('✅ 所有测试通过！AI试衣功能已成功部署。\n');
    console.log('💡 下一步:');
    console.log('1. 访问 https://aideator.top/ai-tryon 测试页面');
    console.log('2. 确保R2存储桶中有测试图片');
    console.log('3. 验证阿里云API密钥是否有效');
  } else {
    console.log('❌ 部分测试失败，请检查部署配置。');
  }
}

// 执行验证
verifyDeployment().catch(console.error);