// Cloudflare Workers数据库迁移脚本
// 这个脚本可以通过wrangler命令执行：npx wrangler d1 execute cloudflare-website-db --file=./migrations/add_reviewed_at_column.sql

export default {
  async fetch(request, env) {
    try {
      // 检查是否已存在reviewed_at列
      const schema = await env.DB.prepare("PRAGMA table_info(Comments)").all();
      const hasReviewedAtColumn = schema.results.some((column) => column.name === 'reviewed_at');
      
      if (hasReviewedAtColumn) {
        return new Response(JSON.stringify({ 
          success: true, 
          message: 'reviewed_at列已存在，无需迁移' 
        }), {
          headers: { 'Content-Type': 'application/json' }
        });
      }
      
      // 添加reviewed_at列
      await env.DB.prepare(
        "ALTER TABLE Comments ADD COLUMN reviewed_at DATETIME"
      ).run();
      
      return new Response(JSON.stringify({ 
        success: true, 
        message: '成功添加reviewed_at列' 
      }), {
        headers: { 'Content-Type': 'application/json' }
      });
    } catch (error) {
      // 如果列已存在，会抛出错误
      if (error.message && error.message.includes('duplicate column name')) {
        return new Response(JSON.stringify({ 
          success: true, 
          message: 'reviewed_at列已存在' 
        }), {
          headers: { 'Content-Type': 'application/json' }
        });
      }
      
      return new Response(JSON.stringify({ 
        success: false, 
        error: error.message 
      }), {
        headers: { 'Content-Type': 'application/json' },
        status: 500
      });
    }
  }
};