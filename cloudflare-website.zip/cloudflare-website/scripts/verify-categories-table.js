// 验证categories表结构的脚本
async function verifyCategoriesTable() {
  try {
    // 这个脚本需要在Worker环境中运行
    console.log('正在验证categories表结构...');
    
    // 检查表结构
    const query = `
      PRAGMA table_info(categories);
    `;
    
    const response = await fetch('/api/debug/query', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ query })
    });
    
    if (!response.ok) {
      console.error('查询失败:', response.status, await response.text());
      return;
    }
    
    const result = await response.json();
    console.log('categories表结构:');
    console.table(result);
    
    // 检查是否有description和parent_id字段
    const hasDescription = result.some(col => col.name === 'description');
    const hasParentId = result.some(col => col.name === 'parent_id');
    
    console.log('表结构检查结果:');
    console.log('- description字段存在:', hasDescription);
    console.log('- parent_id字段存在:', hasParentId);
    
    if (hasDescription && hasParentId) {
      console.log('✅ categories表结构完整');
    } else {
      console.log('❌ categories表结构不完整，需要执行迁移脚本');
    }
  } catch (error) {
    console.error('验证过程中发生错误:', error);
  }
}

// 如果在浏览器环境中运行
if (typeof window !== 'undefined') {
  verifyCategoriesTable();
}

// 如果在Node.js环境中运行
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { verifyCategoriesTable };
}