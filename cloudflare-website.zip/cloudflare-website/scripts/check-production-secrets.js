#!/usr/bin/env node

const { execSync } = require('child_process');

console.log('检查生产环境密钥设置...\n');

try {
  console.log('1. 列出所有生产环境密钥...');
  const secretsOutput = execSync('wrangler secret list', { encoding: 'utf8' });
  console.log(secretsOutput);
  
  // 检查是否包含JWT_SECRET
  if (secretsOutput.includes('JWT_SECRET')) {
    console.log('✅ 生产环境中已设置JWT_SECRET');
  } else {
    console.log('❌ 生产环境中未找到JWT_SECRET');
    console.log('   请运行以下命令设置:');
    console.log('   wrangler secret put JWT_SECRET');
  }
  
  console.log('\n2. 验证Wrangler配置...');
  try {
    const whoamiOutput = execSync('wrangler whoami', { encoding: 'utf8' });
    console.log('✅ Wrangler已正确配置');
    console.log(whoamiOutput);
  } catch (error) {
    console.log('❌ Wrangler配置有问题:', error.message);
  }
  
} catch (error) {
  console.error('检查过程中出现错误:', error.message);
  console.log('\n可能的原因:');
  console.log('- 未安装Wrangler');
  console.log('- 未登录Cloudflare账户');
  console.log('- 当前目录不是Cloudflare Worker项目目录');
  
  console.log('\n解决方法:');
  console.log('1. 确保已安装Wrangler: npm install -g wrangler');
  console.log('2. 登录Cloudflare账户: wrangler login');
  console.log('3. 在项目根目录运行此脚本');
}