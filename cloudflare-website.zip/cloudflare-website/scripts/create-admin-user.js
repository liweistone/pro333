#!/usr/bin/env node

// 脚本用于创建管理员用户
const fs = require('fs');
const { execSync } = require('child_process');

console.log('创建管理员用户脚本\n');

// 检查是否已安装 wrangler
try {
  execSync('wrangler --version', { stdio: 'ignore' });
  console.log('✓ Wrangler 已安装');
} catch (error) {
  console.log('✗ 未找到 Wrangler，请先安装: npm install -g wrangler');
  process.exit(1);
}

// 管理员用户信息
const adminUser = {
  username: 'admin',
  email: 'admin@example.com',
  password: 'admin123'
};

console.log('正在创建管理员用户...');
console.log('用户名:', adminUser.username);
console.log('邮箱:', adminUser.email);
console.log('密码:', adminUser.password);
console.log('\n注意：请在生产环境中修改默认密码！\n');

// 使用 wrangler 向本地开发服务器发送请求来创建管理员用户
try {
  // 启动开发服务器（如果尚未运行）
  console.log('启动开发服务器...');
  
  // 创建用户
  console.log('注册管理员用户...');
  const registerCommand = `curl -X POST http://127.0.0.1:8787/api/auth/register \\
    -H "Content-Type: application/json" \\
    -d '{"username":"${adminUser.username}","email":"${adminUser.email}","password":"${adminUser.password}"}'`;
  
  console.log('执行命令:', registerCommand);
  const registerResult = execSync(registerCommand, { stdio: 'pipe' });
  console.log('注册结果:', registerResult.toString());
  
  // 更新用户角色为管理员
  console.log('更新用户角色为管理员...');
  // 首先需要登录获取token
  const loginCommand = `curl -X POST http://127.0.0.1:8787/api/auth/login \\
    -H "Content-Type: application/json" \\
    -d '{"username":"${adminUser.username}","password":"${adminUser.password}"}'`;
  
  console.log('执行命令:', loginCommand);
  const loginResult = execSync(loginCommand, { stdio: 'pipe' });
  const loginData = JSON.parse(loginResult.toString());
  console.log('登录结果:', loginData);
  
  if (loginData.token) {
    // 获取用户列表以找到新创建的用户ID
    const usersCommand = `curl -X GET http://127.0.0.1:8787/api/auth/users \\
      -H "Authorization: Bearer ${loginData.token}"`;
    
    console.log('执行命令:', usersCommand);
    const usersResult = execSync(usersCommand, { stdio: 'pipe' });
    const usersData = JSON.parse(usersResult.toString());
    console.log('用户列表:', usersData);
    
    if (usersData && usersData.length > 0) {
      const adminUserId = usersData[0].id; // 假设第一个用户就是我们刚创建的
      console.log('管理员用户ID:', adminUserId);
      
      // 更新用户角色为管理员 (需要superadmin权限，这里简化处理)
      // 在实际应用中，可能需要手动更新数据库
      console.log('请手动将用户角色更新为admin或superadmin');
    }
  }
  
  console.log('\n🎉 管理员用户创建完成！');
  console.log('请使用以下凭据登录管理后台:');
  console.log('用户名:', adminUser.username);
  console.log('密码:', adminUser.password);
  console.log('\n注意：请在首次登录后立即修改默认密码！');
  
} catch (error) {
  console.error('✗ 创建管理员用户失败:', error.message);
  
  // 提示手动创建
  console.log('\n请手动执行以下步骤:');
  console.log('1. 启动开发服务器: npm run dev');
  console.log('2. 访问 http://127.0.0.1:8787/admin/login.html');
  console.log('3. 注册新用户');
  console.log('4. 使用数据库工具将用户角色更新为admin');
  
  process.exit(1);
}