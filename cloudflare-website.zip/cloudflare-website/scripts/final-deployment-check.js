#!/usr/bin/env node

const { execSync } = require('child_process');
const fs = require('fs');

console.log('🚀 Cloudflare Worker 部署最终检查\n');

try {
  console.log('🔍 1. 检查项目配置...');
  // 检查wrangler.toml
  if (fs.existsSync('./wrangler.toml')) {
    console.log('   ✅ wrangler.toml 文件存在');
  } else {
    console.log('   ❌ wrangler.toml 文件不存在');
    process.exit(1);
  }
  
  console.log('\n🔍 2. 检查环境变量...');
  const wranglerConfig = fs.readFileSync('./wrangler.toml', 'utf8');
  
  // 检查JWT_SECRET
  const jwtSecretMatch = wranglerConfig.match(/JWT_SECRET = "([^"]+)"/);
  if (jwtSecretMatch && jwtSecretMatch[1]) {
    const jwtSecret = jwtSecretMatch[1];
    console.log('   ✅ JWT_SECRET 已配置');
    console.log('      长度:', jwtSecret.length, '字符');
    if (jwtSecret.length >= 32) {
      console.log('      安全性: 符合要求');
    } else {
      console.log('      安全性: 建议使用至少32字符的密钥');
    }
  } else {
    console.log('   ❌ JWT_SECRET 未配置');
  }
  
  // 检查数据库配置
  if (wranglerConfig.includes('d1_databases')) {
    console.log('   ✅ D1 数据库已配置');
  } else {
    console.log('   ❌ D1 数据库未配置');
  }
  
  // 检查R2存储桶配置
  if (wranglerConfig.includes('r2_buckets')) {
    console.log('   ✅ R2 存储桶已配置');
  } else {
    console.log('   ❌ R2 存储桶未配置');
  }
  
  console.log('\n🔍 3. 检查认证系统...');
  // 检查认证路由
  if (fs.existsSync('./src/routes/auth.ts')) {
    console.log('   ✅ 认证路由文件存在');
  } else {
    console.log('   ❌ 认证路由文件不存在');
  }
  
  // 检查认证中间件
  if (fs.existsSync('./src/middleware/auth.ts')) {
    console.log('   ✅ 认证中间件文件存在');
  } else {
    console.log('   ❌ 认证中间件文件不存在');
  }
  
  console.log('\n🔍 4. 检查部署状态...');
  try {
    const deploymentsOutput = execSync('wrangler deployments list --json', { encoding: 'utf8' });
    const deployments = JSON.parse(deploymentsOutput);
    if (deployments && deployments.length > 0) {
      const latestDeployment = deployments[deployments.length - 1];
      console.log('   ✅ Worker 已部署');
      console.log('      部署ID:', latestDeployment.id);
      console.log('      部署时间:', new Date(latestDeployment.created_on).toLocaleString());
      
      // 检查最新版本的绑定
      try {
        const versionId = latestDeployment.versions[0].version_id;
        const versionOutput = execSync(`wrangler versions view ${versionId}`, { encoding: 'utf8' });
        if (versionOutput.includes('JWT_SECRET')) {
          console.log('      环境变量: JWT_SECRET 已正确绑定');
        } else {
          console.log('      环境变量: JWT_SECRET 未绑定');
        }
      } catch (error) {
        console.log('      环境变量: 无法验证绑定状态');
      }
    } else {
      console.log('   ⚠️  未找到部署记录');
    }
  } catch (error) {
    console.log('   ⚠️  无法获取部署信息');
  }
  
  console.log('\n🔍 5. 检查Wrangler配置...');
  try {
    const whoamiOutput = execSync('wrangler whoami', { encoding: 'utf8' });
    if (whoamiOutput.includes('You are logged in')) {
      console.log('   ✅ Wrangler 已正确配置并登录');
    } else {
      console.log('   ⚠️  Wrangler 登录状态未知');
    }
  } catch (error) {
    console.log('   ❌ Wrangler 配置有问题');
  }
  
  console.log('\n✅ 部署检查完成!');
  console.log('\n📋 下一步建议:');
  console.log('   1. 访问您的网站 URL 进行功能测试');
  console.log('   2. 测试用户登录和管理后台功能');
  console.log('   3. 检查浏览器控制台是否有错误信息');
  console.log('   4. 如有问题，请查看部署日志');
  
} catch (error) {
  console.error('检查过程中出现错误:', error.message);
  process.exit(1);
}