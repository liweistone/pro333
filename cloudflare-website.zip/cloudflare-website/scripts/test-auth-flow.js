#!/usr/bin/env node

const { execSync } = require('child_process');
const fs = require('fs');

console.log('测试认证流程...\n');

try {
  // 1. 检查JWT_SECRET配置
  console.log('1. 检查JWT_SECRET配置...');
  const wranglerConfig = fs.readFileSync('./wrangler.toml', 'utf8');
  const jwtSecretMatch = wranglerConfig.match(/JWT_SECRET = "([^"]+)"/);
  
  if (jwtSecretMatch && jwtSecretMatch[1]) {
    const jwtSecret = jwtSecretMatch[1];
    console.log('✅ JWT_SECRET已配置');
    console.log('   长度:', jwtSecret.length, '字符');
  } else {
    console.log('❌ JWT_SECRET未配置');
    process.exit(1);
  }
  
  // 2. 检查认证中间件
  console.log('\n2. 检查认证中间件...');
  const authMiddlewarePath = './src/middleware/auth.ts';
  if (fs.existsSync(authMiddlewarePath)) {
    const authMiddleware = fs.readFileSync(authMiddlewarePath, 'utf8');
    if (authMiddleware.includes('c.env.JWT_SECRET')) {
      console.log('✅ 认证中间件正确引用了JWT_SECRET');
    } else {
      console.log('❌ 认证中间件未正确引用JWT_SECRET');
    }
  } else {
    console.log('❌ 认证中间件文件不存在');
  }
  
  // 3. 检查管理后台路由
  console.log('\n3. 检查管理后台路由...');
  const adminRoutesPath = './src/routes/admin.ts';
  if (fs.existsSync(adminRoutesPath)) {
    const adminRoutes = fs.readFileSync(adminRoutesPath, 'utf8');
    if (adminRoutes.includes('authMiddleware') && adminRoutes.includes('requireAdmin')) {
      console.log('✅ 管理后台路由正确使用了认证中间件');
    } else {
      console.log('❌ 管理后台路由未正确使用认证中间件');
    }
  } else {
    console.log('❌ 管理后台路由文件不存在');
  }
  
  // 4. 检查前端API请求
  console.log('\n4. 检查前端API请求...');
  const adminJsPath = './public/admin/admin.js';
  if (fs.existsSync(adminJsPath)) {
    const adminJs = fs.readFileSync(adminJsPath, 'utf8');
    if (adminJs.includes('Authorization') && adminJs.includes('Bearer')) {
      console.log('✅ 前端正确设置了认证头');
    } else {
      console.log('❌ 前端未正确设置认证头');
    }
  } else {
    console.log('❌ 前端管理JS文件不存在');
  }
  
  // 5. 检查用户管理页面
  console.log('\n5. 检查用户管理页面...');
  const usersHtmlPath = './public/admin/users.html';
  if (fs.existsSync(usersHtmlPath)) {
    const usersHtml = fs.readFileSync(usersHtmlPath, 'utf8');
    if (usersHtml.includes('/api/admin/users')) {
      console.log('✅ 用户管理页面使用了正确的API路径');
    } else {
      console.log('❌ 用户管理页面未使用正确的API路径');
    }
  } else {
    console.log('❌ 用户管理页面文件不存在');
  }
  
  console.log('\n✅ 认证流程检查完成!');
  console.log('\n建议:');
  console.log('1. 检查浏览器开发者工具中的网络请求');
  console.log('2. 确认请求头中包含正确的Authorization字段');
  console.log('3. 检查响应中的错误信息');
  
} catch (error) {
  console.error('检查过程中出现错误:', error.message);
  process.exit(1);
}