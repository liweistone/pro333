#!/usr/bin/env node

const { execSync } = require('child_process');
const fs = require('fs');

console.log('设置生产环境JWT_SECRET...\n');

try {
  // 从wrangler.toml中读取JWT_SECRET
  console.log('1. 从开发配置中读取JWT_SECRET...');
  const wranglerConfig = fs.readFileSync('./wrangler.toml', 'utf8');
  const jwtSecretMatch = wranglerConfig.match(/JWT_SECRET = "([^"]+)"/);
  
  if (jwtSecretMatch && jwtSecretMatch[1]) {
    const jwtSecret = jwtSecretMatch[1];
    console.log('✅ 成功读取JWT_SECRET');
    console.log('   值长度:', jwtSecret.length, '字符');
    
    // 检查JWT_SECRET强度
    if (jwtSecret.length >= 32) {
      console.log('✅ JWT_SECRET长度符合安全要求（至少32字符）');
    } else {
      console.warn('⚠️  JWT_SECRET长度不足32字符，建议使用更长的密钥');
    }
    
    console.log('\n2. 设置生产环境JWT_SECRET...');
    console.log('   请运行以下命令:');
    console.log('   wrangler secret put JWT_SECRET');
    console.log('   然后粘贴以下值:');
    console.log('   ' + jwtSecret);
    console.log('\n   或者，您可以直接运行:');
    console.log('   echo "' + jwtSecret + '" | wrangler secret put JWT_SECRET');
    
    console.log('\n3. 验证设置...');
    console.log('   设置完成后，您可以通过以下命令验证:');
    console.log('   wrangler secret list');
    
    console.log('\n4. 重新部署...');
    console.log('   设置完成后，建议重新部署应用:');
    console.log('   npm run deploy');
    
  } else {
    console.error('❌ 无法从wrangler.toml中找到JWT_SECRET');
    process.exit(1);
  }
  
} catch (error) {
  console.error('设置过程中出现错误:', error.message);
  process.exit(1);
}