// 验证预设管理修复的综合测试脚本
async function verifyPresetsFix() {
  try {
    console.log('🧪 开始验证预设管理修复...');
    
    // 测试1: 验证数据库表结构
    console.log('\n📝 测试1: 验证数据库表结构');
    try {
      const tableInfoQuery = `
        PRAGMA table_info(categories);
      `;
      
      const response = await fetch('/api/debug/query', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ query: tableInfoQuery })
      });
      
      if (!response.ok) {
        console.log('  ❌ 获取表结构信息失败');
      } else {
        const tableInfo = await response.json();
        const hasDescription = tableInfo.some(col => col.name === 'description');
        const hasParentId = tableInfo.some(col => col.name === 'parent_id');
        
        console.log('  表结构检查结果:');
        console.log('  - description字段存在:', hasDescription);
        console.log('  - parent_id字段存在:', hasParentId);
        
        if (hasDescription && hasParentId) {
          console.log('  ✅ 数据库表结构完整');
        } else {
          console.log('  ❌ 数据库表结构不完整');
        }
      }
    } catch (error) {
      console.log('  ❌ 表结构验证失败:', error.message);
    }
    
    // 测试2: 验证公开API端点
    console.log('\n🌐 测试2: 验证公开API端点');
    try {
      const response = await fetch('/api/presets/categories/list');
      console.log('  状态码:', response.status);
      
      if (response.ok) {
        const data = await response.json();
        console.log('  响应结构:', Object.keys(data));
        console.log('  数据条数:', data.data ? data.data.length : '无数据');
        console.log('  ✅ 公开API端点正常');
      } else {
        const errorText = await response.text();
        console.log('  错误响应:', errorText);
        console.log('  ❌ 公开API端点异常');
      }
    } catch (error) {
      console.log('  ❌ API端点测试失败:', error.message);
    }
    
    // 测试3: 验证认证中间件
    console.log('\n🔐 测试3: 验证认证中间件');
    try {
      // 测试健康检查端点
      const healthResponse = await fetch('/health');
      if (healthResponse.ok) {
        console.log('  ✅ 健康检查端点正常');
      } else {
        console.log('  ❌ 健康检查端点异常');
      }
      
      // 测试测试公开API端点
      const testResponse = await fetch('/test-public');
      if (testResponse.ok) {
        console.log('  ✅ 测试公开API端点正常');
      } else {
        console.log('  ❌ 测试公开API端点异常');
      }
    } catch (error) {
      console.log('  ❌ 认证中间件测试失败:', error.message);
    }
    
    // 测试4: 验证前端代码
    console.log('\n🖥️ 测试4: 验证前端代码');
    try {
      // 检查关键函数是否存在
      if (typeof loadCategories === 'function') {
        console.log('  ✅ loadCategories函数存在');
      } else {
        console.log('  ❌ loadCategories函数不存在');
      }
      
      if (typeof loadPresets === 'function') {
        console.log('  ✅ loadPresets函数存在');
      } else {
        console.log('  ❌ loadPresets函数不存在');
      }
    } catch (error) {
      console.log('  ❌ 前端代码验证失败:', error.message);
    }
    
    console.log('\n🎉 验证完成!');
  } catch (error) {
    console.error('验证过程中发生错误:', error);
  }
}

// 如果在浏览器环境中运行
if (typeof window !== 'undefined') {
  verifyPresetsFix();
}

// 如果在Node.js环境中运行
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { verifyPresetsFix };
}