# Cloudflare 网站 API 文档

## 概述
本文档描述了 Cloudflare 网站项目的所有可用 API 端点。

## 基础 URL
```
http://localhost:8787  (本地开发)
https://yourdomain.com  (生产环境)
```

## 认证
某些端点需要认证。认证通过在请求头中添加 `Authorization: Bearer <token>` 来实现。

## API 端点

### 1. 健康检查
- `GET /health` - 检查服务状态

### 2. 用户认证
- `POST /api/auth/register` - 用户注册
- `POST /api/auth/login` - 用户登录
- `POST /api/auth/logout` - 用户登出
- `GET /api/auth/me` - 获取当前用户信息
- `GET /api/auth/users` - 获取用户列表 (需要管理员权限)
- `PUT /api/auth/users/:id/role` - 更新用户角色 (需要超级管理员权限)
- `PUT /api/auth/users/:id/status` - 启用/禁用用户 (需要管理员权限)

### 3. 文章管理
- `GET /api/articles` - 获取文章列表
- `GET /api/articles/:id` - 获取文章详情
- `POST /api/articles` - 创建文章 (需要管理员权限)
- `PUT /api/articles/:id` - 更新文章 (需要管理员权限)
- `DELETE /api/articles/:id` - 删除文章 (需要管理员权限)
- `GET /api/articles/categories` - 获取文章分类

### 4. 产品管理
- `GET /api/products` - 获取产品列表
- `GET /api/products/:id` - 获取产品详情
- `POST /api/products` - 创建产品 (需要管理员权限)
- `PUT /api/products/:id` - 更新产品 (需要管理员权限)
- `DELETE /api/products/:id` - 删除产品 (需要管理员权限)
- `GET /api/products/categories` - 获取产品分类

### 5. 预设管理
- `GET /api/presets` - 获取预设列表
- `GET /api/presets/:id` - 获取预设详情
- `POST /api/presets` - 创建预设 (需要管理员权限)
- `PUT /api/presets/:id` - 更新预设 (需要管理员权限)
- `DELETE /api/presets/:id` - 删除预设 (需要管理员权限)
- `POST /api/presets/:id/use` - 记录预设使用
- `POST /api/presets/:id/favorite` - 收藏预设
- `DELETE /api/presets/:id/favorite` - 取消收藏
- `GET /api/presets/user/favorites` - 获取用户收藏的预设
- `GET /api/presets/categories` - 获取预设分类

### 6. 广告管理
#### 网站首页广告
- `GET /api/homepage-ads` - 获取网站首页广告列表
- `GET /api/homepage-ads/:id` - 获取单个网站首页广告详情
- `POST /api/homepage-ads` - 创建网站首页广告 (需要管理员权限)
- `PUT /api/homepage-ads/:id` - 更新网站首页广告 (需要管理员权限)
- `DELETE /api/homepage-ads/:id` - 删除网站首页广告 (需要管理员权限)

#### ComfyUI插件端广告
- `GET /api/ads` - 获取ComfyUI插件端广告列表
- `POST /api/ads` - 创建ComfyUI插件端广告 (需要管理员权限)
- `PUT /api/ads/:id` - 更新ComfyUI插件端广告 (需要管理员权限)
- `DELETE /api/ads/:id` - 删除ComfyUI插件端广告 (需要管理员权限)

### 7. 图像管理
- `POST /api/images/upload` - 上传图像 (需要管理员权限)
- `GET /api/images` - 获取图像列表 (需要管理员权限)
- `DELETE /api/images/:id` - 删除图像 (需要管理员权限)
- `GET /api/images/public/:key` - 提供公共图像访问

### 8. 评论系统
- `GET /api/comments` - 获取评论
- `GET /api/comments/pending` - 获取待审核评论 (需要管理员权限)
- `POST /api/comments` - 添加评论 (需要认证)
- `PUT /api/comments/:id` - 更新评论 (作者或管理员)
- `DELETE /api/comments/:id` - 删除评论 (作者或管理员)
- `PUT /api/comments/:id/status` - 审核评论 (需要管理员权限)

### 9. 留言板系统
- `GET /api/guestbook` - 获取留言板消息
- `POST /api/guestbook` - 添加留言 (需要认证)
- `DELETE /api/guestbook/:id` - 删除留言 (作者或管理员)
- `GET /api/guestbook/all` - 获取所有留言（包括未公开的）(需要管理员权限)
- `PUT /api/guestbook/:id/public` - 设置留言公开状态 (需要管理员权限)

### 10. 收藏系统
- `POST /api/favorites` - 添加收藏（文章/产品/预设）
- `DELETE /api/favorites/:type/:id` - 移除收藏（文章/产品/预设）
- `GET /api/favorites` - 获取用户收藏
- `GET /api/favorites/stats` - 获取特定类型收藏统计

### 11. 用户等级系统
- `GET /api/user-levels` - 获取所有用户级别
- `POST /api/user-levels` - 创建用户级别 (需要超级管理员权限)
- `PUT /api/user-levels/:level` - 更新用户级别 (需要超级管理员权限)
- `DELETE /api/user-levels/:level` - 删除用户级别 (需要超级管理员权限)
- `POST /api/user-levels/assign` - 为用户分配级别 (需要管理员权限)

### 12. 文章分类管理
- `GET /api/article-categories` - 获取文章分类列表
- `GET /api/article-categories/:id` - 获取单个文章分类详情
- `POST /api/article-categories` - 创建文章分类 (需要管理员权限)
- `PUT /api/article-categories/:id` - 更新文章分类 (需要管理员权限)
- `DELETE /api/article-categories/:id` - 删除文章分类 (需要管理员权限)

### 13. 管理后台API
#### 用户管理
- `GET /api/admin/users` - 获取用户列表 (需要管理员权限)
- `GET /api/admin/users/:id` - 获取单个用户详情 (需要管理员权限)
- `POST /api/admin/users` - 创建用户 (需要管理员权限)
- `PUT /api/admin/users/:id` - 更新用户信息 (需要管理员权限)
- `PUT /api/admin/users/:id/status` - 启用/禁用用户 (需要管理员权限)
- `DELETE /api/admin/users/:id` - 删除用户 (需要管理员权限)

#### 文章管理
- `GET /api/admin/articles` - 获取文章列表 (需要管理员权限)
- `GET /api/admin/articles/:id` - 获取单篇文章详情 (需要管理员权限)
- `PUT /api/admin/articles/:id/status` - 更新文章状态 (需要管理员权限)
- `PUT /api/admin/articles/:id` - 更新文章 (需要管理员权限)
- `DELETE /api/admin/articles/:id` - 删除文章 (需要管理员权限)

#### 产品管理
- `GET /api/admin/products` - 获取产品列表 (需要管理员权限)
- `GET /api/admin/products/:id` - 获取单个产品详情 (需要管理员权限)
- `PUT /api/admin/products/:id/status` - 更新产品状态 (需要管理员权限)
- `PUT /api/admin/products/:id` - 更新产品 (需要管理员权限)
- `DELETE /api/admin/products/:id` - 删除产品 (需要管理员权限)

#### 预设管理
- `GET /api/admin/presets` - 获取预设列表 (需要管理员权限)
- `GET /api/admin/presets/:id` - 获取单个预设详情 (需要管理员权限)
- `PUT /api/admin/presets/:id/status` - 更新预设状态 (需要管理员权限)
- `PUT /api/admin/presets/:id` - 更新预设 (需要管理员权限)
- `DELETE /api/admin/presets/:id` - 删除预设 (需要管理员权限)

#### 评论管理
- `GET /api/admin/comments` - 获取评论列表 (需要管理员权限)
- `GET /api/admin/comments/:id` - 获取单个评论详情 (需要管理员权限)
- `PUT /api/admin/comments/:id/status` - 审核评论 (需要管理员权限)
- `PUT /api/admin/comments/:id` - 更新评论 (需要管理员权限)
- `DELETE /api/admin/comments/:id` - 删除评论 (需要管理员权限)

#### 留言管理
- `GET /api/admin/guestbook` - 获取留言列表 (需要管理员权限)
- `GET /api/admin/guestbook/:id` - 获取单个留言详情 (需要管理员权限)
- `PUT /api/admin/guestbook/:id/status` - 公开/隐藏留言 (需要管理员权限)
- `PUT /api/admin/guestbook/:id` - 更新留言 (需要管理员权限)
- `DELETE /api/admin/guestbook/:id` - 删除留言 (需要管理员权限)

#### 广告管理
##### 网站首页广告
- `GET /api/admin/advertisements` - 获取网站首页广告列表 (需要管理员权限)
- `POST /api/admin/advertisements` - 创建网站首页广告 (需要管理员权限)
- `PUT /api/admin/advertisements/:id` - 更新网站首页广告 (需要管理员权限)
- `DELETE /api/admin/advertisements/:id` - 删除网站首页广告 (需要管理员权限)

##### 插件端广告
- `GET /api/admin/ads` - 获取插件端广告列表 (需要管理员权限)
- `POST /api/admin/ads` - 创建插件端广告 (需要管理员权限)
- `PUT /api/admin/ads/:id` - 更新插件端广告 (需要管理员权限)
- `DELETE /api/admin/ads/:id` - 删除插件端广告 (需要管理员权限)

#### 媒体管理
- `GET /api/admin/images` - 获取图像列表 (需要管理员权限)
- `DELETE /api/admin/images/:id` - 删除图像 (需要管理员权限)

## 错误响应格式
所有错误响应都遵循以下格式：
```json
{
  "error": "错误描述"
}
```

## 成功响应格式
成功响应根据具体操作返回相应的数据格式。

## 状态码
- `200` - 成功
- `201` - 创建成功
- `400` - 请求错误
- `401` - 未认证
- `403` - 权限不足
- `404` - 资源不存在
- `500` - 服务器内部错误