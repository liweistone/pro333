# 封面图片功能实现

## 概述
为文章和产品添加了封面图片支持，允许为每篇文章和产品指定封面图片。

## 数据库变更

### 文章表 (Articles)
添加了 `cover_image` 字段：
```sql
ALTER TABLE Articles ADD COLUMN cover_image TEXT;
```

### 产品表 (Products)
添加了 `cover_image` 字段：
```sql
ALTER TABLE Products ADD COLUMN cover_image TEXT;
```

## API 变更

### 文章管理 API
- **创建文章** (`POST /api/articles`): 支持 `cover_image` 参数
- **更新文章** (`PUT /api/articles/:id`): 支持更新 `cover_image` 参数

### 产品管理 API
- **创建产品** (`POST /api/products`): 支持 `cover_image` 参数
- **更新产品** (`PUT /api/products/:id`): 支持更新 `cover_image` 参数

## 前端实现
- 更新了文章和产品卡片的展示，支持封面图片显示
- 添加了 `.card-image` CSS 类用于图片样式控制
- 使用 `object-fit: cover` 确保图片正确显示

## 使用示例

### 创建带封面图片的文章
```json
{
  "title": "文章标题",
  "content": "文章内容",
  "category_id": 1,
  "cover_image": "https://example.com/article-cover.jpg"
}
```

### 创建带封面图片的产品
```json
{
  "name": "产品名称",
  "description": "产品描述",
  "price": 99.99,
  "category_id": 1,
  "cover_image": "https://example.com/product-cover.jpg"
}
```

## 注意事项
1. 封面图片字段是可选的，可以为空
2. 建议使用 HTTPS 图片链接以确保在所有环境下正常显示
3. 前端会自动处理图片加载失败的情况
4. 图片尺寸建议为 1200x630 像素以获得最佳显示效果