# 广告管理API文档

## 概述

本网站提供广告管理系统，用于管理ComfyUI插件端的广告。

## 1. 广告API

### 1.1 获取广告列表

**请求**
```
GET /api/ads
```

**查询参数**
- `placement` (可选) - 广告位置筛选

**响应**
```json
[
  {
    "id": "abc123",
    "title": "插件广告标题",
    "image_url": "https://example.com/plugin-ad.jpg",
    "link_url": "https://example.com/plugin",
    "description": "插件广告描述",
    "priority": 1,
    "is_active": 1,
    "created_at": 1672531200,
    "updated_at": 1672531200
  }
]
```

### 1.2 创建广告

**请求**
```
POST /api/ads
```

**请求头**
```
Authorization: Bearer <admin_jwt_token>
Content-Type: application/json
```

**请求体**
```json
{
  "title": "插件广告标题",
  "image_url": "https://example.com/plugin-ad.jpg",
  "link_url": "https://example.com/plugin",
  "description": "插件广告描述",
  "priority": 1,
  "is_active": 1
}
```

**响应**
```json
{
  "id": "abc123",
  "message": "广告创建成功"
}
```

### 1.3 更新广告

**请求**
```
PUT /api/ads/:id
```

**请求头**
```
Authorization: Bearer <admin_jwt_token>
Content-Type: application/json
```

**请求体**
```json
{
  "title": "新插件广告标题",
  "description": "新插件广告描述"
}
```

**响应**
```json
{
  "message": "广告更新成功"
}
```

### 1.4 删除广告

**请求**
```
DELETE /api/ads/:id
```

**请求头**
```
Authorization: Bearer <admin_jwt_token>
```

**响应**
```json
{
  "message": "广告删除成功"
}
```

## 权限说明

- 所有创建、更新、删除操作都需要管理员权限
- 管理员需要通过JWT Token进行身份验证
- 获取广告列表操作无需身份验证

## 错误响应

所有错误响应都遵循以下格式：

```json
{
  "error": "错误描述"
}
```

常见的HTTP状态码：
- 200 - 请求成功
- 201 - 创建成功
- 400 - 请求参数错误
- 401 - 未授权
- 403 - 权限不足
- 500 - 服务器内部错误