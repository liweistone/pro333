# 网站首页广告 API

## 概述
网站首页广告API用于管理网站首页轮播广告，数据存储在`Advertisements`表中。

## API 端点
所有API端点都以 `/api/homepage-ads` 开头。

### 获取广告列表
```
GET /api/homepage-ads
```

**查询参数:**
- `limit` (可选): 限制返回的广告数量，默认为10

**响应:**
```json
[
  {
    "id": 1,
    "image_url": "https://example.com/ad-image.jpg",
    "link_url": "https://example.com",
    "title": "广告标题",
    "description": "广告描述",
    "sort_order": 1,
    "is_active": 1,
    "created_at": "2023-01-01 00:00:00"
  }
]
```

### 获取单个广告详情
```
GET /api/homepage-ads/:id
```

**响应:**
```json
{
  "id": 1,
  "image_url": "https://example.com/ad-image.jpg",
  "link_url": "https://example.com",
  "title": "广告标题",
  "description": "广告描述",
  "sort_order": 1,
  "is_active": 1,
  "created_at": "2023-01-01 00:00:00"
}
```

### 创建广告 (需要管理员权限)
```
POST /api/homepage-ads
```

**请求体:**
```json
{
  "title": "广告标题",
  "image_url": "https://example.com/ad-image.jpg",
  "link_url": "https://example.com",
  "description": "广告描述",
  "sort_order": 1,
  "is_active": 1
}
```

### 更新广告 (需要管理员权限)
```
PUT /api/homepage-ads/:id
```

**请求体:**
```json
{
  "title": "新广告标题",
  "image_url": "https://example.com/new-ad-image.jpg",
  "link_url": "https://example.com/new-link",
  "description": "新广告描述",
  "sort_order": 2,
  "is_active": 1
}
```

### 删除广告 (需要管理员权限)
```
DELETE /api/homepage-ads/:id
```

## 数据库表结构
```sql
CREATE TABLE Advertisements (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  image_url TEXT NOT NULL,
  link_url TEXT,
  title TEXT,
  description TEXT,
  sort_order INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

## 与ComfyUI插件端广告的区别
- **表名**: 使用 `Advertisements` 表而非 `ads` 表
- **排序字段**: 使用 `sort_order` 字段而非 `priority` 字段
- **用途**: 专门用于网站首页轮播广告
- **API端点**: `/api/homepage-ads` 而非 `/api/ads`