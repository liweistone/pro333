# AI应用配置指南

本文档介绍了如何为不同的AI应用配置不同的WebApp ID和API密钥。

## 配置原理

为了支持多个AI应用，我们采用了基于前缀的环境变量命名规范：

- 通用配置：`RUNNINGHUB_API_KEY`（所有应用共用一个API Key）
- 特定应用配置：`{APP_TYPE}_{PLATFORM}_{CONFIG_TYPE}`（不同应用使用不同的WebApp ID）

## 支持的应用类型

1. `text-to-image` - 文生图应用
2. `text-to-video` - 文生视频应用
3. `image-repair` - 图像修复应用
4. `image-upscale` - 图像超分辨率应用
5. `face-swap` - 人脸交换应用

## 支持的平台

1. `runninghub` - RunningHub平台
2. `aliyun` - 阿里云平台

## 配置示例

### 文生图应用配置

```toml
# 通用RunningHub API Key（所有应用共用）
RUNNINGHUB_API_KEY = "your_runninghub_api_key"

# 文生图应用WebApp ID
TEXT_TO_IMAGE_RUNNINGHUB_WEBAPP_ID = "your_text_to_image_webapp_id"

# 阿里云配置（如果需要）
TEXT_TO_IMAGE_DASHSCOPE_API_KEY = "your_dashscope_api_key"
```

### 文生视频应用配置

```toml
# 文生视频应用WebApp ID（使用相同的API Key）
TEXT_TO_VIDEO_RUNNINGHUB_WEBAPP_ID = "your_text_to_video_webapp_id"

# 阿里云配置（如果需要）
TEXT_TO_VIDEO_DASHSCOPE_API_KEY = "your_dashscope_api_key"
```

### 图像修复应用配置

```toml
# 图像修复应用WebApp ID（使用相同的API Key）
IMAGE_REPAIR_RUNNINGHUB_WEBAPP_ID = "your_image_repair_webapp_id"

# 阿里云配置（如果需要）
IMAGE_REPAIR_DASHSCOPE_API_KEY = "your_dashscope_api_key"
```

## 在代码中使用配置

在代码中，我们提供了`getAIConfig`函数来获取对应应用的配置：

```typescript
import { getAIConfig } from '../utils/ai-config';

// 获取文生图应用的RunningHub配置
const runningHubConfig = getAIConfig(env, 'text-to-image', 'runninghub');

// 获取文生视频应用的阿里云配置
const aliyunConfig = getAIConfig(env, 'text-to-video', 'aliyun');
```

## 添加新的AI应用

要添加新的AI应用，请按以下步骤操作：

1. 在`wrangler.toml`中添加相应的WebApp ID配置
2. 在`src/types/index.ts`中添加对应的类型定义
3. 在`src/utils/ai-config.ts`中更新`AIAppType`枚举和配置获取函数
4. 在相应的路由文件中使用新的配置

## 注意事项

1. RUNNINGHUB_API_KEY是通用的，所有应用共用一个API Key
2. 不同的应用只需要配置不同的WebApp ID
3. 环境变量名称必须严格按照命名规范，否则配置将无法生效
4. 在部署到生产环境时，请确保所有敏感信息都已正确配置