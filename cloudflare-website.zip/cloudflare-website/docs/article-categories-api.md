# 文章分类管理API文档

## 概述

本文档说明了如何使用文章分类管理API，用于管理网站文章的分类信息。

## 1. 文章分类API

### 1.1 获取文章分类列表

**请求**
```
GET /api/article-categories
```

**查询参数**
- `parent_id` (可选) - 父分类ID，用于获取特定父分类下的子分类

**响应**
```json
[
  {
    "id": 1,
    "name": "技术文章",
    "description": "技术相关文章分类",
    "parent_id": null,
    "created_at": "2023-01-01 12:00:00"
  },
  {
    "id": 2,
    "name": "教程",
    "description": "教程类文章",
    "parent_id": 1,
    "created_at": "2023-01-02 12:00:00"
  }
]
```

### 1.2 获取单个文章分类详情

**请求**
```
GET /api/article-categories/:id
```

**响应**
```json
{
  "id": 1,
  "name": "技术文章",
  "description": "技术相关文章分类",
  "parent_id": null,
  "created_at": "2023-01-01 12:00:00"
}
```

### 1.3 创建文章分类

**请求**
```
POST /api/article-categories
```

**请求头**
```
Authorization: Bearer <admin_jwt_token>
Content-Type: application/json
```

**请求体**
```json
{
  "name": "新分类名称",
  "description": "分类描述",
  "parent_id": 1 // 可选，父分类ID
}
```

**响应**
```json
{
  "message": "分类创建成功"
}
```

### 1.4 更新文章分类

**请求**
```
PUT /api/article-categories/:id
```

**请求头**
```
Authorization: Bearer <admin_jwt_token>
Content-Type: application/json
```

**请求体**
```json
{
  "name": "更新后的分类名称",
  "description": "更新后的分类描述"
}
```

**响应**
```json
{
  "message": "分类更新成功"
}
```

### 1.5 删除文章分类

**请求**
```
DELETE /api/article-categories/:id
```

**请求头**
```
Authorization: Bearer <admin_jwt_token>
```

**响应**
```json
{
  "message": "分类删除成功"
}
```

**注意：**
- 如果该分类下有子分类，则无法删除
- 如果该分类下有文章，则无法删除

## 权限说明

- 所有创建、更新、删除操作都需要管理员权限
- 管理员需要通过JWT Token进行身份验证
- 获取分类列表和详情操作无需身份验证

## 错误响应

所有错误响应都遵循以下格式：

```json
{
  "error": "错误描述"
}
```

常见的HTTP状态码：
- 200 - 请求成功
- 201 - 创建成功
- 400 - 请求参数错误
- 401 - 未授权
- 403 - 权限不足
- 404 - 分类不存在
- 500 - 服务器内部错误