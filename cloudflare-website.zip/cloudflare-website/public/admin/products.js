// 产品管理功能脚本
document.addEventListener('DOMContentLoaded', function() {
  // 监听自定义事件
  document.addEventListener('showEditCategoryForm', function(e) {
    showEditCategoryForm(e.detail);
  });
  
  document.addEventListener('deleteCategory', function(e) {
    deleteCategory(e.detail);
  });
  
  document.addEventListener('showEditProductForm', function(e) {
    showEditProductForm(e.detail);
  });
  
  document.addEventListener('deleteProduct', function(e) {
    deleteProduct(e.detail);
  });
  
  // 初始化Quill编辑器
  let quill = null;
  let quillEdit = null;
  let selectedCoverImage = null;
  let selectedEditCoverImage = null;
  
  // 初始化Quill编辑器
  function initQuill() {
    if (document.getElementById('editor')) {
      quill = new Quill('#editor', {
        theme: 'snow',
        modules: {
          toolbar: [
            [{ 'header': [1, 2, 3, 4, 5, 6, false] }],
            ['bold', 'italic', 'underline', 'strike'],
            [{ 'list': 'ordered'}, { 'list': 'bullet' }],
            [{ 'script': 'sub'}, { 'script': 'super' }],
            [{ 'indent': '-1'}, { 'indent': '+1' }],
            [{ 'direction': 'rtl' }],
            [{ 'color': [] }, { 'background': [] }],
            [{ 'align': [] }],
            ['link', 'image', 'video'],
            ['clean']
          ]
        }
      });
    }
  }
  
  // 初始化编辑产品的Quill编辑器
  function initQuillEdit() {
    if (document.getElementById('edit-editor')) {
      quillEdit = new Quill('#edit-editor', {
        theme: 'snow',
        modules: {
          toolbar: [
            [{ 'header': [1, 2, 3, 4, 5, 6, false] }],
            ['bold', 'italic', 'underline', 'strike'],
            [{ 'list': 'ordered'}, { 'list': 'bullet' }],
            [{ 'script': 'sub'}, { 'script': 'super' }],
            [{ 'indent': '-1'}, { 'indent': '+1' }],
            [{ 'direction': 'rtl' }],
            [{ 'color': [] }, { 'background': [] }],
            [{ 'align': [] }],
            ['link', 'image', 'video'],
            ['clean']
          ]
        }
      });
    }
  }
  
  // 加载分类
  async function loadCategories() {
    try {
      const response = await adminPanel.apiRequest('/api/product-categories/list')
      
      if (!response.ok) {
        throw new Error('获取分类失败')
      }
      
      const data = await response.json()
      if (data.success) {
        const categories = data.data
        const tbody = document.getElementById('categoriesTable').querySelector('tbody')
        tbody.innerHTML = ''
        
        categories.forEach(category => {
          const row = document.createElement('tr')
          row.innerHTML = `
            <td>${category.id}</td>
            <td>${category.name}</td>
            <td>${category.description || ''}</td>
            <td>${category.parent_id || '无'}</td>
            <td>
              <button class="btn btn-sm btn-primary" onclick="showEditCategoryForm(${category.id})">编辑</button>
              <button class="btn btn-sm btn-danger" onclick="deleteCategory(${category.id})">删除</button>
            </td>
          `
          tbody.appendChild(row)
        })
      } else {
        adminPanel.showMessage('获取分类失败：' + data.message, 'error')
      }
    } catch (error) {
      console.error('Error loading categories:', error)
      adminPanel.showMessage('获取分类失败，请检查网络连接', 'error')
    }
  }
  
  // 显示添加分类表单
  function showAddCategoryForm() {
    // 检查是否已经存在模态框，如果存在则移除
    const existingModal = document.getElementById('addCategoryModal');
    if (existingModal) {
      const modalInstance = bootstrap.Modal.getInstance(existingModal);
      if (modalInstance) {
        modalInstance.hide();
      }
      existingModal.remove();
    }
    
    const modal = document.createElement('div')
    modal.className = 'modal fade'
    modal.id = 'addCategoryModal'
    modal.tabIndex = '-1'
    modal.innerHTML = `
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">添加分类</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <form id="add-category-form">
              <div class="mb-3">
                <label for="category-name" class="form-label">分类名称：</label>
                <input type="text" class="form-control" id="category-name" name="name" required>
              </div>
              <div class="mb-3">
                <label for="category-description" class="form-label">描述：</label>
                <textarea class="form-control" id="category-description" name="description" rows="3"></textarea>
              </div>
              <div class="mb-3">
                <label for="category-parent-id" class="form-label">父级分类：</label>
                <select class="form-select" id="category-parent-id" name="parent_id">
                  <option value="">无</option>
                  <!-- 父级分类选项将在这里动态加载 -->
                </select>
              </div>
            </form>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
            <button type="button" class="btn btn-primary" id="save-category-btn">保存</button>
          </div>
        </div>
      </div>
    `
    
    document.body.appendChild(modal)
    
    const addCategoryModal = new bootstrap.Modal(modal)
    addCategoryModal.show()
    
    // 动态加载父级分类选项
    loadParentCategories()
    
    // 提交表单
    document.getElementById('save-category-btn').addEventListener('click', async function(e) {
      e.preventDefault()
      
      try {
        const form = document.getElementById('add-category-form')
        const formData = new FormData(form)
        const body = {
          name: formData.get('name'),
          description: formData.get('description'),
          parent_id: formData.get('parent_id') || null
        }
        
        const response = await adminPanel.apiRequest('/api/product-categories/add', {
          method: 'POST',
          body: JSON.stringify(body)
        });
        
        // 检查响应状态
        if (response.status === 401) {
          // 令牌失效，已经由apiRequest处理了重定向
          return;
        }
        
        if (!response.ok) {
          throw new Error('添加分类失败');
        }
        
        const data = await response.json();
        if (data.success) {
          if (window.adminPanel) {
            window.adminPanel.cleanupModal('addCategoryModal');
          } else {
            // 降级处理
            addCategoryModal.hide()
            // 确保背景层消失
            setTimeout(() => {
              const backdrop = document.querySelector('.modal-backdrop');
              if (backdrop) {
                backdrop.remove();
              }
            }, 300);
          }
          loadCategories()
          adminPanel.showMessage('分类添加成功', 'success')
        } else {
          adminPanel.showMessage('添加分类失败：' + data.message, 'error')
        }
      } catch (error) {
        console.error('Error adding category:', error)
        adminPanel.showMessage('添加分类失败，请检查网络连接', 'error')
      }
    })
  }
  
  // 加载父级分类选项
  async function loadParentCategories() {
    try {
      const response = await adminPanel.apiRequest('/api/product-categories/list')
      
      if (!response.ok) {
        throw new Error('获取父级分类失败')
      }
      
      const data = await response.json()
      if (data.success) {
        const parentCategories = data.data
        const select = document.getElementById('category-parent-id')
        select.innerHTML = '<option value="">无</option>'
        
        parentCategories.forEach(category => {
          const option = document.createElement('option')
          option.value = category.id
          option.textContent = category.name
          select.appendChild(option)
        })
      }
    } catch (error) {
      console.error('Error loading parent categories:', error)
      adminPanel.showMessage('加载父级分类失败，请检查网络连接', 'error');
    }
  }
  
  // 显示编辑分类表单
  async function showEditCategoryForm(id) {
    try {
      const response = await adminPanel.apiRequest(`/api/product-categories/${id}`)
      
      if (!response.ok) {
        throw new Error('获取分类信息失败')
      }
      
      const data = await response.json()
      if (data.success) {
        const category = data.data
        
        // 检查是否已经存在编辑模态框，如果存在则移除
        const existingModal = document.getElementById('editCategoryModal');
        if (existingModal) {
          const modalInstance = bootstrap.Modal.getInstance(existingModal);
          if (modalInstance) {
            // 在隐藏模态框前先移除焦点元素，避免aria-hidden属性冲突
            const closeBtn = existingModal.querySelector('.btn-close');
            if (closeBtn) {
              closeBtn.blur();
            }
            const saveBtn = document.getElementById('save-edit-category-btn');
            if (saveBtn) {
              saveBtn.blur();
            }
            modalInstance.hide();
          }
          existingModal.remove();
        }
        
        const modal = document.createElement('div')
        modal.className = 'modal fade'
        modal.id = 'editCategoryModal'
        modal.tabIndex = '-1'
        modal.innerHTML = `
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title">编辑分类</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
              <div class="modal-body">
                <form id="edit-category-form">
                  <div class="mb-3">
                    <label for="edit-category-name" class="form-label">分类名称：</label>
                    <input type="text" class="form-control" id="edit-category-name" name="name" value="${category.name}" required>
                  </div>
                  <div class="mb-3">
                    <label for="edit-category-description" class="form-label">描述：</label>
                    <textarea class="form-control" id="edit-category-description" name="description" rows="3">${category.description || ''}</textarea>
                  </div>
                  <div class="mb-3">
                    <label for="edit-category-parent-id" class="form-label">父级分类：</label>
                    <select class="form-select" id="edit-category-parent-id" name="parent_id">
                      <option value="">无</option>
                      <!-- 父级分类选项将在这里动态加载 -->
                    </select>
                  </div>
                </form>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
                <button type="button" class="btn btn-primary" id="save-edit-category-btn">保存</button>
              </div>
            </div>
          </div>
        `
        
        document.body.appendChild(modal)
        
        const editCategoryModal = new bootstrap.Modal(modal)
        editCategoryModal.show()
        
        // 动态加载父级分类选项
        loadParentCategories()
        
        // 设置当前父级分类
        document.getElementById('edit-category-parent-id').value = category.parent_id || ''
        
        // 提交表单
        const saveBtn = document.getElementById('save-edit-category-btn');
        // 移除可能已存在的事件监听器
        const newSaveBtn = saveBtn.cloneNode(true);
        saveBtn.parentNode.replaceChild(newSaveBtn, saveBtn);
        
        newSaveBtn.addEventListener('click', async function(e) {
          e.preventDefault()
          
          try {
            const form = document.getElementById('edit-category-form')
            const formData = new FormData(form)
            const body = {
              name: formData.get('name'),
              description: formData.get('description'),
              parent_id: formData.get('parent_id') || null
            }
            
            const response = await adminPanel.apiRequest(`/api/product-categories/edit/${id}`, {
              method: 'PUT',
              body: JSON.stringify(body)
            });
            
            // 检查响应状态
            if (response.status === 401) {
              // 令牌失效，已经由apiRequest处理了重定向
              return;
            }
            
            if (!response.ok) {
              throw new Error('编辑分类失败');
            }
            
            const data = await response.json();
            if (data.success) {
              // 在隐藏模态框前先移除焦点元素，避免aria-hidden属性冲突
              const closeBtn = modal.querySelector('.btn-close');
              if (closeBtn) {
                closeBtn.blur();
              }
              newSaveBtn.blur();
              
              // 使用统一的模态框清除函数
              if (window.adminPanel) {
                window.adminPanel.cleanupModal('editCategoryModal');
              } else {
                // 降级处理
                editCategoryModal.hide();
                // 确保背景层消失
                setTimeout(() => {
                  const backdrop = document.querySelector('.modal-backdrop');
                  if (backdrop) {
                    backdrop.remove();
                  }
                }, 300);
              }
              loadCategories();
              adminPanel.showMessage('分类编辑成功', 'success');
            } else {
              adminPanel.showMessage('编辑分类失败：' + data.message, 'error');
            }
          } catch (error) {
            console.error('Error editing category:', error)
            adminPanel.showMessage('编辑分类失败，请检查网络连接', 'error')
          }
        })
      }
    } catch (error) {
      console.error('Error showing edit category form:', error)
      adminPanel.showMessage('获取分类信息失败，请检查网络连接', 'error')
    }
  }
  
  // 删除分类
  async function deleteCategory(id) {
    if (confirm('确定要删除这个分类吗？')) {
      try {
        const response = await adminPanel.apiRequest(`/api/product-categories/delete/${id}`, {
          method: 'DELETE'
        })
        
        // 特别处理400状态码（分类下有产品的情况）
        if (response.status === 400) {
          const data = await response.json();
          adminPanel.showMessage('删除分类失败：' + data.error, 'error');
          return;
        }
        
        if (!response.ok) {
          throw new Error('删除分类失败')
        }
        
        const data = await response.json()
        if (data.success) {
          loadCategories()
          adminPanel.showMessage('分类删除成功', 'success')
        } else {
          adminPanel.showMessage('删除分类失败：' + (data.error || data.message), 'error')
        }
      } catch (error) {
        console.error('Error deleting category:', error)
        adminPanel.showMessage('删除分类失败，请检查网络连接', 'error')
      }
    }
  }
  
  // 关闭模态框
  function closeModal() {
    const modals = document.querySelectorAll('.modal')
    modals.forEach(modal => {
      const modalInstance = bootstrap.Modal.getInstance(modal)
      if (modalInstance) {
        modalInstance.hide()
      }
    })
  }
  
  // 加载产品
  async function loadProducts(page = 1) {
    try {
      const response = await adminPanel.apiRequest(`/api/products?page=${page}&limit=10`);
      
      if (!response.ok) {
        throw new Error('获取产品失败');
      }
      
      const data = await response.json();
      if (data.data) {
        const products = data.data;
        const tbody = document.getElementById('productsTable').querySelector('tbody');
        tbody.innerHTML = '';
        
        // 预先获取分类数据，避免重复请求
        const categoriesResponse = await adminPanel.apiRequest('/api/product-categories/list');
        const categoriesData = await categoriesResponse.json();
        const categoryMap = {};
        
        if (categoriesData.success) {
          categoriesData.data.forEach(category => {
            categoryMap[category.id] = category.name;
          });
        }
        
        products.forEach(product => {
          // 处理封面图片URL
          let coverImageHtml = '';
          if (product.cover_image) {
            const imageUrl = product.cover_image.startsWith('http') || product.cover_image.startsWith('/api/images/public/') 
              ? product.cover_image 
              : `/api/images/public/${product.cover_image}`;
            coverImageHtml = `<img src="${imageUrl}" alt="封面" style="width: 50px; height: 50px; object-fit: cover; border-radius: 4px;">`;
          } else {
            coverImageHtml = '<span class="text-muted">无封面</span>';
          }
          
          const row = document.createElement('tr');
          row.innerHTML = `
            <td>${product.id}</td>
            <td>${product.name}</td>
            <td>${coverImageHtml}</td>
            <td>${categoryMap[product.category_id] || '无'}</td>  <!-- 显示分类名称 -->
            <td>¥${product.price || '0.00'}</td>
            <td><span class="badge bg-${product.is_available ? 'success' : 'secondary'}">${product.is_available ? '可用' : '不可用'}</span></td>
            <td><span class="badge bg-${product.visibility === 'public' ? 'primary' : 'secondary'}">${product.visibility === 'public' ? '公开' : '私有'}</span></td>
            <td>${new Date(product.created_at).toLocaleDateString('zh-CN')}</td>
            <td>
              <button class="btn btn-sm btn-primary edit-product-btn" data-id="${product.id}">编辑</button>
              <button class="btn btn-sm btn-danger delete-product-btn" data-id="${product.id}">删除</button>
            </td>
          `;
          tbody.appendChild(row);
        });
        
        // 渲染分页控件
        if (data.pagination) {
          renderPagination(data.pagination, loadProducts);
        }
      } else {
        adminPanel.showMessage('获取产品失败：' + data.message, 'error');
      }
    } catch (error) {
      console.error('Error loading products:', error);
      adminPanel.showMessage('获取产品失败，请检查网络连接', 'error');
    }
  }
  
  // 渲染分页控件
  function renderPagination(pagination, loadFunction) {
    const paginationEl = document.getElementById('pagination');
    if (!paginationEl) return;
    
    const { currentPage, totalPages } = pagination;
    
    let paginationHTML = '';
    
    // 上一页
    if (currentPage > 1) {
      paginationHTML += `<li class="page-item"><a class="page-link" href="#" data-page="${currentPage - 1}">上一页</a></li>`;
    } else {
      paginationHTML += '<li class="page-item disabled"><span class="page-link">上一页</span></li>';
    }
    
    // 页码
    for (let i = 1; i <= totalPages; i++) {
      if (i === currentPage) {
        paginationHTML += `<li class="page-item active"><span class="page-link">${i}</span></li>`;
      } else {
        paginationHTML += `<li class="page-item"><a class="page-link" href="#" data-page="${i}">${i}</a></li>`;
      }
    }
    
    // 下一页
    if (currentPage < totalPages) {
      paginationHTML += `<li class="page-item"><a class="page-link" href="#" data-page="${currentPage + 1}">下一页</a></li>`;
    } else {
      paginationHTML += '<li class="page-item disabled"><span class="page-link">下一页</span></li>';
    }
    
    paginationEl.innerHTML = paginationHTML;
    
    // 绑定分页点击事件
    paginationEl.querySelectorAll('.page-link').forEach(link => {
      link.addEventListener('click', function(e) {
        e.preventDefault();
        const page = this.getAttribute('data-page');
        if (page) {
          loadFunction(parseInt(page));
        }
      });
    });
  }
  
  // 显示添加产品表单
  function showAddProductForm() {
    // 使用已存在的模态框
    const modal = document.getElementById('productModal');
    const modalTitle = modal.querySelector('.modal-title');
    const form = modal.querySelector('form');
    
    // 重置表单
    form.reset();
    
    // 更新模态框标题
    modalTitle.textContent = '添加产品';
    
    // 清空隐藏的ID字段
    document.getElementById('productId').value = '';
    
    // 清空封面图片预览
    const coverImagePreview = document.getElementById('coverImagePreview');
    coverImagePreview.style.display = 'none';
    
    // 销毁现有的编辑器实例
    if (quill) {
      quill.destroy();
      quill = null;
    }
    
    // 清空编辑器内容
    setTimeout(() => {
      initQuill();
      if (quill) {
        quill.root.innerHTML = '';
      }
    }, 100);
    
    // 动态加载分类选项
    loadCategoriesForProduct();
    
    // 绑定封面图片选择和上传事件（如果尚未绑定）
    const selectImageBtn = document.getElementById('selectImageBtn');
    const uploadImageBtn = document.getElementById('uploadImageBtn');
    
    // 移除旧的事件监听器并添加新的
    const newSelectBtn = selectImageBtn.cloneNode(true);
    selectImageBtn.parentNode.replaceChild(newSelectBtn, selectImageBtn);
    
    const newUploadBtn = uploadImageBtn.cloneNode(true);
    uploadImageBtn.parentNode.replaceChild(newUploadBtn, uploadImageBtn);
    
    newSelectBtn.addEventListener('click', showImageSelectModal);
    newUploadBtn.addEventListener('click', showImageUploadModal);
    
    // 更新保存按钮事件
    const saveBtn = document.getElementById('saveProductBtn');
    // 移除之前的事件监听器
    const newSaveBtn = saveBtn.cloneNode(true);
    saveBtn.parentNode.replaceChild(newSaveBtn, saveBtn);
    
    newSaveBtn.addEventListener('click', async function(e) {
      e.preventDefault();
      
      try {
        const name = document.getElementById('productName').value;
        const category_id = document.getElementById('productCategory').value;
        const price = document.getElementById('productPrice').value;
        const visibility = document.getElementById('productVisibility').value;
        const is_available = document.getElementById('productStatus').value === 'true';
        const cover_image = document.getElementById('productCoverImage').value;
        const content = quill ? quill.root.innerHTML : '';
        
        const body = {
          name: name,
          category_id: category_id || null,
          price: price,
          visibility: visibility,
          is_available: is_available,
          description: content,
          cover_image: cover_image || null
        };
        
        const response = await adminPanel.apiRequest('/api/products', {
          method: 'POST',
          body: JSON.stringify(body)
        });
        
        // 检查响应状态
        if (response.status === 401) {
          // 令牌失效，已经由apiRequest处理了重定向
          return;
        }
        
        if (!response.ok) {
          throw new Error('添加产品失败');
        }
        
        const data = await response.json();
        if (data.success) {
          const productModal = bootstrap.Modal.getInstance(modal);
          if (productModal) {
            productModal.hide();
          }
          loadProducts();
          adminPanel.showMessage('产品添加成功', 'success');
        } else {
          adminPanel.showMessage('添加产品失败：' + data.message, 'error');
        }
      } catch (error) {
        console.error('Error adding product:', error);
        adminPanel.showMessage('添加产品失败，请检查网络连接', 'error');
      }
    });
    
    // 显示模态框
    const productModal = new bootstrap.Modal(modal);
    productModal.show();
  }
  
  // 加载产品分类选项
  async function loadCategoriesForProduct() {
    try {
      const response = await adminPanel.apiRequest('/api/product-categories/list')
      
      if (!response.ok) {
        throw new Error('获取分类失败')
      }
      
      const data = await response.json()
      if (data.success) {
        const categories = data.data
        const select = document.getElementById('productCategory')
        select.innerHTML = ''
        
        // 添加默认选项
        const defaultOption = document.createElement('option')
        defaultOption.value = ''
        defaultOption.textContent = '所有分类'
        select.appendChild(defaultOption)
        
        // 添加分类选项
        categories.forEach(category => {
          const option = document.createElement('option')
          option.value = category.id
          option.textContent = category.name
          select.appendChild(option)
        })
      }
    } catch (error) {
      console.error('Error loading categories for product:', error)
      adminPanel.showMessage('加载分类失败，请检查网络连接', 'error');
    }
  }
  
  // 加载产品列表页面的分类筛选选项
  async function loadCategoriesForFilter() {
    try {
      const response = await adminPanel.apiRequest('/api/product-categories/list')
      
      if (!response.ok) {
        throw new Error('获取分类失败')
      }
      
      const data = await response.json()
      if (data.success) {
        const categories = data.data
        const select = document.getElementById('categoryFilter')
        select.innerHTML = ''
        
        // 添加默认选项
        const defaultOption = document.createElement('option')
        defaultOption.value = ''
        defaultOption.textContent = '所有分类'
        select.appendChild(defaultOption)
        
        // 添加分类选项
        categories.forEach(category => {
          const option = document.createElement('option')
          option.value = category.id
          option.textContent = category.name
          select.appendChild(option)
        })
      }
    } catch (error) {
      console.error('Error loading categories for filter:', error)
      adminPanel.showMessage('加载分类失败，请检查网络连接', 'error');
    }
  }
  
  // 显示编辑产品表单
  async function showEditProductForm(id) {
    console.log('显示编辑产品表单，产品ID:', id);
    
    // 检查ID是否有效
    if (!id) {
      console.error('产品ID无效:', id);
      adminPanel.showMessage('产品ID无效', 'error');
      return;
    }
    
    try {
      // 获取产品信息
      const productResponse = await adminPanel.apiRequest(`/api/products/${id}`)
      
      if (!productResponse.ok) {
        throw new Error('获取产品信息失败，状态码: ' + productResponse.status)
      }
      
      const productData = await productResponse.json()
      console.log('获取到的产品数据:', productData);
      
      // 检查API响应结构
      let product;
      if (productData.success) {
        // 如果响应包含success字段，产品数据在data字段中
        product = productData.data || productData;
      } else {
        // 如果响应直接是产品数据
        product = productData;
      }
      
      // 获取分类信息用于下拉框
      const categoriesResponse = await adminPanel.apiRequest('/api/product-categories/list')
      
      if (!categoriesResponse.ok) {
        throw new Error('获取分类信息失败')
      }
      
      const categoriesData = await categoriesResponse.json()
      if (!categoriesData.success) {
        throw new Error('获取分类信息失败：' + categoriesData.message)
      }
      
      const categories = categoriesData.data
      
      // 使用已存在的模态框而不是创建新的
      const modal = document.getElementById('productModal');
      const modalTitle = modal.querySelector('.modal-title');
      const form = modal.querySelector('form');
      
      // 更新模态框标题
      modalTitle.textContent = '编辑产品';
      
      // 填充表单数据
      document.getElementById('productId').value = product.id;
      document.getElementById('productName').value = product.name;
      document.getElementById('productPrice').value = product.price;
      
      // 填充分类选择
      const categorySelect = document.getElementById('productCategory');
      categorySelect.innerHTML = '';
      categories.forEach(category => {
        const option = document.createElement('option');
        option.value = category.id;
        option.textContent = category.name;
        if (category.id == product.category_id) {
          option.selected = true;
        }
        categorySelect.appendChild(option);
      });
      
      // 设置可见性和状态
      document.getElementById('productVisibility').value = product.visibility;
      document.getElementById('productStatus').value = product.is_available ? 'true' : 'false';
      
      // 设置封面图片
      const coverImageInput = document.getElementById('productCoverImage');
      const coverImagePreview = document.getElementById('coverImagePreview');
      const previewImg = coverImagePreview.querySelector('img');
      
      coverImageInput.value = product.cover_image || '';
      if (product.cover_image) {
        // 检查cover_image是否已经是完整URL，如果不是则添加前缀
        const imageUrl = product.cover_image.startsWith('http') || product.cover_image.startsWith('/api/images/public/') 
          ? product.cover_image 
          : `/api/images/public/${product.cover_image}`;
        previewImg.src = imageUrl;
        coverImagePreview.style.display = 'block';
      } else {
        coverImagePreview.style.display = 'none';
      }
      
      // 销毁现有的编辑器实例
      if (quill) {
        quill.destroy();
        quill = null;
      }
      
      // 初始化编辑器并设置内容
      setTimeout(() => {
        initQuill();
        if (quill) {
          quill.root.innerHTML = product.description || '';
        }
      }, 100);
      
      // 绑定封面图片选择和上传事件
      const selectImageBtn = document.getElementById('selectImageBtn');
      const uploadImageBtn = document.getElementById('uploadImageBtn');
      
      // 移除旧的事件监听器并添加新的
      const newSelectBtn = selectImageBtn.cloneNode(true);
      selectImageBtn.parentNode.replaceChild(newSelectBtn, selectImageBtn);
      
      const newUploadBtn = uploadImageBtn.cloneNode(true);
      uploadImageBtn.parentNode.replaceChild(newUploadBtn, uploadImageBtn);
      
      newSelectBtn.addEventListener('click', showImageSelectModal);
      newUploadBtn.addEventListener('click', showImageUploadModal);
      
      // 更新保存按钮事件
      const saveBtn = document.getElementById('saveProductBtn');
      // 移除之前的事件监听器
      const newSaveBtn = saveBtn.cloneNode(true);
      saveBtn.parentNode.replaceChild(newSaveBtn, saveBtn);
      
      newSaveBtn.addEventListener('click', async function(e) {
        e.preventDefault();
        
        try {
          const name = document.getElementById('productName').value;
          const category_id = document.getElementById('productCategory').value;
          const price = document.getElementById('productPrice').value;
          const visibility = document.getElementById('productVisibility').value;
          const is_available = document.getElementById('productStatus').value === 'true';
          const cover_image = document.getElementById('productCoverImage').value;
          const content = quill ? quill.root.innerHTML : '';
          
          const body = {
            name: name,
            category_id: category_id || null,
            price: price,
            visibility: visibility,
            is_available: is_available,
            description: content,
            cover_image: cover_image || null
          };
          
          const response = await adminPanel.apiRequest(`/api/products/${id}`, {
            method: 'PUT',
            body: JSON.stringify(body)
          });
          
          // 检查响应状态
          if (response.status === 401) {
            // 令牌失效，已经由apiRequest处理了重定向
            return;
          }
          
          if (!response.ok) {
            throw new Error('编辑产品失败');
          }
          
          const data = await response.json();
          if (data.success) {
            const productModalInstance = bootstrap.Modal.getInstance(modal);
            if (productModalInstance) {
              // 在隐藏模态框前先移除焦点元素，避免aria-hidden属性冲突
              const closeBtn = modal.querySelector('.btn-close');
              if (closeBtn) {
                closeBtn.blur();
              }
              const saveProductBtn = document.getElementById('saveProductBtn');
              if (saveProductBtn) {
                saveProductBtn.blur();
              }
              productModalInstance.hide();
            }
            loadProducts();
            adminPanel.showMessage('产品编辑成功', 'success');
          } else {
            adminPanel.showMessage('编辑产品失败：' + data.message, 'error');
          }
        } catch (error) {
          console.error('Error editing product:', error);
          adminPanel.showMessage('编辑产品失败，请检查网络连接', 'error');
        }
      });
      
      // 显示模态框
      const productModalInstance = new bootstrap.Modal(modal);
      productModalInstance.show();
    } catch (error) {
      console.error('Error showing edit product form:', error);
      adminPanel.showMessage('获取产品信息失败，请检查网络连接', 'error');
    }
  }
  
  // 删除产品
  async function deleteProduct(id) {
    if (confirm('确定要删除这个产品吗？')) {
      try {
        const response = await adminPanel.apiRequest(`/api/products/${id}`, {
          method: 'DELETE'
        });
        
        // 检查响应状态
        if (response.status === 401) {
          // 令牌失效，已经由apiRequest处理了重定向
          return;
        }
        
        if (!response.ok) {
          // 尝试获取详细的错误信息
          try {
            const errorData = await response.json();
            const errorMessage = errorData.message || errorData.error || '删除产品失败';
            
            // 根据不同的错误状态显示不同的消息
            if (response.status === 500) {
              adminPanel.showMessage('服务器内部错误：' + errorMessage, 'error');
            } else if (response.status === 404) {
              adminPanel.showMessage('产品不存在或已被删除', 'error');
            } else {
              adminPanel.showMessage(errorMessage, 'error');
            }
          } catch (parseError) {
            // 如果无法解析JSON响应，使用状态文本
            adminPanel.showMessage('删除产品失败：' + response.statusText, 'error');
          }
          
          return;
        }
        
        const data = await response.json();
        if (data.success) {
          loadProducts();
          adminPanel.showMessage('产品删除成功', 'success');
        } else {
          adminPanel.showMessage('删除产品失败：' + (data.message || data.error), 'error');
        }
      } catch (error) {
        console.error('Error deleting product:', error);
        adminPanel.showMessage('删除产品失败，请检查网络连接', 'error');
      }
    }
  }
  
  // 搜索产品
  async function searchProducts(page = 1) {
    const searchTerm = document.getElementById('searchInput').value;
    const categoryId = document.getElementById('categoryFilter').value;
    
    try {
      let url = `/api/products?page=${page}&limit=10`;
      const params = [];
      
      if (categoryId) {
        params.push(`category_id=${categoryId}`);
      }
      
      if (searchTerm) {
        params.push(`search=${encodeURIComponent(searchTerm)}`);
      }
      
      if (params.length > 0) {
        url += `&${params.join('&')}`;
      }
      
      const response = await adminPanel.apiRequest(url);
      
      if (!response.ok) {
        throw new Error('搜索产品失败');
      }
      
      const data = await response.json();
      if (data.data) {
        let products = data.data;
        
        // 应用搜索过滤
        if (searchTerm) {
          products = products.filter(product => 
            product.name.toLowerCase().includes(searchTerm.toLowerCase())
          );
        }
        
        if (categoryId) {
          products = products.filter(product => 
            product.category_id == categoryId
          );
        }
        
        const tbody = document.getElementById('productsTable').querySelector('tbody');
        tbody.innerHTML = '';
        
        // 获取所有分类用于映射
        const categoriesResponse = await adminPanel.apiRequest('/api/product-categories/list');
        const categoriesData = await categoriesResponse.json();
        const categoryMap = {};
        
        if (categoriesData.success) {
          categoriesData.data.forEach(category => {
            categoryMap[category.id] = category.name;
          });
        }
        
        products.forEach(product => {
          // 处理封面图片URL
          let coverImageHtml = '';
          if (product.cover_image) {
            const imageUrl = product.cover_image.startsWith('http') || product.cover_image.startsWith('/api/images/public/') 
              ? product.cover_image 
              : `/api/images/public/${product.cover_image}`;
            coverImageHtml = `<img src="${imageUrl}" alt="封面" style="width: 50px; height: 50px; object-fit: cover; border-radius: 4px;">`;
          } else {
            coverImageHtml = '<span class="text-muted">无封面</span>';
          }
          
          const row = document.createElement('tr');
          row.innerHTML = `
            <td>${product.id}</td>
            <td>${product.name}</td>
            <td>${coverImageHtml}</td>
            <td>${categoryMap[product.category_id] || '无'}</td>  <!-- 显示分类名称 -->
            <td>¥${product.price || '0.00'}</td>
            <td><span class="badge bg-${product.is_available ? 'success' : 'secondary'}">${product.is_available ? '可用' : '不可用'}</span></td>
            <td><span class="badge bg-${product.visibility === 'public' ? 'primary' : 'secondary'}">${product.visibility === 'public' ? '公开' : '私有'}</span></td>
            <td>${new Date(product.created_at).toLocaleDateString('zh-CN')}</td>
            <td>
              <button class="btn btn-sm btn-primary edit-product-btn" data-id="${product.id}">编辑</button>
              <button class="btn btn-sm btn-danger delete-product-btn" data-id="${product.id}">删除</button>
            </td>
          `;
          tbody.appendChild(row);
        });
        
        // 渲染分页控件
        if (data.pagination) {
          renderPagination(data.pagination, searchProducts);
        }
      } else {
        adminPanel.showMessage('搜索产品失败：' + data.message, 'error');
      }
    } catch (error) {
      console.error('Error searching products:', error);
      adminPanel.showMessage('搜索产品失败，请检查网络连接', 'error');
    }
  }
  
  // 显示图片选择模态框
  async function showImageSelectModal() {
    const modal = document.getElementById('imageSelectModal');
    
    // 如果模态框不存在，则创建一个
    if (!modal) {
      const newModal = document.createElement('div');
      newModal.className = 'modal fade';
      newModal.id = 'imageSelectModal';
      newModal.tabIndex = '-1';
      newModal.innerHTML = `
        <div class="modal-dialog modal-xl">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">选择图片</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <div class="d-flex justify-content-between mb-3">
                <button class="btn btn-primary" id="refreshImagesBtn">
                  <i class="bi bi-arrow-repeat"></i> 刷新
                </button>
                <div>
                  <input type="text" class="form-control" id="imageSearchInput" placeholder="搜索图片...">
                </div>
              </div>
              <div class="row" id="imageGrid">
                <!-- 图片将通过JavaScript动态加载 -->
              </div>
              <nav>
                <ul class="pagination justify-content-center" id="imagePagination">
                  <!-- 分页将通过JavaScript动态加载 -->
                </ul>
              </nav>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
            </div>
          </div>
        </div>
      `;
      
      document.body.appendChild(newModal);
    }
    
    const imageSelectModal = new bootstrap.Modal(document.getElementById('imageSelectModal'));
    imageSelectModal.show();
    
    // 加载图片
    loadImagesForSelection();
    
    // 绑定刷新按钮事件（确保只绑定一次）
    const refreshBtn = document.getElementById('refreshImagesBtn');
    if (refreshBtn) {
      // 移除旧的事件监听器
      const newRefreshBtn = refreshBtn.cloneNode(true);
      refreshBtn.parentNode.replaceChild(newRefreshBtn, refreshBtn);
      newRefreshBtn.addEventListener('click', loadImagesForSelection);
    }
  }
  
  // 加载图片用于选择
  async function loadImagesForSelection() {
    try {
      const response = await adminPanel.apiRequest('/api/images');
      
      if (response.ok) {
        const result = await response.json();
        const images = result.data || [];
        
        const imageGrid = document.getElementById('imageGrid');
        if (imageGrid) {
          imageGrid.innerHTML = '';
          
          if (images.length === 0) {
            imageGrid.innerHTML = '<div class="col-12 text-center">暂无图片</div>';
            return;
          }
          
          images.forEach(image => {
            const col = document.createElement('div');
            col.className = 'col-md-3 mb-3';
            // 确保使用完整的URL路径显示图片
            const imageUrl = image.object_key.startsWith('http') || image.object_key.startsWith('/api/images/public/') 
              ? image.object_key 
              : `/api/images/public/${image.object_key}`;
              
            col.innerHTML = `
              <div class="card image-grid-item" data-object-key="${image.object_key}">
                <img src="${imageUrl}" class="card-img-top" alt="${image.original_name}" style="height: 150px; object-fit: cover;">
                <div class="card-body p-2">
                  <p class="card-text small text-truncate mb-0">${image.original_name}</p>
                </div>
              </div>
            `;
            imageGrid.appendChild(col);
          });
          
          // 绑定图片选择事件
          document.querySelectorAll('.image-grid-item').forEach(item => {
            // 移除旧的事件监听器
            const newItem = item.cloneNode(true);
            item.parentNode.replaceChild(newItem, item);
            
            newItem.addEventListener('click', function() {
              const objectKey = this.getAttribute('data-object-key');
              
              // 更新预览
              const coverImageInput = document.getElementById('productCoverImage');
              const coverImagePreview = document.getElementById('coverImagePreview');
              const previewImg = coverImagePreview.querySelector('img');
              
              if (coverImageInput) {
                coverImageInput.value = objectKey;
              }
              
              if (previewImg) {
                // 确保使用完整的URL路径
                const imageUrl = objectKey.startsWith('http') || objectKey.startsWith('/api/images/public/') 
                  ? objectKey 
                  : `/api/images/public/${objectKey}`;
                previewImg.src = imageUrl;
                coverImagePreview.style.display = 'block';
              }
              
              // 关闭模态框
              const modal = bootstrap.Modal.getInstance(document.getElementById('imageSelectModal'));
              if (modal) {
                modal.hide();
              }
            });
          });
        }
      }
    } catch (error) {
      console.error('加载图片失败:', error);
      adminPanel.showMessage('加载图片失败', 'error');
    }
  }
  
  // 显示图片上传模态框
  function showImageUploadModal() {
    const modal = document.getElementById('imageUploadModal');
    
    // 如果模态框不存在，则创建一个
    if (!modal) {
      const newModal = document.createElement('div');
      newModal.className = 'modal fade';
      newModal.id = 'imageUploadModal';
      newModal.tabIndex = '-1';
      newModal.innerHTML = `
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">上传图片</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <form id="imageUploadForm">
                <div class="mb-3">
                  <label for="imageFile" class="form-label">选择图片</label>
                  <input class="form-control" type="file" id="imageFile" accept="image/*">
                </div>
                <div class="mb-3">
                  <label for="imageAltText" class="form-label">替代文本</label>
                  <input type="text" class="form-control" id="imageAltText">
                </div>
                <div class="mb-3">
                  <label for="imageDescription" class="form-label">描述</label>
                  <textarea class="form-control" id="imageDescription" rows="3"></textarea>
                </div>
              </form>
              <div id="uploadResult" class="mt-3" style="display: none;"></div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
              <button type="button" class="btn btn-primary" id="uploadImageButton">上传</button>
            </div>
          </div>
        </div>
      `;
      
      document.body.appendChild(newModal);
      
      // 绑定上传按钮事件
      const uploadBtn = newModal.querySelector('#uploadImageButton');
      if (uploadBtn) {
        uploadBtn.addEventListener('click', handleImageUpload);
      }
    }
    
    const imageUploadModal = new bootstrap.Modal(document.getElementById('imageUploadModal'));
    imageUploadModal.show();
    
    // 确保上传按钮事件已绑定
    const uploadBtn = document.getElementById('uploadImageButton');
    if (uploadBtn) {
      // 移除旧的事件监听器
      const newUploadBtn = uploadBtn.cloneNode(true);
      uploadBtn.parentNode.replaceChild(newUploadBtn, uploadBtn);
      newUploadBtn.addEventListener('click', handleImageUpload);
    }
  }
  
  // 处理图片上传
  async function handleImageUpload() {
    const fileInput = document.getElementById('imageFile');
    const altTextInput = document.getElementById('imageAltText');
    const descriptionInput = document.getElementById('imageDescription');
    
    const file = fileInput.files[0];
    if (!file) {
      adminPanel.showMessage('请选择要上传的图片', 'error');
      return;
    }
    
    try {
      // 显示上传进度
      const uploadResult = document.getElementById('uploadResult');
      if (uploadResult) {
        uploadResult.style.display = 'block';
        uploadResult.innerHTML = '<div class="alert alert-info">正在上传...</div>';
      }
      
      // 上传文件
      const result = await adminPanel.uploadImage(file, altTextInput.value, descriptionInput.value);
      
      // 确保response不为null或undefined
      if (!result || !result.data) {
        adminPanel.showMessage('上传失败，请重试', 'error');
        return;
      }
      
      const imageData = result.data;
      
      // 检查object_key是否存在
      if (!imageData.object_key) {
        adminPanel.showMessage('图片上传成功，但无法获取图片信息', 'error');
        return;
      }
      
      adminPanel.showMessage('图片上传成功', 'success');
      
      // 更新预览
      const coverImageInput = document.getElementById('productCoverImage');
      const coverImagePreview = document.getElementById('coverImagePreview');
      const previewImg = coverImagePreview.querySelector('img');
      
      // 将object_key保存到封面图片字段
      if (coverImageInput) {
        coverImageInput.value = imageData.object_key;
      }
      
      if (previewImg) {
        // 确保使用完整的URL路径
        const imageUrl = imageData.url || `/api/images/public/${imageData.object_key}`;
        previewImg.src = imageUrl;
        coverImagePreview.style.display = 'block';
      }
      
      // 关闭模态框
      const modal = bootstrap.Modal.getInstance(document.getElementById('imageUploadModal'));
      if (modal) {
        modal.hide();
      }
    } catch (error) {
      console.error('上传图片出错:', error);
      const uploadResult = document.getElementById('uploadResult');
      if (uploadResult) {
        uploadResult.style.display = 'block';
        uploadResult.innerHTML = `<div class="alert alert-danger">上传图片时发生错误: ${error.message}</div>`;
      }
      adminPanel.showMessage('上传图片时发生错误: ' + error.message, 'error');
    }
  }
  
  // 初始化页面
  loadCategories();
  loadCategoriesForFilter();
  loadProducts(1);
  
  // 修复添加产品按钮的事件绑定
  const addProductBtn = document.getElementById('addProductBtn');
  if (addProductBtn) {
    // 使用标准方式移除旧的事件监听器
    const newAddProductBtn = addProductBtn.cloneNode(false);
    // 复制所有属性
    for (let i = 0; i < addProductBtn.attributes.length; i++) {
      const attr = addProductBtn.attributes[i];
      newAddProductBtn.setAttribute(attr.name, attr.value);
    }
    // 复制子元素
    while (addProductBtn.firstChild) {
      newAddProductBtn.appendChild(addProductBtn.firstChild);
    }
    addProductBtn.parentNode.replaceChild(newAddProductBtn, addProductBtn);
    newAddProductBtn.addEventListener('click', function() {
      showAddProductForm();
    });
  }
  
  // 修复添加分类按钮的事件绑定
  const addCategoryBtn = document.getElementById('addCategoryBtn');
  if (addCategoryBtn) {
    // 使用标准方式移除旧的事件监听器
    const newAddCategoryBtn = addCategoryBtn.cloneNode(false);
    // 复制所有属性
    for (let i = 0; i < addCategoryBtn.attributes.length; i++) {
      const attr = addCategoryBtn.attributes[i];
      newAddCategoryBtn.setAttribute(attr.name, attr.value);
    }
    // 复制子元素
    while (addCategoryBtn.firstChild) {
      newAddCategoryBtn.appendChild(addCategoryBtn.firstChild);
    }
    addCategoryBtn.parentNode.replaceChild(newAddCategoryBtn, addCategoryBtn);
    newAddCategoryBtn.addEventListener('click', function() {
      showAddCategoryForm();
    });
  }
  
  // 绑定搜索事件
  const searchInput = document.getElementById('searchInput');
  if (searchInput) {
    // 使用标准方式移除旧的事件监听器
    const newSearchInput = searchInput.cloneNode(false);
    // 复制所有属性
    for (let i = 0; i < searchInput.attributes.length; i++) {
      const attr = searchInput.attributes[i];
      newSearchInput.setAttribute(attr.name, attr.value);
    }
    // 复制子元素
    while (searchInput.firstChild) {
      newSearchInput.appendChild(searchInput.firstChild);
    }
    searchInput.parentNode.replaceChild(newSearchInput, searchInput);
    newSearchInput.addEventListener('input', function() {
      searchProducts(1);
    });
  }
  
  // 绑定分类过滤事件
  const categoryFilter = document.getElementById('categoryFilter');
  if (categoryFilter) {
    // 使用标准方式移除旧的事件监听器
    const newCategoryFilter = categoryFilter.cloneNode(false);
    // 复制所有属性
    for (let i = 0; i < categoryFilter.attributes.length; i++) {
      const attr = categoryFilter.attributes[i];
      newCategoryFilter.setAttribute(attr.name, attr.value);
    }
    // 复制子元素
    while (categoryFilter.firstChild) {
      newCategoryFilter.appendChild(categoryFilter.firstChild);
    }
    categoryFilter.parentNode.replaceChild(newCategoryFilter, categoryFilter);
    newCategoryFilter.addEventListener('change', function() {
      searchProducts(1);
    });
  }
  
  // 绑定刷新按钮事件
  const refreshBtn = document.getElementById('refreshBtn');
  if (refreshBtn) {
    // 使用标准方式移除旧的事件监听器
    const newRefreshBtn = refreshBtn.cloneNode(false);
    // 复制所有属性
    for (let i = 0; i < refreshBtn.attributes.length; i++) {
      const attr = refreshBtn.attributes[i];
      newRefreshBtn.setAttribute(attr.name, attr.value);
    }
    // 复制子元素
    while (refreshBtn.firstChild) {
      newRefreshBtn.appendChild(refreshBtn.firstChild);
    }
    refreshBtn.parentNode.replaceChild(newRefreshBtn, refreshBtn);
    newRefreshBtn.addEventListener('click', function() {
      loadCategories();
      loadCategoriesForFilter();
      loadProducts(1);
    });
  }
  
  // 绑定封面图片选择和上传事件
  const selectImageBtn = document.getElementById('selectImageBtn');
  if (selectImageBtn) {
    // 使用标准方式移除旧的事件监听器
    const newSelectBtn = selectImageBtn.cloneNode(false);
    // 复制所有属性
    for (let i = 0; i < selectImageBtn.attributes.length; i++) {
      const attr = selectImageBtn.attributes[i];
      newSelectBtn.setAttribute(attr.name, attr.value);
    }
    // 复制子元素
    while (selectImageBtn.firstChild) {
      newSelectBtn.appendChild(selectImageBtn.firstChild);
    }
    selectImageBtn.parentNode.replaceChild(newSelectBtn, selectImageBtn);
    newSelectBtn.addEventListener('click', showImageSelectModal);
  }
  
  const uploadImageBtn = document.getElementById('uploadImageBtn');
  if (uploadImageBtn) {
    // 使用标准方式移除旧的事件监听器
    const newUploadBtn = uploadImageBtn.cloneNode(false);
    // 复制所有属性
    for (let i = 0; i < uploadImageBtn.attributes.length; i++) {
      const attr = uploadImageBtn.attributes[i];
      newUploadBtn.setAttribute(attr.name, attr.value);
    }
    // 复制子元素
    while (uploadImageBtn.firstChild) {
      newUploadBtn.appendChild(uploadImageBtn.firstChild);
    }
    uploadImageBtn.parentNode.replaceChild(newUploadBtn, uploadImageBtn);
    newUploadBtn.addEventListener('click', showImageUploadModal);
  }
  
  // 事件委托已在admin.js中处理
});

// 将函数暴露到全局作用域，以便在admin.js中可以调用
window.showEditCategoryForm = function(id) {
  // 重新定义这个函数，因为原始函数在DOMContentLoaded内部
  document.dispatchEvent(new CustomEvent('showEditCategoryForm', { detail: id }));
};

window.deleteCategory = function(id) {
  // 重新定义这个函数，因为原始函数在DOMContentLoaded内部
  document.dispatchEvent(new CustomEvent('deleteCategory', { detail: id }));
};

window.showEditProductForm = function(id) {
  // 重新定义这个函数，因为原始函数在DOMContentLoaded内部
  document.dispatchEvent(new CustomEvent('showEditProductForm', { detail: id }));
};

window.deleteProduct = function(id) {
  // 重新定义这个函数，因为原始函数在DOMContentLoaded内部
  document.dispatchEvent(new CustomEvent('deleteProduct', { detail: id }));
};

// 确保函数正确暴露到全局作用域
if (typeof window !== 'undefined') {
    window.showEditProductForm = showEditProductForm;
    window.deleteProduct = deleteProduct;
}