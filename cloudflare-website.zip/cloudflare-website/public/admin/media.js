document.addEventListener('DOMContentLoaded', async function() {
    if (!adminPanel.authToken) {
        window.location.href = '/admin/login.html';
        return;
    }

    // 初始化变量
    let currentPage = 1;
    let currentImageId = null;
    const itemsPerPage = 10;

    // DOM元素
    const refreshBtn = document.getElementById('refreshBtn');
    const uploadImageBtn = document.getElementById('uploadImageBtn');
    const searchInput = document.getElementById('searchInput');
    const sortBy = document.getElementById('sortBy');
    const mediaTable = document.getElementById('mediaTable').querySelector('tbody');
    const pagination = document.getElementById('pagination');
    const uploadModal = new bootstrap.Modal(document.getElementById('uploadModal'));
    const imageDetailModal = new bootstrap.Modal(document.getElementById('imageDetailModal'));

    // 事件监听器
    refreshBtn.addEventListener('click', () => loadMediaList());
    uploadImageBtn.addEventListener('click', () => uploadModal.show());
    searchInput.addEventListener('input', () => {
        currentPage = 1;
        loadMediaList();
    });
    sortBy.addEventListener('change', () => {
        currentPage = 1;
        loadMediaList();
    });

    // 上传表单事件
    document.getElementById('submitUploadBtn').addEventListener('click', handleImageUpload);
    
    // 保存图片信息事件
    document.getElementById('saveImageInfoBtn').addEventListener('click', saveImageInfo);

    // 初始化加载
    loadMediaList();

    // 加载媒体列表
    async function loadMediaList() {
        try {
            const search = searchInput.value;
            const sort = sortBy.value;
            const offset = (currentPage - 1) * itemsPerPage;
            
            // 构造查询参数
            const params = new URLSearchParams({
                page: currentPage,
                limit: itemsPerPage,
                sort: sort
            });
            
            if (search) {
                params.append('search', search);
            }
            
            const response = await adminPanel.apiRequest(`/api/images?${params.toString()}`);
            
            if (response.ok) {
                const result = await response.json();
                renderMediaList(result.data || []);
                renderPagination(result.total || 0);
            } else {
                adminPanel.showMessage('加载媒体列表失败', 'error');
            }
        } catch (error) {
            console.error('加载媒体列表出错:', error);
            adminPanel.showMessage('加载媒体列表时发生错误', 'error');
        }
    }

    // 渲染媒体列表
    function renderMediaList(images) {
        mediaTable.innerHTML = '';
        
        if (images.length === 0) {
            const row = document.createElement('tr');
            row.innerHTML = '<td colspan="8" class="text-center">暂无图片数据</td>';
            mediaTable.appendChild(row);
            return;
        }
        
        images.forEach(image => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>
                    <img src="/api/images/public/${image.object_key}" alt="${image.original_name}" 
                         style="width: 50px; height: 50px; object-fit: cover;" class="img-thumbnail">
                </td>
                <td>${image.original_name}</td>
                <td>${image.mime_type}</td>
                <td>${formatFileSize(image.size)}</td>
                <td>${image.uploader_id || '未知'}</td>
                <td>${formatDate(image.uploaded_at)}</td>
                <td>
                    <span class="badge ${image.is_referenced ? 'bg-success' : 'bg-secondary'}">
                        ${image.reference_status || (image.is_referenced ? '已引用' : '未引用')}
                    </span>
                </td>
                <td>${image.usage_count || 0}</td>
                <td>
                    <button class="btn btn-sm btn-outline-primary view-btn" data-id="${image.id}">
                        <i class="bi bi-eye"></i>
                    </button>
                    <button class="btn btn-sm btn-outline-danger delete-btn" data-id="${image.id}">
                        <i class="bi bi-trash"></i>
                    </button>
                </td>
            `;
            mediaTable.appendChild(row);
        });
        
        // 绑定事件
        document.querySelectorAll('.view-btn').forEach(btn => {
            btn.addEventListener('click', () => viewImageDetails(btn.dataset.id));
        });
        
        document.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', () => deleteImage(btn.dataset.id));
        });
    }

    // 渲染分页
    function renderPagination(totalItems) {
        const totalPages = Math.ceil(totalItems / itemsPerPage);
        pagination.innerHTML = '';
        
        if (totalPages <= 1) return;
        
        // 上一页
        const prevLi = document.createElement('li');
        prevLi.className = `page-item ${currentPage === 1 ? 'disabled' : ''}`;
        prevLi.innerHTML = `<a class="page-link" href="#">上一页</a>`;
        if (currentPage > 1) {
            prevLi.addEventListener('click', (e) => {
                e.preventDefault();
                currentPage--;
                loadMediaList();
            });
        }
        pagination.appendChild(prevLi);
        
        // 页码
        for (let i = 1; i <= totalPages; i++) {
            const li = document.createElement('li');
            li.className = `page-item ${i === currentPage ? 'active' : ''}`;
            li.innerHTML = `<a class="page-link" href="#">${i}</a>`;
            li.addEventListener('click', (e) => {
                e.preventDefault();
                currentPage = i;
                loadMediaList();
            });
            pagination.appendChild(li);
        }
        
        // 下一页
        const nextLi = document.createElement('li');
        nextLi.className = `page-item ${currentPage === totalPages ? 'disabled' : ''}`;
        nextLi.innerHTML = `<a class="page-link" href="#">下一页</a>`;
        if (currentPage < totalPages) {
            nextLi.addEventListener('click', (e) => {
                e.preventDefault();
                currentPage++;
                loadMediaList();
            });
        }
        pagination.appendChild(nextLi);
    }

    // 查看图片详情
    async function viewImageDetails(id) {
        try {
            const response = await adminPanel.apiRequest(`/api/images/${id}`);
            
            if (response.ok) {
                const result = await response.json();
                const image = result.data;
                
                // 填充详情模态框
                const imagePreview = document.getElementById('detailImagePreview');
                imagePreview.src = `/api/images/public/${image.object_key}`;
                
                // 确保图片预览区域正确显示
                imagePreview.onload = function() {
                    // 图片加载完成后，确保容器正确显示
                    const container = imagePreview.parentElement;
                    container.style.display = 'flex';
                    
                    // 确保图片保持3:4比例显示
                    const img = this;
                    const containerWidth = container.offsetWidth;
                    const containerHeight = container.offsetHeight;
                    
                    // 根据容器尺寸调整图片显示方式
                    if (img.naturalWidth / img.naturalHeight > containerWidth / containerHeight) {
                        // 图片较宽，以宽度为准
                        img.style.width = '100%';
                        img.style.height = 'auto';
                    } else {
                        // 图片较高，以高度为准
                        img.style.width = 'auto';
                        img.style.height = '100%';
                    }
                };
                
                // 如果图片加载失败，显示占位符
                imagePreview.onerror = function() {
                    this.src = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwIiBoZWlnaHQ9IjEwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwIiBoZWlnaHQ9IjEwMCIgZmlsbD0iI2NjYyIvPjx0ZXh0IHg9IjUwIiB5PSI1MCIgZm9udC1zaXplPSIxMiIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPkltYWdlIE5vdCBGb3VuZDwvdGV4dD48L3N2Zz4=';
                };
                
                document.getElementById('detailOriginalName').textContent = image.original_name;
                document.getElementById('detailObjectKey').textContent = image.object_key;
                document.getElementById('detailMimeType').textContent = image.mime_type;
                document.getElementById('detailSize').textContent = formatFileSize(image.size);
                document.getElementById('detailUploader').textContent = image.uploader_name || image.uploader_id || '未知';
                document.getElementById('detailUploadedAt').textContent = formatDate(image.uploaded_at);
                document.getElementById('detailReferenceStatus').textContent = image.reference_status || (image.is_referenced ? '已引用' : '未引用');
                document.getElementById('detailUsageCount').textContent = image.usage_count || 0;
                document.getElementById('detailPublicUrl').href = `/api/images/public/${image.object_key}`;
                document.getElementById('detailAltText').value = image.alt_text || '';
                document.getElementById('detailDescription').value = image.description || '';
                
                // 显示引用位置
                const usageInfoElement = document.getElementById('detailUsageInfo');
                if (usageInfoElement) {
                    // 检查是否有引用位置，确保正确处理各种情况
                    // 不再依赖is_referenced字段，而是直接检查references数组
                    if (image.references && Array.isArray(image.references) && image.references.length > 0) {
                        let referencesHtml = '<div class="mt-3"><h6>引用位置:</h6><ul class="list-group">';
                        image.references.forEach(reference => {
                            // 限制引用名称长度
                            const name = reference.name && reference.name.length > 50 ? reference.name.substring(0, 50) + '...' : (reference.name || '未命名');
                            referencesHtml += `<li class="list-group-item">${reference.type || '未知类型'}: <a href="${reference.path || '#'}" target="_blank">${name}</a></li>`;
                        });
                        referencesHtml += '</ul></div>';
                        usageInfoElement.innerHTML = referencesHtml;
                    } else {
                        usageInfoElement.innerHTML = '<div class="mt-3"><h6>引用位置:</h6><p class="text-muted">暂无引用</p></div>';
                    }
                }
                
                currentImageId = id;
                imageDetailModal.show();
            } else {
                adminPanel.showMessage('获取图片详情失败', 'error');
            }
        } catch (error) {
            console.error('获取图片详情出错:', error);
            adminPanel.showMessage('获取图片详情时发生错误', 'error');
        }
    }

    // 保存图片信息
    async function saveImageInfo() {
        if (!currentImageId) return;
        
        try {
            const altText = document.getElementById('detailAltText').value;
            const description = document.getElementById('detailDescription').value;
            
            const response = await adminPanel.apiRequest(`/api/images/${currentImageId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    alt_text: altText,
                    description: description
                })
            });
            
            if (response.ok) {
                adminPanel.showMessage('图片信息保存成功', 'success');
                imageDetailModal.hide();
                loadMediaList();
            } else {
                adminPanel.showMessage('保存图片信息失败', 'error');
            }
        } catch (error) {
            console.error('保存图片信息出错:', error);
            adminPanel.showMessage('保存图片信息时发生错误', 'error');
        }
    }

    // 删除图片
    async function deleteImage(id) {
        if (!confirm('确定要删除这张图片吗？此操作不可恢复。')) {
            return;
        }
        
        try {
            const response = await adminPanel.apiRequest(`/api/images/${id}`, {
                method: 'DELETE'
            });
            
            if (response.ok) {
                adminPanel.showMessage('图片删除成功', 'success');
                loadMediaList();
            } else {
                const result = await response.json();
                adminPanel.showMessage(`删除图片失败: ${result.error || '未知错误'}`, 'error');
            }
        } catch (error) {
            console.error('删除图片出错:', error);
            adminPanel.showMessage('删除图片时发生错误', 'error');
        }
    }

    // 处理图片上传
    async function handleImageUpload() {
        const fileInput = document.getElementById('imageFile');
        const altTextInput = document.getElementById('imageAltText');
        const descriptionInput = document.getElementById('imageDescription');
        
        const file = fileInput.files[0];
        if (!file) {
            adminPanel.showMessage('请选择要上传的图片', 'error');
            return;
        }
        
        try {
            // 显示上传进度
            const uploadProgress = document.getElementById('uploadProgress');
            const progressBar = uploadProgress.querySelector('.progress-bar');
            const uploadStatus = document.getElementById('uploadStatus');
            
            uploadProgress.style.display = 'block';
            progressBar.style.width = '0%';
            uploadStatus.textContent = '准备上传...';
            
            // 创建FormData
            const formData = new FormData();
            formData.append('file', file);
            formData.append('alt_text', altTextInput.value);
            formData.append('description', descriptionInput.value);
            
            // 上传文件
            const response = await adminPanel.apiRequest('/api/images/upload', {
                method: 'POST',
                body: formData
            });
            
            if (response.ok) {
                const result = await response.json();
                adminPanel.showMessage('图片上传成功', 'success');
                uploadModal.hide();
                loadMediaList();
                
                // 重置表单
                document.getElementById('uploadForm').reset();
            } else {
                // 尝试解析错误响应
                let errorMessage = '上传失败';
                try {
                    const result = await response.json();
                    errorMessage = result.error || '上传失败';
                } catch (e) {
                    // 如果无法解析JSON，使用状态文本
                    errorMessage = `上传失败: ${response.status} ${response.statusText}`;
                }
                adminPanel.showMessage(errorMessage, 'error');
            }
        } catch (error) {
            console.error('上传图片出错:', error);
            adminPanel.showMessage(`上传图片时发生错误: ${error.message}`, 'error');
        } finally {
            // 隐藏上传进度
            document.getElementById('uploadProgress').style.display = 'none';
        }
    }

    // 格式化文件大小
    function formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    // 格式化日期
    function formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('zh-CN') + ' ' + date.toLocaleTimeString('zh-CN');
    }
});