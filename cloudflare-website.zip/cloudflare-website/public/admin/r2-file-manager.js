// R2文件管理器JavaScript功能
class R2FileManager {
    constructor() {
        this.currentPath = '';
        this.selectedFiles = new Set();
        this.files = [];
        this.isGridView = false;
        this.init();
    }

    init() {
        // 初始化事件监听器
        this.bindEvents();
        
        // 加载根目录文件
        this.loadFiles();
    }

    bindEvents() {
        // 刷新按钮
        const refreshBtn = document.getElementById('refreshBtn');
        if (refreshBtn) {
            refreshBtn.addEventListener('click', () => {
                this.loadFiles();
            });
        }

        // 上传文件按钮
        const uploadFileBtn = document.getElementById('uploadFileBtn');
        if (uploadFileBtn) {
            uploadFileBtn.addEventListener('click', () => {
                this.showUploadModal();
            });
        }

        // 新建文件夹按钮
        const createFolderBtn = document.getElementById('createFolderBtn');
        if (createFolderBtn) {
            createFolderBtn.addEventListener('click', () => {
                this.showCreateFolderModal();
            });
        }

        // 删除选中按钮
        const deleteSelectedBtn = document.getElementById('deleteSelectedBtn');
        if (deleteSelectedBtn) {
            deleteSelectedBtn.addEventListener('click', () => {
                this.deleteSelectedFiles();
            });
        }

        // 下载按钮
        const downloadBtn = document.getElementById('downloadBtn');
        if (downloadBtn) {
            downloadBtn.addEventListener('click', () => {
                this.downloadSelectedFiles();
            });
        }

        // 全选复选框
        const selectAllCheckbox = document.getElementById('selectAllCheckbox');
        if (selectAllCheckbox) {
            selectAllCheckbox.addEventListener('change', (e) => {
                this.toggleSelectAll(e.target.checked);
            });
        }

        // 视图切换
        const viewToggle = document.getElementById('viewToggle');
        if (viewToggle) {
            viewToggle.addEventListener('change', (e) => {
                this.toggleView(e.target.checked);
            });
        }

        // 拖拽上传
        const uploadArea = document.getElementById('uploadArea');
        if (uploadArea) {
            uploadArea.addEventListener('dragover', (e) => {
                e.preventDefault();
                uploadArea.classList.add('dragover');
            });

            uploadArea.addEventListener('dragleave', () => {
                uploadArea.classList.remove('dragover');
            });

            uploadArea.addEventListener('drop', (e) => {
                e.preventDefault();
                uploadArea.classList.remove('dragover');
                
                const files = Array.from(e.dataTransfer.files);
                if (files.length > 0) {
                    this.uploadFiles(files);
                }
            });
        }

        // 面包屑导航点击事件
        document.getElementById('breadcrumb').addEventListener('click', (e) => {
            if (e.target.tagName === 'A') {
                e.preventDefault();
                const path = e.target.getAttribute('data-path') || '';
                this.navigateToPath(path);
            }
        });

        // 模态框确认按钮事件
        document.getElementById('confirmUploadBtn').addEventListener('click', () => {
            const fileInput = document.getElementById('fileInput');
            if (fileInput.files.length > 0) {
                this.uploadFiles(Array.from(fileInput.files));
            }
        });

        document.getElementById('confirmCreateFolderBtn').addEventListener('click', () => {
            const folderName = document.getElementById('folderName').value.trim();
            if (folderName) {
                this.createFolder(folderName);
            }
        });

        // 文件详情模态框中的下载按钮
        document.getElementById('downloadFileBtn').addEventListener('click', () => {
            const fileName = document.getElementById('detailName').textContent;
            const filePath = document.getElementById('detailPath').textContent;
            
            // 查找当前文件对象
            const file = this.files.find(f => f.key === filePath);
            if (file) {
                this.downloadFile(file);
                
                // 关闭模态框
                const modal = bootstrap.Modal.getInstance(document.getElementById('fileDetailModal'));
                if (modal) {
                    modal.hide();
                }
            }
        });
    }

    async loadFiles() {
        try {
            // 显示加载状态
            this.showLoading();

            const response = await adminPanel.apiRequest(`/api/r2/list?prefix=${encodeURIComponent(this.currentPath)}`);
            
            if (response.ok) {
                const data = await response.json();
                this.files = data.files || [];
                this.renderFileList();
                this.updateBreadcrumb();
                this.updateFileCount();
            } else {
                throw new Error('获取文件列表失败');
            }
        } catch (error) {
            console.error('加载文件列表失败:', error);
            adminPanel.showMessage('加载文件列表失败: ' + error.message, 'error');
        } finally {
            this.hideLoading();
        }
    }

    renderFileList() {
        const fileList = document.getElementById('fileList');
        const fileGrid = document.getElementById('fileGridView');
        
        if (this.isGridView) {
            // 网格视图
            fileGrid.innerHTML = '';
            fileGrid.classList.remove('d-none');
            document.getElementById('fileListView').classList.add('d-none');
            
            this.files.forEach(file => {
                const item = this.createGridItem(file);
                fileGrid.appendChild(item);
            });
        } else {
            // 列表视图
            fileList.innerHTML = '';
            document.getElementById('fileListView').classList.remove('d-none');
            fileGrid.classList.add('d-none');
            
            this.files.forEach(file => {
                const row = this.createTableRow(file);
                fileList.appendChild(row);
            });
        }
    }

    createTableRow(file) {
        const row = document.createElement('tr');
        row.className = 'file-item';
        row.dataset.key = file.key;
        
        // 格式化大小
        const size = file.size ? this.formatFileSize(file.size) : '-';
        
        // 格式化时间
        const modified = file.uploadedAt ? new Date(file.uploadedAt).toLocaleString('zh-CN') : '-';
        
        // 判断是否为文件夹
        const isFolder = file.key.endsWith('/');
        
        row.innerHTML = `
            <td>
                <input type="checkbox" class="file-checkbox" data-key="${file.key}">
            </td>
            <td>
                <i class="bi ${isFolder ? 'bi-folder folder-icon' : 'bi-file-earmark file-icon'}"></i>
                <a href="#" class="file-link" data-key="${file.key}">${file.name}</a>
            </td>
            <td>${size}</td>
            <td>${modified}</td>
            <td>
                ${isFolder ? 
                    `<button class="btn btn-sm btn-outline-primary view-btn" data-key="${file.key}">查看</button>` : 
                    `<button class="btn btn-sm btn-outline-info info-btn" data-key="${file.key}">详情</button>
                     <button class="btn btn-sm btn-outline-success download-btn" data-key="${file.key}">下载</button>`}
                <button class="btn btn-sm btn-outline-danger delete-btn" data-key="${file.key}">删除</button>
            </td>
        `;
        
        // 绑定事件
        row.querySelector('.file-checkbox').addEventListener('change', (e) => {
            this.toggleFileSelect(file.key, e.target.checked);
        });
        
        row.querySelector('.file-link').addEventListener('click', (e) => {
            e.preventDefault();
            if (isFolder) {
                this.navigateToPath(file.key);
            } else {
                this.showFileDetail(file);
            }
        });
        
        if (row.querySelector('.view-btn')) {
            row.querySelector('.view-btn').addEventListener('click', () => {
                this.navigateToPath(file.key);
            });
        }
        
        if (row.querySelector('.info-btn')) {
            row.querySelector('.info-btn').addEventListener('click', () => {
                this.showFileDetail(file);
            });
        }
        
        if (row.querySelector('.download-btn')) {
            row.querySelector('.download-btn').addEventListener('click', () => {
                this.downloadFile(file);
            });
        }
        
        row.querySelector('.delete-btn').addEventListener('click', () => {
            this.deleteFile(file.key);
        });
        
        return row;
    }

    createGridItem(file) {
        const item = document.createElement('div');
        item.className = 'file-grid-item';
        item.dataset.key = file.key;
        
        const isFolder = file.key.endsWith('/');
        
        item.innerHTML = `
            <div class="file-grid-icon ${isFolder ? 'bi-folder folder-grid-icon' : 'bi-file-earmark'}"></div>
            <div class="file-name text-truncate">${file.name}</div>
        `;
        
        // 绑定点击事件
        item.addEventListener('click', (e) => {
            if (e.ctrlKey || e.metaKey) {
                // Ctrl/Cmd点击切换选择
                const checkbox = item.querySelector('.file-checkbox');
                if (checkbox) {
                    checkbox.checked = !checkbox.checked;
                    this.toggleFileSelect(file.key, checkbox.checked);
                }
            } else if (isFolder) {
                this.navigateToPath(file.key);
            } else {
                this.showFileDetail(file);
            }
        });
        
        // 右键菜单
        item.addEventListener('contextmenu', (e) => {
            e.preventDefault();
            this.showContextMenu(e, file);
        });
        
        return item;
    }

    toggleFileSelect(key, selected) {
        if (selected) {
            this.selectedFiles.add(key);
        } else {
            this.selectedFiles.delete(key);
        }
        
        this.updateSelectionUI();
    }

    toggleSelectAll(selected) {
        this.selectedFiles.clear();
        
        if (selected) {
            this.files.forEach(file => {
                this.selectedFiles.add(file.key);
            });
        }
        
        this.updateSelectionUI();
    }

    updateSelectionUI() {
        // 更新复选框状态
        document.querySelectorAll('.file-checkbox').forEach(checkbox => {
            checkbox.checked = this.selectedFiles.has(checkbox.dataset.key);
        });
        
        // 更新选中文件网格项的样式
        document.querySelectorAll('.file-grid-item').forEach(item => {
            const key = item.dataset.key;
            if (this.selectedFiles.has(key)) {
                item.classList.add('selected');
            } else {
                item.classList.remove('selected');
            }
        });
        
        // 更新按钮状态
        const deleteBtn = document.getElementById('deleteSelectedBtn');
        const downloadBtn = document.getElementById('downloadBtn');
        
        if (this.selectedFiles.size > 0) {
            deleteBtn.disabled = false;
            downloadBtn.disabled = false;
        } else {
            deleteBtn.disabled = true;
            downloadBtn.disabled = true;
        }
    }

    navigateToPath(path) {
        this.currentPath = path;
        this.selectedFiles.clear();
        this.loadFiles();
    }

    updateBreadcrumb() {
        const breadcrumb = document.getElementById('breadcrumb');
        breadcrumb.innerHTML = '<li class="breadcrumb-item"><a href="#" data-path="">存储桶</a></li>';
        
        if (this.currentPath) {
            const parts = this.currentPath.split('/').filter(part => part);
            let path = '';
            
            parts.forEach((part, index) => {
                path += part + '/';
                if (index === parts.length - 1) {
                    breadcrumb.innerHTML += `<li class="breadcrumb-item active">${part}</li>`;
                } else {
                    breadcrumb.innerHTML += `<li class="breadcrumb-item"><a href="#" data-path="${path}">${part}</a></li>`;
                }
            });
        }
    }

    updateFileCount() {
        const count = this.files.length;
        document.getElementById('fileCount').textContent = `${count} 个项目`;
    }

    showUploadModal() {
        document.getElementById('uploadPath').value = this.currentPath;
        const uploadModal = new bootstrap.Modal(document.getElementById('uploadModal'));
        uploadModal.show();
    }

    showCreateFolderModal() {
        document.getElementById('folderName').value = '';
        const createFolderModal = new bootstrap.Modal(document.getElementById('createFolderModal'));
        createFolderModal.show();
    }

    async uploadFiles(files) {
        try {
            // 关闭模态框
            const uploadModal = bootstrap.Modal.getInstance(document.getElementById('uploadModal'));
            if (uploadModal) {
                uploadModal.hide();
            }
            
            // 显示上传进度
            const progress = document.getElementById('uploadProgress');
            const progressBar = progress.querySelector('.progress-bar');
            let progressText = document.getElementById('uploadProgressText');
            
            // 显示进度条和文本
            progress.classList.remove('d-none');
            progressText.classList.remove('d-none');
            
            // 更新进度文本
            progressText.textContent = '准备上传...';
            
            // 强制重绘以确保元素显示
            progress.offsetHeight;
            progressText.offsetHeight;
            
            for (let i = 0; i < files.length; i++) {
                const file = files[i];
                const formData = new FormData();
                formData.append('file', file);
                formData.append('path', this.currentPath);
                
                // 更新进度
                const percent = Math.round(((i + 1) / files.length) * 100);
                progressBar.style.width = `${percent}%`;
                progressText.textContent = `正在上传: ${file.name} (${i + 1}/${files.length}) ${percent}%`;
                
                // 强制重绘以确保进度更新显示
                progressBar.offsetHeight;
                progressText.offsetHeight;
                
                // 添加一个小延迟以确保UI更新
                await new Promise(resolve => setTimeout(resolve, 50));
                
                const response = await adminPanel.apiRequest('/api/r2/upload', {
                    method: 'POST',
                    body: formData
                });
                
                if (!response.ok) {
                    throw new Error(`上传文件 ${file.name} 失败`);
                }
            }
            
            // 完成上传
            progressBar.style.width = '100%';
            progressText.textContent = '上传完成 (100%)';
            setTimeout(() => {
                progress.classList.add('d-none');
                progressText.classList.add('d-none');
                progressBar.style.width = '0%';
            }, 1500);
            
            adminPanel.showMessage('文件上传成功', 'success');
            this.loadFiles();
        } catch (error) {
            console.error('上传文件失败:', error);
            adminPanel.showMessage('上传文件失败: ' + error.message, 'error');
            
            // 隐藏进度条
            const progress = document.getElementById('uploadProgress');
            const progressText = document.getElementById('uploadProgressText');
            if (progress) progress.classList.add('d-none');
            if (progressText) progressText.classList.add('d-none');
        }
    }

    async createFolder(name) {
        try {
            // 关闭模态框
            const createFolderModal = bootstrap.Modal.getInstance(document.getElementById('createFolderModal'));
            if (createFolderModal) {
                createFolderModal.hide();
            }
            
            const fullPath = this.currentPath + name + '/';
            
            const response = await adminPanel.apiRequest('/api/r2/create-folder', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    path: fullPath
                })
            });
            
            if (response.ok) {
                adminPanel.showMessage('文件夹创建成功', 'success');
                this.loadFiles();
            } else {
                throw new Error('创建文件夹失败');
            }
        } catch (error) {
            console.error('创建文件夹失败:', error);
            adminPanel.showMessage('创建文件夹失败: ' + error.message, 'error');
        }
    }

    async deleteFile(key) {
        if (!confirm(`确定要删除 "${key}" 吗？`)) {
            return;
        }
        
        try {
            const response = await adminPanel.apiRequest(`/api/r2/delete`, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    keys: [key]
                })
            });
            
            if (response.ok) {
                adminPanel.showMessage('文件删除成功', 'success');
                this.loadFiles();
            } else {
                throw new Error('删除文件失败');
            }
        } catch (error) {
            console.error('删除文件失败:', error);
            adminPanel.showMessage('删除文件失败: ' + error.message, 'error');
        }
    }

    async deleteSelectedFiles() {
        if (this.selectedFiles.size === 0) {
            return;
        }
        
        if (!confirm(`确定要删除选中的 ${this.selectedFiles.size} 个文件吗？`)) {
            return;
        }
        
        try {
            const keys = Array.from(this.selectedFiles);
            
            const response = await adminPanel.apiRequest(`/api/r2/delete`, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    keys: keys
                })
            });
            
            if (response.ok) {
                adminPanel.showMessage('文件删除成功', 'success');
                this.selectedFiles.clear();
                this.loadFiles();
            } else {
                throw new Error('删除文件失败');
            }
        } catch (error) {
            console.error('删除文件失败:', error);
            adminPanel.showMessage('删除文件失败: ' + error.message, 'error');
        }
    }

    async downloadFile(file) {
        try {
            // 显示下载进度模态框
            this.showDownloadProgress();
            
            const progress = document.getElementById('downloadProgress');
            const progressBar = progress.querySelector('.progress-bar');
            const progressText = document.getElementById('downloadProgressText');
            
            // 更新进度文本
            progressText.textContent = '准备下载...';
            
            // 使用fetch直接下载文件（绕过adminPanel.apiRequest以便更好地控制进度）
            const response = await fetch(`/api/r2/download/${encodeURIComponent(file.key)}`, {
                headers: {
                    'Authorization': `Bearer ${this.getAuthToken()}`
                }
            });
            
            if (!response.ok) {
                throw new Error('下载文件失败');
            }
            
            // 获取文件大小
            const contentLength = response.headers.get('content-length');
            const total = parseInt(contentLength, 10);
            let loaded = 0;
            
            const reader = response.body.getReader();
            const chunks = [];
            
            // 读取数据块并更新进度
            while (true) {
                const { done, value } = await reader.read();
                
                if (done) {
                    break;
                }
                
                chunks.push(value);
                loaded += value.length;
                
                if (total) {
                    const percentComplete = Math.round((loaded / total) * 100);
                    progressBar.style.width = `${percentComplete}%`;
                    progressText.textContent = `${percentComplete}%`;
                } else {
                    // 如果没有内容长度信息，显示已加载的字节数
                    progressText.textContent = `已下载: ${this.formatFileSize(loaded)}`;
                }
            }
            
            // 创建Blob并触发下载
            const blob = new Blob(chunks);
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = file.name;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);
            
            // 更新进度文本
            progressText.textContent = '下载完成';
            
            // 隐藏进度条
            setTimeout(() => {
                const downloadProgressModal = bootstrap.Modal.getInstance(document.getElementById('downloadProgressModal'));
                if (downloadProgressModal) {
                    downloadProgressModal.hide();
                }
            }, 1000);
        } catch (error) {
            console.error('下载文件失败:', error);
            adminPanel.showMessage('下载文件失败: ' + error.message, 'error');
            
            // 隐藏进度条
            const downloadProgressModal = bootstrap.Modal.getInstance(document.getElementById('downloadProgressModal'));
            if (downloadProgressModal) {
                downloadProgressModal.hide();
            }
        }
    }

    downloadSelectedFiles() {
        // 简化实现：逐个下载选中的文件
        this.selectedFiles.forEach(key => {
            const file = this.files.find(f => f.key === key);
            if (file) {
                this.downloadFile(file);
            }
        });
    }

    showFileDetail(file) {
        document.getElementById('detailName').textContent = file.name;
        document.getElementById('detailSize').textContent = file.size ? this.formatFileSize(file.size) : '-';
        document.getElementById('detailType').textContent = file.contentType || '-';
        document.getElementById('detailModified').textContent = file.uploadedAt ? 
            new Date(file.uploadedAt).toLocaleString('zh-CN') : '-';
        document.getElementById('detailPath').textContent = file.key;
        
        // 预览文件
        const preview = document.getElementById('filePreview');
        const previewContainer = preview.closest('.text-center');
        
        // 清除之前的内容并添加容器
        previewContainer.innerHTML = '<div class="file-preview-container"><div id="filePreviewContent"></div></div>';
        const newPreviewContainer = previewContainer.querySelector('.file-preview-container');
        const previewContent = newPreviewContainer.querySelector('#filePreviewContent');
        
        if (file.contentType && file.contentType.startsWith('image/')) {
            // 对于图片文件，显示预览
            const img = document.createElement('img');
            img.src = `/api/r2/download/${encodeURIComponent(file.key)}`;
            img.alt = file.name;
            img.className = 'file-preview';
            img.style.maxWidth = '100%';
            img.style.maxHeight = '400px';
            img.style.objectFit = 'contain';
            
            // 添加加载处理
            img.onload = function() {
                console.log('图片加载成功');
            };
            
            // 添加错误处理
            img.onerror = function() {
                console.log('图片加载失败');
                newPreviewContainer.innerHTML = '<i class="bi bi-file-earmark-image" style="font-size: 100px; color: #6c757d;"></i><p>图片加载失败</p>';
            };
            
            previewContent.appendChild(img);
        } else if (file.contentType && file.contentType.startsWith('video/')) {
            // 对于视频文件，显示播放器
            const video = document.createElement('video');
            video.controls = true;
            video.className = 'file-preview';
            video.style.maxWidth = '100%';
            video.style.maxHeight = '400px';
            
            const source = document.createElement('source');
            source.src = `/api/r2/download/${encodeURIComponent(file.key)}`;
            source.type = file.contentType;
            
            video.appendChild(source);
            
            // 添加加载错误处理
            video.onerror = function() {
                console.log('视频加载失败');
                newPreviewContainer.innerHTML = '<i class="bi bi-file-earmark-play" style="font-size: 100px; color: #6c757d;"></i><p>视频加载失败</p>';
            };
            
            previewContent.appendChild(video);
        } else if (file.contentType && file.contentType.startsWith('audio/')) {
            // 对于音频文件，显示播放器
            const audio = document.createElement('audio');
            audio.controls = true;
            audio.className = 'file-preview';
            audio.style.width = '100%';
            
            const source = document.createElement('source');
            source.src = `/api/r2/download/${encodeURIComponent(file.key)}`;
            source.type = file.contentType;
            
            audio.appendChild(source);
            
            // 添加加载错误处理
            audio.onerror = function() {
                console.log('音频加载失败');
                newPreviewContainer.innerHTML = '<i class="bi bi-file-earmark-music" style="font-size: 100px; color: #6c757d;"></i><p>音频加载失败</p>';
            };
            
            previewContent.appendChild(audio);
        } else {
            // 对于其他文件，显示文件类型图标
            let iconClass = 'bi-file-earmark';
            let iconName = '文件';
            if (file.contentType) {
                if (file.contentType.includes('pdf')) {
                    iconClass = 'bi-file-earmark-pdf';
                    iconName = 'PDF文档';
                } else if (file.contentType.includes('word')) {
                    iconClass = 'bi-file-earmark-word';
                    iconName = 'Word文档';
                } else if (file.contentType.includes('excel') || file.contentType.includes('spreadsheet')) {
                    iconClass = 'bi-file-earmark-excel';
                    iconName = 'Excel表格';
                } else if (file.contentType.includes('powerpoint') || file.contentType.includes('presentation')) {
                    iconClass = 'bi-file-earmark-ppt';
                    iconName = 'PPT演示文稿';
                } else if (file.contentType.includes('text') || file.contentType.includes('json') || file.contentType.includes('xml')) {
                    iconClass = 'bi-file-earmark-text';
                    iconName = '文本文件';
                } else if (file.contentType.includes('zip') || file.contentType.includes('compressed')) {
                    iconClass = 'bi-file-earmark-zip';
                    iconName = '压缩文件';
                } else if (file.contentType.includes('audio')) {
                    iconClass = 'bi-file-earmark-music';
                    iconName = '音频文件';
                } else if (file.contentType.includes('video')) {
                    iconClass = 'bi-file-earmark-play';
                    iconName = '视频文件';
                }
            }
            
            newPreviewContainer.innerHTML = `<div class="text-center"><i class="bi ${iconClass}" style="font-size: 100px; color: #6c757d;"></i><p class="mt-2">${iconName}</p></div>`;
        }
        
        const modal = new bootstrap.Modal(document.getElementById('fileDetailModal'));
        modal.show();
    }

    toggleView(isGrid) {
        this.isGridView = isGrid;
        this.renderFileList();
    }

    formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    showLoading() {
        // 可以添加加载动画
    }

    hideLoading() {
        // 可以隐藏加载动画
    }

    showDownloadProgress() {
        // 获取已存在的下载进度模态框
        const modalElement = document.getElementById('downloadProgressModal');
        
        if (modalElement) {
            // 重置进度条
            const progressBar = modalElement.querySelector('.progress-bar');
            const progressText = document.getElementById('downloadProgressText');
            
            if (progressBar) {
                progressBar.style.width = '0%';
            }
            
            if (progressText) {
                progressText.textContent = '0%';
            }
            
            // 显示模态框
            const downloadModal = new bootstrap.Modal(modalElement);
            downloadModal.show();
        }
    }

    showContextMenu(e, file) {
        // 简化的右键菜单实现
        e.preventDefault();
        console.log('右键菜单:', file);
    }

    // 获取认证令牌的辅助方法
    getAuthToken() {
        return localStorage.getItem('authToken');
    }

}

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', () => {
    window.r2FileManager = new R2FileManager();
});