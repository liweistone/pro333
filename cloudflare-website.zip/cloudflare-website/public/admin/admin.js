// 管理后台主JavaScript文件
class AdminPanel {
    constructor() {
        this.apiBaseUrl = '/api/admin';
        this.currentUser = null;
        this.authToken = this.getAuthToken();
        this.init();
    }

    init() {
        // 检查用户是否已登录
        if (!this.authToken) {
            this.redirectToLogin();
            return;
        }

        // 验证令牌
        this.validateToken();

        // 绑定全局事件
        this.bindEvents();
    }

    getAuthToken() {
        const token = localStorage.getItem('authToken');
        console.log('获取认证令牌:', token);
        
        // 检查令牌是否存在
        if (!token) {
            console.log('未找到认证令牌');
            return null;
        }
        
        // 简单检查令牌格式
        if (!token.startsWith('eyJ')) {
            console.log('认证令牌格式不正确，清除无效令牌');
            localStorage.removeItem('authToken');
            return null;
        }
        
        return token;
    }

    async validateToken() {
        try {
            const token = this.getAuthToken();
            if (!token) {
                console.log('无认证令牌，重定向到登录页面');
                this.redirectToLogin();
                return;
            }
            
            const response = await fetch('/api/auth/me', {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            if (!response.ok) {
                throw new Error('Token无效');
            }

            const data = await response.json();
            this.currentUser = data.user;
            console.log('当前用户:', this.currentUser);
        } catch (error) {
            console.error('令牌验证失败:', error);
            this.redirectToLogin();
        }
    }

    bindEvents() {
        // 全局点击事件处理
        document.addEventListener('click', (e) => {
            // 处理登出
            if (e.target.id === 'logoutBtn') {
                e.preventDefault();
                this.logout();
            }
            
            // 处理刷新按钮
            if (e.target.id === 'refreshBtn') {
                e.preventDefault();
                location.reload();
            }
            
            // 处理文章管理页面的按钮
            if (e.target.classList.contains('edit-article-btn')) {
                e.preventDefault();
                const articleId = e.target.getAttribute('data-id');
                if (typeof showEditArticleForm === 'function') {
                    showEditArticleForm(articleId);
                }
            }
            
            if (e.target.classList.contains('delete-article-btn')) {
                e.preventDefault();
                const articleId = e.target.getAttribute('data-id');
                if (typeof deleteArticle === 'function') {
                    deleteArticle(articleId);
                }
            }
            
            // 处理分类管理页面的按钮
            if (e.target.classList.contains('btn') && e.target.textContent === '编辑' && e.target.closest('table') && e.target.closest('table').id === 'categoriesTable') {
                const row = e.target.closest('tr');
                if (row) {
                    const firstCell = row.querySelector('td:first-child');
                    if (firstCell) {
                        const categoryId = firstCell.textContent;
                        if (typeof window.showEditCategoryForm === 'function') {
                            window.showEditCategoryForm(categoryId);
                        }
                    }
                }
            }
            
            // 处理分类管理页面的删除按钮
            if (e.target.classList.contains('btn') && e.target.textContent === '删除' && e.target.closest('table') && e.target.closest('table').id === 'categoriesTable') {
                const row = e.target.closest('tr');
                if (row) {
                    const firstCell = row.querySelector('td:first-child');
                    if (firstCell) {
                        const categoryId = firstCell.textContent;
                        if (typeof window.deleteCategory === 'function') {
                            window.deleteCategory(categoryId);
                        }
                    }
                }
            }
            
            // 处理预设管理页面的删除按钮
            if (e.target.classList.contains('delete-preset-btn')) {
                e.preventDefault();
                const presetId = e.target.getAttribute('data-id');
                if (presetId && typeof window.deletePreset === 'function') {
                    window.deletePreset(presetId);
                } else {
                    console.error('获取预设ID失败或函数不存在:', presetId);
                    if (window.adminPanel) {
                        window.adminPanel.showMessage('获取预设ID失败，请检查网络连接', 'error');
                    }
                }
            }
            
            // 处理预设管理页面的添加按钮
            if (e.target.id === 'addPresetBtn' || e.target.id === 'addPresetBtnTop') {
                e.preventDefault();
                if (typeof window.showAddPresetForm === 'function') {
                    window.showAddPresetForm();
                }
            }
            
            // 处理预设管理页面的添加分类按钮
            if (e.target.id === 'addCategoryBtn') {
                e.preventDefault();
                if (typeof window.showAddCategoryForm === 'function') {
                    window.showAddCategoryForm();
                }
            }
            
            // 处理预设管理页面的刷新按钮
            if (e.target.id === 'refreshPresetsBtn') {
                e.preventDefault();
                if (typeof window.loadCategories === 'function' && typeof window.loadPresets === 'function') {
                    window.loadCategories();
                    window.loadPresets(1);
                }
            }
            
            // 处理产品管理页面的按钮
            if (e.target.classList.contains('edit-product-btn')) {
                e.preventDefault();
                const productId = e.target.getAttribute('data-id');
                console.log('编辑产品按钮被点击，产品ID:', productId);
                if (productId && typeof window.showEditProductForm === 'function') {
                    window.showEditProductForm(productId);
                } else {
                    console.error('获取产品ID失败或函数不存在:', productId);
                    if (window.adminPanel) {
                        window.adminPanel.showMessage('获取产品ID失败，请检查网络连接', 'error');
                    }
                }
            }
            
            // 处理预设管理页面的编辑按钮
            if (e.target.classList.contains('edit-preset-btn')) {
                e.preventDefault();
                const presetId = e.target.getAttribute('data-id');
                if (presetId && typeof window.showEditPresetForm === 'function') {
                    window.showEditPresetForm(presetId);
                } else {
                    console.error('获取预设ID失败或函数不存在:', presetId);
                    if (window.adminPanel) {
                        window.adminPanel.showMessage('获取预设ID失败，请检查网络连接', 'error');
                    }
                }
            }
            
            if (e.target.classList.contains('delete-product-btn')) {
                e.preventDefault();
                const productId = e.target.getAttribute('data-id');
                console.log('删除产品按钮被点击，产品ID:', productId);
                if (productId && typeof window.deleteProduct === 'function') {
                    window.deleteProduct(productId);
                } else {
                    console.error('获取产品ID失败或函数不存在:', productId);
                    if (window.adminPanel) {
                        window.adminPanel.showMessage('获取产品ID失败，请检查网络连接', 'error');
                    }
                }
            }
        });
    }

    redirectToLogin() {
        console.log('重定向到登录页面');
        localStorage.removeItem('authToken');
        window.location.href = '/admin/login.html';
    }

    async logout() {
        try {
            await fetch('/api/auth/logout', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${this.getAuthToken()}`,
                    'Content-Type': 'application/json'
                }
            });

            localStorage.removeItem('authToken');
            window.location.href = '/admin/login.html';
        } catch (error) {
            console.error('登出失败:', error);
            localStorage.removeItem('authToken');
            window.location.href = '/admin/login.html';
        }
    }

    async apiRequest(url, options = {}, retries = 3) {
        // 检查是否是文件上传请求（包含FormData）
        const isFileUpload = options.body instanceof FormData;
        
        // 确保认证令牌存在
        let authToken = this.getAuthToken();
        console.log('API请求 - URL:', url, '选项:', options);
        console.log('API请求 - 认证令牌:', authToken);
        
        if (!authToken) {
            // 不直接重定向，而是抛出错误让调用者处理
            const error = new Error('未授权');
            error.status = 401;
            throw error;
        }
        
        // 检查令牌是否过期，如果过期则尝试刷新
        try {
            const payload = JSON.parse(atob(authToken.split('.')[1]));
            if (payload.exp && payload.exp * 1000 < Date.now()) {
                console.log('令牌已过期，尝试刷新...');
                
                // 尝试刷新令牌
                const refreshResponse = await fetch('/api/auth/refresh', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${authToken}`
                    }
                });
                
                if (refreshResponse.ok) {
                    const refreshData = await refreshResponse.json();
                    // 更新存储的令牌
                    localStorage.setItem('authToken', refreshData.token);
                    authToken = refreshData.token; // 使用新令牌
                    console.log('令牌刷新成功');
                } else {
                    console.log('令牌刷新失败');
                    // 刷新失败，清除令牌并重定向到登录页面
                    localStorage.removeItem('authToken');
                    this.redirectToLogin();
                    const error = new Error('令牌已过期，请重新登录');
                    error.status = 401;
                    throw error;
                }
            }
        } catch (e) {
            if (e.message && e.message.includes('令牌已过期')) {
                throw e; // 重新抛出令牌过期错误
            }
            console.error('令牌解析失败:', e);
        }
        
        const defaultOptions = {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        };

        // 只有在非文件上传的情况下才设置Content-Type为application/json
        if (!isFileUpload && !(options.headers && options.headers['Content-Type'])) {
            defaultOptions.headers['Content-Type'] = 'application/json';
        }

        // 合并选项前记录原始选项
        console.log('合并前的选项:', options);
        console.log('默认选项:', defaultOptions);
        // 深度合并选项，确保headers不会被覆盖
        const mergedOptions = {
            ...defaultOptions,
            ...options,
            headers: {
                ...defaultOptions.headers,
                ...(options.headers || {})
            }
        };
        console.log('合并后的选项:', mergedOptions);

        try {
            // 确保URL格式正确
            let fullUrl = url;
            if (!url.startsWith('http') && !url.startsWith('/')) {
                fullUrl = '/' + url;
            }
            
            // 添加时间戳避免缓存
            if (fullUrl.includes('?')) {
                fullUrl += '&_t=' + Date.now();
            } else {
                fullUrl += '?_t=' + Date.now();
            }
            
            console.log(`发送API请求: ${fullUrl}`, mergedOptions);
            console.log('请求头信息:', mergedOptions.headers);
            const response = await fetch(fullUrl, mergedOptions);
            console.log(`收到API响应: ${fullUrl}, 状态码: ${response.status}`);
            console.log('响应头信息:', Object.fromEntries(response.headers));

            // 如果是401未授权，不直接重定向，而是返回响应让调用者处理
            if (response.status === 401) {
                console.log('收到401未授权响应');
                // 克隆响应以避免body stream already read错误
                const clonedResponse = response.clone();
                // 检查响应内容，看是否是令牌过期
                try {
                    const data = await clonedResponse.json();
                    console.log('401错误详情:', data);
                    // 对于401错误，只显示错误信息，不自动退出登录
                    this.showMessage('认证失败: ' + (data.error || '请检查权限'), 'error');
                } catch (e) {
                    console.log('无法解析401错误响应为JSON:', e);
                    // 即使无法解析JSON，也不要自动退出登录，只显示错误信息
                    this.showMessage('认证失败，请检查权限', 'error');
                }
                // 不自动退出登录，只返回响应让调用者处理
                return response;
            }

            // 如果是403权限不足，显示错误信息但不重定向
            if (response.status === 403) {
                console.log('收到403权限不足响应');
                // 克隆响应以避免body stream already read错误
                const clonedResponse = response.clone();
                try {
                    const data = await clonedResponse.json();
                    console.log('403错误详情:', data);
                    this.showMessage('权限不足: ' + (data.error || '您没有执行此操作的权限'), 'error');
                } catch (e) {
                    console.log('无法解析403错误响应为JSON:', e);
                    // 即使无法解析JSON，也不要自动退出登录，只显示错误信息
                    this.showMessage('权限不足: 您没有执行此操作的权限', 'error');
                }
                // 不要自动退出登录，只显示错误信息
                return response; // 返回响应而不是抛出错误
            }

            // 如果是5xx服务器错误且还有重试次数，尝试重试
            if (response.status >= 500 && retries > 0) {
                console.warn(`服务器错误 ${response.status}，${retries} 秒后重试...`);
                await new Promise(resolve => setTimeout(resolve, 1000));
                return this.apiRequest(url, options, retries - 1);
            }

            return response;
        } catch (error) {
            // 网络错误且还有重试次数，尝试重试
            if (retries > 0) {
                console.warn(`网络错误: ${error.message}，${retries} 秒后重试...`);
                await new Promise(resolve => setTimeout(resolve, 1000));
                return this.apiRequest(url, options, retries - 1);
            }
            // 对于网络错误，显示更友好的错误信息
            console.error('网络请求失败:', error);
            throw new Error('网络连接失败，请检查网络设置');
        }
    }

    async fetchCategories() {
        try {
            const response = await this.apiRequest('/api/article-categories/list');
            if (response.ok) {
                const data = await response.json();
                return data.success ? data.data : [];
            } else {
                throw new Error('获取分类失败');
            }
        } catch (error) {
            console.error('获取分类失败:', error);
            return [];
        }
    }

    async fetchImages(page = 1, limit = 20, search = '', sort = 'uploaded_at DESC') {
        try {
            // 构造查询参数
            const params = new URLSearchParams({
                page: page,
                limit: limit,
                sort: sort
            });
            
            if (search) {
                params.append('search', search);
            }
            
            const response = await this.apiRequest(`/api/images?${params.toString()}`);
            if (response.ok) {
                const data = await response.json();
                return data.success ? data : { data: [], total: 0 };
            } else {
                throw new Error('获取图片失败');
            }
        } catch (error) {
            console.error('获取图片失败:', error);
            return { data: [], total: 0 };
        }
    }

    async uploadImage(file, altText = '', description = '') {
        try {
            const formData = new FormData();
            formData.append('file', file);
            formData.append('alt_text', altText);
            formData.append('description', description);

            // 注意：这里不要设置Content-Type，让浏览器自动设置multipart/form-data
            const response = await this.apiRequest('/api/images/upload', {
                method: 'POST',
                body: formData
            });

            if (response.ok) {
                return await response.json();
            } else {
                const errorData = await response.json();
                throw new Error(errorData.error || '上传图片失败');
            }
        } catch (error) {
            console.error('上传图片失败:', error);
            throw error;
        }
    }

    formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('zh-CN', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    showMessage(message, type = 'success') {
        // 创建通知元素
        const notification = document.createElement('div');
        notification.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
        notification.style = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
        notification.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        `;

        // 添加到页面
        document.body.appendChild(notification);

        // 3秒后自动移除
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 3000);
    }

    // 统一的模态框清除函数
    cleanupModal(modalId) {
        try {
            // 获取模态框实例
            const modalElement = document.getElementById(modalId);
            if (modalElement) {
                const modalInstance = bootstrap.Modal.getInstance(modalElement);
                if (modalInstance) {
                    // 隐藏模态框
                    modalInstance.hide();
                    
                    // 移除焦点元素，避免aria-hidden属性冲突
                    const focusableElements = modalElement.querySelectorAll('button, input, select, textarea, [tabindex]:not([tabindex="-1"])');
                    focusableElements.forEach(element => {
                        element.blur();
                    });
                }
                
                // 从DOM中移除模态框
                setTimeout(() => {
                    if (modalElement.parentNode) {
                        modalElement.parentNode.removeChild(modalElement);
                    }
                }, 300);
            }
            
            // 移除背景层
            this.removeModalBackdrop();
        } catch (error) {
            console.error('清理模态框时出错:', error);
        }
    }

    // 移除模态框背景层
    removeModalBackdrop() {
        try {
            // 移除所有模态框背景层
            const backdrops = document.querySelectorAll('.modal-backdrop');
            backdrops.forEach(backdrop => {
                if (backdrop.parentNode) {
                    backdrop.parentNode.removeChild(backdrop);
                }
            });
        } catch (error) {
            console.error('移除模态框背景层时出错:', error);
        }
    }

    // 统一的模态框实例处理函数
    getOrCreateModal(modalId) {
        try {
            const modalElement = document.getElementById(modalId);
            if (!modalElement) {
                console.error('模态框元素不存在:', modalId);
                return null;
            }
            
            // 获取现有实例或创建新实例
            let modalInstance = bootstrap.Modal.getInstance(modalElement);
            if (!modalInstance) {
                modalInstance = new bootstrap.Modal(modalElement);
            }
            
            return modalInstance;
        } catch (error) {
            console.error('获取或创建模态框实例时出错:', error);
            return null;
        }
    }
}

// 初始化管理面板
document.addEventListener('DOMContentLoaded', () => {
    // 初始化Bootstrap组件
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    const tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    })
    
    // 初始化Popover组件
    const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'))
    const popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl)
    })
    
    window.adminPanel = new AdminPanel();
});