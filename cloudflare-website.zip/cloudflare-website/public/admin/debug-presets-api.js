// 调试预设API的脚本
async function debugPresetsAPI() {
  try {
    console.log('=== 开始调试预设数据 ===');
    
    // 检查认证状态
    const token = localStorage.getItem('authToken');
    console.log('认证令牌存在:', !!token);
    if (token) {
      console.log('令牌长度:', token.length);
    }
    
    // 测试分类API
    console.log('\n--- 测试分类API ---');
    const categoriesResponse = await fetch('/api/presets/categories/list', {
      headers: {
        'Authorization': 'Bearer ' + (token || ''),
        'Content-Type': 'application/json'
      }
    });
    console.log('分类API状态:', categoriesResponse.status);
    console.log('分类API状态文本:', categoriesResponse.statusText);
    
    const categoriesHeaders = {};
    for (let [key, value] of categoriesResponse.headers.entries()) {
      categoriesHeaders[key] = value;
    }
    console.log('分类API响应头:', categoriesHeaders);
    
    const categoriesData = await categoriesResponse.json();
    console.log('分类数据:', categoriesData);
    
    // 测试预设API
    console.log('\n--- 测试预设API ---');
    const presetsResponse = await fetch('/api/presets', {
      headers: {
        'Authorization': 'Bearer ' + (token || ''),
        'Content-Type': 'application/json'
      }
    });
    console.log('预设API状态:', presetsResponse.status);
    console.log('预设API状态文本:', presetsResponse.statusText);
    
    const presetsHeaders = {};
    for (let [key, value] of presetsResponse.headers.entries()) {
      presetsHeaders[key] = value;
    }
    console.log('预设API响应头:', presetsHeaders);
    
    const presetsData = await presetsResponse.json();
    console.log('预设数据:', presetsData);
    
    // 检查数据结构
    console.log('\n--- 数据结构分析 ---');
    if (presetsData && typeof presetsData === 'object') {
      console.log('预设数据类型:', Array.isArray(presetsData) ? '数组' : '对象');
      if (Array.isArray(presetsData)) {
        console.log('预设数组长度:', presetsData.length);
        if (presetsData.length > 0) {
          console.log('第一个预设对象结构:', Object.keys(presetsData[0]));
        }
      } else {
        console.log('预设对象键:', Object.keys(presetsData));
        if (presetsData.presets) {
          console.log('presets字段类型:', Array.isArray(presetsData.presets) ? '数组' : typeof presetsData.presets);
          if (Array.isArray(presetsData.presets)) {
            console.log('presets数组长度:', presetsData.presets.length);
            if (presetsData.presets.length > 0) {
              console.log('第一个预设对象结构:', Object.keys(presetsData.presets[0]));
            }
          }
        }
        if (presetsData.categories) {
          console.log('categories字段类型:', typeof presetsData.categories);
          if (typeof presetsData.categories === 'object' && presetsData.categories !== null) {
            console.log('categories对象键数量:', Object.keys(presetsData.categories).length);
          }
        }
      }
    }
    
  } catch (error) {
    console.error('调试错误:', error);
  }
}

// 立即执行调试
debugPresetsAPI();