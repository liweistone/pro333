// 插件端广告管理JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // 添加顶部导航栏交互功能
    // 移动端菜单切换
    if (document.querySelector('.menu-toggle')) {
        document.querySelector('.menu-toggle').addEventListener('click', function() {
            document.getElementById('sidebar').classList.toggle('show');
            document.getElementById('sidebarOverlay').classList.toggle('show');
        });
    }
    
    // 点击覆盖层关闭菜单
    if (document.getElementById('sidebarOverlay')) {
        document.getElementById('sidebarOverlay').addEventListener('click', function() {
            document.getElementById('sidebar').classList.remove('show');
            this.classList.remove('show');
        });
    }
    
    // 窗口大小改变时隐藏菜单
    window.addEventListener('resize', function() {
        if (window.innerWidth > 991) {
            document.getElementById('sidebar').classList.remove('show');
            if (document.getElementById('sidebarOverlay')) {
                document.getElementById('sidebarOverlay').classList.remove('show');
            }
        }
    });
    
    // 登出按钮功能
    if (document.getElementById('logoutBtn')) {
        document.getElementById('logoutBtn').addEventListener('click', function() {
            if (confirm('确定要登出吗？')) {
                localStorage.removeItem('authToken');
                window.location.href = '/admin/login.html';
            }
        });
    }

    const adForm = document.getElementById('adForm');
    const adsList = document.getElementById('adsList');
    const cancelEditBtn = document.getElementById('cancelEdit');
    
    let editingAdId = null;
    
    // 获取广告列表
    async function fetchAds() {
        try {
            const response = await fetch('/api/ads');
            
            // 检查响应状态
            if (!response.ok) {
                if (response.status === 404) {
                    console.error('广告API端点未找到，请检查后端配置');
                    if (adsList) {
                        adsList.innerHTML = '<p>广告API端点未找到，请检查后端配置</p>';
                    }
                    return;
                }
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const ads = await response.json();
            
            // 处理不同的API响应格式
            if (Array.isArray(ads)) {
                renderAds(ads);
            } else if (ads.data && Array.isArray(ads.data)) {
                renderAds(ads.data);
            } else if (ads.ads && Array.isArray(ads.ads)) {
                renderAds(ads.ads);
            } else {
                if (adsList) {
                    adsList.innerHTML = '<p>暂无广告数据</p>';
                }
            }
        } catch (error) {
            console.error('获取广告列表失败:', error);
            if (adsList) {
                adsList.innerHTML = '<p>获取广告列表失败: ' + error.message + '</p>';
            }
        }
    }
    
    // 渲染广告列表
    function renderAds(ads) {
        if (!adsList) return;
        
        if (ads.length === 0) {
            adsList.innerHTML = '<p>暂无广告数据</p>';
            return;
        }
        
        // 添加容器div以实现网格布局
        adsList.innerHTML = `
            <div class="ad-list-container">
                ${ads.map(ad => {
                    // 使用id或_id作为广告ID
                    const adIdToUse = ad.id || ad._id || '';
                    return `
                    <div class="ad-item" data-id="${adIdToUse}">
                        <h3>${ad.title}</h3>
                        ${ad.image_url ? `<img src="${ad.image_url.startsWith('http') || ad.image_url.startsWith('/api/images/public/') ? ad.image_url : `/api/images/public/${ad.image_url}`}" alt="${ad.title}" class="ad-image">` : ''}
                        <div class="ad-details">
                            <p><strong>链接:</strong> ${ad.link_url || '无'}</p>
                            <p><strong>描述:</strong> ${ad.description || '无'}</p>
                            <p><strong>优先级:</strong> ${ad.priority || ad.sort_order || 0}</p>
                            <p><strong>状态:</strong> ${ad.is_active == 1 ? '启用' : '禁用'}</p>
                        </div>
                        <div class="ad-actions">
                            <button class="btn btn-warning edit-btn" data-id="${adIdToUse}">编辑</button>
                            <button class="btn btn-danger delete-btn" data-id="${adIdToUse}">删除</button>
                        </div>
                    </div>
                `}).join('')}
            </div>
        `;
        
        // 绑定编辑和删除事件
        document.querySelectorAll('.edit-btn').forEach(btn => {
            // 移除旧的事件监听器
            const newBtn = btn.cloneNode(true);
            btn.parentNode.replaceChild(newBtn, btn);
            newBtn.addEventListener('click', function() {
                const adId = this.getAttribute('data-id');
                if (adId && adId !== 'null' && adId !== 'undefined') {
                    editAd(adId);
                } else {
                    alert('广告ID无效');
                }
            });
        });
        
        document.querySelectorAll('.delete-btn').forEach(btn => {
            // 移除旧的事件监听器
            const newBtn = btn.cloneNode(true);
            btn.parentNode.replaceChild(newBtn, btn);
            newBtn.addEventListener('click', function() {
                const adId = this.getAttribute('data-id');
                if (adId && adId !== 'null' && adId !== 'undefined') {
                    if (confirm('确定要删除这个广告吗？')) {
                        deleteAd(adId);
                    }
                } else {
                    alert('广告ID无效');
                }
            });
        });
    }
    
    // 编辑广告
    async function editAd(adId) {
        // 验证广告ID
        if (!adId || adId === 'null' || adId === 'undefined') {
            alert('广告ID无效');
            return;
        }
        
        try {
            // 使用admin.js中的apiRequest方法处理认证
            if (window.adminPanel && typeof window.adminPanel.apiRequest === 'function') {
                const response = await window.adminPanel.apiRequest(`/api/ads/${adId}`);
                
                // 特别处理401未授权错误
                if (response.status === 401) {
                    alert('未授权访问，请重新登录');
                    // 清除本地存储的令牌
                    localStorage.removeItem('authToken');
                    // 重定向到登录页面
                    window.location.href = '/admin/login.html';
                    return;
                }
                
                // 检查响应状态
                if (!response.ok) {
                    if (response.status === 404) {
                        alert('广告不存在');
                        return;
                    }
                    const errorText = await response.text();
                    throw new Error(`HTTP error! status: ${response.status}, message: ${errorText}`);
                }
                
                const result = await response.json();
                
                // 处理不同的API响应格式
                let ad = null;
                if (result.success && result.data) {
                    ad = result.data;
                } else if (result.ad) {
                    ad = result.ad;
                } else {
                    ad = result;
                }
                
                if (ad && (ad.id || ad._id)) {
                    const adIdInput = document.getElementById('adId');
                    const titleInput = document.getElementById('title');
                    const imageUrlInput = document.getElementById('image_url');
                    const linkUrlInput = document.getElementById('link_url');
                    const descriptionInput = document.getElementById('description');
                    const priorityInput = document.getElementById('priority');
                    const isActiveInput = document.getElementById('is_active');
                    const heading = document.querySelector('h2');
                    const coverImagePreview = document.getElementById('coverImagePreview');
                    const previewImg = coverImagePreview ? coverImagePreview.querySelector('img') : null;
                    
                    // 使用id或_id作为广告ID
                    const adIdToUse = ad.id || ad._id;
                    
                    if (adIdInput) adIdInput.value = adIdToUse || '';
                    if (titleInput) titleInput.value = ad.title || '';
                    if (imageUrlInput) imageUrlInput.value = ad.image_url || '';
                    if (linkUrlInput) linkUrlInput.value = ad.link_url || '';
                    if (descriptionInput) descriptionInput.value = ad.description || '';
                    if (priorityInput) priorityInput.value = ad.priority || ad.sort_order || 0;
                    if (isActiveInput) isActiveInput.value = ad.is_active || ad.is_active === 0 ? ad.is_active : 1;
                    
                    // 更新图片预览
                    if (ad.image_url && previewImg) {
                        const imageUrl = ad.image_url.startsWith('http') || ad.image_url.startsWith('/api/images/public/') 
                            ? ad.image_url 
                            : `/api/images/public/${ad.image_url}`;
                        previewImg.src = imageUrl;
                        coverImagePreview.style.display = 'block';
                    } else if (coverImagePreview) {
                        coverImagePreview.style.display = 'none';
                    }
                    
                    editingAdId = adIdToUse;
                    if (heading) heading.textContent = '编辑广告';
                    window.scrollTo(0, 0);
                } else {
                    alert('获取广告信息失败: 广告数据无效');
                }
            } else {
                // 备用方案：直接使用fetch
                const response = await fetch(`/api/ads/${adId}`);
                
                // 特别处理401未授权错误
                if (response.status === 401) {
                    alert('未授权访问，请重新登录');
                    // 清除本地存储的令牌
                    localStorage.removeItem('authToken');
                    // 重定向到登录页面
                    window.location.href = '/admin/login.html';
                    return;
                }
                
                // 检查响应状态
                if (!response.ok) {
                    if (response.status === 404) {
                        alert('广告不存在');
                        return;
                    }
                    const errorText = await response.text();
                    throw new Error(`HTTP error! status: ${response.status}, message: ${errorText}`);
                }
                
                const result = await response.json();
                
                // 处理不同的API响应格式
                let ad = null;
                if (result.success && result.data) {
                    ad = result.data;
                } else if (result.ad) {
                    ad = result.ad;
                } else {
                    ad = result;
                }
                
                if (ad && (ad.id || ad._id)) {
                    const adIdInput = document.getElementById('adId');
                    const titleInput = document.getElementById('title');
                    const imageUrlInput = document.getElementById('image_url');
                    const linkUrlInput = document.getElementById('link_url');
                    const descriptionInput = document.getElementById('description');
                    const priorityInput = document.getElementById('priority');
                    const isActiveInput = document.getElementById('is_active');
                    const heading = document.querySelector('h2');
                    const coverImagePreview = document.getElementById('coverImagePreview');
                    const previewImg = coverImagePreview ? coverImagePreview.querySelector('img') : null;
                    
                    // 使用id或_id作为广告ID
                    const adIdToUse = ad.id || ad._id;
                    
                    if (adIdInput) adIdInput.value = adIdToUse || '';
                    if (titleInput) titleInput.value = ad.title || '';
                    if (imageUrlInput) imageUrlInput.value = ad.image_url || '';
                    if (linkUrlInput) linkUrlInput.value = ad.link_url || '';
                    if (descriptionInput) descriptionInput.value = ad.description || '';
                    if (priorityInput) priorityInput.value = ad.priority || ad.sort_order || 0;
                    if (isActiveInput) isActiveInput.value = ad.is_active || ad.is_active === 0 ? ad.is_active : 1;
                    
                    // 更新图片预览
                    if (ad.image_url && previewImg) {
                        const imageUrl = ad.image_url.startsWith('http') || ad.image_url.startsWith('/api/images/public/') 
                            ? ad.image_url 
                            : `/api/images/public/${ad.image_url}`;
                        previewImg.src = imageUrl;
                        coverImagePreview.style.display = 'block';
                    } else if (coverImagePreview) {
                        coverImagePreview.style.display = 'none';
                    }
                    
                    editingAdId = adIdToUse;
                    if (heading) heading.textContent = '编辑广告';
                    window.scrollTo(0, 0);
                } else {
                    alert('获取广告信息失败: 广告数据无效');
                }
            }
        } catch (error) {
            console.error('获取广告信息失败:', error);
            alert('获取广告信息失败: ' + error.message);
        }
    }
    
    // 删除广告
    async function deleteAd(adId) {
        // 验证广告ID
        if (!adId || adId === 'null' || adId === 'undefined') {
            alert('广告ID无效');
            return;
        }
        
        if (!confirm('确定要删除这个广告吗？')) {
            return;
        }
        
        try {
            // 使用admin.js中的apiRequest方法处理认证
            if (window.adminPanel && typeof window.adminPanel.apiRequest === 'function') {
                const response = await window.adminPanel.apiRequest(`/api/ads/${adId}`, {
                    method: 'DELETE'
                });
                
                // 特别处理401未授权错误
                if (response.status === 401) {
                    alert('未授权访问，请重新登录');
                    // 清除本地存储的令牌
                    localStorage.removeItem('authToken');
                    // 重定向到登录页面
                    window.location.href = '/admin/login.html';
                    return;
                }
                
                // 检查响应状态
                if (!response.ok) {
                    if (response.status === 404) {
                        alert('广告不存在');
                        return;
                    }
                    const errorText = await response.text();
                    throw new Error(`HTTP error! status: ${response.status}, message: ${errorText}`);
                }
                
                const result = await response.json();
                
                if (result.success) {
                    alert('广告删除成功');
                    fetchAds(); // 重新加载广告列表
                } else {
                    alert('删除广告失败: ' + (result.error || '未知错误'));
                }
            } else {
                // 备用方案：直接使用fetch
                const response = await fetch(`/api/ads/${adId}`, {
                    method: 'DELETE',
                    headers: {
                        'Authorization': `Bearer ${localStorage.getItem('authToken')}`
                    }
                });
                
                // 特别处理401未授权错误
                if (response.status === 401) {
                    alert('未授权访问，请重新登录');
                    // 清除本地存储的令牌
                    localStorage.removeItem('authToken');
                    // 重定向到登录页面
                    window.location.href = '/admin/login.html';
                    return;
                }
                
                // 检查响应状态
                if (!response.ok) {
                    if (response.status === 404) {
                        alert('广告不存在');
                        return;
                    }
                    const errorText = await response.text();
                    throw new Error(`HTTP error! status: ${response.status}, message: ${errorText}`);
                }
                
                const result = await response.json();
                
                if (result.success) {
                    alert('广告删除成功');
                    fetchAds(); // 重新加载广告列表
                } else {
                    alert('删除广告失败: ' + (result.error || '未知错误'));
                }
            }
        } catch (error) {
            console.error('删除广告失败:', error);
            alert('删除广告失败: ' + error.message);
        }
    }
    
    // 保存广告
    async function saveAd(event) {
        event.preventDefault();
        
        const titleInput = document.getElementById('title');
        const imageUrlInput = document.getElementById('image_url');
        const linkUrlInput = document.getElementById('link_url');
        const descriptionInput = document.getElementById('description');
        const priorityInput = document.getElementById('priority');
        const isActiveInput = document.getElementById('is_active');
        const adIdInput = document.getElementById('adId');
        
        const adData = {
            title: titleInput ? titleInput.value : '',
            image_url: imageUrlInput ? imageUrlInput.value : '',
            link_url: linkUrlInput ? linkUrlInput.value : '',
            description: descriptionInput ? descriptionInput.value : '',
            priority: priorityInput ? (parseInt(priorityInput.value) || 0) : 0,
            is_active: isActiveInput ? parseInt(isActiveInput.value) : 0
        };
        
        const adId = adIdInput ? adIdInput.value : '';
        // 确保广告ID有效
        const isEditing = adId && adId !== 'null' && adId !== 'undefined';
        
        try {
            // 使用admin.js中的apiRequest方法处理认证
            if (window.adminPanel && typeof window.adminPanel.apiRequest === 'function') {
                const url = isEditing ? `/api/ads/${adId}` : '/api/ads';
                const method = isEditing ? 'PUT' : 'POST';
                
                const response = await window.adminPanel.apiRequest(url, {
                    method: method,
                    body: JSON.stringify(adData)
                });
                
                // 特别处理401未授权错误
                if (response.status === 401) {
                    alert('未授权访问，请重新登录');
                    // 清除本地存储的令牌
                    localStorage.removeItem('authToken');
                    // 重定向到登录页面
                    window.location.href = '/admin/login.html';
                    return;
                }
                
                // 检查响应状态
                if (!response.ok) {
                    let errorMessage = `HTTP error! status: ${response.status}`;
                    try {
                        const errorResult = await response.json();
                        errorMessage = errorResult.error || errorMessage;
                    } catch (e) {
                        // 如果无法解析错误响应为JSON，使用默认错误消息
                    }
                    throw new Error(errorMessage);
                }
                
                const result = await response.json();
                
                if (result.success) {
                    alert(isEditing ? '广告更新成功' : '广告创建成功');
                    if (adForm) adForm.reset();
                    if (adIdInput) adIdInput.value = '';
                    editingAdId = null;
                    const heading = document.querySelector('h2');
                    if (heading) heading.textContent = '添加/编辑广告';
                    
                    // 清空图片预览
                    const coverImagePreview = document.getElementById('coverImagePreview');
                    if (coverImagePreview) {
                        coverImagePreview.style.display = 'none';
                        const previewImg = coverImagePreview.querySelector('img');
                        if (previewImg) {
                            previewImg.src = '';
                        }
                    }
                    
                    fetchAds(); // 重新加载广告列表
                } else {
                    alert('保存广告失败: ' + (result.error || '未知错误'));
                }
            } else {
                // 备用方案：直接使用fetch
                const url = isEditing ? `/api/ads/${adId}` : '/api/ads';
                const method = isEditing ? 'PUT' : 'POST';
                
                const response = await fetch(url, {
                    method: method,
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${localStorage.getItem('authToken')}`
                    },
                    body: JSON.stringify(adData)
                });
                
                // 特别处理401未授权错误
                if (response.status === 401) {
                    alert('未授权访问，请重新登录');
                    // 清除本地存储的令牌
                    localStorage.removeItem('authToken');
                    // 重定向到登录页面
                    window.location.href = '/admin/login.html';
                    return;
                }
                
                // 检查响应状态
                if (!response.ok) {
                    let errorMessage = `HTTP error! status: ${response.status}`;
                    try {
                        const errorResult = await response.json();
                        errorMessage = errorResult.error || errorMessage;
                    } catch (e) {
                        // 如果无法解析错误响应为JSON，使用默认错误消息
                    }
                    throw new Error(errorMessage);
                }
                
                const result = await response.json();
                
                if (result.success) {
                    alert(isEditing ? '广告更新成功' : '广告创建成功');
                    if (adForm) adForm.reset();
                    if (adIdInput) adIdInput.value = '';
                    editingAdId = null;
                    const heading = document.querySelector('h2');
                    if (heading) heading.textContent = '添加/编辑广告';
                    
                    // 清空图片预览
                    const coverImagePreview = document.getElementById('coverImagePreview');
                    if (coverImagePreview) {
                        coverImagePreview.style.display = 'none';
                        const previewImg = coverImagePreview.querySelector('img');
                        if (previewImg) {
                            previewImg.src = '';
                        }
                    }
                    
                    fetchAds(); // 重新加载广告列表
                } else {
                    alert('保存广告失败: ' + (result.error || '未知错误'));
                }
            }
        } catch (error) {
            console.error('保存广告失败:', error);
            alert('保存广告失败: ' + error.message);
        }
    }
    
    // 取消编辑
    function cancelEdit() {
        if (adForm) adForm.reset();
        const adIdInput = document.getElementById('adId');
        if (adIdInput) adIdInput.value = '';
        editingAdId = null;
        const heading = document.querySelector('h2');
        if (heading) heading.textContent = '添加/编辑广告';
        
        // 清空图片预览
        const coverImagePreview = document.getElementById('coverImagePreview');
        if (coverImagePreview) {
            coverImagePreview.style.display = 'none';
            const previewImg = coverImagePreview.querySelector('img');
            if (previewImg) {
                previewImg.src = '';
            }
        }
    }
    
    // 显示图片选择模态框
    async function showImageSelectModal() {
        const modal = document.getElementById('imageSelectModal');
        
        // 如果模态框不存在，则创建一个
        if (!modal) {
            const newModal = document.createElement('div');
            newModal.className = 'modal fade';
            newModal.id = 'imageSelectModal';
            newModal.tabIndex = '-1';
            newModal.innerHTML = `
                <div class="modal-dialog modal-xl">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">选择图片</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="d-flex justify-content-between mb-3">
                                <button class="btn btn-primary" id="refreshImagesBtn">
                                    <i class="bi bi-arrow-repeat"></i> 刷新
                                </button>
                                <div>
                                    <input type="text" class="form-control" id="imageSearchInput" placeholder="搜索图片...">
                                </div>
                            </div>
                            <div class="row" id="imageGrid">
                                <!-- 图片将通过JavaScript动态加载 -->
                            </div>
                            <nav>
                                <ul class="pagination justify-content-center" id="imagePagination">
                                    <!-- 分页将通过JavaScript动态加载 -->
                                </ul>
                            </nav>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
                        </div>
                    </div>
                </div>
            `;
            
            document.body.appendChild(newModal);
        }
        
        const imageSelectModal = new bootstrap.Modal(document.getElementById('imageSelectModal'));
        imageSelectModal.show();
        
        // 加载图片
        loadImagesForSelection();
        
        // 绑定刷新按钮事件（确保只绑定一次）
        const refreshBtn = document.getElementById('refreshImagesBtn');
        if (refreshBtn) {
            // 移除旧的事件监听器
            const newRefreshBtn = refreshBtn.cloneNode(true);
            refreshBtn.parentNode.replaceChild(newRefreshBtn, refreshBtn);
            newRefreshBtn.addEventListener('click', loadImagesForSelection);
        }
    }
    
    // 加载图片用于选择
    async function loadImagesForSelection() {
        try {
            const response = await adminPanel.apiRequest('/api/images');
            
            if (response.ok) {
                const result = await response.json();
                const images = result.data || [];
                
                const imageGrid = document.getElementById('imageGrid');
                if (imageGrid) {
                    imageGrid.innerHTML = '';
                    
                    if (images.length === 0) {
                        imageGrid.innerHTML = '<div class="col-12 text-center">暂无图片</div>';
                        return;
                    }
                    
                    images.forEach(image => {
                        const col = document.createElement('div');
                        col.className = 'col-md-3 mb-3';
                        // 确保使用完整的URL路径显示图片
                        const imageUrl = image.object_key.startsWith('http') || image.object_key.startsWith('/api/images/public/') 
                            ? image.object_key 
                            : `/api/images/public/${image.object_key}`;
                            
                        col.innerHTML = `
                            <div class="card image-grid-item" data-object-key="${image.object_key}">
                                <img src="${imageUrl}" class="card-img-top" alt="${image.original_name}" style="height: 150px; object-fit: cover;">
                                <div class="card-body p-2">
                                    <p class="card-text small text-truncate mb-0">${image.original_name}</p>
                                </div>
                            </div>
                        `;
                        imageGrid.appendChild(col);
                    });
                    
                    // 绑定图片选择事件
                    document.querySelectorAll('.image-grid-item').forEach(item => {
                        // 移除旧的事件监听器
                        const newItem = item.cloneNode(true);
                        item.parentNode.replaceChild(newItem, item);
                        
                        newItem.addEventListener('click', function() {
                            const objectKey = this.getAttribute('data-object-key');
                            
                            // 更新预览
                            const imageUrlInput = document.getElementById('image_url');
                            const coverImagePreview = document.getElementById('coverImagePreview');
                            const previewImg = coverImagePreview ? coverImagePreview.querySelector('img') : null;
                            
                            if (imageUrlInput && objectKey) {
                                imageUrlInput.value = objectKey;
                            }
                            
                            if (previewImg && objectKey) {
                                // 确保使用完整的URL路径
                                const imageUrl = objectKey.startsWith('http') || objectKey.startsWith('/api/images/public/') 
                                    ? objectKey 
                                    : `/api/images/public/${objectKey}`;
                                previewImg.src = imageUrl;
                                coverImagePreview.style.display = 'block';
                            }
                            
                            // 关闭模态框
                            const modal = bootstrap.Modal.getInstance(document.getElementById('imageSelectModal'));
                            if (modal) {
                                modal.hide();
                            }
                        });
                    });
                }
            }
        } catch (error) {
            console.error('加载图片失败:', error);
            adminPanel.showMessage('加载图片失败', 'error');
        }
    }
    
    // 显示图片上传模态框
    function showImageUploadModal() {
        const modal = document.getElementById('imageUploadModal');
        
        // 如果模态框不存在，则创建一个
        if (!modal) {
            const newModal = document.createElement('div');
            newModal.className = 'modal fade';
            newModal.id = 'imageUploadModal';
            newModal.tabIndex = '-1';
            newModal.innerHTML = `
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">上传图片</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form id="imageUploadForm">
                                <div class="mb-3">
                                    <label for="imageFile" class="form-label">选择图片</label>
                                    <input class="form-control" type="file" id="imageFile" accept="image/*">
                                </div>
                                <div class="mb-3">
                                    <label for="imageAltText" class="form-label">替代文本</label>
                                    <input type="text" class="form-control" id="imageAltText">
                                </div>
                                <div class="mb-3">
                                    <label for="imageDescription" class="form-label">描述</label>
                                    <textarea class="form-control" id="imageDescription" rows="3"></textarea>
                                </div>
                            </form>
                            <div id="uploadResult" class="mt-3" style="display: none;"></div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
                            <button type="button" class="btn btn-primary" id="uploadImageButton">上传</button>
                        </div>
                    </div>
                </div>
            `;
            
            document.body.appendChild(newModal);
            
            // 绑定上传按钮事件
            const uploadBtn = newModal.querySelector('#uploadImageButton');
            if (uploadBtn) {
                uploadBtn.addEventListener('click', handleImageUpload);
            }
        }
        
        const imageUploadModal = new bootstrap.Modal(document.getElementById('imageUploadModal'));
        imageUploadModal.show();
        
        // 确保上传按钮事件已绑定
        const uploadBtn = document.getElementById('uploadImageButton');
        if (uploadBtn) {
            // 移除旧的事件监听器
            const newUploadBtn = uploadBtn.cloneNode(true);
            uploadBtn.parentNode.replaceChild(newUploadBtn, uploadBtn);
            newUploadBtn.addEventListener('click', handleImageUpload);
        }
    }
    
    // 处理图片上传
    async function handleImageUpload() {
        const fileInput = document.getElementById('imageFile');
        const altTextInput = document.getElementById('imageAltText');
        const descriptionInput = document.getElementById('imageDescription');
        
        const file = fileInput.files[0];
        if (!file) {
            adminPanel.showMessage('请选择要上传的图片', 'error');
            return;
        }
        
        try {
            // 显示上传进度
            const uploadResult = document.getElementById('uploadResult');
            if (uploadResult) {
                uploadResult.style.display = 'block';
                uploadResult.innerHTML = '<div class="alert alert-info">正在上传...</div>';
            }
            
            // 上传文件
            const result = await adminPanel.uploadImage(file, altTextInput.value, descriptionInput.value);
            
            // 确保response不为null或undefined
            if (!result || !result.data) {
                adminPanel.showMessage('上传失败，请重试', 'error');
                return;
            }
            
            const imageData = result.data;
            
            // 检查object_key是否存在
            if (!imageData.object_key) {
                adminPanel.showMessage('图片上传成功，但无法获取图片信息', 'error');
                return;
            }
            
            // 确保object_key是有效的
            if (imageData.object_key === 'null' || imageData.object_key === 'undefined') {
                adminPanel.showMessage('图片上传成功，但获取到无效的图片信息', 'error');
                return;
            }
            
            adminPanel.showMessage('图片上传成功', 'success');
            
            // 更新预览
            const imageUrlInput = document.getElementById('image_url');
            const coverImagePreview = document.getElementById('coverImagePreview');
            const previewImg = coverImagePreview ? coverImagePreview.querySelector('img') : null;
            
            // 将object_key保存到图片URL字段
            if (imageUrlInput) {
                imageUrlInput.value = imageData.object_key;
            }
            
            if (previewImg) {
                // 确保使用完整的URL路径
                const imageUrl = imageData.url || `/api/images/public/${imageData.object_key}`;
                previewImg.src = imageUrl;
                coverImagePreview.style.display = 'block';
            }
            
            // 关闭模态框
            const modal = bootstrap.Modal.getInstance(document.getElementById('imageUploadModal'));
            if (modal) {
                modal.hide();
            }
        } catch (error) {
            console.error('上传图片出错:', error);
            const uploadResult = document.getElementById('uploadResult');
            if (uploadResult) {
                uploadResult.style.display = 'block';
                uploadResult.innerHTML = `<div class="alert alert-danger">上传图片时发生错误: ${error.message}</div>`;
            }
            adminPanel.showMessage('上传图片时发生错误: ' + error.message, 'error');
        }
    }
    
    // 绑定事件
    if (adForm) adForm.addEventListener('submit', saveAd);
    if (cancelEditBtn) cancelEditBtn.addEventListener('click', cancelEdit);
    
    // 绑定封面图片选择和上传事件
    const selectImageBtn = document.getElementById('selectImageBtn');
    if (selectImageBtn) {
        // 使用标准方式移除旧的事件监听器
        const newSelectBtn = selectImageBtn.cloneNode(false);
        // 复制所有属性
        for (let i = 0; i < selectImageBtn.attributes.length; i++) {
            const attr = selectImageBtn.attributes[i];
            newSelectBtn.setAttribute(attr.name, attr.value);
        }
        // 复制子元素
        while (selectImageBtn.firstChild) {
            newSelectBtn.appendChild(selectImageBtn.firstChild);
        }
        selectImageBtn.parentNode.replaceChild(newSelectBtn, selectImageBtn);
        newSelectBtn.addEventListener('click', showImageSelectModal);
    }
    
    const uploadImageBtn = document.getElementById('uploadImageBtn');
    if (uploadImageBtn) {
        // 使用标准方式移除旧的事件监听器
        const newUploadBtn = uploadImageBtn.cloneNode(false);
        // 复制所有属性
        for (let i = 0; i < uploadImageBtn.attributes.length; i++) {
            const attr = uploadImageBtn.attributes[i];
            newUploadBtn.setAttribute(attr.name, attr.value);
        }
        // 复制子元素
        while (uploadImageBtn.firstChild) {
            newUploadBtn.appendChild(uploadImageBtn.firstChild);
        }
        uploadImageBtn.parentNode.replaceChild(newUploadBtn, uploadImageBtn);
        newUploadBtn.addEventListener('click', showImageUploadModal);
    }
    
    // 初始化页面
    fetchAds();
});