// 预设管理功能脚本
// 确保在DOM加载后初始化
let isInitialized = false;

document.addEventListener('DOMContentLoaded', function() {
  if (isInitialized) return;
  isInitialized = true;
  
  console.log('预设管理页面初始化...');
  
  // 等待adminPanel初始化
  const initInterval = setInterval(() => {
    if (window.adminPanel && window.adminPanel.authToken) {
      clearInterval(initInterval);
      initializePresets();
      // 添加事件监听器
      addEventListeners();
    }
  }, 100);
  
  // 10秒超时
  setTimeout(() => {
    clearInterval(initInterval);
    if (!window.adminPanel) {
      console.error('AdminPanel初始化超时');
      adminPanel.showMessage('系统初始化失败，请刷新页面', 'error');
    }
  }, 10000);
});

// 添加事件监听器
function addEventListeners() {
  // 事件委托已在admin.js中处理，这里只需要确保函数正确暴露到全局作用域
  // 确保在DOM更新后绑定事件
  setTimeout(bindCategoryEvents, 100);
  setTimeout(bindPresetEvents, 100);
  
  // 绑定图片选择和上传按钮事件
  const selectImageBtn = document.getElementById('selectImageBtn');
  if (selectImageBtn) {
    selectImageBtn.addEventListener('click', showImageSelectModal);
  }
  
  const uploadImageBtn = document.getElementById('uploadImageBtn');
  if (uploadImageBtn) {
    uploadImageBtn.addEventListener('click', showImageUploadModal);
  }
  
  // 绑定效果图选择和上传按钮事件
  const selectEffectImagesBtn = document.getElementById('selectEffectImagesBtn');
  if (selectEffectImagesBtn) {
    selectEffectImagesBtn.addEventListener('click', showEffectImagesSelectModal);
  }
  
  const uploadEffectImagesBtn = document.getElementById('uploadEffectImagesBtn');
  if (uploadEffectImagesBtn) {
    uploadEffectImagesBtn.addEventListener('click', showEffectImagesUploadModal);
  }
  
  // 绑定保存按钮事件
  const saveCategoryBtn = document.getElementById('saveCategoryBtn');
  if (saveCategoryBtn) {
    saveCategoryBtn.addEventListener('click', saveCategory);
  }
  
  const savePresetBtn = document.getElementById('savePresetBtn');
  if (savePresetBtn) {
    savePresetBtn.addEventListener('click', savePreset);
  }
  
  // 绑定添加按钮事件
  const addCategoryBtn = document.getElementById('addCategoryBtn');
  if (addCategoryBtn) {
    addCategoryBtn.addEventListener('click', showAddCategoryForm);
  }
  
  const addPresetBtn = document.getElementById('addPresetBtn');
  if (addPresetBtn) {
    addPresetBtn.addEventListener('click', showAddPresetForm);
  }
  
  // 为新添加的按钮绑定事件
  const addPresetBtnTop = document.getElementById('addPresetBtnTop');
  if (addPresetBtnTop) {
    addPresetBtnTop.addEventListener('click', showAddPresetForm);
  }
  
  // 绑定刷新按钮事件
  const refreshBtn = document.getElementById('refreshPresetsBtn');
  if (refreshBtn) {
    refreshBtn.addEventListener('click', function() {
      loadCategories();
      loadPresets(1);
    });
  }
  
  // 绑定搜索事件
  const searchInput = document.getElementById('searchInput');
  if (searchInput) {
    searchInput.addEventListener('input', function() {
      searchPresets(1);
    });
  }
  
  const categoryFilter = document.getElementById('categoryFilter');
  if (categoryFilter) {
    categoryFilter.addEventListener('change', function() {
      searchPresets(1);
    });
  }
}

// 绑定分类事件
function bindCategoryEvents() {
  // 移除之前可能添加的事件监听器，避免重复绑定
  const categoriesTable = document.getElementById('categoriesTable');
  if (categoriesTable) {
    const editCategoryButtons = categoriesTable.querySelectorAll('.edit-category-btn');
    const deleteCategoryButtons = categoriesTable.querySelectorAll('.delete-category-btn');
    
    // 编辑分类按钮
    editCategoryButtons.forEach(button => {
      // 移除之前可能添加的事件监听器
      const newButton = button.cloneNode(true);
      button.parentNode.replaceChild(newButton, button);
      newButton.addEventListener('click', function() {
        const categoryId = this.getAttribute('data-id');
        // 直接调用函数
        showEditCategoryForm(categoryId);
      });
    });
    
    // 删除分类按钮
    deleteCategoryButtons.forEach(button => {
      // 移除之前可能添加的事件监听器
      const newButton = button.cloneNode(true);
      button.parentNode.replaceChild(newButton, button);
      newButton.addEventListener('click', function() {
        const categoryId = this.getAttribute('data-id');
        // 直接调用函数
        deleteCategory(categoryId);
      });
    });
  }
}

// 绑定预设事件
function bindPresetEvents() {
  // 移除之前可能添加的事件监听器，避免重复绑定
  const presetsTable = document.getElementById('presetsTable');
  if (presetsTable) {
    const editPresetButtons = presetsTable.querySelectorAll('.edit-preset-btn');
    const deletePresetButtons = presetsTable.querySelectorAll('.delete-preset-btn');
    
    // 编辑预设按钮
    editPresetButtons.forEach(button => {
      // 移除之前可能添加的事件监听器
      const newButton = button.cloneNode(true);
      button.parentNode.replaceChild(newButton, button);
      newButton.addEventListener('click', function() {
        const presetId = this.getAttribute('data-id');
        // 直接调用函数
        showEditPresetForm(presetId);
      });
    });
    
    // 删除预设按钮
    deletePresetButtons.forEach(button => {
      // 移除之前可能添加的事件监听器
      const newButton = button.cloneNode(true);
      button.parentNode.replaceChild(newButton, button);
      newButton.addEventListener('click', function() {
        const presetId = this.getAttribute('data-id');
        // 直接调用函数
        deletePreset(presetId);
      });
    });
  }
}

// 显示图片选择模态框
async function showImageSelectModal() {
  const modal = document.getElementById('imageSelectModal');
  
  // 如果模态框不存在，则创建一个
  if (!modal) {
    const newModal = document.createElement('div');
    newModal.className = 'modal fade';
    newModal.id = 'imageSelectModal';
    newModal.tabIndex = '-1';
    newModal.innerHTML = `
      <div class="modal-dialog modal-xl">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">选择图片</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <div class="d-flex justify-content-between mb-3">
              <button class="btn btn-primary" id="refreshImagesBtn">
                <i class="bi bi-arrow-repeat"></i> 刷新
              </button>
              <div>
                <input type="text" class="form-control" id="imageSearchInput" placeholder="搜索图片...">
              </div>
            </div>
            <div class="row" id="imageGrid">
              <!-- 图片将通过JavaScript动态加载 -->
            </div>
            <nav>
              <ul class="pagination justify-content-center" id="imagePagination">
                <!-- 分页将通过JavaScript动态加载 -->
              </ul>
            </nav>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
          </div>
        </div>
      </div>
    `;
    
    document.body.appendChild(newModal);
    
    // 绑定刷新按钮事件
    const refreshBtn = newModal.querySelector('#refreshImagesBtn');
    if (refreshBtn) {
      refreshBtn.addEventListener('click', function() {
        loadImages(1, 20, document.getElementById('imageSearchInput')?.value || '');
      });
    }
    
    // 绑定搜索输入框事件
    const searchInput = newModal.querySelector('#imageSearchInput');
    if (searchInput) {
      searchInput.addEventListener('input', function() {
        loadImages(1, 20, this.value);
      });
    }
  }
  
  const imageSelectModal = new bootstrap.Modal(document.getElementById('imageSelectModal'));
  imageSelectModal.show();
  
  // 加载图片
  loadImages();
}

// 显示效果图选择模态框
async function showEffectImagesSelectModal() {
  const modal = document.getElementById('effectImagesSelectModal');
  
  // 如果模态框不存在，则创建一个
  if (!modal) {
    const newModal = document.createElement('div');
    newModal.className = 'modal fade';
    newModal.id = 'effectImagesSelectModal';
    newModal.tabIndex = '-1';
    newModal.innerHTML = `
      <div class="modal-dialog modal-xl">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">选择效果图</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <div class="d-flex justify-content-between mb-3">
              <button class="btn btn-primary" id="refreshEffectImagesBtn">
                <i class="bi bi-arrow-repeat"></i> 刷新
              </button>
              <div>
                <input type="text" class="form-control" id="effectImagesSearchInput" placeholder="搜索图片...">
              </div>
            </div>
            <div class="row" id="effectImagesGrid">
              <!-- 图片将通过JavaScript动态加载 -->
            </div>
            <nav>
              <ul class="pagination justify-content-center" id="effectImagesPagination">
                <!-- 分页将通过JavaScript动态加载 -->
              </ul>
            </nav>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
            <button type="button" class="btn btn-primary" id="confirmEffectImagesBtn">确认选择</button>
          </div>
        </div>
      </div>
    `;
    
    document.body.appendChild(newModal);
    
    // 绑定刷新按钮事件
    const refreshBtn = newModal.querySelector('#refreshEffectImagesBtn');
    if (refreshBtn) {
      refreshBtn.addEventListener('click', function() {
        loadEffectImages(1, 20, document.getElementById('effectImagesSearchInput')?.value || '');
      });
    }
    
    // 绑定搜索输入框事件
    const searchInput = newModal.querySelector('#effectImagesSearchInput');
    if (searchInput) {
      searchInput.addEventListener('input', function() {
        loadEffectImages(1, 20, this.value);
      });
    }
    
    // 绑定确认按钮事件
    const confirmBtn = newModal.querySelector('#confirmEffectImagesBtn');
    if (confirmBtn) {
      confirmBtn.addEventListener('click', confirmEffectImagesSelection);
    }
  }
  
  const effectImagesSelectModal = new bootstrap.Modal(document.getElementById('effectImagesSelectModal'));
  effectImagesSelectModal.show();
  
  // 加载图片
  loadEffectImages();
}

// 显示图片上传模态框
function showImageUploadModal() {
  const modal = document.getElementById('imageUploadModal');
  
  // 如果模态框不存在，则创建一个
  if (!modal) {
    const newModal = document.createElement('div');
    newModal.className = 'modal fade';
    newModal.id = 'imageUploadModal';
    newModal.tabIndex = '-1';
    newModal.innerHTML = `
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">上传图片</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <form id="imageUploadForm">
              <div class="mb-3">
                <label for="imageFile" class="form-label">选择图片</label>
                <input class="form-control" type="file" id="imageFile" accept="image/*">
              </div>
              <div class="mb-3">
                <label for="imageAltText" class="form-label">替代文本</label>
                <input type="text" class="form-control" id="imageAltText">
              </div>
              <div class="mb-3">
                <label for="imageDescription" class="form-label">描述</label>
                <textarea class="form-control" id="imageDescription" rows="3"></textarea>
              </div>
            </form>
            <div id="uploadResult" class="mt-3" style="display: none;"></div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
            <button type="button" class="btn btn-primary" id="uploadImageButton">上传</button>
          </div>
        </div>
      </div>
    `;
    
    document.body.appendChild(newModal);
    
    // 绑定上传按钮事件
    const uploadBtn = newModal.querySelector('#uploadImageButton');
    if (uploadBtn) {
      // 移除之前可能添加的事件监听器
      const newUploadBtn = uploadBtn.cloneNode(true);
      uploadBtn.parentNode.replaceChild(newUploadBtn, uploadBtn);
      newUploadBtn.addEventListener('click', handleImageUpload);
    }
  } else {
    // 如果模态框已存在，确保上传按钮事件已绑定
    const uploadBtn = modal.querySelector('#uploadImageButton');
    if (uploadBtn) {
      // 移除之前可能添加的事件监听器
      const newUploadBtn = uploadBtn.cloneNode(true);
      uploadBtn.parentNode.replaceChild(newUploadBtn, uploadBtn);
      newUploadBtn.addEventListener('click', handleImageUpload);
    }
  }
  
  const imageUploadModal = new bootstrap.Modal(document.getElementById('imageUploadModal'));
  imageUploadModal.show();
}

// 显示效果图上传模态框
function showEffectImagesUploadModal() {
  const modal = document.getElementById('effectImagesUploadModal');
  
  // 如果模态框不存在，则创建一个
  if (!modal) {
    const newModal = document.createElement('div');
    newModal.className = 'modal fade';
    newModal.id = 'effectImagesUploadModal';
    newModal.tabIndex = '-1';
    newModal.innerHTML = `
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">上传效果图</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <form id="effectImagesUploadForm">
              <div class="mb-3">
                <label for="effectImagesFile" class="form-label">选择图片</label>
                <input class="form-control" type="file" id="effectImagesFile" accept="image/*" multiple>
              </div>
              <div class="mb-3">
                <label for="effectImagesAltText" class="form-label">替代文本</label>
                <input type="text" class="form-control" id="effectImagesAltText">
              </div>
              <div class="mb-3">
                <label for="effectImagesDescription" class="form-label">描述</label>
                <textarea class="form-control" id="effectImagesDescription" rows="3"></textarea>
              </div>
            </form>
            <div id="effectImagesUploadResult" class="mt-3" style="display: none;"></div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
            <button type="button" class="btn btn-primary" id="uploadEffectImagesButton">上传</button>
          </div>
        </div>
      </div>
    `;
    
    document.body.appendChild(newModal);
    
    // 绑定上传按钮事件
    const uploadBtn = newModal.querySelector('#uploadEffectImagesButton');
    if (uploadBtn) {
      // 移除之前可能添加的事件监听器
      const newUploadBtn = uploadBtn.cloneNode(true);
      uploadBtn.parentNode.replaceChild(newUploadBtn, uploadBtn);
      newUploadBtn.addEventListener('click', handleEffectImagesUpload);
    }
  } else {
    // 如果模态框已存在，确保上传按钮事件已绑定
    const uploadBtn = modal.querySelector('#uploadEffectImagesButton');
    if (uploadBtn) {
      // 移除之前可能添加的事件监听器
      const newUploadBtn = uploadBtn.cloneNode(true);
      uploadBtn.parentNode.replaceChild(newUploadBtn, uploadBtn);
      newUploadBtn.addEventListener('click', handleEffectImagesUpload);
    }
  }
  
  const effectImagesUploadModal = new bootstrap.Modal(document.getElementById('effectImagesUploadModal'));
  effectImagesUploadModal.show();
}

// 处理图片上传
async function handleImageUpload() {
  const fileInput = document.getElementById('imageFile');
  const altTextInput = document.getElementById('imageAltText');
  const descriptionInput = document.getElementById('imageDescription');
  
  const file = fileInput.files[0];
  if (!file) {
    adminPanel.showMessage('请选择要上传的图片', 'error');
    return;
  }
  
  try {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('alt_text', altTextInput.value || '');
    formData.append('description', descriptionInput.value || '');
    
    const response = await adminPanel.apiRequest('/api/images/upload', {
      method: 'POST',
      body: formData
    });
    
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error || '上传图片失败');
    }
    
    const responseData = await response.json();
    
    // 检查响应数据结构
    if (!responseData.success || !responseData.data) {
      throw new Error('服务器返回无效响应');
    }
    
    const data = responseData.data;
    
    // 更新预设表单中的图片字段
    const coverImageInput = document.getElementById('presetCoverImage');
    if (coverImageInput) {
      coverImageInput.value = data.object_key;
    }
    
    // 更新预览
    const coverImagePreview = document.getElementById('coverImagePreview');
    const previewImg = coverImagePreview.querySelector('img');
    if (previewImg) {
      // 确保使用完整的URL路径
      const imageUrl = data.object_key.startsWith('http') || data.object_key.startsWith('/api/images/public/') 
        ? data.object_key 
        : `/api/images/public/${data.object_key}`;
      previewImg.src = imageUrl;
      coverImagePreview.style.display = 'block';
    }
    
    // 关闭模态框并确保背景层消失
    cleanupModal('imageUploadModal');
    
    adminPanel.showMessage('图片上传成功', 'success');
  } catch (error) {
    console.error('Error uploading image:', error);
    adminPanel.showMessage('上传图片失败: ' + error.message, 'error');
  }
}

// 处理效果图上传
async function handleEffectImagesUpload() {
  const fileInput = document.getElementById('effectImagesFile');
  const altTextInput = document.getElementById('effectImagesAltText');
  const descriptionInput = document.getElementById('effectImagesDescription');
  
  const files = fileInput.files;
  if (!files || files.length === 0) {
    adminPanel.showMessage('请选择要上传的图片', 'error');
    return;
  }
  
  try {
    const uploadedImages = [];
    
    // 逐个上传文件
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const formData = new FormData();
      formData.append('file', file);
      formData.append('alt_text', altTextInput.value || '');
      formData.append('description', descriptionInput.value || '');
      
      const response = await adminPanel.apiRequest('/api/images/upload', {
        method: 'POST',
        body: formData
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(`上传图片失败 (${file.name}): ${errorData.error || '未知错误'}`);
      }
      
      const responseData = await response.json();
      
      // 检查响应数据结构
      if (!responseData.success || !responseData.data) {
        throw new Error(`服务器返回无效响应 (${file.name})`);
      }
      
      uploadedImages.push(responseData.data);
    }
    
    // 更新预设表单中的效果图字段
    const effectImagesInput = document.getElementById('presetEffectImages');
    if (effectImagesInput) {
      const imageKeys = uploadedImages.map(img => img.object_key);
      effectImagesInput.value = imageKeys.join(',');
    }
    
    // 更新预览
    renderEffectImagesPreview(uploadedImages);
    
    // 关闭模态框并确保背景层消失
    cleanupModal('effectImagesUploadModal');
    
    adminPanel.showMessage(`成功上传 ${uploadedImages.length} 张图片`, 'success');
  } catch (error) {
    console.error('Error uploading effect images:', error);
    adminPanel.showMessage('上传效果图失败: ' + error.message, 'error');
  }
}

// 加载图片列表
async function loadImages(page = 1, limit = 20, search = '') {
  try {
    const params = new URLSearchParams({
      page: page,
      limit: limit,
      search: search
    });
    
    const response = await adminPanel.apiRequest(`/api/images?${params.toString()}`);
    
    if (!response.ok) {
      throw new Error('获取图片失败');
    }
    
    const data = await response.json();
    renderImageGrid(data.data);
    renderImagePagination(data.total, page, limit);
  } catch (error) {
    console.error('Error loading images:', error);
    adminPanel.showMessage('获取图片失败，请检查网络连接', 'error');
  }
}

// 加载效果图列表
async function loadEffectImages(page = 1, limit = 20, search = '') {
  try {
    const params = new URLSearchParams({
      page: page,
    });
    const response = await fetch(`/api/effect-images?${params}`);
    if (!response.ok) {
      throw new Error('Network response was not ok');
    }
    const data = await response.json();
    renderEffectImages(data);
  } catch (error) {
    console.error('There was a problem with the fetch operation:', error);
    adminPanel.showMessage('获取图片失败，请检查网络连接', 'error');
  }
}

// 加载预设列表
async function loadPresets(page = 1, limit = 20, search = '') {
  try {
    const params = new URLSearchParams({
      page: page,
      limit: limit,
      search: search,
    });
    const response = await fetch(`/api/presets?${params}`);
    if (!response.ok) {
      throw new Error('Network response was not ok');
    }
    const data = await response.json();
    renderPresets(data);
  } catch (error) {
    console.error('There was a problem with the fetch operation:', error);
    adminPanel.showMessage('搜索预设失败，请检查网络连接', 'error');
  }
}

// 渲染分页控件
function renderPagination(pagination, loadFunction) {
  const paginationEl = document.getElementById('pagination');
  if (!paginationEl) {
    console.warn('分页元素未找到');
    return;
  }
  
  // 如果没有分页信息或只有一页，隐藏分页控件
  if (!pagination || pagination.totalPages <= 1) {
    paginationEl.innerHTML = '';
    return;
  }
  
  const { currentPage, totalPages } = pagination;
  
  // 验证分页数据
  if (typeof currentPage !== 'number' || typeof totalPages !== 'number' || currentPage < 1 || totalPages < 1) {
    console.warn('无效的分页数据:', pagination);
    paginationEl.innerHTML = '';
    return;
  }
  
  let paginationHTML = '';
  
  // 上一页按钮
  if (currentPage > 1) {
    paginationHTML += `<li class="page-item"><a class="page-link" href="#" data-page="${currentPage - 1}">上一页</a></li>`;
  } else {
    paginationHTML += '<li class="page-item disabled"><span class="page-link">上一页</span></li>';
  }
  
  // 页码按钮
  // 计算显示的页码范围
  let startPage = Math.max(1, currentPage - 2);
  let endPage = Math.min(totalPages, currentPage + 2);
  
  // 确保始终显示5个页码按钮（如果总页数足够）
  if (endPage - startPage < 4) {
    if (startPage === 1) {
      endPage = Math.min(totalPages, startPage + 4);
    } else {
      startPage = Math.max(1, endPage - 4);
    }
  }
  
  // 添加省略号
  if (startPage > 1) {
    paginationHTML += '<li class="page-item"><a class="page-link" href="#" data-page="1">1</a></li>';
    if (startPage > 2) {
      paginationHTML += '<li class="page-item disabled"><span class="page-link">...</span></li>';
    }
  }
  
  // 添加页码按钮
  for (let i = startPage; i <= endPage; i++) {
    if (i === currentPage) {
      paginationHTML += `<li class="page-item active"><span class="page-link">${i}</span></li>`;
    } else {
      paginationHTML += `<li class="page-item"><a class="page-link" href="#" data-page="${i}">${i}</a></li>`;
    }
  }
  
  // 添加省略号和最后一页
  if (endPage < totalPages) {
    if (endPage < totalPages - 1) {
      paginationHTML += '<li class="page-item disabled"><span class="page-link">...</span></li>';
    }
    paginationHTML += `<li class="page-item"><a class="page-link" href="#" data-page="${totalPages}">${totalPages}</a></li>`;
  }
  
  // 下一页按钮
  if (currentPage < totalPages) {
    paginationHTML += `<li class="page-item"><a class="page-link" href="#" data-page="${currentPage + 1}">下一页</a></li>`;
  } else {
    paginationHTML += '<li class="page-item disabled"><span class="page-link">下一页</span></li>';
  }
  
  paginationEl.innerHTML = paginationHTML;
  
  // 绑定分页点击事件
  paginationEl.querySelectorAll('.page-link').forEach(link => {
    link.addEventListener('click', function(e) {
      e.preventDefault();
      const page = parseInt(this.getAttribute('data-page'));
      if (page && typeof loadFunction === 'function') {
        loadFunction(page);
      }
    });
  });
}

// 统一的模态框清除函数，确保背景层完全消失
function clearModal() {
  const modal = document.getElementById('modal');
  modal.style.display = 'none';
}

// 渲染图片网格
function renderImageGrid(images) {
  const imageGrid = document.getElementById('imageGrid');
  imageGrid.innerHTML = '';
  images.forEach(image => {
    const col = document.createElement('div');
    col.className = 'col-md-3 mb-3';
    // 确保使用完整的URL路径显示图片
    const imageUrl = image.object_key.startsWith('http') || image.object_key.startsWith('/api/images/public/') 
      ? image.object_key 
      : `/api/images/public/${image.object_key}`;
      
    col.innerHTML = `
      <div class="card image-grid-item" data-object-key="${image.object_key}">
        <img src="${imageUrl}" class="card-img-top" alt="${image.original_name || '图片'}" style="height: 150px; object-fit: cover;">
        <div class="card-body p-2">
          <p class="card-text small text-truncate mb-0">${image.original_name || '无描述'}</p>
        </div>
      </div>
    `;
    imageGrid.appendChild(col);
  });
  
  // 绑定图片选择事件
  document.querySelectorAll('.image-grid-item').forEach(item => {
    // 移除旧的事件监听器
    const newItem = item.cloneNode(true);
    item.parentNode.replaceChild(newItem, item);
    
    newItem.addEventListener('click', function() {
      const objectKey = this.getAttribute('data-object-key');
      
      // 更新预览
      const coverImageInput = document.getElementById('presetCoverImage');
      const coverImagePreview = document.getElementById('coverImagePreview');
      const previewImg = coverImagePreview.querySelector('img');
      
      if (coverImageInput) {
        coverImageInput.value = objectKey;
      }
      
      if (previewImg) {
        // 确保使用完整的URL路径
        const imageUrl = objectKey.startsWith('http') || objectKey.startsWith('/api/images/public/') 
          ? objectKey 
          : `/api/images/public/${objectKey}`;
        previewImg.src = imageUrl;
        coverImagePreview.style.display = 'block';
      }
      
      // 关闭模态框并确保背景层消失
      cleanupModal('imageSelectModal');
    });
  });
}

// 渲染效果图网格
function renderEffectImagesGrid(images) {
  const imageGrid = document.getElementById('effectImagesGrid');
  imageGrid.innerHTML = '';
  
  images.forEach(image => {
    const col = document.createElement('div');
    col.className = 'col-md-3 mb-3';
    // 确保使用完整的URL路径显示图片
    const imageUrl = image.object_key.startsWith('http') || image.object_key.startsWith('/api/images/public/') 
      ? image.object_key 
      : `/api/images/public/${image.object_key}`;
      
    col.innerHTML = `
      <div class="card effect-image-grid-item" data-object-key="${image.object_key}">
        <img src="${imageUrl}" class="card-img-top" alt="${image.original_name || '图片'}" style="height: 150px; object-fit: cover;">
        <div class="card-body p-2">
          <p class="card-text small text-truncate mb-0">${image.original_name || '无描述'}</p>
        </div>
      </div>
    `;
    imageGrid.appendChild(col);
  });
  
  // 绑定图片选择事件
  document.querySelectorAll('.effect-image-grid-item').forEach(item => {
    // 移除旧的事件监听器
    const newItem = item.cloneNode(true);
    item.parentNode.replaceChild(newItem, item);
    
    newItem.addEventListener('click', function() {
      // 切换选中状态
      this.classList.toggle('selected');
      this.style.border = this.classList.contains('selected') ? '2px solid #007bff' : 'none';
    });
  });
}

// 渲染分页控件
function renderPagination(pagination, loadFunction) {
  const paginationEl = document.getElementById('pagination');
  if (!paginationEl) {
    console.warn('分页元素未找到');
    return;
  }
  
  // 如果没有分页信息或只有一页，隐藏分页控件
  if (!pagination || pagination.totalPages <= 1) {
    paginationEl.innerHTML = '';
    return;
  }
  
  const { currentPage, totalPages } = pagination;
  
  // 验证分页数据
  if (typeof currentPage !== 'number' || typeof totalPages !== 'number' || currentPage < 1 || totalPages < 1) {
    console.warn('无效的分页数据:', pagination);
    paginationEl.innerHTML = '';
    return;
  }
  
  let paginationHTML = '';
  
  // 上一页按钮
  if (currentPage > 1) {
    paginationHTML += `<li class="page-item"><a class="page-link" href="#" data-page="${currentPage - 1}">上一页</a></li>`;
  } else {
    paginationHTML += '<li class="page-item disabled"><span class="page-link">上一页</span></li>';
  }
  
  // 页码按钮
  // 计算显示的页码范围
  let startPage = Math.max(1, currentPage - 2);
  let endPage = Math.min(totalPages, currentPage + 2);
  
  // 确保始终显示5个页码按钮（如果总页数足够）
  if (endPage - startPage < 4) {
    if (startPage === 1) {
      endPage = Math.min(totalPages, startPage + 4);
    } else {
      startPage = Math.max(1, endPage - 4);
    }
  }
  
  // 添加省略号
  if (startPage > 1) {
    paginationHTML += '<li class="page-item"><a class="page-link" href="#" data-page="1">1</a></li>';
    if (startPage > 2) {
      paginationHTML += '<li class="page-item disabled"><span class="page-link">...</span></li>';
    }
  }
  
  // 添加页码按钮
  for (let i = startPage; i <= endPage; i++) {
    if (i === currentPage) {
      paginationHTML += `<li class="page-item active"><span class="page-link">${i}</span></li>`;
    } else {
      paginationHTML += `<li class="page-item"><a class="page-link" href="#" data-page="${i}">${i}</a></li>`;
    }
  }
  
  // 添加省略号和最后一页
  if (endPage < totalPages) {
    if (endPage < totalPages - 1) {
      paginationHTML += '<li class="page-item disabled"><span class="page-link">...</span></li>';
    }
    paginationHTML += `<li class="page-item"><a class="page-link" href="#" data-page="${totalPages}">${totalPages}</a></li>`;
  }
  
  // 下一页按钮
  if (currentPage < totalPages) {
    paginationHTML += `<li class="page-item"><a class="page-link" href="#" data-page="${currentPage + 1}">下一页</a></li>`;
  } else {
    paginationHTML += '<li class="page-item disabled"><span class="page-link">下一页</span></li>';
  }
  
  paginationEl.innerHTML = paginationHTML;
  
  // 绑定分页点击事件
  paginationEl.querySelectorAll('.page-link').forEach(link => {
    link.addEventListener('click', function(e) {
      e.preventDefault();
      const page = parseInt(this.getAttribute('data-page'));
      if (page && typeof loadFunction === 'function') {
        loadFunction(page);
      }
    });
  });
}

// 统一的模态框清除函数，确保背景层完全消失
function cleanupModal(modalId) {
  // 使用adminPanel提供的统一清除函数（如果可用）
  if (window.adminPanel && typeof window.adminPanel.cleanupModal === 'function') {
    window.adminPanel.cleanupModal(modalId);
    return;
  }
  
  // 降级处理：手动清除模态框和背景层
  const modalElement = document.getElementById(modalId);
  if (modalElement) {
    const modal = bootstrap.Modal.getInstance(modalElement);
    if (modal) {
      // 先移除焦点元素，避免aria-hidden属性冲突
      const focusedElements = modalElement.querySelectorAll('button, input, select, textarea, [tabindex]:not([tabindex="-1"])');
      focusedElements.forEach(el => el.blur());
      
      // 隐藏模态框
      modal.hide();
    }
  }
  
  // 确保所有背景层都被移除
  setTimeout(() => {
    const backdrops = document.querySelectorAll('.modal-backdrop');
    backdrops.forEach(backdrop => {
      if (backdrop && backdrop.parentNode) {
        backdrop.parentNode.removeChild(backdrop);
      }
    });
    
    // 移除可能残留的modal-open类
    document.body.classList.remove('modal-open');
    
    // 清除可能残留的padding-right样式
    document.body.style.paddingRight = '';
  }, 300);
}

// 确认效果图选择
function confirmEffectImagesSelection() {
  const selectedItems = document.querySelectorAll('.effect-image-grid-item.selected');
  const selectedKeys = Array.from(selectedItems).map(item => item.getAttribute('data-object-key'));
  
  // 更新预设表单中的效果图字段
  const effectImagesInput = document.getElementById('presetEffectImages');
  if (effectImagesInput) {
    effectImagesInput.value = selectedKeys.join(',');
  }
  
  // 更新预览
  renderEffectImagesPreviewFromKeys(selectedKeys);
  
  // 关闭模态框并确保背景层消失
  cleanupModal('effectImagesSelectModal');
}

// 从图片键渲染效果图预览
async function renderEffectImagesPreviewFromKeys(imageKeys) {
  const previewContainer = document.getElementById('effectImagesPreview');
  if (!previewContainer) return;
  
  previewContainer.innerHTML = '';
  previewContainer.style.display = 'none';
  
  if (imageKeys && imageKeys.length > 0) {
    previewContainer.style.display = 'block';
    
    for (const key of imageKeys) {
      try {
        // 获取图片详细信息
        const response = await adminPanel.apiRequest(`/api/images/public/${key}`);
        if (response.ok) {
          const imageUrl = key.startsWith('http') || key.startsWith('/api/images/public/') 
            ? key 
            : `/api/images/public/${key}`;
            
          const imgElement = document.createElement('img');
          imgElement.src = imageUrl;
          imgElement.alt = '效果图';
          imgElement.className = 'img-thumbnail me-2 mb-2';
          imgElement.style.maxHeight = '100px';
          previewContainer.appendChild(imgElement);
        }
      } catch (error) {
        console.error('获取图片信息失败:', error);
      }
    }
  }
}

// 渲染效果图预览
function renderEffectImagesPreview(images) {
  const previewContainer = document.getElementById('effectImagesPreview');
  if (!previewContainer) return;
  
  previewContainer.innerHTML = '';
  previewContainer.style.display = 'none';
  
  if (images && images.length > 0) {
    previewContainer.style.display = 'block';
    
    images.forEach(image => {
      // 修复可能的错误URL格式
      let imageUrl = image.object_key;
      if (imageUrl) {
        // 修复可能的错误URL格式
        if (imageUrl.startsWith('/preset_effects/')) {
          // 从错误的URL中提取对象键
          const objectKey = imageUrl.substring('/preset_effects/'.length);
          imageUrl = `/api/images/public/${objectKey}`;
        } else if (!imageUrl.startsWith('http') && !imageUrl.startsWith('/api/images/public/')) {
          // 添加正确的前缀
          imageUrl = `/api/images/public/${imageUrl}`;
        }
        
        const imgElement = document.createElement('img');
        imgElement.src = imageUrl;
        imgElement.alt = image.original_name || '效果图';
        imgElement.className = 'img-thumbnail me-2 mb-2';
        imgElement.style.maxHeight = '100px';
        imgElement.onerror = function() {
          // 处理图片加载错误
          console.error('效果图加载失败:', imageUrl);
          this.outerHTML = '<div class="text-danger">图片加载失败</div>';
        };
        previewContainer.appendChild(imgElement);
      }
    });
  }
}

// 上传图片
// 注意：这个函数已被handleImageUpload替换，保留此注释以避免混淆

// 初始化预设管理页面
async function initializePresets() {
  try {
    // 加载分类数据
    await loadCategories();
    
    // 加载预设数据（第一页）
    await loadPresets(1);
    
    console.log('预设管理页面初始化完成');
  } catch (error) {
    console.error('初始化预设管理页面失败:', error);
    adminPanel.showMessage('页面初始化失败，请刷新页面重试', 'error');
  }
}

// 加载分类数据
async function loadCategories() {
  try {
    // 修改为使用认证头，因为后端需要管理员权限
    const response = await adminPanel.apiRequest('/api/presets/categories/list');
    
    if (!response.ok) {
      throw new Error('获取分类失败: ' + response.status + ' ' + response.statusText);
    }
    
    const data = await response.json();
    const categoriesArray = data.success ? data.data : [];
    
    // 创建分类映射以便查找父级分类名称
    const categoryMap = {};
    categoriesArray.forEach(category => {
      categoryMap[category.id] = category;
    });
    
    const tbody = document.getElementById('categoriesTable').querySelector('tbody');
    tbody.innerHTML = '';
    
    // 先处理一级分类（没有parent_id的分类）
    const topLevelCategories = categoriesArray.filter(category => !category.parent_id);
    // 再处理二级分类（有parent_id的分类）
    const subLevelCategories = categoriesArray.filter(category => category.parent_id);
    
    // 渲染一级分类
    topLevelCategories.forEach(category => {
      const row = document.createElement('tr');
      row.innerHTML = `
        <td>${category.id}</td>
        <td><strong>${category.name}</strong></td>
        <td>${category.description || ''}</td>
        <td>无</td>
        <td>
          <button class="btn btn-sm btn-primary edit-category-btn" data-id="${category.id}">编辑</button>
          <button class="btn btn-sm btn-danger delete-category-btn" data-id="${category.id}">删除</button>
        </td>
      `;
      tbody.appendChild(row);
    });
    
    // 渲染二级分类，使用缩进表示层级关系
    subLevelCategories.forEach(category => {
      // 构造分类名称显示，如果有父级分类则显示层级关系
      let displayName = category.name;
      if (category.parent_id && categoryMap[category.parent_id]) {
        displayName = `${categoryMap[category.parent_id].name} / ${category.name}`;
      }
      
      const row = document.createElement('tr');
      row.innerHTML = `
        <td>${category.id}</td>
        <td style="padding-left: 20px;">${displayName}</td>
        <td>${category.description || ''}</td>
        <td>${category.parent_id ? (categoryMap[category.parent_id] ? categoryMap[category.parent_id].name : category.parent_id) : '无'}</td>
        <td>
          <button class="btn btn-sm btn-primary edit-category-btn" data-id="${category.id}">编辑</button>
          <button class="btn btn-sm btn-danger delete-category-btn" data-id="${category.id}">删除</button>
        </td>
      `;
      tbody.appendChild(row);
    });
    
    // 重新绑定事件监听器
    setTimeout(bindCategoryEvents, 100);
    
    // 更新分类筛选下拉框
    updateCategoryFilter(categoriesArray);
    
    // 更新预设表单中的分类下拉框
    updatePresetCategorySelect(categoriesArray);
  } catch (error) {
    console.error('Error loading categories:', error);
    adminPanel.showMessage('获取分类失败，请检查网络连接: ' + error.message, 'error');
  }
}

// 更新分类筛选下拉框
function updateCategoryFilter(categories) {
  const select = document.getElementById('categoryFilter');
  select.innerHTML = '<option value="">所有分类</option>';
  
  // 创建分类映射以便查找父级分类名称
  const categoryMap = {};
  categories.forEach(category => {
    categoryMap[category.id] = category;
  });
  
  // 先处理一级分类（没有parent_id的分类）
  const topLevelCategories = categories.filter(category => !category.parent_id);
  // 再处理二级分类（有parent_id的分类）
  const subLevelCategories = categories.filter(category => category.parent_id);
  
  // 添加一级分类
  topLevelCategories.forEach(category => {
    const option = document.createElement('option');
    option.value = category.id;
    option.textContent = category.name;
    select.appendChild(option);
  });
  
  // 添加二级分类，使用缩进表示层级关系
  subLevelCategories.forEach(category => {
    // 构造分类名称显示，如果有父级分类则显示层级关系
    let displayName = category.name;
    if (category.parent_id && categoryMap[category.parent_id]) {
      displayName = `${categoryMap[category.parent_id].name} / ${category.name}`;
    }
    
    const option = document.createElement('option');
    option.value = category.id;
    option.textContent = displayName;
    // 为二级分类添加缩进样式
    option.style.paddingLeft = '20px';
    select.appendChild(option);
  });
}

// 更新预设表单中的分类下拉框
function updatePresetCategorySelect(categories) {
  const select = document.getElementById('presetCategory');
  select.innerHTML = '';
  
  // 创建分类映射以便查找父级分类名称
  const categoryMap = {};
  categories.forEach(category => {
    categoryMap[category.id] = category;
  });
  
  // 先处理一级分类（没有parent_id的分类）
  const topLevelCategories = categories.filter(category => !category.parent_id);
  // 再处理二级分类（有parent_id的分类）
  const subLevelCategories = categories.filter(category => category.parent_id);
  
  // 添加一级分类
  topLevelCategories.forEach(category => {
    const option = document.createElement('option');
    option.value = category.id;
    option.textContent = category.name;
    select.appendChild(option);
  });
  
  // 添加二级分类，使用缩进表示层级关系
  subLevelCategories.forEach(category => {
    // 构造分类名称显示，如果有父级分类则显示层级关系
    let displayName = category.name;
    if (category.parent_id && categoryMap[category.parent_id]) {
      displayName = `${categoryMap[category.parent_id].name} / ${category.name}`;
    }
    
    const option = document.createElement('option');
    option.value = category.id;
    option.textContent = displayName;
    // 为二级分类添加缩进样式
    option.style.paddingLeft = '20px';
    select.appendChild(option);
  });
}

// 加载预设数据
async function loadPresets(page = 1) {
  // 确保页码是有效的正整数
  page = Math.max(1, parseInt(page) || 1);
  console.log('加载预设数据，页码:', page);
  try {
    const response = await adminPanel.apiRequest(`/api/presets?page=${page}&limit=10`);
    
    if (!response.ok) {
      throw new Error('获取预设失败');
    }
    
    const data = await response.json();
    let presets = [];
    let categories = {};
    
    // 兼容不同的响应格式
    if (data && data.presets !== undefined) {
      // 格式1: { presets: [], categories: {} }
      presets = data.presets || [];
      categories = data.categories || {};
    } else if (Array.isArray(data)) {
      // 格式2: 直接返回数组
      presets = data;
      // 需要单独加载分类映射
      categories = await loadCategoryMap();
    } else if (data && data.data) {
      // 格式3: { data: [], categories: {} }
      presets = data.data || [];
      categories = data.categories || {};
    } else {
      console.warn('未知的响应格式:', data);
      presets = [];
      categories = {};
    }
    
    // 渲染表格数据
    renderPresetsTable(presets, categories);
    
    // 重新绑定事件监听器
    setTimeout(bindPresetEvents, 100);
    
    // 渲染分页控件 - 确保正确处理分页信息
    if (data.pagination) {
      renderPagination(data.pagination, loadPresets);
    } else if (data.total !== undefined) {
      // 如果响应中包含total字段，手动计算分页信息
      const total = data.total || presets.length;
      const limit = 10;
      const totalPages = Math.ceil(total / limit);
      // 确保总页数至少为1
      const validTotalPages = Math.max(1, totalPages);
      const paginationInfo = {
        currentPage: page,
        totalPages: validTotalPages,
        total: total
      };
      renderPagination(paginationInfo, loadPresets);
    } else {
      // 如果没有分页信息，隐藏分页控件
      const paginationEl = document.getElementById('pagination');
      if (paginationEl) {
        paginationEl.innerHTML = '';
      }
    }
  } catch (error) {
    console.error('Error loading presets:', error);
    adminPanel.showMessage('获取预设失败，请检查网络连接', 'error');
  }
}

// 加载分类映射
async function loadCategoryMap() {
  try {
    // 修改为使用认证头，因为后端需要管理员权限
    const response = await adminPanel.apiRequest('/api/presets/categories/list');
    if (response.ok) {
      const data = await response.json();
      if (data.success) {
        const categories = data.data;
        const categoryMap = {};
        // 创建完整的分类映射，包含parent_id信息
        categories.forEach(category => {
          categoryMap[category.id] = category;
        });
        return categoryMap;
      }
    }
    return {};
  } catch (error) {
    console.error('Error loading category map:', error);
    return {};
  }
}

// 渲染预设表格
function renderPresetsTable(presets, categories) {
  const tbody = document.getElementById('presetsTable').querySelector('tbody');
  tbody.innerHTML = '';
  
  // 创建分类映射以便查找父级分类名称
  const categoryMap = {};
  Object.keys(categories).forEach(categoryId => {
    categoryMap[categoryId] = categories[categoryId];
  });
  
  presets.forEach(preset => {
    // 获取分类名称，如果有父级分类则显示层级关系
    let categoryName = '未知分类';
    if (categories[preset.category_id]) {
      const category = categories[preset.category_id];
      categoryName = category.name;
      // 如果有父级分类，则显示层级关系
      if (category.parent_id && categoryMap[category.parent_id]) {
        categoryName = `${categoryMap[category.parent_id].name} / ${category.name}`;
      }
    }
    
    const visibilityText = {
      'public': '公开',
      'authenticated': '登录用户可见',
      'private': '私有'
    }[preset.visibility] || preset.visibility;
    
    // 处理封面图片URL
    let coverImageHtml = '';
    if (preset.image) {
      const imageUrl = preset.image.startsWith('http') || preset.image.startsWith('/api/images/public/') 
        ? preset.image 
        : `/api/images/public/${preset.image}`;
      coverImageHtml = `<img src="${imageUrl}" alt="封面" style="width: 50px; height: 50px; object-fit: cover; border-radius: 4px;">`;
    } else {
      coverImageHtml = '<span class="text-muted">无封面</span>';
    }
    
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${preset.id}</td>
      <td>${preset.title}</td>
      <td>${coverImageHtml}</td>
      <td>${categoryName}</td>
      <td>${visibilityText}</td>
      <td>${adminPanel.formatDate(preset.created_at)}</td>
      <td>
        <button class="btn btn-sm btn-primary edit-preset-btn" data-id="${preset.id}">编辑</button>
        <button class="btn btn-sm btn-danger delete-preset-btn" data-id="${preset.id}">删除</button>
      </td>
    `;
    tbody.appendChild(row);
  });
}

// 显示编辑分类表单
  async function showEditCategoryForm(id) {
    try {
      // 检查ID是否有效
      if (!id) {
        console.error('分类ID无效:', id);
        adminPanel.showMessage('分类ID无效', 'error');
        return;
      }
      
      const response = await adminPanel.apiRequest(`/api/presets/categories/${id}`);
      
      if (!response.ok) {
        throw new Error('获取分类信息失败');
      }
      
      const data = await response.json();
      if (data.success) {
        const category = data.data;
        
        // 确保模态框中的元素存在再进行操作
        const categoryIdElement = document.getElementById('categoryId');
        const categoryNameElement = document.getElementById('categoryName');
        const categoryDescriptionElement = document.getElementById('categoryDescription');
        const categoryParentElement = document.getElementById('categoryParent');
        const categoryModalLabelElement = document.getElementById('categoryModalLabel');
        
        if (!categoryIdElement || !categoryNameElement || !categoryDescriptionElement || !categoryParentElement || !categoryModalLabelElement) {
          console.error('编辑分类表单中的元素未找到');
          adminPanel.showMessage('页面元素加载不完整，请刷新页面后重试', 'error');
          return;
        }
        
        // 填充表单数据
        categoryIdElement.value = category.id;
        categoryNameElement.value = category.name;
        categoryDescriptionElement.value = category.description || '';
        
        // 加载父级分类选项
        await loadParentCategoriesForEdit(category.id);
        
        // 设置父级分类
        categoryParentElement.value = category.parent_id || '';
        
        // 更新模态框标题
        categoryModalLabelElement.textContent = '编辑分类';
        
        // 显示模态框
        const categoryModalElement = document.getElementById('categoryModal');
        // 先隐藏可能已显示的模态框
        const existingModal = bootstrap.Modal.getInstance(categoryModalElement);
        if (existingModal) {
          // 在隐藏模态框前先移除焦点元素，避免aria-hidden属性冲突
          const closeBtn = categoryModalElement.querySelector('.btn-close');
          if (closeBtn) {
            closeBtn.blur();
          }
          const saveCategoryBtn = document.getElementById('saveCategoryBtn');
          if (saveCategoryBtn) {
            saveCategoryBtn.blur();
          }
          existingModal.hide();
        }
        const categoryModal = new bootstrap.Modal(categoryModalElement);
        categoryModal.show();
      } else {
        adminPanel.showMessage('获取分类信息失败：' + data.message, 'error');
      }
    } catch (error) {
      console.error('Error showing edit category form:', error);
      adminPanel.showMessage('获取分类信息失败，请检查网络连接', 'error');
    }
  }

// 显示添加分类表单
function showAddCategoryForm() {
  // 确保模态框中的元素存在再进行操作
  const categoryIdElement = document.getElementById('categoryId');
  const categoryNameElement = document.getElementById('categoryName');
  const categoryDescriptionElement = document.getElementById('categoryDescription');
  const categoryParentElement = document.getElementById('categoryParent');
  const categoryModalLabelElement = document.getElementById('categoryModalLabel');
  
  if (!categoryIdElement || !categoryNameElement || !categoryDescriptionElement || 
      !categoryParentElement || !categoryModalLabelElement) {
    console.error('添加分类表单中的元素未找到');
    adminPanel.showMessage('页面元素加载不完整，请刷新页面后重试', 'error');
    return;
  }
  
  // 清空表单数据
  categoryIdElement.value = '';
  categoryNameElement.value = '';
  categoryDescriptionElement.value = '';
  categoryParentElement.value = '';
  
  // 加载父级分类选项
  loadParentCategoriesForEdit();
  
  // 更新模态框标题
  categoryModalLabelElement.textContent = '添加分类';
  
  // 显示模态框
  const categoryModalElement = document.getElementById('categoryModal');
  // 先隐藏可能已显示的模态框
  const existingModal = bootstrap.Modal.getInstance(categoryModalElement);
  if (existingModal) {
    existingModal.hide();
  }
  const categoryModal = new bootstrap.Modal(categoryModalElement);
  categoryModal.show();
}

// 加载父级分类选项（编辑时使用）
async function loadParentCategoriesForEdit(excludeId = null) {
  try {
    // 修改为使用认证头，因为后端需要管理员权限
    const response = await adminPanel.apiRequest('/api/presets/categories/list');
    
    if (!response.ok) {
      throw new Error('获取父级分类失败');
    }
    
    const data = await response.json();
    const categoriesArray = data.success ? data.data : [];
    
    const select = document.getElementById('categoryParent');
    select.innerHTML = '<option value="">无</option>';
    
    categoriesArray.forEach(category => {
      // 排除当前正在编辑的分类，避免自己作为自己的父级
      if (!excludeId || category.id !== excludeId) {
        const option = document.createElement('option');
        option.value = category.id;
        option.textContent = category.name;
        select.appendChild(option);
      }
    });
  } catch (error) {
    console.error('Error loading parent categories:', error);
    adminPanel.showMessage('加载父级分类失败，请检查网络连接', 'error');
  }
}

// 删除分类
async function deleteCategory(id) {
  if (confirm('确定要删除这个分类吗？')) {
    try {
      const response = await adminPanel.apiRequest(`/api/presets/categories/${id}`, {
        method: 'DELETE'
      });
      
      // 对于204状态码（无内容），不需要解析JSON
      if (response.status === 204) {
        await loadCategories();
        adminPanel.showMessage('分类删除成功', 'success');
        return;
      }
      
      if (!response.ok) {
        // 尝试获取错误信息
        let errorMessage = '删除分类失败';
        try {
          const errorData = await response.json();
          errorMessage = errorData.error || errorData.message || errorMessage;
        } catch (e) {
          // 如果无法解析错误信息，使用状态文本
          errorMessage = `${errorMessage}: ${response.status} ${response.statusText}`;
        }
        throw new Error(errorMessage);
      }
      
      const data = await response.json();
      // 检查响应状态码或响应数据来确定是否成功
      if (response.status === 200 || response.status === 204 || (data && (data.success || data.message))) {
        await loadCategories();
        adminPanel.showMessage('分类删除成功', 'success');
      } else {
        const errorMsg = data.message || data.error || '未知错误';
        adminPanel.showMessage('删除分类失败：' + errorMsg, 'error');
        // 如果是因为有关联预设导致的删除失败，给出更具体的提示
        if (errorMsg.includes('预设')) {
          adminPanel.showMessage('请先删除使用此分类的所有预设，然后再删除分类', 'info');
        }
      }
    } catch (error) {
      console.error('Error deleting category:', error);
      adminPanel.showMessage('删除分类失败：' + error.message, 'error');
    }
  }
}

// 保存分类（添加或更新）
async function saveCategory() {
  try {
    const id = document.getElementById('categoryId').value;
    const name = document.getElementById('categoryName').value;
    const description = document.getElementById('categoryDescription').value;
    const parent_id = document.getElementById('categoryParent').value;
    
    if (!name) {
      adminPanel.showMessage('分类名称是必需的', 'error');
      return;
    }
    
    const categoryData = { name, description, parent_id: parent_id || null };
    let url = '/api/presets/categories';
    let method = 'POST';
    
    if (id) {
      url += `/${id}`;
      method = 'PUT';
    }
    
    console.log('保存分类请求:', { url, method, categoryData });
    
    const response = await adminPanel.apiRequest(url, {
      method: method,
      body: JSON.stringify(categoryData)
    });
    
    console.log('保存分类响应:', response.status, response.statusText);
    
    // 检查响应状态
    if (response.status === 401) {
      adminPanel.showMessage('权限不足，请重新登录', 'error');
      return;
    }
    
    if (response.status === 403) {
      adminPanel.showMessage('权限不足，无法执行此操作', 'error');
      return;
    }
    
    // 特别处理400错误（参数验证失败）
    if (response.status === 400) {
      try {
        const errorData = await response.json();
        adminPanel.showMessage('参数错误：' + (errorData.error || errorData.message || '请求参数不正确'), 'error');
      } catch (e) {
        adminPanel.showMessage('参数错误：请求参数不正确', 'error');
      }
      return;
    }
    
    if (!response.ok) {
      // 尝试获取错误详情
      let errorMessage = '保存分类失败';
      try {
        const errorData = await response.json();
        errorMessage = errorData.error || errorData.message || errorMessage;
      } catch (e) {
        errorMessage = `${errorMessage}: ${response.status} ${response.statusText}`;
      }
      throw new Error(errorMessage);
    }
    
    // 对于成功响应，处理不同情况
    let data;
    try {
      data = await response.json();
      console.log('保存分类返回数据:', data);
    } catch (e) {
      // 如果无法解析JSON，根据状态码判断成功与否
      if (response.status === 200 || response.status === 201 || response.status === 204) {
        data = { success: true, message: '操作成功' };
      } else {
        throw new Error('服务器返回无效响应');
      }
    }
    
    // 检查响应数据中的success字段或者状态码
    if (data.success || response.status === 200 || response.status === 201 || response.status === 204) {
      // 使用统一的模态框清除函数
      cleanupModal('categoryModal');
      
      // 重新加载分类数据
      await loadCategories();
      adminPanel.showMessage(id ? '分类更新成功' : '分类添加成功', 'success');
    } else {
      const errorMsg = data.message || data.error || '未知错误';
      adminPanel.showMessage((id ? '更新分类失败：' : '添加分类失败：') + errorMsg, 'error');
    }
  } catch (error) {
    console.error('Error saving category:', error);
    adminPanel.showMessage('保存分类失败：' + error.message, 'error');
  }
}

// 显示编辑预设表单
async function showEditPresetForm(id) {
  try {
    // 检查ID是否有效
    if (!id) {
      console.error('预设ID无效:', id);
      adminPanel.showMessage('预设ID无效', 'error');
      return;
    }
    
    const response = await adminPanel.apiRequest(`/api/presets/${id}`);
    
    if (!response.ok) {
      throw new Error('获取预设信息失败');
    }
    
    const data = await response.json();
    const preset = data.success ? data.data : data;
    
    // 确保模态框中的元素存在再进行操作
    const presetIdElement = document.getElementById('presetId');
    const presetTitleElement = document.getElementById('presetTitle');
    const presetCategoryElement = document.getElementById('presetCategory');
    const presetVisibilityElement = document.getElementById('presetVisibility');
    const presetPositiveElement = document.getElementById('presetPositive');
    const presetNegativeElement = document.getElementById('presetNegative');
    const presetDescriptionElement = document.getElementById('presetDescription');
    const presetCoverImageElement = document.getElementById('presetCoverImage');
    const presetEffectImagesElement = document.getElementById('presetEffectImages');
    const presetModalLabelElement = document.getElementById('presetModalLabel');
    const coverImagePreviewElement = document.getElementById('coverImagePreview');
    const effectImagesPreviewElement = document.getElementById('effectImagesPreview');
    
    if (!presetIdElement || !presetTitleElement || !presetCategoryElement || !presetVisibilityElement || 
        !presetPositiveElement || !presetNegativeElement || !presetDescriptionElement || 
        !presetCoverImageElement || !presetEffectImagesElement || !presetModalLabelElement || 
        !coverImagePreviewElement || !effectImagesPreviewElement) {
      console.error('编辑预设表单中的元素未找到');
      adminPanel.showMessage('页面元素加载不完整，请刷新页面后重试', 'error');
      return;
    }
    
    // 填充表单数据
    presetIdElement.value = preset.id;
    presetTitleElement.value = preset.title;
    presetCategoryElement.value = preset.category_id;
    presetVisibilityElement.value = preset.visibility || 'public';
    presetPositiveElement.value = preset.positive || '';
    presetNegativeElement.value = preset.negative || '';
    presetDescriptionElement.value = preset.description || '';
    presetCoverImageElement.value = preset.image || '';
    
    // 显示图片预览
    const previewImg = coverImagePreviewElement.querySelector('img');
    if (preset.image) {
      // 确保使用完整的URL路径
      const imageUrl = preset.image.startsWith('http') || preset.image.startsWith('/api/images/public/') 
        ? preset.image 
        : `/api/images/public/${preset.image}`;
      if (previewImg) {
        previewImg.src = imageUrl;
      }
      coverImagePreviewElement.style.display = 'block';
    } else {
      coverImagePreviewElement.style.display = 'none';
    }
    
    // 获取并显示效果图预览
    try {
      const effectImagesResponse = await adminPanel.apiRequest(`/api/presets/${id}/effect-images`);
      if (effectImagesResponse.ok) {
        const effectImagesData = await effectImagesResponse.json();
        const effectImages = effectImagesData.images || [];
        
        // 设置隐藏字段的值
        if (effectImages.length > 0) {
          const imageKeys = effectImages.map(img => img.object_key);
          presetEffectImagesElement.value = imageKeys.join(',');
          // 渲染效果图预览
          renderEffectImagesPreviewForEdit(imageKeys);
        } else {
          presetEffectImagesElement.value = '';
          effectImagesPreviewElement.style.display = 'none';
        }
      } else {
        // 如果获取效果图失败，清空相关字段
        presetEffectImagesElement.value = '';
        effectImagesPreviewElement.style.display = 'none';
      }
    } catch (error) {
      console.error('获取预设效果图失败:', error);
      // 如果获取效果图失败，清空相关字段
      presetEffectImagesElement.value = '';
      effectImagesPreviewElement.style.display = 'none';
    }
    
    // 更新模态框标题
    presetModalLabelElement.textContent = '编辑预设';
    
    // 显示模态框
    const presetModalElement = document.getElementById('presetModal');
    // 先隐藏可能已显示的模态框
    const existingModal = bootstrap.Modal.getInstance(presetModalElement);
    if (existingModal) {
      // 在隐藏模态框前先移除焦点元素，避免aria-hidden属性冲突
      const closeBtn = presetModalElement.querySelector('.btn-close');
      if (closeBtn) {
        closeBtn.blur();
      }
      const savePresetBtn = document.getElementById('savePresetBtn');
      if (savePresetBtn) {
        savePresetBtn.blur();
      }
      existingModal.hide();
    }
    const presetModal = new bootstrap.Modal(presetModalElement);
    presetModal.show();
  } catch (error) {
    console.error('Error showing edit preset form:', error);
    adminPanel.showMessage('获取预设信息失败，请检查网络连接', 'error');
  }
}

// 为编辑预设渲染效果图预览
function renderEffectImagesPreviewForEdit(imageKeys) {
  const previewContainer = document.getElementById('effectImagesPreview');
  if (!previewContainer) return;
  
  previewContainer.innerHTML = '';
  previewContainer.style.display = 'none';
  
  if (imageKeys && imageKeys.length > 0) {
    previewContainer.style.display = 'block';
    
    imageKeys.forEach(key => {
      const imageUrl = key.startsWith('http') || key.startsWith('/api/images/public/') 
        ? key 
        : `/api/images/public/${key}`;
        
      const imgElement = document.createElement('img');
      imgElement.src = imageUrl;
      imgElement.alt = '效果图';
      imgElement.className = 'img-thumbnail me-2 mb-2';
      imgElement.style.maxHeight = '100px';
      // 为每个图片添加删除按钮
      const container = document.createElement('div');
      container.style.display = 'inline-block';
      container.style.position = 'relative';
      
      const deleteBtn = document.createElement('button');
      deleteBtn.innerHTML = '&times;';
      deleteBtn.className = 'btn btn-danger btn-sm';
      deleteBtn.style.position = 'absolute';
      deleteBtn.style.top = '0';
      deleteBtn.style.right = '0';
      deleteBtn.style.padding = '2px 6px';
      deleteBtn.style.fontSize = '12px';
      deleteBtn.style.borderRadius = '50%';
      deleteBtn.style.minWidth = 'auto';
      
      // 绑定删除事件
      deleteBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        // 从预览中移除图片
        container.remove();
        // 更新隐藏字段的值
        updateEffectImagesValue();
      });
      
      container.appendChild(imgElement);
      container.appendChild(deleteBtn);
      previewContainer.appendChild(container);
    });
  }
}

// 更新效果图字段的值
function updateEffectImagesValue() {
  const previewContainer = document.getElementById('effectImagesPreview');
  const effectImagesInput = document.getElementById('presetEffectImages');
  if (!previewContainer || !effectImagesInput) return;
  
  const images = previewContainer.querySelectorAll('img');
  const imageKeys = Array.from(images).map(img => {
    const src = img.src;
    // 从URL中提取图片键值
    if (src.includes('/api/images/public/')) {
      return src.split('/api/images/public/')[1];
    }
    return src;
  });
  
  effectImagesInput.value = imageKeys.join(',');
}

// 显示添加预设表单
function showAddPresetForm() {
  // 确保模态框中的元素存在再进行操作
  const presetFormElement = document.getElementById('presetForm');
  const presetIdElement = document.getElementById('presetId');
  const presetVisibilityElement = document.getElementById('presetVisibility');
  const coverImagePreviewElement = document.getElementById('coverImagePreview');
  const effectImagesPreviewElement = document.getElementById('effectImagesPreview');
  const presetModalLabelElement = document.getElementById('presetModalLabel');
  const presetModalElement = document.getElementById('presetModal');
  
  if (!presetFormElement || !presetIdElement || !presetVisibilityElement || 
      !coverImagePreviewElement || !effectImagesPreviewElement || !presetModalLabelElement || !presetModalElement) {
    console.error('添加预设表单中的元素未找到');
    adminPanel.showMessage('页面元素加载不完整，请刷新页面后重试', 'error');
    return;
  }
  
  // 清空表单数据
  presetFormElement.reset();
  presetIdElement.value = '';
  presetVisibilityElement.value = 'public';
  
  // 隐藏图片预览
  coverImagePreviewElement.style.display = 'none';
  effectImagesPreviewElement.style.display = 'none';
  
  // 更新模态框标题
  presetModalLabelElement.textContent = '添加预设';
  
  // 显示模态框
  // 先隐藏可能已显示的模态框
  const existingModal = bootstrap.Modal.getInstance(presetModalElement);
  if (existingModal) {
    existingModal.hide();
  }
  const presetModal = new bootstrap.Modal(presetModalElement);
  presetModal.show();
}



// 保存预设（添加或更新）
async function savePreset() {
  try {
    const id = document.getElementById('presetId').value;
    const title = document.getElementById('presetTitle').value;
    const category_id = document.getElementById('presetCategory').value;
    const visibility = document.getElementById('presetVisibility').value;
    const positive = document.getElementById('presetPositive').value;
    const negative = document.getElementById('presetNegative').value;
    const description = document.getElementById('presetDescription').value;
    const image = document.getElementById('presetCoverImage').value;
    const effect_images_str = document.getElementById('presetEffectImages').value;
    
    // 解析效果图字段
    let effect_images = [];
    if (effect_images_str) {
      effect_images = effect_images_str.split(',').map(key => key.trim()).filter(key => key);
    }
    
    if (!title || !category_id || !positive) {
      adminPanel.showMessage('标题、分类和Positive Prompt是必需的', 'error');
      return;
    }
    
    const presetData = {
      title,
      category_id,
      visibility,
      positive,
      negative: negative || null,
      description: description || null,
      image: image || null,
      effect_images: effect_images
    };
    
    let url = '/api/presets';
    let method = 'POST';
    
    if (id) {
      url += `/${id}`;
      method = 'PUT';
    }
    
    console.log('保存预设请求:', { url, method, presetData });
    
    const response = await adminPanel.apiRequest(url, {
      method: method,
      body: JSON.stringify(presetData)
    });
    
    console.log('保存预设响应:', response.status, response.statusText);
    
    // 检查响应状态
    if (response.status === 401) {
      adminPanel.showMessage('权限不足，请重新登录', 'error');
      return;
    }
    
    if (response.status === 403) {
      adminPanel.showMessage('权限不足，无法执行此操作', 'error');
      return;
    }
    
    // 特别处理400错误（参数验证失败）
    if (response.status === 400) {
      try {
        const errorData = await response.json();
        adminPanel.showMessage('参数错误：' + (errorData.error || errorData.message || '请求参数不正确'), 'error');
      } catch (e) {
        adminPanel.showMessage('参数错误：请求参数不正确', 'error');
      }
      return;
    }
    
    if (!response.ok) {
      // 尝试获取错误详情
      let errorMessage = '保存预设失败';
      try {
        const errorData = await response.json();
        errorMessage = errorData.error || errorData.message || errorMessage;
      } catch (e) {
        errorMessage = `${errorMessage}: ${response.status} ${response.statusText}`;
      }
      throw new Error(errorMessage);
    }
    
    // 对于成功响应，处理不同情况
    let data;
    try {
      data = await response.json();
      console.log('保存预设返回数据:', data);
    } catch (e) {
      // 如果无法解析JSON，根据状态码判断成功与否
      if (response.status === 200 || response.status === 201 || response.status === 204) {
        data = { success: true, message: '操作成功' };
      } else {
        throw new Error('服务器返回无效响应');
      }
    }
    
    // 检查响应数据中的success字段或者状态码
    if (data.success || response.status === 200 || response.status === 201 || response.status === 204) {
      // 使用统一的模态框清除函数
      cleanupModal('presetModal');
      
      // 重新加载预设数据
      await loadPresets();
      adminPanel.showMessage(id ? '预设更新成功' : '预设添加成功', 'success');
    } else {
      const errorMsg = data.message || data.error || '未知错误';
      adminPanel.showMessage((id ? '更新预设失败：' : '添加预设失败：') + errorMsg, 'error');
    }
  } catch (error) {
    console.error('Error saving preset:', error);
    adminPanel.showMessage('保存预设失败：' + error.message, 'error');
  }
}

// 删除预设
async function deletePreset(id) {
  if (confirm('确定要删除这个预设吗？')) {
    try {
      const response = await adminPanel.apiRequest(`/api/presets/${id}`, {
        method: 'DELETE'
      });
      
      // 对于204状态码（无内容），不需要解析JSON
      if (response.status === 204) {
        await loadPresets();
        adminPanel.showMessage('预设删除成功', 'success');
        return;
      }
      
      if (!response.ok) {
        // 尝试获取错误信息
        let errorMessage = '删除预设失败';
        try {
          const errorData = await response.json();
          errorMessage = errorData.error || errorData.message || errorMessage;
        } catch (e) {
          // 如果无法解析错误信息，使用状态文本
          errorMessage = `${errorMessage}: ${response.status} ${response.statusText}`;
        }
        throw new Error(errorMessage);
      }
      
      const data = await response.json();
      // 检查响应状态码或响应数据来确定是否成功
      if (response.status === 200 || response.status === 204 || (data && (data.success || data.message))) {
        await loadPresets();
        adminPanel.showMessage('预设删除成功', 'success');
      } else {
        adminPanel.showMessage('删除预设失败：' + (data.message || data.error || '未知错误'), 'error');
      }
    } catch (error) {
      console.error('Error deleting preset:', error);
      adminPanel.showMessage('删除预设失败：' + error.message, 'error');
    }
  }
}

// 搜索预设
async function searchPresets(page = 1) {
  const searchTerm = document.getElementById('searchInput').value;
  const categoryId = document.getElementById('categoryFilter').value;
  
  // 确保页码是有效的正整数
  page = Math.max(1, parseInt(page) || 1);
  console.log('搜索预设数据，页码:', page, '搜索词:', searchTerm, '分类ID:', categoryId);
  
  try {
    let url = `/api/presets?page=${page}&limit=10`;
    const params = [];
    
    if (categoryId) {
      params.push(`category_id=${categoryId}`);
    }
    
    if (searchTerm) {
      params.push(`search=${encodeURIComponent(searchTerm)}`);
      // 搜索时重置为第一页
      page = 1;
    }
    
    if (params.length > 0) {
      url += `&${params.join('&')}`;
    }
    
    const response = await adminPanel.apiRequest(url);
    
    if (response.status === 401 || response.status === 403) {
      return;
    }
    
    if (!response.ok) {
      throw new Error('搜索预设失败');
    }
    
    const data = await response.json();
    
    // 兼容不同的响应格式
    let presets = [];
    let categories = {};
    
    if (data && data.presets !== undefined) {
      // 格式1: { presets: [], categories: {} }
      presets = data.presets || [];
      categories = data.categories || {};
    } else if (Array.isArray(data)) {
      // 格式2: 直接返回数组
      presets = data;
      // 需要单独加载分类映射
      categories = await loadCategoryMap();
    } else if (data && data.data) {
      // 格式3: { data: [], categories: {} }
      presets = data.data || [];
      categories = data.categories || {};
    } else {
      console.warn('未知的响应格式:', data);
      presets = [];
      categories = {};
    }
    
    // 应用搜索过滤
    if (searchTerm) {
      presets = presets.filter(preset => 
        preset.title && preset.title.toLowerCase().includes(searchTerm.toLowerCase())
      );
      // 搜索时重置为第一页
      page = 1;
    }
    
    // 渲染表格数据
    renderPresetsTable(presets, categories);
    
    // 重新绑定事件监听器
    setTimeout(bindPresetEvents, 100);
    
    // 渲染分页控件
    if (data.pagination) {
      renderPagination(data.pagination, searchPresets);
    } else if (data.total !== undefined) {
      // 如果响应中包含total字段，手动计算分页信息
      const total = data.total || presets.length;
      const limit = 10;
      const totalPages = Math.ceil(total / limit);
      // 确保总页数至少为1
      const validTotalPages = Math.max(1, totalPages);
      const paginationInfo = {
        currentPage: page,
        totalPages: validTotalPages,
        total: total
      };
      renderPagination(paginationInfo, searchPresets);
    } else {
      // 如果没有分页信息，隐藏分页控件
      const paginationEl = document.getElementById('pagination');
      if (paginationEl) {
        paginationEl.innerHTML = '';
      }
    }
  } catch (error) {
    console.error('Error searching presets:', error);
    adminPanel.showMessage('搜索预设失败，请检查网络连接', 'error');
  }
}

// 渲染分页控件
function renderPagination(pagination, loadFunction) {
  const paginationEl = document.getElementById('pagination');
  if (!paginationEl) {
    console.warn('分页元素未找到');
    return;
  }
  
  // 如果没有分页信息或只有一页，隐藏分页控件
  if (!pagination || pagination.totalPages <= 1) {
    paginationEl.innerHTML = '';
    return;
  }
  
  const { currentPage, totalPages } = pagination;
  
  // 验证分页数据
  if (typeof currentPage !== 'number' || typeof totalPages !== 'number' || currentPage < 1 || totalPages < 1) {
    console.warn('无效的分页数据:', pagination);
    paginationEl.innerHTML = '';
    return;
  }
  
  let paginationHTML = '';
  
  // 上一页按钮
  if (currentPage > 1) {
    paginationHTML += `<li class="page-item"><a class="page-link" href="#" data-page="${currentPage - 1}">上一页</a></li>`;
  } else {
    paginationHTML += '<li class="page-item disabled"><span class="page-link">上一页</span></li>';
  }
  
  // 页码按钮
  // 计算显示的页码范围
  let startPage = Math.max(1, currentPage - 2);
  let endPage = Math.min(totalPages, currentPage + 2);
  
  // 确保始终显示5个页码按钮（如果总页数足够）
  if (endPage - startPage < 4) {
    if (startPage === 1) {
      endPage = Math.min(totalPages, startPage + 4);
    } else {
      startPage = Math.max(1, endPage - 4);
    }
  }
  
  // 添加省略号
  if (startPage > 1) {
    paginationHTML += '<li class="page-item"><a class="page-link" href="#" data-page="1">1</a></li>';
    if (startPage > 2) {
      paginationHTML += '<li class="page-item disabled"><span class="page-link">...</span></li>';
    }
  }
  
  // 添加页码按钮
  for (let i = startPage; i <= endPage; i++) {
    if (i === currentPage) {
      paginationHTML += `<li class="page-item active"><span class="page-link">${i}</span></li>`;
    } else {
      paginationHTML += `<li class="page-item"><a class="page-link" href="#" data-page="${i}">${i}</a></li>`;
    }
  }
  
  // 添加省略号和最后一页
  if (endPage < totalPages) {
    if (endPage < totalPages - 1) {
      paginationHTML += '<li class="page-item disabled"><span class="page-link">...</span></li>';
    }
    paginationHTML += `<li class="page-item"><a class="page-link" href="#" data-page="${totalPages}">${totalPages}</a></li>`;
  }
  
  // 下一页按钮
  if (currentPage < totalPages) {
    paginationHTML += `<li class="page-item"><a class="page-link" href="#" data-page="${currentPage + 1}">下一页</a></li>`;
  } else {
    paginationHTML += '<li class="page-item disabled"><span class="page-link">下一页</span></li>';
  }
  
  paginationEl.innerHTML = paginationHTML;
  
  // 绑定分页点击事件
  paginationEl.querySelectorAll('.page-link').forEach(link => {
    link.addEventListener('click', function(e) {
      e.preventDefault();
      const page = parseInt(this.getAttribute('data-page'));
      if (page && typeof loadFunction === 'function') {
        loadFunction(page);
      }
    });
  });
}

// 统一的模态框清除函数，确保背景层完全消失
function cleanupModal(modalId) {
  // 使用adminPanel提供的统一清除函数（如果可用）
  if (window.adminPanel && typeof window.adminPanel.cleanupModal === 'function') {
    window.adminPanel.cleanupModal(modalId);
    return;
  }
  
  // 降级处理：手动清除模态框和背景层
  const modalElement = document.getElementById(modalId);
  if (modalElement) {
    const modal = bootstrap.Modal.getInstance(modalElement);
    if (modal) {
      // 先移除焦点元素，避免aria-hidden属性冲突
      const focusedElements = modalElement.querySelectorAll('button, input, select, textarea, [tabindex]:not([tabindex="-1"])');
      focusedElements.forEach(el => el.blur());
      
      // 隐藏模态框
      modal.hide();
    }
  }
  
  // 确保所有背景层都被移除
  setTimeout(() => {
    const backdrops = document.querySelectorAll('.modal-backdrop');
    backdrops.forEach(backdrop => {
      if (backdrop && backdrop.parentNode) {
        backdrop.parentNode.removeChild(backdrop);
      }
    });
    
    // 移除可能残留的modal-open类
    document.body.classList.remove('modal-open');
    
    // 清除可能残留的padding-right样式
    document.body.style.paddingRight = '';
  }, 300);
}
