// 统一的认证和导航管理模块

// 更新认证UI状态
function updateAuthUI() {
    const token = localStorage.getItem('token');
    const authButtons = document.querySelector('.auth-buttons');
    const userCenterLink = document.getElementById('userCenterLink');
    const adminLink = document.getElementById('adminLink');
    
    if (token) {
        // 用户已登录
        authButtons.innerHTML = `
            <button class="btn btn-outline" id="logoutBtn">退出</button>
        `;
        userCenterLink.style.display = 'list-item';
        
        // 检查是否是管理员
        try {
            const payload = JSON.parse(atob(token.split('.')[1]));
            if (payload.role === 'admin' || payload.role === 'superadmin') {
                if (adminLink) {
                    adminLink.style.display = 'list-item';
                }
            } else {
                if (adminLink) {
                    adminLink.style.display = 'none';
                }
            }
        } catch (e) {
            if (adminLink) {
                adminLink.style.display = 'none';
            }
        }
        
        // 绑定退出按钮事件
        document.getElementById('logoutBtn').addEventListener('click', function() {
            localStorage.removeItem('token');
            updateAuthUI();
            showNotification('已退出登录', 'success');
            // 刷新页面以更新UI状态
            window.location.reload();
        });
    } else {
        // 用户未登录
        authButtons.innerHTML = `
            <button class="btn btn-outline" id="loginBtn">登录</button>
            <button class="btn btn-primary" id="registerBtn">注册</button>
        `;
        userCenterLink.style.display = 'none';
        if (adminLink) {
            adminLink.style.display = 'none';
        }
        
        // 绑定登录和注册按钮事件
        document.getElementById('loginBtn').addEventListener('click', function(event) {
            event.preventDefault();
            document.getElementById('loginModal').style.display = 'flex';
        });
        
        document.getElementById('registerBtn').addEventListener('click', function(event) {
            event.preventDefault();
            document.getElementById('registerModal').style.display = 'flex';
        });
    }
}

// 检查用户登录状态
function checkLoginStatus() {
    const token = localStorage.getItem('token');
    return !!token;
}

// 显示通知
function showNotification(message, type) {
    const notification = document.getElementById('notification');
    if (notification) {
        notification.textContent = message;
        notification.className = `notification ${type} show`;
        setTimeout(() => notification.classList.remove('show'), 3000);
    } else {
        // 如果页面没有notification元素，使用alert
        alert(message);
    }
}

// 初始化认证模块
document.addEventListener('DOMContentLoaded', function() {
    // 绑定移动端菜单切换
    const menuToggle = document.querySelector('.menu-toggle');
    if (menuToggle) {
        menuToggle.addEventListener('click', function() {
            const nav = document.getElementById('mainNav');
            if (nav) {
                nav.classList.toggle('active');
            }
        });
    }

    // 点击导航链接后关闭菜单
    document.querySelectorAll('#mainNav a').forEach(link => {
        link.addEventListener('click', () => {
            const nav = document.getElementById('mainNav');
            if (nav) {
                nav.classList.remove('active');
            }
        });
    });

    // 关闭对话框
    document.querySelectorAll('.close').forEach(function(closeButton) {
      closeButton.addEventListener('click', function() {
        document.getElementById('loginModal').style.display = 'none';
        document.getElementById('registerModal').style.display = 'none';
      });
    });

    // 点击模态框外部关闭对话框
    window.addEventListener('click', function(event) {
      const loginModal = document.getElementById('loginModal');
      const registerModal = document.getElementById('registerModal');
      
      if (event.target === loginModal) {
        loginModal.style.display = 'none';
      }
      
      if (event.target === registerModal) {
        registerModal.style.display = 'none';
      }
    });

    // 处理登录表单提交
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', async function(event) {
          event.preventDefault();

          const username = document.getElementById('loginUsername').value;
          const password = document.getElementById('loginPassword').value;

          try {
            const response = await fetch('/api/auth/login', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json'
              },
              body: JSON.stringify({ username, password })
            });

            const data = await response.json();

            if (response.ok) {
              console.log('登录成功:', data);
              // 保存token到localStorage
              localStorage.setItem('token', data.token);
              // 关闭模态框
              document.getElementById('loginModal').style.display = 'none';
              // 更新UI
              updateAuthUI();
              showNotification('登录成功！', 'success');
            } else {
              console.error('登录失败:', data.error);
              showNotification('登录失败: ' + data.error, 'error');
            }
          } catch (error) {
            console.error('请求失败:', error);
            showNotification('请求失败，请稍后重试', 'error');
          }
        });
    }

    // 处理注册表单提交
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', async function(event) {
          event.preventDefault();

          const username = document.getElementById('registerUsername').value;
          const email = document.getElementById('registerEmail').value;
          const password = document.getElementById('registerPassword').value;

          try {
            const response = await fetch('/api/auth/register', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json'
              },
              body: JSON.stringify({ username, email, password })
            });

            const data = await response.json();

            if (response.ok) {
              console.log('注册成功:', data);
              // 关闭模态框
              document.getElementById('registerModal').style.display = 'none';
              // 显示成功消息
              showNotification('注册成功！请登录', 'success');
            } else {
              console.error('注册失败:', data.error);
              showNotification('注册失败: ' + data.error, 'error');
            }
          } catch (error) {
            console.error('请求失败:', error);
            showNotification('请求失败，请稍后重试', 'error');
          }
        });
    }

    // 初始化认证状态
    updateAuthUI();
});