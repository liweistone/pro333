// Grsai API 适配层，用于与后端适配层通信
class GrsaiAPI {
  constructor() {
    this.baseUrl = '/api/grsai-batch-image';
    this.token = localStorage.getItem('token');
  }

  // 检查认证状态
  checkAuth() {
    const token = localStorage.getItem('token');
    if (!token) {
      throw new Error('用户未登录');
    }
    this.token = token;
    return true;
  }

  // 创建批量生成任务
  async createGenerationTask(prompt, config, referenceImages = []) {
    this.checkAuth();
    
    const response = await fetch(`${this.baseUrl}/generate`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${this.token}`
      },
      body: JSON.stringify({
        prompt,
        aspectRatio: config.aspectRatio,
        imageSize: config.imageSize,
        referenceImages
      })
    });

    const result = await response.json();
    if (!response.ok) {
      throw new Error(result.error || '创建任务失败');
    }

    return result.task_id;
  }

  // 查询任务状态
  async checkTaskStatus(taskId) {
    this.checkAuth();
    
    const response = await fetch(`${this.baseUrl}/status/${taskId}`, {
      headers: {
        'Authorization': `Bearer ${this.token}`
      }
    });

    const result = await response.json();
    if (!response.ok) {
      throw new Error(result.error || '查询状态失败');
    }

    return {
      id: taskId,
      results: result.results,
      progress: result.progress,
      status: result.task_status,
      failure_reason: result.error
    };
  }
}

// 替换原始的 API 调用函数
if (typeof window !== 'undefined') {
  window.GrsaiAPI = GrsaiAPI;
  
  // 重写 createGenerationTask 函数
  window.createGenerationTask = async (prompt, config, referenceImages = []) => {
    const api = new GrsaiAPI();
    return await api.createGenerationTask(prompt, config, referenceImages);
  };
  
  // 重写 checkTaskStatus 函数
  window.checkTaskStatus = async (taskId) => {
    const api = new GrsaiAPI();
    return await api.checkTaskStatus(taskId);
  };
}