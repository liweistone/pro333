// 检查categories表结构的脚本
async function checkCategoriesTableStructure() {
  try {
    // 获取表结构信息
    const tableInfo = await c.env.DB.prepare(
      "PRAGMA table_info(categories)"
    ).all();
    
    console.log('Categories表结构:');
    console.table(tableInfo.results);
    
    // 检查是否有数据
    const countResult = await c.env.DB.prepare(
      "SELECT COUNT(*) as count FROM categories"
    ).first();
    
    console.log('Categories表中的记录数:', countResult.count);
    
    // 如果有数据，显示前几条记录
    if (countResult.count > 0) {
      const sampleData = await c.env.DB.prepare(
        "SELECT * FROM categories LIMIT 5"
      ).all();
      
      console.log('Categories表样本数据:');
      console.table(sampleData.results);
    }
  } catch (error) {
    console.error('检查表结构时出错:', error);
  }
}

// 运行检查
checkCategoriesTableStructure();