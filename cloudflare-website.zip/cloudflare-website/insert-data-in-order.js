// 按正确顺序插入测试数据脚本
const { execSync } = require('child_process');

console.log('开始按正确顺序插入测试数据...\n');

// 按正确顺序插入数据的SQL命令
const insertTestDataSQL = `
-- 插入测试用户（确保先插入用户，因为文章和产品需要author_id）
INSERT OR IGNORE INTO Users (id, username, email, password_hash, role) VALUES 
(1, 'admin', 'admin@example.com', '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9', 'superadmin'),
(2, 'user1', 'user1@example.com', '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9', 'user');

-- 插入文章分类
INSERT OR IGNORE INTO ArticleCategories (id, name, description) VALUES 
(1, '技术教程', 'Cloudflare和AI技术相关的教程'),
(2, '使用指南', '产品使用指南和最佳实践');

-- 插入产品分类
INSERT OR IGNORE INTO ProductCategories (id, name, description) VALUES 
(1, '预设包', 'ComfyUI预设集合'),
(2, '工具', 'AI创作工具');

-- 插入预设分类
INSERT OR IGNORE INTO categories (id, name) VALUES 
('portrait', '人像'),
('landscape', '风景'),
('art', '艺术');

-- 插入测试文章（使用已存在的分类ID和用户ID）
INSERT OR IGNORE INTO Articles (id, title, content, category_id, author_id, is_published, visibility, cover_image) VALUES 
(1, 'Cloudflare Workers 入门指南', '这是一篇关于如何使用 Cloudflare Workers 构建无服务器应用的详细指南。Cloudflare Workers 提供了一个全球分布的无服务器执行环境，让开发者能够在全球范围内运行代码，而无需管理服务器。', 1, 1, 1, 'public', 'https://example.com/article-cover1.jpg'),
(2, 'D1 数据库使用教程', 'D1 是 Cloudflare 提供的无服务器 SQL 数据库，基于 SQLite 构建。它为 Workers 应用提供了原生集成的数据库解决方案，具有低延迟、高可用的特点。', 1, 1, 1, 'public', 'https://example.com/article-cover2.jpg'),
(3, 'ComfyUI 基础使用教程', 'ComfyUI 是一个强大的图像生成工具，本文将介绍其基本使用方法和核心概念。', 2, 1, 1, 'public', 'https://example.com/article-cover3.jpg');

-- 插入测试产品（使用已存在的分类ID）
INSERT OR IGNORE INTO Products (id, name, description, price, category_id, visibility, cover_image) VALUES 
(1, 'ComfyUI 高级预设包', '包含100+个高质量的 ComfyUI 预设，适用于各种图像生成场景', 29.99, 1, 'public', 'https://example.com/product-cover1.jpg'),
(2, 'AI 图像生成工具包', '完整的 AI 图像生成工具集合，包含模型、脚本和教程', 99.99, 2, 'public', 'https://example.com/product-cover2.jpg'),
(3, '风景画专用预设集', '专门针对风景画生成优化的高质量预设集合', 19.99, 1, 'public', 'https://example.com/product-cover3.jpg');

-- 插入测试预设（使用已存在的分类ID）
INSERT OR IGNORE INTO presets (id, title, category_id, description, positive, negative, image, visibility) VALUES 
('preset-1', '人像优化预设', 'portrait', '专门用于优化人像照片的 ComfyUI 预设', 'portrait, high quality, detailed face, sharp eyes', 'deformed, mutated hands, bad anatomy', 'https://example.com/preset1.jpg', 'public'),
('preset-2', '风景画预设', 'landscape', '适用于风景画生成的高质量预设', 'landscape, beautiful scenery, high resolution, detailed', 'blurry, low quality, distorted', 'https://example.com/preset2.jpg', 'public'),
('preset-3', '艺术创作预设', 'art', '适用于艺术创作的多样化预设', 'artistic, creative, high quality', 'low quality, deformed', 'https://example.com/preset3.jpg', 'public');

-- 插入Advertisements表测试数据（网站首页广告）
INSERT OR IGNORE INTO Advertisements (id, image_url, link_url, title, description, sort_order, is_active) VALUES
(1, 'https://example.com/homepage-ad1.jpg', 'https://example.com/product1', '首页广告1', '这是第一个首页广告', 1, 1),
(2, 'https://example.com/homepage-ad2.jpg', 'https://example.com/product2', '首页广告2', '这是第二个首页广告', 2, 1),
(3, 'https://example.com/homepage-ad3.jpg', 'https://example.com/product3', '首页广告3', '这是第三个首页广告', 3, 1);

-- 插入ads表测试数据（ComfyUI插件端广告）
INSERT OR IGNORE INTO ads (id, title, image_url, link_url, description, priority, is_active) VALUES
('ad1', 'ComfyUI插件广告1', 'https://example.com/plugin-ad1.jpg', 'https://example.com/plugin1', '这是第一个ComfyUI插件广告', 1, 1),
('ad2', 'ComfyUI插件广告2', 'https://example.com/plugin-ad2.jpg', 'https://example.com/plugin2', '这是第二个ComfyUI插件广告', 2, 1),
('ad3', 'ComfyUI插件广告3', 'https://example.com/plugin-ad3.jpg', 'https://example.com/plugin3', '这是第三个ComfyUI插件广告', 3, 1);
`;

const fs = require('fs');
const path = require('path');

// 将SQL写入临时文件
const tempInsertSQLFile = path.join(__dirname, 'temp-insert-data-in-order.sql');

fs.writeFileSync(tempInsertSQLFile, insertTestDataSQL);

try {
  // 插入新数据
  console.log('正在按正确顺序插入测试数据...');
  execSync(`npx wrangler d1 execute my-database --remote --file=${tempInsertSQLFile}`, { stdio: 'inherit' });
  console.log('✅ 测试数据插入成功！');
} catch (error) {
  console.error('❌ 操作失败:', error.message);
} finally {
  // 删除临时文件
  if (fs.existsSync(tempInsertSQLFile)) {
    fs.unlinkSync(tempInsertSQLFile);
  }
}

console.log('\n💡 现在您可以访问 https://aideator.top/ 查看填充的数据');