-- 插入预设分类
INSERT INTO categories (id, name) VALUES 
('portrait', '人像'),
('landscape', '风景'),
('art', '艺术');

-- 插入测试预设
INSERT INTO presets (id, title, category_id, description, positive, negative, image, visibility) VALUES 
('preset-1', '人像优化预设', 'portrait', '专门用于优化人像照片的 ComfyUI 预设', 'portrait, high quality, detailed face, sharp eyes', 'deformed, mutated hands, bad anatomy', 'https://example.com/preset1.jpg', 'public'),
('preset-2', '风景画预设', 'landscape', '适用于风景画生成的高质量预设', 'landscape, beautiful scenery, high resolution, detailed', 'blurry, low quality, distorted', 'https://example.com/preset2.jpg', 'public'),
('preset-3', '艺术创作预设', 'art', '适用于艺术创作的多样化预设', 'artistic, creative, high quality', 'low quality, deformed', 'https://example.com/preset3.jpg', 'public');