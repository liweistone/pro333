// 验证URL修复
console.log('验证URL修复...');

// 模拟环境
const mockReq = {
  url: 'http://localhost:8787/api/upload/upload-for-ai-tryon'
};

// 修复前的URL生成逻辑
const oldPublicUrl = `${new URL(mockReq.url).origin}/api/ai-tryon/public-image/test-key`;
console.log('修复前的URL:', oldPublicUrl);

// 修复后的URL生成逻辑
const newPublicUrl = `${new URL(mockReq.url).origin}/api/upload/public-image/test-key`;
console.log('修复后的URL:', newPublicUrl);

// 检查路由注册
console.log('路由注册:');
console.log('app.route("/api/upload", uploadRoutes);');

console.log('\n验证结果:');
console.log('修复前的URL路径: /api/ai-tryon/public-image/test-key');
console.log('修复后的URL路径: /api/upload/public-image/test-key');
console.log('路由注册路径: /api/upload');
console.log('修复后的URL路径与路由注册路径匹配: ✓');