// 插入测试首页广告数据的脚本
async function insertTestHomepageAds() {
  // 由于我们无法直接访问D1数据库，我们将使用wrangler命令行工具来插入测试数据
  // 这个脚本只是说明我们需要插入的数据
  
  console.log('需要插入的Advertisements表测试数据:');
  console.log('1. 首页广告1:');
  console.log('   image_url: https://images.unsplash.com/photo-1501854140801-50d01698950b?ixlib=rb-1.2.1&auto=format&fit=crop&w=2000&q=80');
  console.log('   link_url: https://example.com/product1');
  console.log('   title: 首页广告1');
  console.log('   description: 这是第一个首页广告');
  console.log('   sort_order: 1');
  console.log('   is_active: 1');
  console.log('');
  
  console.log('2. 首页广告2:');
  console.log('   image_url: https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?ixlib=rb-1.2.1&auto=format&fit=crop&w=2000&q=80');
  console.log('   link_url: https://example.com/product2');
  console.log('   title: 首页广告2');
  console.log('   description: 这是第二个首页广告');
  console.log('   sort_order: 2');
  console.log('   is_active: 1');
  console.log('');
  
  console.log('3. 首页广告3:');
  console.log('   image_url: https://images.unsplash.com/photo-1469474968028-56623f02e42e?ixlib=rb-1.2.1&auto=format&fit=crop&w=2000&q=80');
  console.log('   link_url: https://example.com/product3');
  console.log('   title: 首页广告3');
  console.log('   description: 这是第三个首页广告');
  console.log('   sort_order: 3');
  console.log('   is_active: 1');
}

insertTestHomepageAds();