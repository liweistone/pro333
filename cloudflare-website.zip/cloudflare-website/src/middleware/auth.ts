import { createMiddleware } from 'hono/factory';
import { verify } from 'hono/jwt';
import type { Variables } from '../types';

// 真实的JWT认证中间件
export const authMiddleware = createMiddleware(async (c, next) => {
  console.log('=== 认证中间件被调用 ===');
  console.log('认证中间件 - 完整请求URL:', c.req.url);
  const authHeader = c.req.header('Authorization');
  
  // 在 authMiddleware 中添加调试信息
  console.log('认证中间件 - 请求路径:', c.req.path);
  console.log('认证中间件 - 请求方法:', c.req.method);
  console.log('认证中间件 - 认证头:', authHeader);
  console.log('认证中间件 - 所有请求头:', Object.fromEntries(c.req.raw.headers));
  console.log('认证中间件 - 环境变量JWT_SECRET存在:', !!c.env.JWT_SECRET);
  
  // 如果没有认证头，对于需要认证的路由应该返回401错误
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    console.log('认证中间件 - 缺少认证头或格式不正确');
    console.log('认证头值:', authHeader);
    // 对于需要认证的路由，如果缺少认证头，应该返回401错误
    return c.json({ error: '需要登录' }, 401);
  }
  
  const token = authHeader.substring(7); // 移除 'Bearer ' 前缀
  console.log('认证中间件 - 提取的令牌长度:', token.length);
  console.log('认证中间件 - 提取的令牌前10个字符:', token.substring(0, 10));
  
  // 检查JWT_SECRET是否存在
  if (!c.env.JWT_SECRET) {
    console.error('认证中间件 - JWT_SECRET未配置');
    return c.json({ error: '服务器配置错误：JWT_SECRET未设置' }, 500);
  }
  
  try {
    // 验证JWT令牌
    console.log('认证中间件 - 使用JWT_SECRET进行验证:', c.env.JWT_SECRET.substring(0, 10) + '...');
    const decoded = await verify(token, c.env.JWT_SECRET);
    console.log('认证中间件 - 令牌解码结果:', decoded);
    
    // 检查令牌是否过期
    if (decoded.exp && decoded.exp * 1000 < Date.now()) {
      console.log('认证中间件 - 令牌已过期');
      console.log('认证中间件 - 令牌过期时间:', new Date(decoded.exp * 1000));
      console.log('认证中间件 - 当前时间:', new Date());
      // 令牌过期时返回401错误
      return c.json({ error: '登录已过期，请重新登录' }, 401);
    }
    
    // 设置用户信息
    c.set('user', {
      id: decoded.id,
      username: decoded.username,
      email: decoded.email,
      role: decoded.role,
      membership_level: decoded.membership_level
    });
    
    console.log('认证中间件 - 认证成功，用户:', c.get('user'));
    
    await next();
  } catch (error: any) {
    console.error('JWT验证失败:', error.message);
    console.error('错误堆栈:', error.stack);
    // 对于需要认证的路由，令牌无效时应该返回401错误
    return c.json({ error: '令牌无效，请重新登录' }, 401);
  }
});

// 角色权限检查中间件
export const requireRole = (roles: string | string[]) => {
  return createMiddleware(async (c, next) => {
    const user = c.get('user');
    
    console.log('权限检查中间件 - 当前用户:', user);
    console.log('权限检查中间件 - 需要的角色:', roles);
    
    if (!user) {
      console.error('需要登录: 用户未认证');
      return c.json({ error: '需要登录' }, 401);
    }
    
    const allowedRoles = Array.isArray(roles) ? roles : [roles];
    
    if (!allowedRoles.includes(user.role)) {
      console.error(`权限不足: 用户角色为 ${user.role}，需要的角色: ${allowedRoles.join(', ')}`);
      return c.json({ error: '权限不足' }, 403);
    }
    
    console.log('权限检查中间件 - 权限验证通过');
    await next();
  });
};

// 管理员权限检查中间件
export const requireAdmin = createMiddleware(async (c, next) => {
  const user = c.get('user');
  
  console.log('管理员权限检查中间件 - 当前用户:', user);
  
  if (!user) {
    console.error('需要登录: 用户未认证（管理员权限检查）');
    return c.json({ error: '需要登录' }, 401);
  }
  
  if (user.role !== 'admin' && user.role !== 'superadmin') {
    console.error(`需要管理员权限: 用户角色为 ${user.role}`);
    return c.json({ error: '需要管理员权限' }, 403);
  }
  
  console.log('管理员权限检查中间件 - 权限验证通过');
  await next();
});