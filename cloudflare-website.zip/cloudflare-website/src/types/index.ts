// 类型定义
export type Bindings = {
  DB: any; // D1Database;
  MY_BUCKET: any; // R2Bucket;
  JWT_SECRET: string;
  DASHSCOPE_API_KEY: string; // 阿里云百炼API密钥
  // 通用RunningHub配置
  RUNNINGHUB_API_KEY?: string;
  RUNNINGHUB_WEBAPP_ID?: string;
  // 文生图应用RunningHub配置（只需要WebApp ID，API Key使用通用配置）
  TEXT_TO_IMAGE_RUNNINGHUB_WEBAPP_ID?: string;
  // 其他AI应用RunningHub配置（只需要WebApp ID，API Key使用通用配置）
  TEXT_TO_VIDEO_RUNNINGHUB_WEBAPP_ID?: string;
  IMAGE_REPAIR_RUNNINGHUB_WEBAPP_ID?: string;
  IMAGE_UPSCALE_RUNNINGHUB_WEBAPP_ID?: string;
  FACE_SWAP_RUNNINGHUB_WEBAPP_ID?: string;
  CHEST_ENLARGEMENT_RUNNINGHUB_WEBAPP_ID?: string;
  // 其他AI应用阿里云配置
  TEXT_TO_IMAGE_DASHSCOPE_API_KEY?: string;
  TEXT_TO_VIDEO_DASHSCOPE_API_KEY?: string;
  IMAGE_REPAIR_DASHSCOPE_API_KEY?: string;
  IMAGE_UPSCALE_DASHSCOPE_API_KEY?: string;
  FACE_SWAP_DASHSCOPE_API_KEY?: string;
  // 阿里云OSS配置
  OSS_REGION?: string;
  OSS_BUCKET?: string;
  OSS_ACCESS_KEY_ID?: string;
  OSS_ACCESS_KEY_SECRET?: string;
  
  // 支付系统配置
  EPAY_API_URL?: string;
  EPAY_PID?: string;
  EPAY_PLATFORM_PUBLIC_KEY?: string;
  EPAY_MERCHANT_PRIVATE_KEY?: string;
  
  // 支付回调域名配置
  PAYMENT_RETURN_DOMAIN?: string;
  PAYMENT_NOTIFY_DOMAIN?: string;
};

export type Variables = {
  user?: {
    id: number;
    username: string;
    email: string;
    role: string;
    membership_level: string;
  };
};

// 用户相关类型
export type User = {
  id: number;
  username: string;
  email: string;
  role: string;
  membership_level: string;
  profile_image?: string;
  bio?: string;
  preferences?: any;
  created_at: string;
  last_login?: string;
  is_active: boolean;
};

// 文章相关类型
export type ArticleCategory = {
  id: number;
  name: string;
  description?: string;
  parent_id?: number;
};

export type Article = {
  id: number;
  title: string;
  content: string;
  category_id: number;
  author_id: number;
  is_published: boolean;
  visibility: string;
  view_count: number;
  favorite_count: number;
  created_at: string;
  updated_at: string;
};

// 产品相关类型
export type ProductCategory = {
  id: number;
  name: string;
  description?: string;
  parent_id?: number;
};

export type Product = {
  id: number;
  name: string;
  description: string;
  price: number;
  category_id: number;
  features?: any;
  is_available: boolean;
  visibility: string;
  view_count: number;
  favorite_count: number;
  created_at: string;
};

// 评论相关类型
export type Comment = {
  id: number;
  content: string;
  user_id: number;
  parent_type: string;
  parent_id: number;
  created_at: string;
  status: string;
};

// 留言板相关类型
export type GuestbookMessage = {
  id: number;
  user_id: number;
  message: string;
  created_at: string;
  is_public: boolean;
};

// 广告相关类型
export type Advertisement = {
  id: number;
  image_url: string;
  link_url?: string;
  title?: string;
  description?: string;
  sort_order: number;
  is_active: boolean;
  created_at: string;
};

// ComfyUI预设相关类型
export type PresetCategory = {
  id: string;
  name: string;
  created_at: number;
  updated_at: number;
};

export type Preset = {
  id: string;
  title: string;
  category_id: string;
  description?: string;
  positive: string;
  negative?: string;
  image?: string;
  visibility: string;
  preset_type: string;
  view_count: number;
  favorite_count: number;
  use_count: number;
  created_at: number;
  updated_at: number;
  last_used_at?: number;
};

export type PresetAd = {
  id: string;
  title: string;
  image_url: string;
  link_url: string;
  description?: string;
  priority: number;
  is_active: number;
  created_at: number;
  updated_at: number;
};

// 图像管理相关类型
export type R2Image = {
  id: number;
  object_key: string;
  original_name: string;
  mime_type: string;
  size: number;
  uploader_id: number;
  uploaded_at: string;
  alt_text?: string;
  description?: string;
  is_used: boolean;
  usage_count: number;
  is_referenced?: boolean;
  reference_status?: string;
};

export type ImageUsage = {
  id: number;
  image_id: number;
  used_in_type: string;
  used_in_id: number;
  used_at: string;
};