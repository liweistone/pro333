import { R2Explorer } from 'r2-explorer';

// 创建R2 Explorer配置
export const r2ExplorerConfig = R2Explorer({
  readonly: false,
  // 可以添加其他配置选项
});