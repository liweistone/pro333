import { Hono } from 'hono';
import { cors } from 'hono/cors';
import { logger } from 'hono/logger';
import { verify } from 'hono/jwt';

// 导入路由
import authRoutes from './routes/auth';
import articleRoutes from './routes/articles';
import productRoutes from './routes/products';
import presetRoutes from './routes/presets';
import presetAdRoutes from './routes/ads';  // ComfyUI插件端广告
import homepageAdRoutes from './routes/Advertisements';  // 网站首页广告
import imageRoutes from './routes/images';
import commentRoutes from './routes/comments';
import guestbookRoutes from './routes/guestbook';
import favoriteRoutes from './routes/favorites';
import userLevelRoutes from './routes/userlevels';
import articleCategoryRoutes from './routes/ArticleCategories';
import productCategoryRoutes from './routes/ProductCategories';
import adminRoutes from './routes/admin';
import userRoutes from './routes/users';
import debugRoutes from './routes/debug'; // 调试路由
import r2Routes from './routes/r2'; // R2文件管理路由
import aiTryonRoutes from './routes/ai-tryon'; // AI试衣路由
import uploadRoutes from './routes/upload-and-serve'; // 上传和专用访问路由
import textToImageRoutes from './routes/text-to-image'; // 文生图路由
import grsaiBatchImageRoutes from './routes/grsai-batch-image'; // Grsai批量出图路由
import fixPresetEffectsRoutes from './routes/fix-preset-effects'; // 预设效果图URL修复路由

import paymentRoutes from './routes/payment'; // 支付系统路由

// 导入R2 Explorer配置
import { r2ExplorerConfig } from './r2-explorer-config';

// 类型定义
type Bindings = {
  DB: any; // D1Database;
  MY_BUCKET: any; // R2Bucket;
  JWT_SECRET: string;
  ASSETS: any; // Fetcher;
  DASHSCOPE_API_KEY: string; // 阿里云百炼API密钥
};

type Variables = {
  user?: {
    id: number;
    username: string;
    email: string;
    role: string;
    membership_level: string;
  };
};

const app = new Hono<{ Bindings: Bindings; Variables: Variables }>();

// 中间件
app.use('*', logger());
app.use('*', cors({
  origin: ['http://localhost:3000', 'https://aideator.top'],
  credentials: true,
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization'],
}));

// 为API路由添加额外的CORS处理
app.use('/api/*', async (c, next) => {
  // 设置CORS头部
  c.header('Access-Control-Allow-Origin', '*');
  c.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  c.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  await next();
});

// 处理所有OPTIONS请求
app.options('*', (c) => {
  return new Response(null, { status: 204 });
});

// 设置全局字符编码（仅对API路由）
app.use('/api/*', async (c, next) => {
  await next();
  // 只有在响应是JSON时才设置字符编码
  if (c.res.headers.get('Content-Type')?.includes('application/json')) {
    c.header('Content-Type', 'application/json; charset=utf-8');
  }
});

// 专门处理AI试衣页面路由
app.get('/ai-tryon', async (c) => {
  if (c.env.ASSETS) {
    try {
      const assetResponse = await c.env.ASSETS.fetch(
        new Request(new URL('/ai-tryon.html', c.req.url).href, c.req.raw)
      );
      if (assetResponse && assetResponse.status !== 404) {
        return assetResponse;
      }
    } catch (e) {
      console.error('Error fetching ai-tryon.html:', e);
    }
  }
  
  return c.text('AI试衣页面未找到', 404);
});

// R2-Explorer 路由
app.get('/r2-explorer', async (c) => {
  try {
    // 修改请求路径，移除前缀
    const url = new URL(c.req.url);
    url.pathname = url.pathname.replace('/r2-explorer', '') || '/';
    
    // 创建一个新的请求对象
    const newRequest = new Request(url.href, c.req);
    
    // 创建适配的环境对象
    const env = {
      ASSETS: c.env.ASSETS,
      MY_BUCKET: c.env.MY_BUCKET,
    };
    
    // 调用 R2Explorer 处理请求
    // @ts-ignore - 忽略类型检查，因为 R2Explorer 的类型定义可能不完整
    return r2ExplorerConfig.fetch(newRequest, env, c.executionCtx);
  } catch (error) {
    console.error('Error loading R2 Explorer:', error);
    return c.text('Error loading R2 Explorer: ' + (error as Error).message, 500);
  }
});

app.get('/r2-explorer/*', async (c) => {
  try {
    // 修改请求路径，移除前缀
    const url = new URL(c.req.url);
    url.pathname = url.pathname.replace('/r2-explorer', '') || '/';
    
    // 创建一个新的请求对象
    const newRequest = new Request(url.href, c.req);
    
    // 创建适配的环境对象
    const env = {
      ASSETS: c.env.ASSETS,
      MY_BUCKET: c.env.MY_BUCKET,
    };
    
    // 调用 R2Explorer 处理请求
    // @ts-ignore - 忽略类型检查，因为 R2Explorer 的类型定义可能不完整
    return r2ExplorerConfig.fetch(newRequest, env, c.executionCtx);
  } catch (error) {
    console.error('Error loading R2 Explorer:', error);
    return c.text('Error loading R2 Explorer: ' + (error as Error).message, 500);
  }
});

// 静态资源服务
app.get('/static/*', async (c) => {
  const url = new URL(c.req.url);
  const pathname = url.pathname;
  const key = pathname.replace('/static/', '');
  
  // 尝试从ASSETS绑定获取静态资源
  if (c.env.ASSETS) {
    try {
      const assetResponse = await c.env.ASSETS.fetch(c.req.raw);
      if (assetResponse && assetResponse.status !== 404) {
        return assetResponse;
      }
    } catch (e) {
      console.error('Error fetching asset:', e);
    }
  }
  
  return c.text('Static asset not found', 404);
});

// 临时访问端点（无需认证）- 为AI试衣功能提供临时图片访问
app.get('/api/ai-tryon/temp-access/:token', async (c) => {
  try {
    const token = c.req.param('token');
    
    console.log('临时访问端点被调用，令牌:', token);
    
    if (!token) {
      return c.json({ error: '令牌不能为空' }, 400);
    }
    
    // 验证JWT令牌
    const decoded = await verify(token, c.env.JWT_SECRET);
    
    console.log('令牌解码结果:', decoded);
    
    // 检查令牌是否过期
    if (decoded.exp && decoded.exp * 1000 < Date.now()) {
      console.log('令牌已过期，过期时间:', new Date(decoded.exp * 1000));
      return c.json({ error: '令牌已过期' }, 401);
    }
    
    // 获取文件
    console.log('尝试获取文件，key:', decoded.key);
    const object = await c.env.MY_BUCKET.get(decoded.key as string);
    if (!object) {
      console.log('文件不存在，key:', decoded.key);
      return c.json({ error: '文件不存在' }, 404);
    }
    
    console.log('文件获取成功，大小:', object.size);
    
    // 设置响应头
    const headers = new Headers();
    object.writeHttpMetadata(headers);
    headers.set('etag', object.httpEtag);
    headers.set('Access-Control-Allow-Origin', '*'); // 允许跨域访问
    headers.set('Cache-Control', 'public, max-age=7200'); // 设置缓存2小时（增加缓存时间）
    // 为AI服务访问进一步放宽安全策略
    headers.set('Content-Security-Policy', 'default-src * data: blob: http: https:; script-src * \'unsafe-inline\' \'unsafe-eval\'; style-src * \'unsafe-inline\'; img-src * data: blob: http: https:; connect-src *'); // 进一步放宽内容安全策略
    headers.set('X-Content-Type-Options', 'nosniff'); // 防止MIME类型嗅探
    
    // 对于图片文件，设置更具体的Content-Type
    if (!headers.has('Content-Type')) {
      const key = (decoded.key as string).toLowerCase();
      if (key.endsWith('.jpg') || key.endsWith('.jpeg')) {
        headers.set('Content-Type', 'image/jpeg');
      } else if (key.endsWith('.png')) {
        headers.set('Content-Type', 'image/png');
      } else if (key.endsWith('.gif')) {
        headers.set('Content-Type', 'image/gif');
      } else if (key.endsWith('.webp')) {
        headers.set('Content-Type', 'image/webp');
      }
    }
    
    // 返回文件内容（使用流式响应）
    return new Response(object.body, {
      headers
    });
  } catch (error) {
    console.error('临时访问失败:', error);
    // 如果是JWT验证错误，返回更友好的错误信息
    if (error instanceof Error && error.message.includes('verify')) {
      return c.json({ error: '临时访问令牌无效或已过期: ' + error.message }, 401);
    }
    return c.json({ error: '临时访问失败: ' + (error as Error).message }, 500);
  }
});

// 添加一个简单的代理端点来测试SSL连接
app.get('/api/ssl-test', async (c) => {
  try {
    // 测试外部API连接
    const testUrl = 'https://www.runninghub.cn/task/openapi/quick-ai-app/run';
    console.log('测试外部API连接:', testUrl);
    
    const response = await fetch(testUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        webappId: "1959831828515467265",
        apiKey: "75faa4e0296945e796c3914bd95e3e52",
        quickCreateCode: "006",
        nodeInfoList: []
      })
    });
    
    console.log('外部API响应状态:', response.status);
    
    if (response.ok) {
      const data = await response.json();
      return c.json({ 
        success: true, 
        message: 'SSL连接测试成功',
        response: data
      });
    } else {
      const errorText = await response.text();
      return c.json({ 
        success: false, 
        message: 'SSL连接测试失败',
        status: response.status,
        error: errorText
      }, 500); // 统一返回500状态码
    }
  } catch (error) {
    console.error('SSL测试错误:', error);
    return c.json({ 
      success: false, 
      message: 'SSL连接测试出错',
      error: (error as Error).message
    }, 500);
  }
});

// 为阿里云试衣API提供专门的图片访问端点（优化版本）
app.get('/api/ai-tryon/public-image/:key', async (c) => {
  try {
    const key = c.req.param('key');
    const expires = c.req.query('expires'); // 可选的过期时间参数
    
    console.log('[AI-TRYON-PUBLIC-IMAGE] 阿里云试衣API专用图片访问端点被调用', { 
      key, 
      expires,
      userAgent: c.req.header('User-Agent'),
      referer: c.req.header('Referer')
    });
    
    if (!key) {
      console.log('[AI-TRYON-PUBLIC-IMAGE] 文件key不能为空');
      return c.json({ error: '文件key不能为空' }, 400);
    }
    
    // 检查是否过期（如果提供了expires参数）
    if (expires) {
      const expiresTime = parseInt(expires);
      if (!isNaN(expiresTime) && Date.now() > expiresTime) {
        console.log('[AI-TRYON-PUBLIC-IMAGE] 临时URL已过期', { expiresTime, currentTime: Date.now() });
        return c.json({ error: '临时URL已过期' }, 401);
      }
    }
    
    const decodedKey = decodeURIComponent(key);
    console.log('[AI-TRYON-PUBLIC-IMAGE] 解码后的key:', decodedKey);
    
    // 从R2获取对象
    const object = await c.env.MY_BUCKET.get(decodedKey);
    
    if (!object) {
      console.log('[AI-TRYON-PUBLIC-IMAGE] 文件不存在', { key: decodedKey });
      return c.json({ error: '文件不存在' }, 404);
    }
    
    console.log('[AI-TRYON-PUBLIC-IMAGE] 文件获取成功', { 
      key: decodedKey, 
      size: object.size,
      uploaded: object.uploaded,
      httpEtag: object.httpEtag
    });
    
    // 设置响应头，专门为阿里云试衣API优化
    const headers = new Headers();
    object.writeHttpMetadata(headers);
    headers.set('etag', object.httpEtag);
    
    // 专门为阿里云试衣API设置的头部
    headers.set('Access-Control-Allow-Origin', '*');
    headers.set('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS');
    headers.set('Access-Control-Allow-Headers', '*');
    headers.set('Access-Control-Max-Age', '86400'); // 24小时
    
    // 设置缓存控制，提高访问速度
    headers.set('Cache-Control', 'public, max-age=172800'); // 48小时缓存
    
    // 设置内容安全策略，允许阿里云服务访问
    headers.set('Content-Security-Policy', 'default-src * data: blob: http: https:; img-src * data: blob: http: https:; connect-src *');
    
    // 设置其他有助于阿里云访问的头部
    headers.set('Timing-Allow-Origin', '*');
    headers.set('X-Content-Type-Options', 'nosniff');
    headers.set('X-Frame-Options', 'DENY');
    headers.set('Accept-Ranges', 'bytes');
    
    // 对于图片文件，确保Content-Type正确设置
    if (!headers.has('Content-Type')) {
      const lowerKey = decodedKey.toLowerCase();
      if (lowerKey.endsWith('.jpg') || lowerKey.endsWith('.jpeg')) {
        headers.set('Content-Type', 'image/jpeg');
      } else if (lowerKey.endsWith('.png')) {
        headers.set('Content-Type', 'image/png');
      } else if (lowerKey.endsWith('.gif')) {
        headers.set('Content-Type', 'image/gif');
      } else if (lowerKey.endsWith('.webp')) {
        headers.set('Content-Type', 'image/webp');
      } else {
        // 默认设置为jpeg
        headers.set('Content-Type', 'image/jpeg');
      }
    }
    
    // 添加一些额外的头部来改善阿里云服务的访问体验
    headers.set('X-Robots-Tag', 'noindex, nofollow');
    headers.set('X-XSS-Protection', '1; mode=block');
    
    console.log('[AI-TRYON-PUBLIC-IMAGE] 返回响应头:');
    for (const [headerKey, value] of headers.entries()) {
      console.log(`${headerKey}: ${value}`);
    }
    
    // 返回文件内容
    return new Response(object.body, {
      headers
    });
  } catch (error) {
    console.error('[AI-TRYON-PUBLIC-IMAGE] 阿里云试衣API图片访问失败:', error);
    return c.json({ error: '图片访问失败: ' + (error as Error).message }, 500);
  }
});

// 路由注册 - 先注册API路由，再注册静态资源路由
app.route('/api/comments', commentRoutes);
app.route('/api/auth', authRoutes);
app.route('/api/articles', articleRoutes);
app.route('/api/products', productRoutes);
app.route('/api/presets', presetRoutes);
app.route('/api/ads', presetAdRoutes);  // ComfyUI插件端广告
app.route('/api/homepage-ads', homepageAdRoutes);  // 网站首页广告
app.route('/api/images', imageRoutes);
app.route('/api/guestbook', guestbookRoutes);
app.route('/api/favorites', favoriteRoutes);
app.route('/api/user-levels', userLevelRoutes);
app.route('/api/article-categories', articleCategoryRoutes);
app.route('/api/product-categories', productCategoryRoutes);
console.log('注册admin路由');
app.route('/api/admin', adminRoutes);
console.log('admin路由注册完成');
app.route('/api', userRoutes);
app.route('/api/debug', debugRoutes); // 调试路由
app.route('/api/r2', r2Routes); // R2文件管理路由
app.route('/api/ai-tryon', aiTryonRoutes); // AI试衣路由
app.route('/api/upload', uploadRoutes); // 上传和专用访问路由
app.route('/api/text-to-image', textToImageRoutes); // 文生图路由
app.route('/api/grsai-batch-image', grsaiBatchImageRoutes); // Grsai批量出图路由
app.route('/api/fix-preset-effects', fixPresetEffectsRoutes); // 预设效果图URL修复路由

app.route('/api/payment', paymentRoutes); // 支付系统路由

// 健康检查端点
app.get('/health', (c) => {
  console.log('健康检查端点被调用');
  return c.json({ status: 'OK', timestamp: new Date().toISOString() });
});

// 测试路由
app.get('/test', async (c) => {
  console.log('主应用测试路由被调用');
  return c.json({ message: '主应用测试路由工作正常' });
});

// API测试路由
app.get('/api/test', async (c) => {
  console.log('API测试路由被调用');
  return c.json({ message: 'API测试路由工作正常' });
});

// 简单测试路由
app.get('/simple-test', async (c) => {
  console.log('简单测试路由被调用');
  return c.text('简单测试路由工作正常');
});

// 测试公开API端点
app.get('/test-public', async (c) => {
  return c.json({ message: 'This is a public endpoint', user: c.get('user') });
});

// 数据库检查端点（仅用于调试）
app.get('/debug/db-stats', async (c) => {
  try {
    // 检查用户表
    const userResults = await c.env.DB.prepare(
      'SELECT COUNT(*) as count FROM Users'
    ).first();
    
    // 检查文章表
    const articleResults = await c.env.DB.prepare(
      'SELECT COUNT(*) as count FROM Articles'
    ).first();
    
    // 检查产品表
    const productResults = await c.env.DB.prepare(
      'SELECT COUNT(*) as count FROM Products'
    ).first();
    
    // 检查预设表
    const presetResults = await c.env.DB.prepare(
      'SELECT COUNT(*) as count FROM presets'
    ).first();
    
    return c.json({
      users: userResults.count,
      articles: articleResults.count,
      products: productResults.count,
      presets: presetResults.count
    });
  } catch (error: any) {
    return c.json({ error: error.message }, 500);
  }
});

// 获取用户列表（仅用于调试）
app.get('/debug/users', async (c) => {
  try {
    const { results } = await c.env.DB.prepare(
      'SELECT id, username, email, role FROM Users LIMIT 10'
    ).all();
    
    return c.json(results);
  } catch (error: any) {
    return c.json({ error: error.message }, 500);
  }
});

// 获取评论列表（仅用于调试）
app.get('/debug/comments', async (c) => {
  try {
    const { results } = await c.env.DB.prepare(
      'SELECT * FROM Comments LIMIT 10'
    ).all();
    
    return c.json(results);
  } catch (error: any) {
    return c.json({ error: error.message }, 500);
  }
});

// 获取评论表结构（仅用于调试）
app.get('/debug/comments/schema', async (c) => {
  try {
    const { results } = await c.env.DB.prepare(
      "PRAGMA table_info(Comments)"
    ).all();
    
    return c.json(results);
  } catch (error: any) {
    return c.json({ error: error.message }, 500);
  }
});

// 根页面服务index.html - 放在API路由之后，确保API路由优先匹配
app.get('/', async (c) => {
  if (c.env.ASSETS) {
    try {
      const assetResponse = await c.env.ASSETS.fetch(
        new Request(new URL('/index.html', c.req.url).href, c.req.raw)
      );
      if (assetResponse && assetResponse.status !== 404) {
        return assetResponse;
      }
    } catch (e) {
      console.error('Error fetching index.html:', e);
    }
  }
  
  return c.text('Welcome to Cloudflare Website API');
});

// 通配符路由，用于服务其他静态资源 - 放在最后，确保API路由优先匹配
app.get('*', async (c) => {
  if (c.env.ASSETS) {
    try {
      const assetResponse = await c.env.ASSETS.fetch(c.req.raw);
      if (assetResponse && assetResponse.status !== 404) {
        return assetResponse;
      }
    } catch (e) {
      console.error('Error fetching asset:', e);
    }
  }
  
  return c.text('Not found', 404);
});

export default app;