import { Hono } from 'hono';
import { authMiddleware } from '../middleware/auth';
import type { Bindings, Variables } from '../types';

// 日志工具函数
const logInfo = (message: string, data?: any) => {
  console.log(`[GRSAI-BATCH-IMAGE-INFO] ${new Date().toISOString()} - ${message}`, data ? JSON.stringify(data) : '');
};

const logError = (message: string, error?: any) => {
  console.error(`[GRSAI-BATCH-IMAGE-ERROR] ${new Date().toISOString()} - ${message}`, error);
};

const logDebug = (message: string, data?: any) => {
  console.debug(`[GRSAI-BATCH-IMAGE-DEBUG] ${new Date().toISOString()} - ${message}`, data ? JSON.stringify(data) : '');
};

const grsaiBatchImageRoutes = new Hono<{ Bindings: Bindings; Variables: Variables }>();

// 从环境变量获取 Grsai API 配置
const getGrsaiConfig = (env: any) => {
  const apiKey = env.GRSAI_API_KEY || 'sk-823abcd4cca74bd5972d3c05e1bece15'; // 使用默认值作为后备
  const baseUrl = env.GRSAI_BASE_URL || 'https://grsai.dakka.com.cn';
  return { apiKey, baseUrl };
};

// 创建批量生成任务
grsaiBatchImageRoutes.post('/generate', authMiddleware, async (c) => {
  logInfo('[GRSAI-BATCH-IMAGE-CREATE] 开始创建批量生成任务');
  try {
    // 获取请求参数
    const body = await c.req.json();
    logDebug('[GRSAI-BATCH-IMAGE-CREATE] 接收到的请求参数', body);
    const { prompt, aspectRatio = '1:1', imageSize = '1K', referenceImages = [] } = body;

    // 参数验证
    if (!prompt || typeof prompt !== 'string') {
      return c.json({ error: '提示词是必需的' }, 400);
    }

    console.log('[GRSAI-BATCH-IMAGE-CREATE] 批量生成任务请求:', { prompt, aspectRatio, imageSize });

    // 获取 Grsai 配置
    const { apiKey, baseUrl } = getGrsaiConfig(c.env);
    if (!apiKey || apiKey === 'YOUR_GRSAI_API_KEY_HERE' || apiKey.startsWith('sk-') === false) {
      return c.json({ 
        error: 'Grsai API密钥未正确配置，请在wrangler.toml文件中设置有效的GRSAI_API_KEY' 
      }, 500);
    }

    // 准备API请求参数
    const model = imageSize === '1K' ? 'nano-banana-pro-vip' : 'nano-banana-pro';
    const apiUrl = `${baseUrl}/v1/draw/nano-banana`;

    const requestBody = {
      model,
      prompt,
      aspectRatio,
      imageSize,
      urls: referenceImages,
      webHook: "-1", 
      shutProgress: false
    };

    console.log('[GRSAI-BATCH-IMAGE-CREATE] 发送到Grsai API的请求:', JSON.stringify(requestBody, null, 2));

    // 调用Grsai API
    logInfo('[GRSAI-BATCH-IMAGE-CREATE] 开始调用Grsai批量生成API');
    logDebug('[GRSAI-BATCH-IMAGE-CREATE] API请求详情', {
      url: apiUrl,
      headers: {
        'Content-Type': 'application/json'
      },
      body: requestBody
    });

    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`
      },
      body: JSON.stringify(requestBody)
    });

    logDebug('[GRSAI-BATCH-IMAGE-CREATE] API响应状态', { 
      status: response.status, 
      statusText: response.statusText 
    });

    if (!response.ok) {
      const errorText = await response.text();
      logError('[GRSAI-BATCH-IMAGE-CREATE] Grsai批量生成API调用失败', { 
        status: response.status, 
        statusText: response.statusText, 
        errorText: errorText 
      });
      
      // 如果是API密钥错误，返回更友好的提示
      if (errorText.includes('InvalidApiKey') || response.status === 401) {
        return c.json({ 
          error: 'Grsai API密钥无效，请检查wrangler.toml文件中的GRSAI_API_KEY配置' 
        }, 500);
      }
      
      return c.json({ error: `Grsai批量生成API调用失败: ${errorText}` }, 500);
    }

    const result: any = await response.json();
    console.log('[GRSAI-BATCH-IMAGE-CREATE] Grsai API响应:', result);
    
    if (result.code !== 0) {
      logError('[GRSAI-BATCH-IMAGE-CREATE] Grsai API返回错误', result);
      return c.json({ error: result.msg || 'Grsai批量生成API调用失败' }, 500);
    }

    // 保存任务信息到数据库
    const user = c.get('user');
    if (user) {
      try {
        // 创建任务记录
        const { success } = await c.env.DB.prepare(
          'INSERT INTO text_to_image_tasks (user_id, task_id, prompt, status, created_at) VALUES (?, ?, ?, ?, ?)'
        ).bind(
          user.id,
          result.data.id,
          prompt,
          'RUNNING',
          new Date().toISOString()
        ).run();
        
        if (!success) {
          logError('[GRSAI-BATCH-IMAGE-CREATE] 保存任务信息到数据库失败');
        }
      } catch (dbError) {
        logError('[GRSAI-BATCH-IMAGE-CREATE] 数据库操作错误', dbError);
      }
    }
    
    // 返回任务ID
    return c.json({
      success: true,
      task_id: result.data.id,
      message: '批量生成任务已创建'
    });
  } catch (error) {
    logError('[GRSAI-BATCH-IMAGE-CREATE] 创建批量生成任务错误', error);
    return c.json({ error: '创建批量生成任务失败: ' + (error as Error).message }, 500);
  }
});

// 查询任务状态
grsaiBatchImageRoutes.get('/status/:taskId', authMiddleware, async (c) => {
  logInfo('[GRSAI-BATCH-IMAGE-STATUS] 开始查询批量生成任务状态');
  try {
    const taskId = c.req.param('taskId');
    logDebug('[GRSAI-BATCH-IMAGE-STATUS] 查询的任务ID', { taskId });
    
    if (!taskId) {
      return c.json({ error: '任务ID是必需的' }, 400);
    }

    // 获取 Grsai 配置
    const { apiKey, baseUrl } = getGrsaiConfig(c.env);

    const apiUrl = `${baseUrl}/v1/draw/result`;
    const requestBody = { id: taskId };

    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`
      },
      body: JSON.stringify(requestBody)
    });

    const result: any = await response.json();
    console.log('[GRSAI-BATCH-IMAGE-STATUS] Grsai API响应:', result);

    if (!response.ok) {
      const errorText = await response.text();
      console.error('[GRSAI-BATCH-IMAGE-STATUS] 查询任务状态失败:', errorText);
      
      return c.json({ error: `查询任务状态失败: ${errorText}` }, 500);
    }

    if (result.code !== 0) {
      console.error('[GRSAI-BATCH-IMAGE-STATUS] Grsai API返回错误:', result.msg);
      return c.json({ error: result.msg || '查询任务状态失败' }, 500);
    }

    // 更新数据库中的任务状态
    const user = c.get('user');
    if (user) {
      try {
        // 检查任务是否存在
        const task = await c.env.DB.prepare(
          'SELECT id FROM text_to_image_tasks WHERE user_id = ? AND task_id = ?'
        ).bind(user.id, taskId).first();
        
        if (task) {
          // 处理结果数据
          let taskStatus = 'RUNNING';
          let imageUrls = [];
          
          if (result.data.results && result.data.results.length > 0) {
            // 任务已完成
            imageUrls = result.data.results.map((item: any) => ({
              url: item.url || '',
              content: item.content || ''
            }));
            taskStatus = 'SUCCESS';
          } else if (result.data.status) {
            // 根据状态更新
            taskStatus = result.data.status.toUpperCase();
          }
          
          // 更新任务状态和图片URL
          const imageUrlsJson = JSON.stringify(imageUrls);
          const { success } = await c.env.DB.prepare(
            'UPDATE text_to_image_tasks SET status = ?, finished_at = ?, image_urls = ? WHERE user_id = ? AND task_id = ?'
          ).bind(
            taskStatus,
            new Date().toISOString(),
            imageUrlsJson,
            user.id,
            taskId
          ).run();
          
          if (!success) {
            logError('[GRSAI-BATCH-IMAGE-STATUS] 更新任务状态到数据库失败');
          }
        }
      } catch (dbError) {
        logError('[GRSAI-BATCH-IMAGE-STATUS] 数据库操作错误', dbError);
      }
    }
    
    // 返回任务状态
    return c.json({
      success: true,
      task_status: result.data.status || 'UNKNOWN',
      progress: result.data.progress || 0,
      results: result.data.results || [],
      message: '任务状态查询成功'
    });
  } catch (error) {
    logError('[GRSAI-BATCH-IMAGE-STATUS] 查询任务状态错误', error);
    return c.json({ error: '查询任务状态失败: ' + (error as Error).message }, 500);
  }
});

export default grsaiBatchImageRoutes;