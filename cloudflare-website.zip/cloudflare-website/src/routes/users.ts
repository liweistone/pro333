import { Hono } from 'hono';
import { authMiddleware, requireAdmin } from '../middleware/auth';
import type { Bindings, Variables } from '../types';

const app = new Hono<{ Bindings: Bindings; Variables: Variables }>();

// 添加获取用户信息的路由
app.get('/api/users/:id', async (c) => {
    const { id } = c.req.param();
    const db = c.env.DB;
    
    try {
        const user = await db.prepare('SELECT username FROM users WHERE id = ?').bind(id).first();
        
        if (!user) {
            return c.json({ error: '用户不存在' }, 404);
        }
        
        return c.json(user);
    } catch (error) {
        console.error('获取用户信息失败:', error);
        return c.json({ error: '服务器内部错误' }, 500);
    }
});

export default app;