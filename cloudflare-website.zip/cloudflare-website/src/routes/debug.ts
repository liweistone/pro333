import { Hono } from 'hono';
import type { Bindings, Variables } from '../types';

const debugRoutes = new Hono<{ Bindings: Bindings; Variables: Variables }>();

// 检查评论表结构
debugRoutes.get('/comments-schema', async (c) => {
  try {
    const { results } = await c.env.DB.prepare(
      "PRAGMA table_info(Comments)"
    ).all();
    
    return c.json(results);
  } catch (error: any) {
    return c.json({ error: error.message }, 500);
  }
});

// 添加reviewed_at列（如果不存在）
debugRoutes.post('/add-reviewed-at', async (c) => {
  try {
    // 尝试添加reviewed_at列
    await c.env.DB.prepare(
      "ALTER TABLE Comments ADD COLUMN reviewed_at DATETIME"
    ).run();
    
    return c.json({ 
      success: true, 
      message: '成功添加reviewed_at列' 
    });
  } catch (error: any) {
    // 如果列已存在，会抛出错误
    if (error.message.includes('duplicate column name')) {
      return c.json({ 
        success: true, 
        message: 'reviewed_at列已存在' 
      });
    }
    
    return c.json({ 
      success: false, 
      error: error.message 
    }, 500);
  }
});

// 执行数据库迁移
debugRoutes.post('/migrate', async (c) => {
  try {
    console.log('开始执行数据库迁移...');
    
    // 检查是否已存在reviewed_at列
    const schema = await c.env.DB.prepare("PRAGMA table_info(Comments)").all();
    const hasReviewedAtColumn = schema.results.some((column: any) => column.name === 'reviewed_at');
    
    if (hasReviewedAtColumn) {
      console.log('reviewed_at列已存在，无需迁移');
      return c.json({ 
        success: true, 
        message: '数据库已是最新的，无需迁移' 
      });
    }
    
    // 添加reviewed_at列
    await c.env.DB.prepare(
      "ALTER TABLE Comments ADD COLUMN reviewed_at DATETIME"
    ).run();
    
    console.log('数据库迁移完成');
    return c.json({ 
      success: true, 
      message: '数据库迁移成功完成' 
    });
  } catch (error: any) {
    console.error('数据库迁移失败:', error);
    return c.json({ 
      success: false, 
      error: error.message 
    }, 500);
  }
});

export default debugRoutes;