import { Hono } from 'hono';
import { authMiddleware, requireRole } from '../middleware/auth';
import type { Bindings, Variables } from '../types';

const guestbookRoutes = new Hono<{ Bindings: Bindings; Variables: Variables }>();

// 获取留言板消息
guestbookRoutes.get('/', async (c) => {
  const { page = '1', limit = '20' } = c.req.query();
  const offset = (parseInt(page) - 1) * parseInt(limit);
  
  const { results } = await c.env.DB.prepare(`
    SELECT g.*, u.username 
    FROM Guestbook g
    JOIN Users u ON g.user_id = u.id
    WHERE g.is_public = 1
    ORDER BY g.created_at DESC
    LIMIT ? OFFSET ?
  `).bind(parseInt(limit), offset).all();
  
  return c.json(results, 200, {
    "Content-Type": "application/json; charset=utf-8"
  });
});

// 添加留言 (需要认证)
guestbookRoutes.post('/', authMiddleware, async (c) => {
  // 显式处理请求体以确保正确的字符编码
  const text = await c.req.text();
  const decodedText = decodeURIComponent(encodeURIComponent(text));
  const data = JSON.parse(decodedText);
  const { message } = data;
  const user = c.get('user');
  
  if (!user) {
    return c.json({ error: '需要登录才能发表留言' }, 401, {
      "Content-Type": "application/json; charset=utf-8"
    });
  }
  
  if (!message) {
    return c.json({ error: '留言内容是必需的' }, 400, {
      "Content-Type": "application/json; charset=utf-8"
    });
  }
  
  // 确保消息内容正确处理
  const processedMessage = message;
  
  const { success } = await c.env.DB.prepare(`
    INSERT INTO Guestbook (user_id, message)
    VALUES (?, ?)
  `).bind(user.id, processedMessage).run();
  
  if (success) {
    return c.json({ message: '留言提交成功' }, 201, {
      "Content-Type": "application/json; charset=utf-8"
    });
  } else {
    return c.json({ error: '提交留言失败' }, 500, {
      "Content-Type": "application/json; charset=utf-8"
    });
  }
});

// 删除留言 (作者或管理员)
guestbookRoutes.delete('/:id', authMiddleware, async (c) => {
  const messageId = c.req.param('id');
  const user = c.get('user');
  
  if (!user) {
    return c.json({ error: '需要登录才能删除留言' }, 401, {
      "Content-Type": "application/json; charset=utf-8"
    });
  }
  
  // 检查留言是否存在以及用户是否有权限
  const message = await c.env.DB.prepare(
    "SELECT user_id FROM Guestbook WHERE id = ?"
  ).bind(messageId).first();
  
  if (!message) {
    return c.json({ error: '留言不存在' }, 404, {
      "Content-Type": "application/json; charset=utf-8"
    });
  }
  
  if (message.user_id !== user.id && user.role !== 'admin' && user.role !== 'superadmin') {
    return c.json({ error: '您没有权限删除此留言' }, 403, {
      "Content-Type": "application/json; charset=utf-8"
    });
  }
  
  const { success } = await c.env.DB.prepare(
    "DELETE FROM Guestbook WHERE id = ?"
  ).bind(messageId).run();
  
  if (success) {
    return c.json({ message: '留言删除成功' }, 200, {
    "Content-Type": "application/json; charset=utf-8"
  });
  } else {
    return c.json({ error: '删除留言失败' }, 500, {
    "Content-Type": "application/json; charset=utf-8"
  });
  }
});

// 管理员获取所有留言（包括未公开的）- 支持分页和筛选
guestbookRoutes.get('/all', authMiddleware, requireRole(['admin', 'superadmin']), async (c) => {
  const { page = '1', limit = '20', is_public, user, search } = c.req.query();
  const offset = (parseInt(page) - 1) * parseInt(limit);
  
  // 构建查询语句
  let query = `
    SELECT g.*, u.username 
    FROM Guestbook g
    JOIN Users u ON g.user_id = u.id
  `;
  
  // 添加筛选条件
  const conditions = [];
  const bindings = [];
  
  if (is_public !== undefined) {
    conditions.push("g.is_public = ?");
    bindings.push(is_public === '1' ? 1 : 0);
  }
  
  if (user) {
    conditions.push("u.username LIKE ?");
    bindings.push(`%${user}%`);
  }
  
  if (search) {
    conditions.push("g.message LIKE ?");
    bindings.push(`%${search}%`);
  }
  
  if (conditions.length > 0) {
    query += " WHERE " + conditions.join(" AND ");
  }
  
  query += " ORDER BY g.created_at DESC LIMIT ? OFFSET ?";
  bindings.push(parseInt(limit), offset);
  
  const { results } = await c.env.DB.prepare(query).bind(...bindings).all();
  
  // 获取总数用于分页
  let countQuery = `
    SELECT COUNT(*) as total
    FROM Guestbook g
    JOIN Users u ON g.user_id = u.id
  `;
  
  if (conditions.length > 0) {
    countQuery += " WHERE " + conditions.join(" AND ");
  }
  
  const countResult = await c.env.DB.prepare(countQuery).bind(...bindings.slice(0, -2)).first();
  const total = countResult.total;
  const totalPages = Math.ceil(total / parseInt(limit));
  
  return c.json({
    messages: results,
    total,
    page: parseInt(page),
    pages: totalPages
  }, 200, {
    "Content-Type": "application/json; charset=utf-8"
  });
});

// 管理员获取单个留言详情
guestbookRoutes.get('/all/:id', authMiddleware, requireRole(['admin', 'superadmin']), async (c) => {
  const messageId = c.req.param('id');
  
  const message = await c.env.DB.prepare(`
    SELECT g.*, u.username 
    FROM Guestbook g
    JOIN Users u ON g.user_id = u.id
    WHERE g.id = ?
  `).bind(messageId).first();
  
  if (!message) {
    return c.json({ error: '留言不存在' }, 404, {
      "Content-Type": "application/json; charset=utf-8"
    });
  }
  
  return c.json(message, 200, {
    "Content-Type": "application/json; charset=utf-8"
  });
});

// 管理员设置留言公开状态
guestbookRoutes.put('/:id/public', authMiddleware, requireRole(['admin', 'superadmin']), async (c) => {
  const messageId = c.req.param('id');
  const user = c.get('user');
  
  console.log('设置留言公开状态 - 留言ID:', messageId);
  console.log('设置留言公开状态 - 当前用户:', user);
  
  const { is_public } = await c.req.json();
  
  console.log('设置留言公开状态 - 请求参数:', { is_public });
  
  const { success } = await c.env.DB.prepare(
    "UPDATE Guestbook SET is_public = ? WHERE id = ?"
  ).bind(is_public ? 1 : 0, messageId).run();
  
  if (success) {
    return c.json({ message: '留言公开状态更新成功' }, 200, {
      "Content-Type": "application/json; charset=utf-8"
    });
  } else {
    return c.json({ error: '更新留言状态失败' }, 500, {
      "Content-Type": "application/json; charset=utf-8"
    });
  }
});

// 管理员批量删除留言
guestbookRoutes.delete('/batch', authMiddleware, requireRole(['admin', 'superadmin']), async (c) => {
  const { ids } = await c.req.json();
  
  if (!ids || !Array.isArray(ids) || ids.length === 0) {
    return c.json({ error: '请提供要删除的留言ID列表' }, 400, {
      "Content-Type": "application/json; charset=utf-8"
    });
  }
  
  // 构建SQL语句
  const placeholders = ids.map(() => '?').join(',');
  const query = `DELETE FROM Guestbook WHERE id IN (${placeholders})`;
  
  const { success } = await c.env.DB.prepare(query).bind(...ids).run();
  
  if (success) {
    return c.json({ message: `成功删除${ids.length}条留言` }, 200, {
      "Content-Type": "application/json; charset=utf-8"
    });
  } else {
    return c.json({ error: '批量删除留言失败' }, 500, {
      "Content-Type": "application/json; charset=utf-8"
    });
  }
});

// 管理员批量设置公开状态
guestbookRoutes.put('/batch/public', authMiddleware, requireRole(['admin', 'superadmin']), async (c) => {
  const { ids, is_public } = await c.req.json();
  
  if (!ids || !Array.isArray(ids) || ids.length === 0) {
    return c.json({ error: '请提供要更新的留言ID列表' }, 400, {
      "Content-Type": "application/json; charset=utf-8"
    });
  }
  
  // 构建SQL语句
  const placeholders = ids.map(() => '?').join(',');
  const query = `UPDATE Guestbook SET is_public = ? WHERE id IN (${placeholders})`;
  
  const bindings = [is_public ? 1 : 0, ...ids];
  const { success } = await c.env.DB.prepare(query).bind(...bindings).run();
  
  if (success) {
    return c.json({ message: `成功更新${ids.length}条留言的公开状态` }, 200, {
      "Content-Type": "application/json; charset=utf-8"
    });
  } else {
    return c.json({ error: '批量更新留言状态失败' }, 500, {
      "Content-Type": "application/json; charset=utf-8"
    });
  }
});

export default guestbookRoutes;