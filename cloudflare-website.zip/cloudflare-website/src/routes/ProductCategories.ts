import { Hono } from 'hono'
import { authMiddleware, requireAdmin } from '../middleware/auth'
import type { Bindings, Variables } from '../types';

const productCategoriesRouter = new Hono<{ Bindings: Bindings; Variables: Variables }>()

// 获取所有分类
productCategoriesRouter.get('/list', async (c) => {
  try {
    const { results } = await c.env.DB.prepare('SELECT * FROM ProductCategories ORDER BY id DESC').all()
    return c.json({ success: true, data: results })
  } catch (error) {
    console.error('Error fetching product categories:', error)
    return c.json({ success: false, message: '获取分类失败' })
  }
})

// 获取所有分类（用于产品页面筛选）
productCategoriesRouter.get('/', async (c) => {
  try {
    const { results } = await c.env.DB.prepare('SELECT * FROM ProductCategories ORDER BY id DESC').all()
    return c.json({ success: true, data: results })
  } catch (error) {
    console.error('Error fetching product categories:', error)
    return c.json({ success: false, message: '获取分类失败' })
  }
})

// 获取单个分类 (用于编辑时显示当前数据)
productCategoriesRouter.get('/:id', async (c) => {
  try {
    const id = c.req.param('id')
    const category = await c.env.DB.prepare('SELECT * FROM ProductCategories WHERE id = ?').bind(id).first()
    
    if (category) {
      return c.json({ success: true, data: category })
    } else {
      return c.json({ success: false, message: '分类不存在' }, 404)
    }
  } catch (error) {
    console.error('Error fetching product category:', error)
    return c.json({ success: false, message: '获取分类失败' })
  }
})

// 添加分类 (需要管理员权限)
productCategoriesRouter.post('/add', authMiddleware, requireAdmin, async (c) => {
  try {
    const body = await c.req.json();
    const { name, description, parent_id } = body;
    
    // 验证输入
    if (!name) {
      return c.json({ success: false, error: '分类名称是必需的' }, 400);
    }
    
    // 检查分类名是否已存在
    const existingCategory = await c.env.DB.prepare(
      'SELECT id FROM ProductCategories WHERE name = ?'
    ).bind(name).first();
    
    if (existingCategory) {
      return c.json({ success: false, error: '分类名称已存在' }, 400);
    }
    
    // 插入分类
    const result = await c.env.DB.prepare(
      'INSERT INTO ProductCategories (name, description, parent_id) VALUES (?, ?, ?)'
    ).bind(name, description || null, parent_id || null).run();
    
    if (result.success) {
      return c.json({ success: true, message: '分类添加成功' });
    } else {
      return c.json({ success: false, error: '分类添加失败' }, 500);
    }
  } catch (error: any) {
    console.error('Error adding product category:', error);
    return c.json({ success: false, error: '添加分类失败: ' + (error.message || '未知错误') }, 500);
  }
});

// 编辑分类 (需要管理员权限)
productCategoriesRouter.put('/edit/:id', authMiddleware, requireAdmin, async (c) => {
  try {
    const id = c.req.param('id');
    const body = await c.req.json();
    const { name, description, parent_id } = body;
    
    // 验证输入
    if (!name) {
      return c.json({ success: false, error: '分类名称是必需的' }, 400);
    }
    
    // 检查分类是否存在
    const existingCategory = await c.env.DB.prepare(
      'SELECT id FROM ProductCategories WHERE id = ?'
    ).bind(id).first();
    
    if (!existingCategory) {
      return c.json({ success: false, error: '分类不存在' }, 404);
    }
    
    // 检查分类名是否已存在（排除当前分类）
    const duplicateCategory = await c.env.DB.prepare(
      'SELECT id FROM ProductCategories WHERE name = ? AND id != ?'
    ).bind(name, id).first();
    
    if (duplicateCategory) {
      return c.json({ success: false, error: '分类名称已存在' }, 400);
    }
    
    // 更新分类
    const result = await c.env.DB.prepare(
      'UPDATE ProductCategories SET name = ?, description = ?, parent_id = ? WHERE id = ?'
    ).bind(name, description || null, parent_id || null, id).run();
    
    if (result.success) {
      return c.json({ success: true, message: '分类编辑成功' });
    } else {
      return c.json({ success: false, error: '分类编辑失败' }, 500);
    }
  } catch (error: any) {
    console.error('Error editing product category:', error);
    return c.json({ success: false, error: '编辑分类失败: ' + (error.message || '未知错误') }, 500);
  }
});

// 删除分类 (需要管理员权限)
productCategoriesRouter.delete('/delete/:id', authMiddleware, requireAdmin, async (c) => {
  try {
    const id = c.req.param('id');
    
    // 检查分类是否存在
    const existingCategory = await c.env.DB.prepare(
      'SELECT id FROM ProductCategories WHERE id = ?'
    ).bind(id).first();
    
    if (!existingCategory) {
      return c.json({ success: false, error: '分类不存在' }, 404);
    }
    
    // 检查是否有产品属于该分类
    const products = await c.env.DB.prepare(
      'SELECT COUNT(*) as count FROM Products WHERE category_id = ?'
    ).bind(id).first();
    
    if (products && products.count > 0) {
      return c.json({ success: false, error: `该分类下有${products.count}个产品，无法删除。请先将这些产品移至其他分类或删除它们。` }, 400);
    }
    
    // 删除分类
    const result = await c.env.DB.prepare('DELETE FROM ProductCategories WHERE id = ?').bind(id).run();
    
    if (result.success) {
      return c.json({ success: true, message: '分类删除成功' });
    } else {
      return c.json({ success: false, error: '分类删除失败' }, 500);
    }
  } catch (error: any) {
    console.error('Error deleting product category:', error);
    return c.json({ success: false, error: '删除分类失败: ' + (error.message || '未知错误') }, 500);
  }
});

export default productCategoriesRouter