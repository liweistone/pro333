import { Hono } from 'hono'
import { authMiddleware, requireAdmin } from '../middleware/auth'
import type { Bindings, Variables } from '../types';

const adminRouter = new Hono<{ Bindings: Bindings; Variables: Variables }>()

// 测试路由
adminRouter.get('/test', async (c) => {
  console.log('=== Admin测试路由被调用 ===');
  console.log('请求路径:', c.req.path);
  console.log('完整URL:', c.req.url);
  return c.json({ message: '测试路由工作正常' });
})

// 公共测试路由
adminRouter.get('/public-test', async (c) => {
  console.log('=== Admin公共测试路由被调用 ===');
  console.log('请求路径:', c.req.path);
  console.log('完整URL:', c.req.url);
  return c.json({ message: '公共测试路由工作正常' });
})

// 获取用户总数
const getUserCount = async (c: any) => {
    const result = await c.env.DB.prepare('SELECT COUNT(*) as count FROM Users').first();
    return result?.count || 0;
};

// 获取待审核评论数量
const getPendingCommentsCount = async (c: any) => {
    const result = await c.env.DB.prepare('SELECT COUNT(*) as count FROM Comments WHERE status = ?').bind('pending').first();
    return result?.count || 0;
};

// 获取文章总数
const getArticleCount = async (c: any) => {
    const result = await c.env.DB.prepare('SELECT COUNT(*) as count FROM Articles').first();
    return result?.count || 0;
};

// 获取产品总数
const getProductCount = async (c: any) => {
    const result = await c.env.DB.prepare('SELECT COUNT(*) as count FROM Products').first();
    return result?.count || 0;
};

// 获取预设总数
const getPresetCount = async (c: any) => {
    const result = await c.env.DB.prepare('SELECT COUNT(*) as count FROM presets').first();
    return result?.count || 0;
};

// 获取最近文章
const getRecentArticles = async (c: any) => {
    const articles: any = await c.env.DB.prepare(`
        SELECT 
            a.id, 
            a.title,
            a.created_at,
            u.username as author_name
        FROM Articles a
        JOIN Users u ON a.author_id = u.id
        ORDER BY a.created_at DESC
        LIMIT 5
    `).all();
    
    return articles.results.map((article: any) => ({
        id: article.id,
        title: article.title,
        author: article.author_name,
        created_at: article.created_at
    }));
};

// 管理员主页 (需要管理员权限)
adminRouter.get('/', authMiddleware, requireAdmin, async (c) => {
  try {
    // 返回管理员页面HTML
    return c.html(`
      <!DOCTYPE html>
      <html lang="zh-CN">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>后台管理系统</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="/admin/admin.css">
      </head>
      <body>
        <div class="container">
          <h1>欢迎使用后台管理系统</h1>
          <p>您已成功登录，可以开始管理网站内容。</p>
          <nav>
            <a href="/admin/articles.html" class="btn btn-primary">文章管理</a>
            <a href="/admin/products" class="btn btn-secondary">产品管理</a>
            <a href="/admin/presets" class="btn btn-secondary">预设管理</a>
            <a href="/admin/ads" class="btn btn-secondary">广告管理</a>
            <a href="/admin/comments" class="btn btn-secondary">评论管理</a>
            <a href="/admin/guestbook" class="btn btn-secondary">留言板管理</a>
            <a href="/admin/media" class="btn btn-secondary">媒体管理</a>
          </nav>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
      </body>
      </html>
    `)
  } catch (error) {
    console.error('Admin access error:', error)
    return c.json({ success: false, message: '访问后台管理系统失败' }, 500)
  }
})

// 文章管理页面 (需要管理员权限)
adminRouter.get('/articles', authMiddleware, requireAdmin, async (c) => {
  try {
    // 返回文章管理页面HTML
    return c.html(`
      <!DOCTYPE html>
      <html lang="zh-CN">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>文章管理</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="/admin/admin.css">
      </head>
      <body>
        <div class="container">
          <h1>文章管理</h1>
          <div id="article-categories">
            <h2>文章分类管理</h2>
            <button onclick="loadCategories()" class="btn btn-secondary">刷新</button>
            <button onclick="showAddCategoryForm()" class="btn btn-primary">+ 添加分类</button>
            <table id="categories-table" class="table table-striped">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>分类名称</th>
                  <th>描述</th>
                  <th>父级分类</th>
                  <th>操作</th>
                </tr>
              </thead>
              <tbody id="categories-body">
                <!-- 分类数据将在这里动态加载 -->
              </tbody>
            </table>
          </div>
          
          <div id="articles-list">
            <h2>文章列表</h2>
            <button onclick="loadArticles()" class="btn btn-secondary">刷新</button>
            <button onclick="showAddArticleForm()" class="btn btn-primary">+ 添加文章</button>
            <select id="category-filter" class="form-select d-inline-block w-auto">
              <option value="">所有分类</option>
              <!-- 分类选项将在这里动态加载 -->
            </select>
            <input type="text" id="search-input" class="form-control d-inline-block w-auto" placeholder="搜索文章...">
            <button onclick="searchArticles()" class="btn btn-primary">搜索</button>
            
            <table id="articles-table" class="table table-striped">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>标题</th>
                  <th>分类</th>
                  <th>作者</th>
                  <th>状态</th>
                  <th>可见性</th>
                  <th>创建时间</th>
                  <th>操作</th>
                </tr>
              </thead>
              <tbody id="articles-body">
                <!-- 文章数据将在这里动态加载 -->
              </tbody>
            </table>
          </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
        <script src="/admin/articles.js"></script>
      </body>
      </html>
    `)
  } catch (error) {
    console.error('Articles admin access error:', error)
    return c.json({ success: false, message: '访问文章管理页面失败' }, 500)
  }
})

// 添加新的API端点来支持各种统计数量的查询
adminRouter.get('/articles/count', authMiddleware, requireAdmin, async (c) => {
    try {
        const user = c.get('user');
        console.log('获取文章总数 - 当前用户:', user);
        const count = await getArticleCount(c);
        console.log('文章总数:', count);
        return c.json({ count });
    } catch (error: any) {
        console.error('获取文章总数失败:', error);
        return c.json({ error: '获取文章总数失败: ' + error.message }, 500);
    }
});

adminRouter.get('/products/count', authMiddleware, requireAdmin, async (c) => {
    try {
        const user = c.get('user');
        console.log('获取产品总数 - 当前用户:', user);
        const count = await getProductCount(c);
        console.log('产品总数:', count);
        return c.json({ count });
    } catch (error: any) {
        console.error('获取产品总数失败:', error);
        return c.json({ error: '获取产品总数失败: ' + error.message }, 500);
    }
});

adminRouter.get('/presets/count', authMiddleware, requireAdmin, async (c) => {
    try {
        const user = c.get('user');
        console.log('获取预设总数 - 当前用户:', user);
        const count = await getPresetCount(c);
        console.log('预设总数:', count);
        return c.json({ count });
    } catch (error: any) {
        console.error('获取预设总数失败:', error);
        return c.json({ error: '获取预设总数失败: ' + error.message }, 500);
    }
});

adminRouter.get('/users/count', authMiddleware, requireAdmin, async (c) => {
    try {
        const user = c.get('user');
        console.log('获取用户总数 - 当前用户:', user);
        const count = await getUserCount(c);
        console.log('用户总数:', count);
        return c.json({ count });
    } catch (error: any) {
        console.error('获取用户总数失败:', error);
        return c.json({ error: '获取用户总数失败: ' + error.message }, 500);
    }
});

adminRouter.get('/comments/pending/count', authMiddleware, requireAdmin, async (c) => {
    try {
        const user = c.get('user');
        console.log('获取待审核评论数量 - 当前用户:', user);
        const count = await getPendingCommentsCount(c);
        console.log('待审核评论数量:', count);
        return c.json({ count });
    } catch (error: any) {
        console.error('获取待审核评论数量失败:', error);
        return c.json({ error: '获取待审核评论数量失败: ' + error.message }, 500);
    }
});

adminRouter.get('/articles/recent', authMiddleware, requireAdmin, async (c) => {
    try {
        const articles = await getRecentArticles(c);
        return c.json({ data: articles });
    } catch (error: any) {
        console.error('获取最近文章失败:', error);
        return c.json({ error: '获取最近文章失败: ' + error.message }, 500);
    }
});

// 用户管理API端点
// 获取用户列表 (需要管理员权限)
adminRouter.get('/users', authMiddleware, requireAdmin, async (c) => {
    const { page = '1', limit = '10' } = c.req.query();
    const offset = (parseInt(page) - 1) * parseInt(limit);
    
    try {
        // 先查询总数
        const countResult = await c.env.DB.prepare(
            'SELECT COUNT(*) as total FROM Users'
        ).first();
        
        const total = countResult.total;
        const totalPages = Math.ceil(total / parseInt(limit));
        
        const { results } = await c.env.DB.prepare(
            'SELECT id, username, email, role, membership_level, created_at, last_login, is_active, bio, profile_image FROM Users ORDER BY created_at DESC LIMIT ? OFFSET ?'
        ).bind(parseInt(limit), offset).all();
        
        // 确保响应头设置正确
        c.header('Content-Type', 'application/json; charset=utf-8');
        return c.json({
            success: true,
            data: results,
            total: total,
            page: parseInt(page),
            pages: totalPages
        });
    } catch (error: any) {
        console.error('获取用户列表失败:', error);
        return c.json({ success: false, error: '获取用户列表失败: ' + error.message }, 500);
    }
});

// 获取单个用户详情 (需要管理员权限)
adminRouter.get('/users/:id', authMiddleware, requireAdmin, async (c) => {
    const userId = c.req.param('id');
    
    try {
        const user = await c.env.DB.prepare(
            'SELECT id, username, email, role, membership_level, created_at, last_login, is_active, bio, profile_image FROM Users WHERE id = ?'
        ).bind(userId).first();
        
        if (!user) {
            return c.json({ success: false, error: '用户不存在' }, 404);
        }
        
        // 确保响应头设置正确
        c.header('Content-Type', 'application/json; charset=utf-8');
        return c.json({ success: true, data: user });
    } catch (error: any) {
        console.error('获取用户详情失败:', error);
        return c.json({ success: false, error: '获取用户详情失败: ' + error.message }, 500);
    }
});

// 创建用户 (需要管理员权限)
adminRouter.post('/users', authMiddleware, requireAdmin, async (c) => {
    console.log('创建用户路由被调用');
    console.log('请求头:', Object.fromEntries(c.req.raw.headers));
    try {
        console.log('尝试解析请求体');
        const { username, email, password, role, membership_level, is_active, bio, profile_image } = await c.req.json();
        console.log('解析后的请求体:', { username, email, password, role, membership_level, is_active, bio, profile_image });
        
        // 简单验证
        if (!username || !email || !password) {
            return c.json({ success: false, error: '用户名、邮箱和密码都是必需的' }, 400);
        }
        
        // 检查用户是否已存在
        const existingUser = await c.env.DB.prepare(
            'SELECT id FROM Users WHERE username = ? OR email = ?'
        ).bind(username, email).first();
        
        if (existingUser) {
            return c.json({ success: false, error: '用户名或邮箱已存在' }, 400);
        }
        
        // 验证角色
        const validRoles = ['user', 'admin', 'superadmin'];
        if (role && !validRoles.includes(role)) {
            return c.json({ success: false, error: '无效的角色' }, 400);
        }
        
        // 对密码进行哈希处理
        const encoder = new TextEncoder();
        const data = encoder.encode(password);
        const hashBuffer = await crypto.subtle.digest('SHA-256', data);
        const hashArray = Array.from(new Uint8Array(hashBuffer));
        const password_hash = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
        
        // 创建新用户
        const { success } = await c.env.DB.prepare(
            'INSERT INTO Users (username, email, password_hash, role, membership_level, is_active, bio, profile_image) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
        ).bind(
            username, 
            email, 
            password_hash, 
            role || 'user',
            membership_level || 'basic',
            is_active !== undefined ? (is_active ? 1 : 0) : 1,
            bio || '',
            profile_image || ''
        ).run();
        
        if (success) {
            return c.json({ success: true, message: '用户创建成功' }, 201);
        } else {
            return c.json({ success: false, error: '创建用户失败' }, 500);
        }
    } catch (error: any) {
        console.error('创建用户失败:', error);
        return c.json({ success: false, error: '创建用户失败: ' + error.message }, 500);
    }
});

// 更新用户信息 (需要管理员权限)
adminRouter.put('/users/:id', authMiddleware, requireAdmin, async (c) => {
    const userId = c.req.param('id');
    
    // 添加调试信息
    console.log('更新用户信息 - 用户ID:', userId);
    console.log('更新用户信息 - 当前用户:', c.get('user'));
    
    try {
        const { username, email, password, role, membership_level, is_active, bio, profile_image } = await c.req.json();
        
        console.log('更新用户信息 - 请求数据:', { username, email, password, role, membership_level, is_active, bio, profile_image });
        
        // 检查用户是否存在
        const existingUser = await c.env.DB.prepare(
            'SELECT id FROM Users WHERE id = ?'
        ).bind(userId).first();
        
        if (!existingUser) {
            console.log('更新用户失败 - 用户不存在:', userId);
            return c.json({ success: false, error: '用户不存在' }, 404);
        }
        
        // 构建更新语句
        const updates = [];
        const values = [];
        
        if (username !== undefined) {
            // 检查用户名是否已存在（排除当前用户）
            const duplicateUser = await c.env.DB.prepare(
                'SELECT id FROM Users WHERE username = ? AND id != ?'
            ).bind(username, userId).first();
            
            if (duplicateUser) {
                console.log('更新用户失败 - 用户名已存在:', username);
                return c.json({ success: false, error: '用户名已存在' }, 400);
            }
            updates.push('username = ?');
            values.push(username);
        }
        
        if (email !== undefined) {
            // 检查邮箱是否已存在（排除当前用户）
            const duplicateUser = await c.env.DB.prepare(
                'SELECT id FROM Users WHERE email = ? AND id != ?'
            ).bind(email, userId).first();
            
            if (duplicateUser) {
                console.log('更新用户失败 - 邮箱已存在:', email);
                return c.json({ success: false, error: '邮箱已存在' }, 400);
            }
            updates.push('email = ?');
            values.push(email);
        }
        
        if (password !== undefined && password !== '') {
            const encoder = new TextEncoder();
            const data = encoder.encode(password);
            const hashBuffer = await crypto.subtle.digest('SHA-256', data);
            const hashArray = Array.from(new Uint8Array(hashBuffer));
            const password_hash = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
            updates.push('password_hash = ?');
            values.push(password_hash);
            console.log('更新用户密码 - 已生成新密码哈希');
        }
        
        if (role !== undefined) {
            // 验证角色
            const validRoles = ['user', 'admin', 'superadmin'];
            if (!validRoles.includes(role)) {
                console.log('更新用户失败 - 无效的角色:', role);
                return c.json({ success: false, error: '无效的角色' }, 400);
            }
            updates.push('role = ?');
            values.push(role);
        }
        
        if (membership_level !== undefined) {
            updates.push('membership_level = ?');
            values.push(membership_level);
        }
        
        if (is_active !== undefined) {
            updates.push('is_active = ?');
            values.push(is_active ? 1 : 0);
        }
        
        if (bio !== undefined) {
            updates.push('bio = ?');
            values.push(bio);
        }
        
        if (profile_image !== undefined) {
            updates.push('profile_image = ?');
            values.push(profile_image);
        }
        
        // 如果没有要更新的字段，返回成功消息
        if (updates.length === 0) {
            console.log('更新用户 - 无更新内容');
            return c.json({ success: true, message: '无更新内容' }, 200);
        }
        
        values.push(userId);
        
        console.log('执行用户更新 - SQL:', `UPDATE Users SET ${updates.join(', ')} WHERE id = ?`, '参数:', values);
        
        const { success } = await c.env.DB.prepare(
            `UPDATE Users SET ${updates.join(', ')} WHERE id = ?`
        ).bind(...values).run();
        
        if (success) {
            console.log('用户信息更新成功 - 用户ID:', userId);
            return c.json({ success: true, message: '用户信息更新成功' }, 200);
        } else {
            console.log('更新用户信息失败 - 用户ID:', userId);
            return c.json({ success: false, error: '更新用户信息失败' }, 500);
        }
    } catch (error: any) {
        console.error('更新用户信息失败:', error);
        return c.json({ success: false, error: '更新用户信息失败: ' + error.message }, 500);
    }
});

// 删除用户 (需要管理员权限)
adminRouter.delete('/users/:id', authMiddleware, requireAdmin, async (c) => {
    console.log('删除用户路由被调用');
    const userId = c.req.param('id');
    
    try {
        // 检查用户是否存在
        const existingUser = await c.env.DB.prepare(
            'SELECT id FROM Users WHERE id = ?'
        ).bind(userId).first();
        
        if (!existingUser) {
            return c.json({ success: false, error: '用户不存在' }, 404);
        }
        
        // 防止用户删除自己
        const currentUser = c.get('user');
        if (currentUser && currentUser.id.toString() === userId) {
            return c.json({ success: false, error: '不能删除当前登录用户' }, 400);
        }
        
        // 删除用户相关数据
        // 删除用户的收藏
        await c.env.DB.prepare(
            'DELETE FROM UserFavorites WHERE user_id = ?'
        ).bind(userId).run();
        
        // 删除用户的评论
        await c.env.DB.prepare(
            'DELETE FROM Comments WHERE user_id = ?'
        ).bind(userId).run();
        
        // 删除用户的留言
        await c.env.DB.prepare(
            'DELETE FROM Guestbook WHERE user_id = ?'
        ).bind(userId).run();
        
        // 删除用户的会话
        await c.env.DB.prepare(
            'DELETE FROM UserSessions WHERE user_id = ?'
        ).bind(userId).run();
        
        // 删除用户的预设收藏
        await c.env.DB.prepare(
            'DELETE FROM user_favorite_presets WHERE user_id = ?'
        ).bind(userId).run();
        
        // 删除用户的文章阅读记录
        await c.env.DB.prepare(
            'DELETE FROM ArticleViews WHERE user_id = ?'
        ).bind(userId).run();
        
        // 删除用户的产品查看记录
        await c.env.DB.prepare(
            'DELETE FROM ProductViews WHERE user_id = ?'
        ).bind(userId).run();
        
        // 最后删除用户
        const { success } = await c.env.DB.prepare(
            'DELETE FROM Users WHERE id = ?'
        ).bind(userId).run();
        
        if (success) {
            return c.json({ success: true, message: '用户删除成功' });
        } else {
            return c.json({ success: false, error: '删除用户失败' }, 500);
        }
    } catch (error: any) {
        console.error('删除用户失败:', error);
        return c.json({ success: false, error: '删除用户失败: ' + error.message }, 500);
    }
});

export default adminRouter