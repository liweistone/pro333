import { Hono } from 'hono';
import { authMiddleware, requireAdmin } from '../middleware/auth';
import type { Bindings, Variables } from '../types';
import { updateImageUsageRecord } from './articles'; // 导入图片引用更新函数

const productRoutes = new Hono<{ Bindings: Bindings; Variables: Variables }>();

// 获取产品分类
productRoutes.get('/categories', async (c) => {
  console.log('Product categories API called');
  try {
    const { results } = await c.env.DB.prepare(
      'SELECT * FROM ProductCategories ORDER BY name'
    ).all();
    
    console.log('Product categories results:', results);
    c.header('Content-Type', 'application/json; charset=utf-8');
    return c.json({ success: true, data: results });
  } catch (error: any) {
    console.error('Error fetching product categories:', error);
    return c.json({ success: false, message: '获取分类失败: ' + (error.message || '未知错误') }, 500);
  }
});

// 获取公开产品列表 (无需认证)
productRoutes.get('/public', async (c) => {
  const { limit = '10' } = c.req.query();
  const limitValue = Math.min(parseInt(limit), 50); // 限制最大50条记录
  
  try {
    const { results } = await c.env.DB.prepare(`
      SELECT * FROM Products 
      WHERE visibility = 'public' AND is_available = 1
      ORDER BY created_at DESC
      LIMIT ?
    `).bind(limitValue).all();
    
    // 处理cover_image字段，确保返回的是完整的URL
    const productsWithImageUrl = results.map((product: any) => ({
      ...product,
      cover_image: product.cover_image ? `/api/images/public/${product.cover_image}` : null
    }));
    
    c.header('Content-Type', 'application/json; charset=utf-8');
    return c.json(productsWithImageUrl);
  } catch (error: any) {
    console.error('Error fetching public products:', error);
    return c.json({ success: false, error: '获取产品失败: ' + (error.message || '未知错误') }, 500);
  }
});

// 获取单个公开产品详情 (无需认证)
productRoutes.get('/public/:id', async (c) => {
  const productId = c.req.param('id');
  
  try {
    const product = await c.env.DB.prepare(`
      SELECT * FROM Products 
      WHERE id = ? AND visibility = 'public' AND is_available = 1
    `).bind(productId).first();
    
    if (!product) {
      return c.json({ error: '产品不存在或您没有访问权限' }, 404);
    }
    
    // 处理cover_image字段，确保返回的是完整的URL
    const productWithImageUrl = {
      ...product,
      cover_image: product.cover_image ? `/api/images/public/${product.cover_image}` : null
    };
    
    // 增加查看计数
    await c.env.DB.prepare(`
      INSERT INTO ProductViews (product_id, user_id) 
      VALUES (?, ?)
    `).bind(productId, null).run();
    
    // 更新产品的view_count
    await c.env.DB.prepare(`
      UPDATE Products SET view_count = view_count + 1 WHERE id = ?
    `).bind(productId).run();
    
    c.header('Content-Type', 'application/json; charset=utf-8');
    return c.json(productWithImageUrl);
  } catch (error: any) {
    console.error('Error fetching public product:', error);
    return c.json({ error: '获取产品详情失败: ' + (error.message || '未知错误') }, 500);
  }
});

// 获取产品列表 (需要管理员权限)
productRoutes.get('/', authMiddleware, requireAdmin, async (c) => {
  const { page = '1', limit = '10', category_id } = c.req.query();
  const offset = (parseInt(page) - 1) * parseInt(limit);
  
  const user = c.get('user');
  let visibilityCondition = "visibility = 'public'";
  let queryParams: any[] = [];
  
  if (user) {
    if (user.role === 'admin' || user.role === 'superadmin') {
      visibilityCondition = "1=1"; // 管理员可以看到所有内容
    } else {
      visibilityCondition = "(visibility = 'public' OR visibility = 'authenticated')";
    }
  }
  
  if (category_id) {
    visibilityCondition += " AND category_id = ?";
    queryParams.push(category_id);
  }
  
  // 先查询总数
  const countQuery = `SELECT COUNT(*) as total FROM Products WHERE ${visibilityCondition}`;
  const countResult = await c.env.DB.prepare(countQuery).bind(...queryParams).first();
  const total = countResult.total;
  
  // 然后查询当前页的数据
  queryParams.push(parseInt(limit), offset);
  
  const { results } = await c.env.DB.prepare(`
    SELECT * FROM Products 
    WHERE ${visibilityCondition}
    ORDER BY created_at DESC
    LIMIT ? OFFSET ?
  `).bind(...queryParams).all();
  
  // 处理cover_image字段，确保返回的是完整的URL
  const productsWithImageUrl = results.map((product: any) => ({
    ...product,
    cover_image: product.cover_image ? `/api/images/public/${product.cover_image}` : null
  }));
  
  // 返回包含分页信息的数据
  const response = {
    data: productsWithImageUrl,
    pagination: {
      currentPage: parseInt(page),
      totalPages: Math.ceil(total / parseInt(limit)),
      totalItems: total,
      itemsPerPage: parseInt(limit)
    }
  };
  
  c.header('Content-Type', 'application/json; charset=utf-8');
  return c.json(response);
});

// 获取产品详情 (需要管理员权限)
productRoutes.get('/:id', authMiddleware, requireAdmin, async (c) => {
  const productId = c.req.param('id');
  const user = c.get('user');
  
  let permissionCondition = "visibility = 'public'";
  
  if (user) {
    if (user.role === 'admin' || user.role === 'superadmin') {
      permissionCondition = "1=1";
    } else {
      permissionCondition = "(visibility = 'public' OR visibility = 'authenticated')";
    }
  }
  
  const product = await c.env.DB.prepare(`
    SELECT * FROM Products 
    WHERE id = ? AND ${permissionCondition}
  `).bind(productId).first();
  
  if (!product) {
    return c.json({ error: '产品不存在或您没有访问权限' }, 404);
  }
  
  // 处理cover_image字段，确保返回的是完整的URL
  const productWithImageUrl = {
    ...product,
    cover_image: product.cover_image ? `/api/images/public/${product.cover_image}` : null
  };
  
  // 增加查看计数
  await c.env.DB.prepare(`
    INSERT INTO ProductViews (product_id, user_id) 
    VALUES (?, ?)
  `).bind(productId, user?.id || null).run();
  
  // 更新产品的view_count
  await c.env.DB.prepare(`
    UPDATE Products SET view_count = view_count + 1 WHERE id = ?
  `).bind(productId).run();
  
  c.header('Content-Type', 'application/json; charset=utf-8');
  return c.json(productWithImageUrl);
});

// 创建产品 (需要管理员权限)
productRoutes.post('/', authMiddleware, requireAdmin, async (c) => {
  try {
    const { name, description, price, category_id, features, visibility = 'public', is_available = true, cover_image } = await c.req.json();
    const user = c.get('user');
    
    if (!name || !description || !price || !category_id) {
      return c.json({ success: false, error: '名称、描述、价格和分类ID都是必需的' }, 400);
    }
    
    // 插入产品
    const insertResult = await c.env.DB.prepare(`
      INSERT INTO Products (name, description, price, category_id, features, visibility, is_available, cover_image)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).bind(
      name, 
      description, 
      price, 
      category_id, 
      JSON.stringify(features || {}), 
      visibility, 
      is_available ? 1 : 0, 
      cover_image || null
    ).run();
    
    if (insertResult.success) {
      // 如果有封面图片，更新图片的引用状态
      if (cover_image) {
        // 获取新插入的产品ID
        const productId = insertResult.meta.last_row_id;
        await updateImageUsageRecord(c, cover_image, 'product', productId.toString(), true);
      }
      
      return c.json({ success: true, message: '产品创建成功' }, 201);
    } else {
      return c.json({ success: false, error: '创建产品失败' }, 500);
    }
  } catch (error: any) {
    console.error('Error creating product:', error);
    return c.json({ success: false, error: '创建产品失败: ' + (error.message || '未知错误') }, 500);
  }
});

// 更新产品 (需要管理员权限)
productRoutes.put('/:id', authMiddleware, requireAdmin, async (c) => {
  try {
    const productId = c.req.param('id');
    const { name, description, price, category_id, features, visibility, is_available, cover_image } = await c.req.json();
    
    // 先获取原始产品信息，以便检查封面图片变化
    const originalProduct = await c.env.DB.prepare(
      'SELECT cover_image FROM Products WHERE id = ?'
    ).bind(productId).first();
    
    // 构建更新语句
    const updates: string[] = [];
    const values: any[] = [];
    
    // 只有在字段存在时才更新
    if (name !== undefined) {
      updates.push('name = ?');
      values.push(name);
    }
    
    if (description !== undefined) {
      updates.push('description = ?');
      values.push(description);
    }
    
    if (price !== undefined) {
      updates.push('price = ?');
      values.push(price);
    }
    
    if (category_id !== undefined) {
      updates.push('category_id = ?');
      values.push(category_id);
    }
    
    if (features !== undefined) {
      updates.push('features = ?');
      values.push(JSON.stringify(features || {}));
    }
    
    if (visibility !== undefined) {
      updates.push('visibility = ?');
      values.push(visibility);
    }
    
    if (is_available !== undefined) {
      updates.push('is_available = ?');
      values.push(is_available ? 1 : 0);
    }
    
    if (cover_image !== undefined) {
      updates.push('cover_image = ?');
      values.push(cover_image || null);
    }
    
    // 如果没有提供任何更新字段，则返回成功（无变化）
    if (updates.length === 0) {
      return c.json({ success: true, message: '无更新内容' });
    }
    
    values.push(productId);
    
    const { success } = await c.env.DB.prepare(`
      UPDATE Products SET ${updates.join(', ')}
      WHERE id = ?
    `).bind(...values).run();
    
    // 如果更新成功，处理图片引用状态
    if (success) {
      // 如果封面图片发生了变化，更新相关图片的引用状态
      if (originalProduct && originalProduct.cover_image !== cover_image) {
        // 取消旧图片的引用状态
        if (originalProduct.cover_image) {
          await updateImageUsageRecord(c, originalProduct.cover_image, 'product', productId, false);
        }
        // 设置新图片的引用状态
        if (cover_image) {
          await updateImageUsageRecord(c, cover_image, 'product', productId, true);
        }
      }
      return c.json({ success: true, message: '产品更新成功' });
    } else {
      return c.json({ success: false, error: '更新产品失败' }, 500);
    }
  } catch (error: any) {
    console.error('Error updating product:', error);
    return c.json({ success: false, error: '更新产品失败: ' + (error.message || '未知错误') }, 500);
  }
});

// 删除产品 (需要管理员权限)
productRoutes.delete('/:id', authMiddleware, requireAdmin, async (c) => {
  try {
    const productId = c.req.param('id');
    
    // 先获取产品信息，用于取消图片引用
    const product = await c.env.DB.prepare(
      'SELECT cover_image FROM Products WHERE id = ?'
    ).bind(productId).first();
    
    // 删除与该产品相关的收藏记录
    await c.env.DB.prepare(
      'DELETE FROM UserFavorites WHERE item_type = ? AND item_id = ?'
    ).bind('product', productId).run();
    
    // 删除与该产品相关的评论
    await c.env.DB.prepare(
      'DELETE FROM Comments WHERE parent_type = ? AND parent_id = ?'
    ).bind('product', productId).run();
    
    // 删除与该产品相关的查看记录
    await c.env.DB.prepare(
      'DELETE FROM ProductViews WHERE product_id = ?'
    ).bind(productId).run();
    
    // 删除产品主记录
    const { success } = await c.env.DB.prepare(
      'DELETE FROM Products WHERE id = ?'
    ).bind(productId).run();
    
    if (success) {
      // 如果产品有封面图片，取消图片引用状态
      if (product && product.cover_image) {
        await updateImageUsageRecord(c, product.cover_image, 'product', productId, false);
      }
      return c.json({ success: true, message: '产品删除成功' });
    } else {
      return c.json({ success: false, error: '删除产品失败' }, 500);
    }
  } catch (error: any) {
    console.error('Error deleting product:', error);
    return c.json({ success: false, error: '删除产品失败: ' + (error.message || '未知错误') }, 500);
  }
});

export default productRoutes;