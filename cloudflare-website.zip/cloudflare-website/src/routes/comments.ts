import { Hono } from 'hono';
import { authMiddleware, requireRole } from '../middleware/auth';
import type { Bindings, Variables } from '../types';

const commentRoutes = new Hono<{ Bindings: Bindings; Variables: Variables }>();

// 获取评论列表的API端点（用于管理后台）
commentRoutes.get('/list', authMiddleware, requireRole(['admin', 'superadmin']), async (c) => {
  try {
    const { page = '1', limit = '20', status, type, search } = c.req.query();
    const offset = (parseInt(page) - 1) * parseInt(limit);
    
    let sql = `
      SELECT c.*, u.username,
             CASE 
               WHEN c.parent_type = 'article' THEN (SELECT title FROM Articles WHERE id = c.parent_id)
               WHEN c.parent_type = 'product' THEN (SELECT name FROM Products WHERE id = c.parent_id)
               WHEN c.parent_type = 'preset' THEN (SELECT title FROM presets WHERE id = c.parent_id)
             END as parent_title
      FROM Comments c
      JOIN Users u ON c.user_id = u.id
    `;
    
    const conditions = [];
    const bindings: any[] = [];
    
    if (status) {
      conditions.push("c.status = ?");
      bindings.push(status);
    }
    
    if (type) {
      conditions.push("c.parent_type = ?");
      bindings.push(type);
    }
    
    if (search) {
      conditions.push("c.content LIKE ?");
      bindings.push(`%${search}%`);
    }
    
    if (conditions.length > 0) {
      sql += " WHERE " + conditions.join(" AND ");
    }
    
    sql += " ORDER BY c.created_at DESC LIMIT ? OFFSET ?";
    bindings.push(parseInt(limit), offset);
    
    const { results } = await c.env.DB.prepare(sql).bind(...bindings).all();
    
    // 获取总数
    let countSql = "SELECT COUNT(*) as total FROM Comments c JOIN Users u ON c.user_id = u.id";
    if (conditions.length > 0) {
      countSql += " WHERE " + conditions.join(" AND ");
    }
    
    const countResult = await c.env.DB.prepare(countSql).bind(...bindings.slice(0, -2)).first();
    const total = countResult.total;
    
    return c.json({
      success: true,
      data: results,
      total: total,
      page: parseInt(page),
      pages: Math.ceil(total / parseInt(limit))
    });
  } catch (error: any) {
    console.error('获取评论列表失败:', error);
    return c.json({
      success: false,
      message: '获取评论列表失败: ' + error.message
    }, 500);
  }
});

// 获取评论
commentRoutes.get('/', async (c) => {
  const { parent_type, parent_id, page = '1', limit = '20' } = c.req.query();
  const offset = (parseInt(page) - 1) * parseInt(limit);
  
  if (!parent_type || !parent_id) {
    return c.json({ error: 'parent_type 和 parent_id 是必需的' }, 400);
  }
  
  const { results } = await c.env.DB.prepare(`
    SELECT c.*, u.username 
    FROM Comments c
    JOIN Users u ON c.user_id = u.id
    WHERE c.parent_type = ? AND c.parent_id = ? AND c.status = 'approved'
    ORDER BY c.created_at DESC
    LIMIT ? OFFSET ?
  `).bind(parent_type, parent_id, parseInt(limit), offset).all();
  
  return c.json(results);
});

// 获取用户评论 (需要认证)
commentRoutes.get('/user', authMiddleware, async (c) => {
  const user = c.get('user');
  const { page = '1', limit = '20' } = c.req.query();
  const offset = (parseInt(page) - 1) * parseInt(limit);
  
  if (!user) {
    return c.json({ error: '需要登录才能查看评论' }, 401);
  }
  
  try {
    console.log(`获取用户 ${user.id} 的评论，页码: ${page}, 每页: ${limit}`);
    
    // 获取用户评论
    const result = await c.env.DB.prepare(`
      SELECT c.*, 
             CASE 
               WHEN c.parent_type = 'article' THEN (SELECT title FROM Articles WHERE id = c.parent_id)
               WHEN c.parent_type = 'product' THEN (SELECT name FROM Products WHERE id = c.parent_id)
               WHEN c.parent_type = 'preset' THEN (SELECT title FROM presets WHERE id = c.parent_id)
             END as parent_title
      FROM Comments c
      WHERE c.user_id = ?
      ORDER BY c.created_at DESC
      LIMIT ? OFFSET ?
    `).bind(user.id, parseInt(limit), offset).all();
    
    console.log(`查询结果:`, result);
    
    // 获取用户评论总数
    const countResult = await c.env.DB.prepare(
      "SELECT COUNT(*) as total FROM Comments WHERE user_id = ?"
    ).bind(user.id).first();
    
    console.log(`评论总数:`, countResult);
    
    return c.json({
      success: true,
      data: result.results || [],
      total: countResult.total,
      page: parseInt(page),
      pages: Math.ceil(countResult.total / parseInt(limit))
    });
  } catch (error: any) {
    console.error('获取用户评论失败:', error);
    return c.json({
      success: false,
      message: '获取用户评论失败: ' + error.message
    }, 500);
  }
});

// 获取评论详情（用于前端显示）
commentRoutes.get('/:id', async (c) => {
  try {
    const commentId = c.req.param('id');
    
    const comment = await c.env.DB.prepare(`
      SELECT c.*, u.username,
             CASE 
               WHEN c.parent_type = 'article' THEN (SELECT title FROM Articles WHERE id = c.parent_id)
               WHEN c.parent_type = 'product' THEN (SELECT name FROM Products WHERE id = c.parent_id)
               WHEN c.parent_type = 'preset' THEN (SELECT title FROM presets WHERE id = c.parent_id)
             END as parent_title
      FROM Comments c
      JOIN Users u ON c.user_id = u.id
      WHERE c.id = ?
    `).bind(commentId).first();
    
    if (!comment) {
      return c.json({ error: '评论不存在' }, 404);
    }
    
    return c.json({
      success: true,
      data: comment
    });
  } catch (error: any) {
    console.error('获取评论详情失败:', error);
    return c.json({
      success: false,
      message: '获取评论详情失败: ' + error.message
    }, 500);
  }
});

// 添加评论 (需要认证)
commentRoutes.post('/', authMiddleware, async (c) => {
  const { content, parent_type, parent_id } = await c.req.json();
  const user = c.get('user');
  
  if (!user) {
    return c.json({ error: '需要登录才能发表评论' }, 401);
  }
  
  if (!content || !parent_type || !parent_id) {
    return c.json({ error: '内容、parent_type 和 parent_id 都是必需的' }, 400);
  }
  
  // 验证父级内容是否存在
  let parentExists = false;
  if (parent_type === 'article') {
    parentExists = await c.env.DB.prepare(
      "SELECT 1 FROM Articles WHERE id = ?"
    ).bind(parent_id).first();
  } else if (parent_type === 'product') {
    parentExists = await c.env.DB.prepare(
      "SELECT 1 FROM Products WHERE id = ?"
    ).bind(parent_id).first();
  } else if (parent_type === 'preset') {
    parentExists = await c.env.DB.prepare(
      "SELECT 1 FROM presets WHERE id = ?"
    ).bind(parent_id).first();
  }
  
  if (!parentExists) {
    return c.json({ error: '父级内容不存在' }, 404);
  }
  
  const { success } = await c.env.DB.prepare(`
    INSERT INTO Comments (content, user_id, parent_type, parent_id)
    VALUES (?, ?, ?, ?)
  `).bind(content, user.id, parent_type, parent_id).run();
  
  if (success) {
    return c.json({ message: '评论提交成功，等待审核' }, 201);
  } else {
    return c.json({ error: '提交评论失败' }, 500);
  }
});

// 更新评论 (作者或管理员)
commentRoutes.put('/:id', authMiddleware, async (c) => {
  const commentId = c.req.param('id');
  const { content } = await c.req.json();
  const user = c.get('user');
  
  if (!user) {
    return c.json({ error: '需要登录才能更新评论' }, 401);
  }
  
  // 检查评论是否存在以及用户是否有权限
  const comment = await c.env.DB.prepare(
    "SELECT user_id FROM Comments WHERE id = ?"
  ).bind(commentId).first();
  
  if (!comment) {
    return c.json({ error: '评论不存在' }, 404);
  }
  
  if (comment.user_id !== user.id && user.role !== 'admin' && user.role !== 'superadmin') {
    return c.json({ error: '您没有权限更新此评论' }, 403);
  }
  
  const { success } = await c.env.DB.prepare(
    "UPDATE Comments SET content = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?"
  ).bind(content, commentId).run();
  
  if (success) {
    return c.json({ message: '评论更新成功' });
  } else {
    return c.json({ error: '更新评论失败' }, 500);
  }
});

// 删除评论 (作者或管理员)
commentRoutes.delete('/:id', authMiddleware, async (c) => {
  const commentId = c.req.param('id');
  const user = c.get('user');
  
  if (!user) {
    return c.json({ error: '需要登录才能删除评论' }, 401);
  }
  
  // 检查评论是否存在以及用户是否有权限
  const comment = await c.env.DB.prepare(
    "SELECT user_id FROM Comments WHERE id = ?"
  ).bind(commentId).first();
  
  if (!comment) {
    return c.json({ error: '评论不存在' }, 404);
  }
  
  if (comment.user_id !== user.id && user.role !== 'admin' && user.role !== 'superadmin') {
    return c.json({ error: '您没有权限删除此评论' }, 403);
  }
  
  const { success } = await c.env.DB.prepare(
    "DELETE FROM Comments WHERE id = ?"
  ).bind(commentId).run();
  
  if (success) {
    return c.json({ message: '评论删除成功' });
  } else {
    return c.json({ error: '删除评论失败' }, 500);
  }
});

// 审核评论 (需要管理员权限)
commentRoutes.put('/:id/status', authMiddleware, requireRole(['admin', 'superadmin']), async (c) => {
  try {
    const commentId = c.req.param('id');
    const { status, reason } = await c.req.json();
    
    console.log(`审核评论 ${commentId}, 状态: ${status}, 理由: ${reason}`);
    console.log('当前用户:', c.get('user'));
    
    if (!['pending', 'approved', 'rejected'].includes(status)) {
      return c.json({ error: '状态值无效' }, 400);
    }
    
    // 先尝试更新包含reviewed_at字段的语句
    try {
      const { success } = await c.env.DB.prepare(
        "UPDATE Comments SET status = ?, review_reason = ?, reviewed_at = CURRENT_TIMESTAMP WHERE id = ?"
      ).bind(status, reason || '', commentId).run();
      
      if (success) {
        return c.json({ 
          success: true,
          message: '评论状态更新成功' 
        });
      } else {
        return c.json({ 
          success: false,
          error: '更新评论状态失败' 
        }, 500);
      }
    } catch (dbError: any) {
      // 如果包含reviewed_at字段的更新失败，则尝试不包含该字段的更新
      console.log('包含reviewed_at字段的更新失败，尝试不包含该字段的更新:', dbError.message);
      
      const { success } = await c.env.DB.prepare(
        "UPDATE Comments SET status = ?, review_reason = ? WHERE id = ?"
      ).bind(status, reason || '', commentId).run();
      
      if (success) {
        return c.json({ 
          success: true,
          message: '评论状态更新成功' 
        });
      } else {
        return c.json({ 
          success: false,
          error: '更新评论状态失败' 
        }, 500);
      }
    }
  } catch (error: any) {
    console.error('审核评论失败:', error);
    return c.json({
      success: false,
      message: '审核评论失败: ' + error.message
    }, 500);
  }
});

export default commentRoutes;