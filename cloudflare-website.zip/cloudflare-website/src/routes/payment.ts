import { Hono } from 'hono';
import { authMiddleware, requireRole } from '../middleware/auth';
import type { Bindings, Variables } from '../types';

interface PaymentConfig {
  apiurl: string;
  pid: string;
  platformPublicKey: string;
  merchantPrivateKey: string;
}

interface PaymentParams {
  type: string;
  notifyUrl: string;
  returnUrl: string;
  outTradeNo: string;
  name: string;
  money: string;
  timestamp?: string;
  sign?: string;
  signType?: string;
  pid?: string;  // 添加pid属性
  [key: string]: any;  // 允许其他动态属性
}

interface PaymentOrder {
  id: number;
  userId: string;
  outTradeNo: string;
  tradeNo?: string;
  productName: string;
  amount: number;
  paymentMethod: string;
  status: 'pending' | 'paid' | 'failed' | 'refunded';
  createdAt: string;
  paidAt?: string;
}

interface PaymentApiResponse {
  code: number;
  msg?: string;
  data?: any;
}

const paymentRoutes = new Hono<{ Bindings: Bindings; Variables: Variables }>();

// 获取支付配置
const getPaymentConfig = (env: Bindings): PaymentConfig => {
  return {
    apiurl: env.EPAY_API_URL || 'http://pay.www.com/',
    pid: env.EPAY_PID || '1000',
    platformPublicKey: env.EPAY_PLATFORM_PUBLIC_KEY || '',
    merchantPrivateKey: env.EPAY_MERCHANT_PRIVATE_KEY || ''
  };
};

// 生成RSA签名的辅助函数（简化版，实际实现需要更复杂的加密逻辑）
const generateSign = (params: Record<string, any>, privateKey: string): string => {
  // 在实际实现中，这里需要使用类似PHP中的RSA签名逻辑
  // 由于Cloudflare Workers环境限制，我们需要使用Web Crypto API或其他替代方案
  const sortedKeys = Object.keys(params).sort();
  let signString = '';
  for (const key of sortedKeys) {
    if (key !== 'sign' && key !== 'sign_type' && params[key] !== undefined && params[key] !== '') {
      signString += `&${key}=${params[key]}`;
    }
  }
  if (signString) {
    signString = signString.substring(1); // 移除开头的 &
  }

  // 注意：这里只是一个占位符实现，实际需要实现完整的RSA签名逻辑
  // 在Cloudflare Workers中实现RSA签名较为复杂，可能需要使用第三方库
  return 'generated-signature-placeholder';
};

// 验证回调签名
const verifySign = (params: Record<string, any>, signature: string, publicKey: string): boolean => {
  // 类似地，这里也需要实现完整的RSA验签逻辑
  // 作为占位符，我们暂时返回true
  return true;
};

// 创建支付订单
paymentRoutes.post('/create', authMiddleware, async (c) => {
  try {
    const user = c.get('user');
    if (!user) {
      return c.json({ error: '需要登录才能创建支付订单' }, 401);
    }

    const { productName, amount, paymentMethod, returnUrl, notifyUrl } = await c.req.json();

    if (!productName || !amount || !paymentMethod) {
      return c.json({ error: '商品名称、金额和支付方式都是必需的' }, 400);
    }

    // 生成商户订单号
    const outTradeNo = `ORD${Date.now()}${Math.random().toString(36).substr(2, 9)}`;

    // 保存订单到数据库
    const insertResult = await c.env.DB.prepare(`
      INSERT INTO payment_orders (
        user_id, 
        out_trade_no, 
        product_name, 
        amount, 
        payment_method, 
        status, 
        created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?)
    `).bind(
      user.id,
      outTradeNo,
      productName,
      parseFloat(amount),
      paymentMethod,
      'pending',
      new Date().toISOString()
    ).run();

    if (!insertResult.success) {
      return c.json({ error: '创建支付订单失败' }, 500);
    }

    // 获取支付配置
    const config = getPaymentConfig(c.env);

    // 构造支付参数 - 使用环境配置的域名或当前请求域名
    const currentDomain = `${c.req.url.split('/')[0]}//${c.req.url.split('/')[2]}`;
    const defaultReturnUrl = c.env.PAYMENT_RETURN_DOMAIN || currentDomain;
    const defaultNotifyUrl = c.env.PAYMENT_NOTIFY_DOMAIN || currentDomain;

    const paymentParams: PaymentParams = {
      type: paymentMethod,
      notifyUrl: notifyUrl || `${defaultNotifyUrl}/api/payment/notify`,
      returnUrl: returnUrl || `${defaultReturnUrl}/api/payment/return`,
      outTradeNo,
      name: productName,
      money: amount.toString(),
      timestamp: Math.floor(Date.now() / 1000).toString()
    };

    // 添加商户ID
    paymentParams.pid = config.pid;

    // 生成签名
    const signature = generateSign(paymentParams, config.merchantPrivateKey);
    paymentParams.sign = signature;
    paymentParams.signType = 'RSA';

    // 构造支付链接
    const payUrl = `${config.apiurl}api/pay/submit?${new URLSearchParams({
      ...paymentParams as any,
      type: paymentParams.type,
      notify_url: paymentParams.notifyUrl,
      return_url: paymentParams.returnUrl,
      out_trade_no: paymentParams.outTradeNo,
      name: paymentParams.name,
      money: paymentParams.money,
      pid: paymentParams.pid!,
      timestamp: paymentParams.timestamp!,
      sign: paymentParams.sign,
      sign_type: paymentParams.signType!
    }).toString()}`;

    return c.json({
      success: true,
      orderId: outTradeNo,
      payUrl,
      message: '支付订单创建成功'
    });
  } catch (error) {
    console.error('创建支付订单失败:', error);
    return c.json({ error: '创建支付订单失败: ' + (error as Error).message }, 500);
  }
});

// 获取支付订单详情
paymentRoutes.get('/order/:orderId', authMiddleware, async (c) => {
  try {
    const orderId = c.req.param('orderId');
    const user = c.get('user');

    if (!user) {
      return c.json({ error: '需要登录才能查看订单详情' }, 401);
    }

    const order = await c.env.DB.prepare(`
      SELECT * FROM payment_orders 
      WHERE out_trade_no = ? AND user_id = ?
    `).bind(orderId, user.id).first();

    if (!order) {
      return c.json({ error: '订单不存在' }, 404);
    }

    return c.json({
      success: true,
      data: order
    });
  } catch (error) {
    console.error('获取订单详情失败:', error);
    return c.json({ error: '获取订单详情失败: ' + (error as Error).message }, 500);
  }
});

// 查询支付订单状态
paymentRoutes.get('/status/:orderId', async (c) => {
  try {
    const orderId = c.req.param('orderId');

    // 首先从本地数据库获取订单状态
    const order = await c.env.DB.prepare(`
      SELECT * FROM payment_orders 
      WHERE out_trade_no = ?
    `).bind(orderId).first();

    if (!order) {
      return c.json({ error: '订单不存在' }, 404);
    }

    // 如果订单已经支付或失败，直接返回本地状态
    if (order.status !== 'pending') {
      return c.json({
        success: true,
        data: {
          out_trade_no: order.out_trade_no,
          trade_no: order.trade_no,
          status: order.status,
          paid_at: order.paid_at
        }
      });
    }

    // 否则，向支付网关查询最新状态
    const config = getPaymentConfig(c.env);

    // 准备查询参数
    const queryParams = {
      pid: config.pid,
      trade_no: orderId,
      timestamp: Math.floor(Date.now() / 1000).toString()
    };

    // 生成签名
    const signature = generateSign(queryParams, config.merchantPrivateKey);
    
    // 向支付网关发送查询请求
    const response = await fetch(`${config.apiurl}api/pay/query`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams({
        ...queryParams,
        sign: signature,
        sign_type: 'RSA'
      })
    });

    const result = await response.json() as PaymentApiResponse;

    if (result.code === 0 && result.data) {
      // 更新本地数据库中的订单状态
      await c.env.DB.prepare(`
        UPDATE payment_orders 
        SET 
          trade_no = ?,
          status = ?,
          paid_at = ?
        WHERE out_trade_no = ?
      `).bind(
        result.data.trade_no,
        result.data.status === 1 ? 'paid' : 'failed',
        result.data.pay_time || new Date().toISOString(),
        orderId
      ).run();

      return c.json({
        success: true,
        data: result.data
      });
    } else {
      return c.json({
        success: false,
        error: result.msg || '查询订单状态失败'
      });
    }
  } catch (error) {
    console.error('查询订单状态失败:', error);
    return c.json({ error: '查询订单状态失败: ' + (error as Error).message }, 500);
  }
});

// 异步通知处理（支付网关回调）
paymentRoutes.post('/notify', async (c) => {
  try {
    // 获取支付网关的回调参数
    const queries = c.req.queries();
    const queryParams: Record<string, string> = {};
    
    if (queries) {
      for (const [key, value] of Object.entries(queries)) {
        if (Array.isArray(value)) {
          queryParams[key] = value[0]; // 取第一个值
        } else {
          queryParams[key] = value as string;
        }
      }
    }

    // 获取支付配置
    const config = getPaymentConfig(c.env);

    // 验证签名
    const signature = queryParams.sign;
    if (!signature) {
      console.error('回调缺少签名');
      return c.text('fail');
    }

    // 移除sign参数用于验签
    const paramsToVerify = { ...queryParams };
    delete paramsToVerify.sign;
    delete paramsToVerify.sign_type;

    const isValid = verifySign(paramsToVerify, signature, config.platformPublicKey);
    if (!isValid) {
      console.error('回调签名验证失败');
      return c.text('fail');
    }

    // 获取回调参数
    const outTradeNo = queryParams.out_trade_no;
    const tradeNo = queryParams.trade_no;
    const tradeStatus = queryParams.trade_status;
    const paymentMethod = queryParams.type;
    const amount = parseFloat(queryParams.money || '0');

    // 更新订单状态
    if (tradeStatus === 'TRADE_SUCCESS') {
      const updateResult = await c.env.DB.prepare(`
        UPDATE payment_orders 
        SET 
          trade_no = ?,
          status = 'paid',
          paid_at = ?
        WHERE out_trade_no = ? AND status = 'pending'
      `).bind(tradeNo, new Date().toISOString(), outTradeNo).run();

      if (updateResult.success) {
        // 支付成功，执行业务逻辑
        console.log(`订单 ${outTradeNo} 支付成功，交易号: ${tradeNo}`);
        
        // 处理支付成功后的业务逻辑
        await handlePaymentSuccess(c, outTradeNo, amount);
        
        return c.text('success');
      }
    } else {
      // 订单支付失败
      await c.env.DB.prepare(`
        UPDATE payment_orders 
        SET 
          status = 'failed'
        WHERE out_trade_no = ?
      `).bind(outTradeNo).run();
      
      console.log(`订单 ${outTradeNo} 支付失败`);
    }

    return c.text('success');
  } catch (error) {
    console.error('处理支付通知失败:', error);
    return c.text('fail');
  }
});

// 页面跳转同步通知处理
paymentRoutes.get('/return', async (c) => {
  try {
    // 获取支付网关的回调参数
    const queries = c.req.queries();
    const queryParams: Record<string, string> = {};
    
    if (queries) {
      for (const [key, value] of Object.entries(queries)) {
        if (Array.isArray(value)) {
          queryParams[key] = value[0]; // 取第一个值
        } else {
          queryParams[key] = value as string;
        }
      }
    }

    // 获取支付配置
    const config = getPaymentConfig(c.env);

    // 验证签名
    const signature = queryParams.sign;
    if (!signature) {
      return c.html(`
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <title>支付结果</title>
        </head>
        <body>
          <h2>支付验证失败</h2>
          <p>签名验证失败，请稍后查看订单状态。</p>
          <a href="/">返回首页</a>
        </body>
        </html>
      `);
    }

    // 移除sign参数用于验签
    const paramsToVerify = { ...queryParams };
    delete paramsToVerify.sign;
    delete paramsToVerify.sign_type;

    const isValid = verifySign(paramsToVerify, signature, config.platformPublicKey);
    if (!isValid) {
      return c.html(`
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <title>支付结果</title>
        </head>
        <body>
          <h2>支付验证失败</h2>
          <p>签名验证失败，请稍后查看订单状态。</p>
          <a href="/">返回首页</a>
        </body>
        </html>
      `);
    }

    // 获取回调参数
    const outTradeNo = queryParams.out_trade_no;
    const tradeNo = queryParams.trade_no;
    const tradeStatus = queryParams.trade_status;

    // 检查本地订单状态
    const order = await c.env.DB.prepare(`
      SELECT * FROM payment_orders 
      WHERE out_trade_no = ?
    `).bind(outTradeNo).first();

    if (!order) {
      return c.html(`
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <title>支付结果</title>
        </head>
        <body>
          <h2>支付结果</h2>
          <p>未找到对应的订单信息。</p>
          <a href="/">返回首页</a>
        </body>
        </html>
      `);
    }

    let statusText = '处理中';
    let statusClass = 'info';
    if (tradeStatus === 'TRADE_SUCCESS') {
      statusText = '支付成功';
      statusClass = 'success';
    } else {
      statusText = '支付失败';
      statusClass = 'danger';
    }

    return c.html(`
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>支付结果</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
      </head>
      <body>
        <div class="container mt-5">
          <div class="row justify-content-center">
            <div class="col-md-6">
              <div class="card">
                <div class="card-header bg-${statusClass} text-white">
                  <h4 class="mb-0">支付结果</h4>
                </div>
                <div class="card-body">
                  <h5 class="card-title text-${statusClass}">${statusText}</h5>
                  <p class="card-text">
                    <strong>商户订单号:</strong> ${outTradeNo}<br>
                    <strong>支付交易号:</strong> ${tradeNo || 'N/A'}<br>
                    <strong>支付状态:</strong> ${tradeStatus}<br>
                  </p>
                  <a href="/user-center.html" class="btn btn-primary">查看账户</a>
                  <a href="/" class="btn btn-secondary">返回首页</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </body>
      </html>
    `);
  } catch (error) {
    console.error('处理支付返回失败:', error);
    return c.html(`
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>支付结果</title>
      </head>
      <body>
        <h2>支付结果</h2>
        <p>处理支付返回时发生错误。</p>
        <a href="/">返回首页</a>
      </body>
      </html>
    `);
  }
});

// 为管理员提供支付订单管理功能
paymentRoutes.get('/admin/orders', authMiddleware, requireRole(['admin', 'superadmin']), async (c) => {
  try {
    const { page = '1', limit = '20', status, userId } = c.req.query();
    const pageNum = parseInt(page);
    const limitNum = parseInt(limit);
    const offset = (pageNum - 1) * limitNum;

    let query = `
      SELECT po.*, u.username 
      FROM payment_orders po
      LEFT JOIN Users u ON po.user_id = u.id
    `;
    const conditions = [];
    const params = [];

    if (status) {
      conditions.push(`po.status = ?`);
      params.push(status);
    }

    if (userId) {
      conditions.push(`po.user_id = ?`);
      params.push(userId);
    }

    if (conditions.length > 0) {
      query += ` WHERE ${conditions.join(' AND ')}`;
    }

    query += ` ORDER BY po.created_at DESC LIMIT ? OFFSET ?`;
    params.push(limitNum, offset);

    const { results } = await c.env.DB.prepare(query).bind(...params).all();

    // 获取总数
    let countQuery = `SELECT COUNT(*) as total FROM payment_orders po`;
    if (conditions.length > 0) {
      countQuery += ` WHERE ${conditions.join(' AND ')}`;
    }
    const countResult = await c.env.DB.prepare(countQuery).bind(...params.slice(0, -2)).first();

    return c.json({
      success: true,
      data: results,
      pagination: {
        currentPage: pageNum,
        totalPages: Math.ceil(countResult.total / limitNum),
        total: countResult.total,
        limit: limitNum
      }
    });
  } catch (error) {
    console.error('获取支付订单失败:', error);
    return c.json({ error: '获取支付订单失败: ' + (error as Error).message }, 500);
  }
});

// 退款功能
paymentRoutes.post('/refund/:orderId', authMiddleware, requireRole(['admin', 'superadmin']), async (c) => {
  try {
    const orderId = c.req.param('orderId');
    const { refundAmount, reason } = await c.req.json();

    // 检查订单是否存在且状态为已支付
    const order = await c.env.DB.prepare(`
      SELECT * FROM payment_orders 
      WHERE out_trade_no = ? AND status = 'paid'
    `).bind(orderId).first();

    if (!order) {
      return c.json({ error: '订单不存在或未支付，无法退款' }, 404);
    }

    // 获取支付配置
    const config = getPaymentConfig(c.env);

    // 准备退款参数
    const refundParams = {
      pid: config.pid,
      trade_no: order.trade_no, // 原支付交易号
      money: refundAmount || order.amount.toString(),
      out_refund_no: `RFND${Date.now()}${Math.random().toString(36).substr(2, 9)}`, // 退款单号
      reason: reason || '用户申请退款',
      timestamp: Math.floor(Date.now() / 1000).toString()
    };

    // 生成签名
    const signature = generateSign(refundParams, config.merchantPrivateKey);

    // 向支付网关发送退款请求
    const response = await fetch(`${config.apiurl}api/pay/refund`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams({
        ...refundParams,
        sign: signature,
        sign_type: 'RSA'
      })
    });

    const result = await response.json() as PaymentApiResponse;

    if (result.code === 0) {
      // 退款请求成功，更新本地订单状态
      await c.env.DB.prepare(`
        UPDATE payment_orders 
        SET 
          status = 'refunded',
          updated_at = ?
        WHERE out_trade_no = ?
      `).bind(new Date().toISOString(), orderId).run();

      return c.json({
        success: true,
        data: result.data,
        message: '退款申请已提交'
      });
    } else {
      return c.json({
        success: false,
        error: result.msg || '退款申请失败'
      });
    }
  } catch (error) {
    console.error('处理退款失败:', error);
    return c.json({ error: '处理退款失败: ' + (error as Error).message }, 500);
  }
});

// 处理支付成功的业务逻辑函数
async function handlePaymentSuccess(c: any, orderId: string, amount: number) {
  try {
    // 获取订单信息
    const order = await c.env.DB.prepare(`
      SELECT po.*, u.id as user_db_id
      FROM payment_orders po
      JOIN Users u ON po.user_id = u.id
      WHERE po.out_trade_no = ?
    `).bind(orderId).first();

    if (!order) {
      console.error('订单不存在:', orderId);
      return;
    }

    // 根据支付金额或产品名称确定用户权益
    let newMembershipLevel = 'basic';
    let membershipDurationMonths = 1; // 默认1个月
    
    // 根据金额确定会员等级
    if (amount >= 299) {
      newMembershipLevel = 'premium'; // 年费高级会员
      membershipDurationMonths = 12;
    } else if (amount >= 99) {
      newMembershipLevel = 'premium'; // 高级会员
      membershipDurationMonths = 3;
    } else if (amount >= 29.9) {
      newMembershipLevel = 'premium'; // 高级会员
      membershipDurationMonths = 1;
    } else if (amount >= 9.9) {
      newMembershipLevel = 'vip'; // VIP会员
      membershipDurationMonths = 1;
    }

    // 计算会员到期时间
    const now = new Date();
    const expirationDate = new Date(now.setMonth(now.getMonth() + membershipDurationMonths));
    
    // 更新用户等级和到期时间
    await c.env.DB.prepare(`
      UPDATE Users 
      SET 
        membership_level = ?,
        membership_expires_at = ?,
        last_payment_at = ?,
        updated_at = ?
      WHERE id = ?
    `).bind(
      newMembershipLevel, 
      expirationDate.toISOString(),
      new Date().toISOString(),
      new Date().toISOString(),
      order.user_db_id
    ).run();

    console.log(`用户 ${order.user_db_id} 等级已更新为 ${newMembershipLevel}，到期时间: ${expirationDate.toISOString()}`);
    
    // 可以在这里添加其他业务逻辑，如：
    // - 发送支付成功通知
    // - 增加用户积分
    // - 解锁特定功能
    // - 记录支付日志等
    
  } catch (error) {
    console.error('处理支付成功业务逻辑失败:', error);
  }
}

export default paymentRoutes;