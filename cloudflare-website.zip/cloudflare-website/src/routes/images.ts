import { Hono } from 'hono';
import { authMiddleware, requireAdmin } from '../middleware/auth';
import { shouldAddWatermark, addWatermark } from '../utils/image-processing';
import type { Bindings, Variables } from '../types';

const imageRoutes = new Hono<{ Bindings: Bindings; Variables: Variables }>();

// 上传图像 (需要管理员权限)
imageRoutes.post('/upload', authMiddleware, requireAdmin, async (c) => {
    const user = c.get('user');

    if (!user) {
        console.log('Upload failed: User not authenticated');
        return c.json({ error: '需要登录才能上传图像' }, 401);
    }

    console.log('User authenticated for upload:', {
        id: user.id,
        username: user.username,
        role: user.role
    });

    console.log('Parsing form data...');
    try {
        const formData = await c.req.parseBody();
        console.log('Form data keys:', Object.keys(formData));
        
        const file = formData.file as File;
        const altText = formData.alt_text as string || '';
        const description = formData.description as string || '';

        if (!file) {
            console.log('Upload failed: No file provided');
            return c.json({ error: '没有提供文件' }, 400);
        }

        console.log('File info:', {
            name: file.name,
            size: file.size,
            type: file.type
        });

        // 检查文件大小（限制为10MB）
        if (file.size > 10 * 1024 * 1024) {
            console.log('Upload failed: File too large', {
                size: file.size,
                maxSize: 10 * 1024 * 1024
            });
            return c.json({ 
                error: `文件大小不能超过10MB，当前文件大小: ${Math.round(file.size / 1024 / 1024 * 100) / 100}MB` 
            }, 400);
        }

        // 检查文件类型
        const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        if (!allowedTypes.includes(file.type)) {
            // 检查文件扩展名作为备用验证
            const fileExtension = file.name.split('.').pop()?.toLowerCase();
            const allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
            
            if (!fileExtension || !allowedExtensions.includes(fileExtension)) {
                console.log('Upload failed: Invalid file type', {
                    mimeType: file.type,
                    extension: fileExtension
                });
                return c.json({ 
                    error: `只允许上传JPEG、PNG、GIF或WebP格式的图片，当前文件类型: ${file.type}，文件扩展名: ${fileExtension || '无'}` 
                }, 400);
            }
        }

        console.log('Generating object key...');
        const fileExtension = file.name.split('.').pop();
        const objectKey = `${Date.now()}-${Math.random().toString(36).substring(2, 15)}.${fileExtension}`;
        console.log('Generated object key:', objectKey);

        console.log('Uploading to R2...');
        await c.env.MY_BUCKET.put(objectKey, file.stream(), {
            httpMetadata: {
                contentType: file.type,
            },
        });
        console.log('Successfully uploaded to R2');

        console.log('Saving metadata to database...');
        const { success, meta } = await c.env.DB.prepare(`
            INSERT INTO R2Images (object_key, original_name, mime_type, size, uploader_id, alt_text, description)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        `).bind(objectKey, file.name, file.type, file.size, user.id, altText, description).run();

        if (!success) {
            console.log('Database save failed, deleting from R2...');
            await c.env.MY_BUCKET.delete(objectKey);
            return c.json({ error: '保存图像信息失败' }, 500);
        }

        console.log('Successfully saved metadata to database', {
            lastRowId: meta.last_row_id
        });

        console.log('Generating accessible URL...');
        const imageUrl = `/api/images/public/${objectKey}`;

        // 确保返回完整的数据结构
        const imageData = {
            object_key: objectKey,
            url: imageUrl,
            thumbnail_url: imageUrl  // 对于简单实现，我们使用相同的URL作为缩略图
        };
        
        return c.json({
            success: true,
            data: imageData,
            message: '上传成功'
        });
    } catch (error) {
        console.error('Upload failed with exception:', error);
        return c.json({ error: '上传失败: ' + (error as Error).message }, 500);
    }
});

// 获取图像列表 (需要管理员权限)
imageRoutes.get('/', authMiddleware, requireAdmin, async (c) => {
    console.log('Fetching image list...');
    const { page = '1', limit = '10', search = '', sort = 'uploaded_at DESC' } = c.req.query();
    const offset = (parseInt(page) - 1) * parseInt(limit);

    // 构建查询条件
    let whereClause = '';
    const bindings: any[] = [];
    
    if (search) {
        whereClause = 'WHERE original_name LIKE ?';
        bindings.push(`%${search}%`);
    }

    // 构建排序子句
    const allowedSortColumns = ['uploaded_at', 'size'];
    const allowedSortDirections = ['ASC', 'DESC'];
    const [sortColumn, sortDirection] = sort.split(' ');
    
    let orderClause = 'ORDER BY uploaded_at DESC';
    if (allowedSortColumns.includes(sortColumn) && allowedSortDirections.includes(sortDirection)) {
        orderClause = `ORDER BY ${sortColumn} ${sortDirection}`;
    }

    // 获取总数
    const countQuery = `SELECT COUNT(*) as count FROM R2Images ${whereClause}`;
    const countResult = await c.env.DB.prepare(countQuery).bind(...bindings).first();
    const total = countResult.count;

    // 获取数据
    const dataQuery = `
        SELECT *, 
               CASE WHEN is_referenced THEN '已引用' ELSE '未引用' END AS reference_status,
               (SELECT COUNT(*) FROM ImageUsage WHERE image_id = R2Images.id) AS usage_count
        FROM R2Images 
        ${whereClause}
        ${orderClause}
        LIMIT ? OFFSET ?
    `;
    
    const { results } = await c.env.DB.prepare(dataQuery)
        .bind(...bindings, parseInt(limit), offset)
        .all();

    return c.json({ 
        success: true, 
        data: results,
        total,
        page: parseInt(page),
        limit: parseInt(limit)
    });
});

// 获取单个图像详情 (需要管理员权限)
imageRoutes.get('/:id', authMiddleware, requireAdmin, async (c) => {
    const imageId = c.req.param('id');
    
    const image = await c.env.DB.prepare(`
        SELECT r.*, u.username as uploader_name, CASE WHEN r.is_referenced THEN '已引用' ELSE '未引用' END AS reference_status 
        FROM R2Images r 
        LEFT JOIN Users u ON r.uploader_id = u.id
        WHERE r.id = ?
    `).bind(imageId).first();

    if (!image) {
        return c.json({ error: '图像不存在' }, 404);
    }

    // 获取引用详情
    const usageRecords = await c.env.DB.prepare(`
        SELECT * FROM ImageUsage 
        WHERE image_id = ?
    `).bind(imageId).all();

    // 处理引用详情，获取引用位置信息
    const references = [];
    for (const record of usageRecords.results || []) {
        let referenceInfo = null;
        if (record.used_in_type === 'article') {
            referenceInfo = await c.env.DB.prepare(`
                SELECT id, title as name FROM Articles WHERE id = ?
            `).bind(record.used_in_id).first();
        } else if (record.used_in_type === 'product') {
            referenceInfo = await c.env.DB.prepare(`
                SELECT id, name FROM Products WHERE id = ?
            `).bind(record.used_in_id).first();
        } else if (record.used_in_type === 'preset') {
            referenceInfo = await c.env.DB.prepare(`
                SELECT id, title as name FROM presets WHERE id = ?
            `).bind(record.used_in_id).first();
        }
        
        // 生成正确的详情页面路径
        let path = '';
        switch (record.used_in_type) {
            case 'article':
                path = `/article.html?id=${record.used_in_id}`;
                break;
            case 'product':
                path = `/product.html?id=${record.used_in_id}`;
                break;
            case 'preset':
                path = `/preset.html?id=${record.used_in_id}`;
                break;
            default:
                path = `/${record.used_in_type}s/${record.used_in_id}`;
        }
        
        // 即使referenceInfo为null，也添加引用记录以确保前端能正确显示
        references.push({
            type: record.used_in_type,
            name: referenceInfo ? referenceInfo.name : '未知引用',
            path: path
        });
    }

    // 更新图片的usage_count和is_referenced字段
    const usageCount = references.length;
    const isReferenced = usageCount > 0;
    
    const updateResult = await c.env.DB.prepare(`
        UPDATE R2Images 
        SET usage_count = ?, is_referenced = ?
        WHERE id = ?
    `).bind(usageCount, isReferenced ? 1 : 0, imageId).run();
    
    // 检查更新是否成功
    if (!updateResult.success) {
        console.error('更新图片引用计数失败:', updateResult);
    }

    // 重新获取图片信息以确保字段已更新
    const updatedImage = await c.env.DB.prepare(`
        SELECT r.*, u.username as uploader_name, CASE WHEN r.is_referenced THEN '已引用' ELSE '未引用' END AS reference_status 
        FROM R2Images r 
        LEFT JOIN Users u ON r.uploader_id = u.id
        WHERE r.id = ?
    `).bind(imageId).first();

    const imageData = {
        ...updatedImage,
        references: references,
        usage_count: usageCount
    };
    
    // 添加调试日志
    console.log('图片详情返回数据:', JSON.stringify(imageData, null, 2));
    console.log('usageCount值:', usageCount);
    console.log('references数组长度:', references.length);

    return c.json({ 
        success: true, 
        data: imageData 
    });
});

// 更新图像信息 (需要管理员权限)
imageRoutes.put('/:id', authMiddleware, requireAdmin, async (c) => {
    const imageId = c.req.param('id');
    const { alt_text, description } = await c.req.json();

    // 检查图像是否存在
    const existingImage = await c.env.DB.prepare(
        "SELECT id FROM R2Images WHERE id = ?"
    ).bind(imageId).first();

    if (!existingImage) {
        return c.json({ error: '图像不存在' }, 404);
    }

    try {
        // 更新图像信息
        const { success } = await c.env.DB.prepare(`
            UPDATE R2Images 
            SET alt_text = ?, description = ?
            WHERE id = ?
        `).bind(alt_text || '', description || '', imageId).run();

        if (success) {
            return c.json({ 
                success: true,
                message: '图像信息更新成功' 
            });
        } else {
            return c.json({ error: '更新图像信息失败' }, 500);
        }
    } catch (error) {
        return c.json({ error: '更新图像信息失败: ' + (error as Error).message }, 500);
    }
});

// 删除图像 (需要管理员权限)
imageRoutes.delete('/:id', authMiddleware, requireAdmin, async (c) => {
    const imageId = c.req.param('id');

    // 获取图像信息
    const image = await c.env.DB.prepare(
        "SELECT object_key FROM R2Images WHERE id = ?"
    ).bind(imageId).first();

    if (!image) {
        return c.json({ error: '图像不存在' }, 404);
    }

    try {
        // 从 R2 删除对象
        await c.env.MY_BUCKET.delete(image.object_key);

        // 从数据库删除记录
        const { success } = await c.env.DB.prepare(
            "DELETE FROM R2Images WHERE id = ?"
        ).bind(imageId).run();

        if (success) {
            return c.json({ 
                success: true,
                message: '图像删除成功' 
            });
        } else {
            return c.json({ error: '删除图像记录失败' }, 500);
        }
    } catch (error) {
        return c.json({ error: '删除图像失败: ' + (error as Error).message }, 500);
    }
});

// 提供公共图像访问（优化版本，支持阿里云试衣API访问）
imageRoutes.get('/public/:key', async (c) => {
    console.log('Fetching public image...');
    const key = c.req.param('key');
    // 获取用户信息（如果已认证）
    const user = c.get('user');

    try {
        const object = await c.env.MY_BUCKET.get(key);

        if (object === null) {
            return c.json({ error: '图像不存在' }, 404);
        }

        // 检查用户等级，决定是否需要添加水印
        const shouldAddWatermarkFlag = await shouldAddWatermark(user, c.env.DB);

        // 如果需要添加水印，则处理图片
        if (shouldAddWatermarkFlag) {
            // 使用Cloudflare Images API添加水印
            try {
                const imageStream = object.body;
                // 实际添加水印
                const watermarkText = '© AI试衣平台';
                const watermarkedResponse = await addWatermark(
                    imageStream, 
                    watermarkText, 
                    { 
                        position: 'bottom-right',
                        fontSize: 20,
                        fontColor: 'rgba(255, 255, 255, 0.7)',
                        opacity: 0.7
                    },
                    c.env
                );
                
                // 设置响应头
                const headers = new Headers();
                object.writeHttpMetadata(headers);
                headers.set('etag', object.httpEtag);
                
                // 为阿里云试衣API访问添加适当的CORS头
                headers.set('Access-Control-Allow-Origin', '*');
                headers.set('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS');
                headers.set('Access-Control-Allow-Headers', 'Accept, Content-Type, Origin, Referer');
                
                // 设置缓存控制，提高访问速度
                headers.set('Cache-Control', 'public, max-age=3600'); // 1小时缓存
                
                // 设置内容安全策略，允许阿里云服务访问
                headers.set('Content-Security-Policy', 'default-src * data: blob:; img-src * data: blob: http: https:;');
                
                // 移除可能阻止外部访问的头部
                headers.delete('X-Content-Type-Options');
                
                // 复制水印响应的头部
                for (const [key, value] of watermarkedResponse.headers.entries()) {
                    headers.set(key, value);
                }
                
                return new Response(watermarkedResponse.body, {
                    headers,
                });
            } catch (watermarkError) {
                console.error('添加水印失败:', watermarkError);
                // 如果水印添加失败，返回原始图像
                console.log('Returning image data without watermark due to error...');
                const headers = new Headers();
                object.writeHttpMetadata(headers);
                headers.set('etag', object.httpEtag);
                
                // 为阿里云试衣API访问添加适当的CORS头
                headers.set('Access-Control-Allow-Origin', '*');
                headers.set('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS');
                headers.set('Access-Control-Allow-Headers', 'Accept, Content-Type, Origin, Referer');
                
                // 设置缓存控制，提高访问速度
                headers.set('Cache-Control', 'public, max-age=3600'); // 1小时缓存
                
                // 设置内容安全策略，允许阿里云服务访问
                headers.set('Content-Security-Policy', 'default-src * data: blob:; img-src * data: blob: http: https:;');
                
                // 移除可能阻止外部访问的头部
                headers.delete('X-Content-Type-Options');
                
                return new Response(object.body, {
                    headers,
                });
            }
        } else {
            // 不添加水印，直接返回原图
            console.log('Returning image data without watermark...');
            const headers = new Headers();
            object.writeHttpMetadata(headers);
            headers.set('etag', object.httpEtag);
            
            // 为阿里云试衣API访问添加适当的CORS头
            headers.set('Access-Control-Allow-Origin', '*');
            headers.set('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS');
            headers.set('Access-Control-Allow-Headers', 'Accept, Content-Type, Origin, Referer');
            
            // 设置缓存控制，提高访问速度
            headers.set('Cache-Control', 'public, max-age=3600'); // 1小时缓存
            
            // 设置内容安全策略，允许阿里云服务访问
            headers.set('Content-Security-Policy', 'default-src * data: blob:; img-src * data: blob: http: https:;');
            
            // 移除可能阻止外部访问的头部
            headers.delete('X-Content-Type-Options');
            
            return new Response(object.body, {
                headers,
            });
        }
    } catch (error) {
        console.error('Fetch image failed:', error);
        return c.json({ error: '获取图像失败' }, 500);
    }
});

export default imageRoutes;