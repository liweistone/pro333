import { Hono } from 'hono'
import { authMiddleware, requireAdmin } from '../middleware/auth'
import type { Bindings, Variables } from '../types';

const articleCategoriesRouter = new Hono<{ Bindings: Bindings; Variables: Variables }>()

// 获取所有分类
articleCategoriesRouter.get('/list', async (c) => {
  try {
    const { results } = await c.env.DB.prepare('SELECT * FROM ArticleCategories ORDER BY id DESC').all()
    return c.json({ success: true, data: results })
  } catch (error) {
    console.error('Error fetching article categories:', error)
    return c.json({ success: false, message: '获取分类失败' })
  }
})

// 获取所有分类（用于文章页面筛选）
articleCategoriesRouter.get('/', async (c) => {
  try {
    const { results } = await c.env.DB.prepare('SELECT * FROM ArticleCategories ORDER BY id DESC').all()
    return c.json(results)
  } catch (error) {
    console.error('Error fetching article categories:', error)
    return c.json({ success: false, message: '获取分类失败' })
  }
})

// 获取单个分类 (用于编辑时显示当前数据)
articleCategoriesRouter.get('/:id', async (c) => {
  try {
    const id = c.req.param('id')
    const category = await c.env.DB.prepare('SELECT * FROM ArticleCategories WHERE id = ?').bind(id).first()
    
    if (category) {
      return c.json({ success: true, data: category })
    } else {
      return c.json({ success: false, message: '分类不存在' }, 404)
    }
  } catch (error) {
    console.error('Error fetching article category:', error)
    return c.json({ success: false, message: '获取分类失败' })
  }
})

// 添加分类 (需要管理员权限)
articleCategoriesRouter.post('/add', authMiddleware, requireAdmin, async (c) => {
  try {
    const body = await c.req.json()
    const { name, description, parent_id } = body
    
    // 检查分类名是否已存在
    const existingCategory = await c.env.DB.prepare(
      'SELECT id FROM ArticleCategories WHERE name = ?'
    ).bind(name).first()
    
    if (existingCategory) {
      return c.json({ success: false, message: '分类名称已存在' }, 400)
    }
    
    // 先尝试使用时间戳字段的查询
    let result;
    try {
      result = await c.env.DB.prepare(
        'INSERT INTO ArticleCategories (name, description, parent_id, created_at, updated_at) VALUES (?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)'
      ).bind(name, description, parent_id).run()
    } catch (e) {
      // 如果时间戳字段不存在，则使用不带时间戳字段的查询
      result = await c.env.DB.prepare(
        'INSERT INTO ArticleCategories (name, description, parent_id) VALUES (?, ?, ?)'
      ).bind(name, description, parent_id).run()
    }
    
    const { success } = result;
    
    if (success) {
      return c.json({ success: true, message: '分类添加成功' })
    } else {
      return c.json({ success: false, message: '分类添加失败' }, 500)
    }
  } catch (error: any) {
    console.error('Error adding article category:', error)
    return c.json({ success: false, message: '添加分类失败: ' + (error.message || '未知错误') })
  }
})

// 编辑分类 (需要管理员权限)
articleCategoriesRouter.put('/edit/:id', authMiddleware, requireAdmin, async (c) => {
  try {
    const id = c.req.param('id')
    const body = await c.req.json()
    const { name, description, parent_id } = body
    
    // 检查分类是否存在
    const existingCategory = await c.env.DB.prepare(
      'SELECT id FROM ArticleCategories WHERE id = ?'
    ).bind(id).first()
    
    if (!existingCategory) {
      return c.json({ success: false, message: '分类不存在' }, 404)
    }
    
    // 检查分类名是否已存在（排除当前分类）
    const duplicateCategory = await c.env.DB.prepare(
      'SELECT id FROM ArticleCategories WHERE name = ? AND id != ?'
    ).bind(name, id).first()
    
    if (duplicateCategory) {
      return c.json({ success: false, message: '分类名称已存在' }, 400)
    }
    
    // 先尝试使用时间戳字段的查询
    let result;
    try {
      result = await c.env.DB.prepare(
        'UPDATE ArticleCategories SET name = ?, description = ?, parent_id = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?'
      ).bind(name, description, parent_id, id).run()
    } catch (e) {
      // 如果时间戳字段不存在，则使用不带时间戳字段的查询
      result = await c.env.DB.prepare(
        'UPDATE ArticleCategories SET name = ?, description = ?, parent_id = ? WHERE id = ?'
      ).bind(name, description, parent_id, id).run()
    }
    
    const { success } = result;
    
    if (success) {
      return c.json({ success: true, message: '分类编辑成功' })
    } else {
      return c.json({ success: false, message: '分类编辑失败' }, 500)
    }
  } catch (error: any) {
    console.error('Error editing article category:', error)
    return c.json({ success: false, message: '编辑分类失败: ' + (error.message || '未知错误') })
  }
})

// 删除分类 (需要管理员权限)
articleCategoriesRouter.delete('/delete/:id', authMiddleware, requireAdmin, async (c) => {
  try {
    const id = c.req.param('id')
    
    // 检查分类是否存在
    const existingCategory = await c.env.DB.prepare(
      'SELECT id FROM ArticleCategories WHERE id = ?'
    ).bind(id).first()
    
    if (!existingCategory) {
      return c.json({ success: false, message: '分类不存在' }, 404)
    }
    
    // 检查是否有文章属于该分类
    const articles = await c.env.DB.prepare(
      'SELECT COUNT(*) as count FROM Articles WHERE category_id = ?'
    ).bind(id).first()
    
    if (articles.count > 0) {
      return c.json({ success: false, message: '该分类下有文章，无法删除' }, 400)
    }
    
    const { success } = await c.env.DB.prepare('DELETE FROM ArticleCategories WHERE id = ?').bind(id).run()
    
    if (success) {
      return c.json({ success: true, message: '分类删除成功' })
    } else {
      return c.json({ success: false, message: '分类删除失败' }, 500)
    }
  } catch (error) {
    console.error('Error deleting article category:', error)
    return c.json({ success: false, message: '删除分类失败' })
  }
})

export default articleCategoriesRouter