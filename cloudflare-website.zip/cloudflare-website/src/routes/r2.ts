import { Hono } from 'hono'
import { authMiddleware, requireAdmin } from '../middleware/auth'
import type { Bindings, Variables } from '../types';

const r2Router = new Hono<{ Bindings: Bindings; Variables: Variables }>()

// 列出文件
r2Router.get('/list', authMiddleware, requireAdmin, async (c) => {
    try {
        const prefix = c.req.query('prefix') || '';
        const delimiter = '/';
        
        // 使用R2的list方法获取文件列表
        const listing = await c.env.MY_BUCKET.list({
            prefix: prefix,
            delimiter: delimiter
        });
        
        // 处理文件和文件夹
        const files = [];
        
        // 处理对象（文件）
        for (const object of listing.objects) {
            // 跳过当前目录对象（如果存在）
            if (object.key === prefix) {
                continue;
            }
            
            // 获取文件名（去掉路径前缀）
            const name = object.key.substring(prefix.length);
            
            // 只处理直接子级（不包含更多斜杠，或者只有一个斜杠且在末尾）
            if (name.includes('/') && !name.endsWith('/')) {
                continue;
            }
            
            files.push({
                key: object.key,
                name: name.endsWith('/') ? name.slice(0, -1) : name,
                size: object.size,
                uploadedAt: object.uploaded.toISOString(),
                contentType: object.httpMetadata?.contentType || 'application/octet-stream',
                isFolder: name.endsWith('/')
            });
        }
        
        // 处理公共前缀（文件夹）
        for (const prefixItem of listing.delimitedPrefixes) {
            // 跳过当前目录
            if (prefixItem === prefix) {
                continue;
            }
            
            // 获取文件夹名
            const name = prefixItem.substring(prefix.length);
            
            files.push({
                key: prefixItem,
                name: name.endsWith('/') ? name.slice(0, -1) : name,
                size: 0,
                uploadedAt: new Date().toISOString(),
                contentType: 'folder',
                isFolder: true
            });
        }
        
        // 按名称排序，文件夹优先
        files.sort((a, b) => {
            if (a.isFolder && !b.isFolder) return -1;
            if (!a.isFolder && b.isFolder) return 1;
            return a.name.localeCompare(b.name);
        });
        
        return c.json({
            success: true,
            files: files
        });
    } catch (error: any) {
        console.error('获取文件列表失败:', error);
        return c.json({ 
            success: false, 
            error: '获取文件列表失败: ' + error.message 
        }, 500);
    }
});

// 上传文件
r2Router.post('/upload', authMiddleware, requireAdmin, async (c) => {
    try {
        const formData = await c.req.formData();
        const file = formData.get('file') as File;
        const path = formData.get('path') as string || '';
        
        if (!file) {
            return c.json({ 
                success: false, 
                error: '没有上传文件' 
            }, 400);
        }
        
        // 生成对象键
        const objectKey = path + file.name;
        
        // 上传到R2
        await c.env.MY_BUCKET.put(objectKey, file.stream(), {
            httpMetadata: {
                contentType: file.type,
            },
        });
        
        return c.json({
            success: true,
            message: '文件上传成功',
            key: objectKey
        });
    } catch (error: any) {
        console.error('上传文件失败:', error);
        return c.json({ 
            success: false, 
            error: '上传文件失败: ' + error.message 
        }, 500);
    }
});

// 创建文件夹
r2Router.post('/create-folder', authMiddleware, requireAdmin, async (c) => {
    try {
        const { path } = await c.req.json();
        
        if (!path) {
            return c.json({ 
                success: false, 
                error: '路径不能为空' 
            }, 400);
        }
        
        // 确保路径以斜杠结尾
        const folderPath = path.endsWith('/') ? path : path + '/';
        
        // 创建一个空对象来表示文件夹
        await c.env.MY_BUCKET.put(folderPath, new Uint8Array(), {
            httpMetadata: {
                contentType: 'application/directory',
            },
        });
        
        return c.json({
            success: true,
            message: '文件夹创建成功',
            key: folderPath
        });
    } catch (error: any) {
        console.error('创建文件夹失败:', error);
        return c.json({ 
            success: false, 
            error: '创建文件夹失败: ' + error.message 
        }, 500);
    }
});

// 下载文件
r2Router.get('/download/*', authMiddleware, requireAdmin, async (c) => {
    try {
        // 获取文件路径
        const key = c.req.path.replace('/api/r2/download/', '');
        
        if (!key) {
            return c.json({ 
                success: false, 
                error: '文件路径不能为空' 
            }, 400);
        }
        
        // 从R2获取对象
        const object = await c.env.MY_BUCKET.get(decodeURIComponent(key));
        
        if (!object) {
            return c.json({ 
                success: false, 
                error: '文件不存在' 
            }, 404);
        }
        
        // 设置响应头
        const headers = new Headers();
        object.writeHttpMetadata(headers);
        headers.set('etag', object.httpEtag);
        headers.set('Content-Disposition', `attachment; filename="${encodeURIComponent(key.split('/').pop() || '')}"`);
        
        // 返回文件内容
        return new Response(object.body, {
            headers
        });
    } catch (error: any) {
        console.error('下载文件失败:', error);
        return c.json({ 
            success: false, 
            error: '下载文件失败: ' + error.message 
        }, 500);
    }
});

// 删除文件或文件夹
r2Router.delete('/delete', authMiddleware, requireAdmin, async (c) => {
    try {
        const { keys } = await c.req.json();
        
        if (!keys || !Array.isArray(keys) || keys.length === 0) {
            return c.json({ 
                success: false, 
                error: '请提供要删除的文件或文件夹路径' 
            }, 400);
        }
        
        // 删除多个对象
        await c.env.MY_BUCKET.delete(keys);
        
        return c.json({
            success: true,
            message: `成功删除 ${keys.length} 个文件或文件夹`,
            deletedKeys: keys
        });
    } catch (error: any) {
        console.error('删除文件失败:', error);
        return c.json({ 
            success: false, 
            error: '删除文件失败: ' + error.message 
        }, 500);
    }
});

export default r2Router;