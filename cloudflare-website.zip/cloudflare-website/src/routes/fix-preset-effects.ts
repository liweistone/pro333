import { Hono } from 'hono';
import { authMiddleware, requireAdmin } from '../middleware/auth';
import type { Bindings, Variables } from '../types';

const fixPresetEffectsRoutes = new Hono<{ Bindings: Bindings; Variables: Variables }>();

// 修复预设效果图URL的端点（需要管理员权限）
fixPresetEffectsRoutes.post('/fix-urls', authMiddleware, requireAdmin, async (c) => {
  try {
    console.log('开始修复预设效果图URL...');
    
    // 查询所有预设效果图的使用记录
    const { results: imageUsageRecords } = await c.env.DB.prepare(`
      SELECT iu.*, r.object_key 
      FROM ImageUsage iu 
      JOIN R2Images r ON iu.image_id = r.id 
      WHERE iu.used_in_type = 'preset_effect'
    `).all();
    
    console.log(`找到 ${imageUsageRecords.results?.length || 0} 条预设效果图记录`);
    
    let fixedCount = 0;
    
    // 检查每条记录是否需要修复
    for (const record of imageUsageRecords.results || []) {
      // 这里我们可以添加具体的修复逻辑
      // 例如检查图片URL是否正确，如果不正确则进行修复
      
      // 目前我们只是记录信息，实际的修复逻辑需要根据具体情况实现
      console.log(`检查记录 ID: ${record.id}, 图片ID: ${record.image_id}, 对象键: ${record.object_key}`);
      
      // 如果发现错误的URL格式，可以在这里进行修复
      // 例如：更新数据库中的相关字段
    }
    
    return c.json({ 
      success: true, 
      message: `检查完成，修复了 ${fixedCount} 条记录`,
      totalRecords: imageUsageRecords.results?.length || 0,
      fixedRecords: fixedCount
    });
  } catch (error: any) {
    console.error('修复预设效果图URL时出错:', error);
    return c.json({ 
      success: false, 
      error: '修复失败: ' + (error.message || '未知错误') 
    }, 500);
  }
});

// 检查特定图片URL的端点
fixPresetEffectsRoutes.get('/check-url/:objectKey', authMiddleware, requireAdmin, async (c) => {
  try {
    const objectKey = c.req.param('objectKey');
    
    console.log(`检查图片URL: ${objectKey}`);
    
    // 检查图片是否存在
    const image = await c.env.DB.prepare(`
      SELECT * FROM R2Images WHERE object_key = ?
    `).bind(objectKey).first();
    
    if (!image) {
      return c.json({ 
        success: false, 
        error: '图片不存在' 
      }, 404);
    }
    
    // 检查图片的使用记录
    const { results: usageRecords } = await c.env.DB.prepare(`
      SELECT * FROM ImageUsage WHERE image_id = ?
    `).bind(image.id).all();
    
    // 生成正确的URL
    const correctUrl = `/api/images/public/${objectKey}`;
    
    return c.json({ 
      success: true,
      image: {
        ...image,
        correct_url: correctUrl
      },
      usageRecords: usageRecords.results || [],
      message: '图片信息检查完成'
    });
  } catch (error: any) {
    console.error('检查图片URL时出错:', error);
    return c.json({ 
      success: false, 
      error: '检查失败: ' + (error.message || '未知错误') 
    }, 500);
  }
});

export default fixPresetEffectsRoutes;