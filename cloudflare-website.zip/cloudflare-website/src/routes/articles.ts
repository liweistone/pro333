import { Hono } from 'hono'
import { authMiddleware, requireAdmin } from '../middleware/auth'
import type { Bindings, Variables } from '../types';

const articlesRouter = new Hono<{ Bindings: Bindings; Variables: Variables }>()

// 获取文章列表
articlesRouter.get('/', async (c) => {
  try {
    const { page = '1', limit = '10' } = c.req.query();
    const offset = (parseInt(page) - 1) * parseInt(limit);
    
    // 先查询总数
    const countResult = await c.env.DB.prepare(
      'SELECT COUNT(*) as total FROM Articles a JOIN Users u ON a.author_id = u.id'
    ).first();
    const total = countResult.total;
    
    // 然后查询当前页的数据
    const { results } = await c.env.DB.prepare(
      'SELECT a.*, u.username as author_name FROM Articles a JOIN Users u ON a.author_id = u.id ORDER BY a.created_at DESC LIMIT ? OFFSET ?'
    ).bind(parseInt(limit), offset).all();
    
    // 处理cover_image字段，确保返回的是完整的URL
    const articlesWithImageUrl = results.map((article: any) => ({
      ...article,
      cover_image: article.cover_image ? `/api/images/public/${article.cover_image}` : null
    }));
    
    // 返回包含分页信息的数据
    return c.json({
      success: true,
      data: articlesWithImageUrl,
      pagination: {
        currentPage: parseInt(page),
        totalPages: Math.ceil(total / parseInt(limit)),
        totalItems: total,
        itemsPerPage: parseInt(limit)
      }
    });
  } catch (error) {
    console.error('Error fetching articles:', error)
    return c.json({ success: false, message: '获取文章失败' }, 500)
  }
})

// 获取文章列表（旧端点，保持兼容性）
articlesRouter.get('/list', async (c) => {
  try {
    const { page = '1', limit = '10' } = c.req.query();
    const offset = (parseInt(page) - 1) * parseInt(limit);
    
    // 先查询总数
    const countResult = await c.env.DB.prepare(
      'SELECT COUNT(*) as total FROM Articles a JOIN Users u ON a.author_id = u.id'
    ).first();
    const total = countResult.total;
    
    // 然后查询当前页的数据
    const { results } = await c.env.DB.prepare(
      'SELECT a.*, u.username as author_name FROM Articles a JOIN Users u ON a.author_id = u.id ORDER BY a.created_at DESC LIMIT ? OFFSET ?'
    ).bind(parseInt(limit), offset).all();
    
    // 处理cover_image字段，确保返回的是完整的URL
    const articlesWithImageUrl = results.map((article: any) => ({
      ...article,
      cover_image: article.cover_image ? `/api/images/public/${article.cover_image}` : null
    }));
    
    // 返回包含分页信息的数据
    return c.json({
      success: true,
      data: articlesWithImageUrl,
      pagination: {
        currentPage: parseInt(page),
        totalPages: Math.ceil(total / parseInt(limit)),
        totalItems: total,
        itemsPerPage: parseInt(limit)
      }
    });
  } catch (error) {
    console.error('Error fetching articles:', error)
    return c.json({ success: false, message: '获取文章失败' }, 500)
  }
})

// 获取单篇文章
articlesRouter.get('/:id', async (c) => {
  try {
    const id = c.req.param('id')
    const article = await c.env.DB.prepare(
      'SELECT a.*, u.username as author_name FROM Articles a JOIN Users u ON a.author_id = u.id WHERE a.id = ?'
    ).bind(id).first()
    
    if (article) {
      // 处理cover_image字段，确保返回的是完整的URL
      const articleWithImageUrl = {
        ...article,
        cover_image: article.cover_image ? `/api/images/public/${article.cover_image}` : null
      };
      
      return c.json({ success: true, data: articleWithImageUrl })
    } else {
      return c.json({ success: false, message: '文章不存在' }, 404)
    }
  } catch (error) {
    console.error('Error fetching article:', error)
    return c.json({ success: false, message: '获取文章失败' }, 500)
  }
})

// 添加文章
articlesRouter.post('/add', authMiddleware, requireAdmin, async (c) => {
  try {
    const body = await c.req.json()
    const { title, content, category_id, is_published, visibility, cover_image } = body
    
    const user = c.get('user')
    if (!user) {
      return c.json({ success: false, message: '用户未登录' }, 401)
    }
    
    const { success } = await c.env.DB.prepare(
      'INSERT INTO Articles (title, content, category_id, is_published, visibility, cover_image, author_id, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)'
    ).bind(title, content, category_id, is_published ? 1 : 0, visibility, cover_image || null, user.id).run()
    
    // 如果有封面图片，更新图片的引用状态
    if (success && cover_image) {
      await updateImageReferenceStatus(c, cover_image, true);
    }
    
    if (success) {
      return c.json({ success: true, message: '文章添加成功' })
    } else {
      return c.json({ success: false, message: '文章添加失败' }, 500)
    }
  } catch (error: any) {
    console.error('Error adding article:', error)
    return c.json({ success: false, message: '添加文章失败: ' + (error.message || '未知错误') })
  }
})

// 编辑文章
articlesRouter.put('/edit/:id', authMiddleware, requireAdmin, async (c) => {
  try {
    const id = c.req.param('id')
    const body = await c.req.json()
    const { title, content, category_id, is_published, visibility, cover_image } = body
    
    const user = c.get('user')
    if (!user) {
      return c.json({ success: false, message: '用户未登录' }, 401)
    }
    
    // 先获取原始文章信息，以便检查封面图片变化
    const originalArticle = await c.env.DB.prepare(
      'SELECT cover_image FROM Articles WHERE id = ?'
    ).bind(id).first()
    
    const { success } = await c.env.DB.prepare(
      'UPDATE Articles SET title = ?, content = ?, category_id = ?, is_published = ?, visibility = ?, cover_image = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?'
    ).bind(title, content, category_id, is_published ? 1 : 0, visibility, cover_image || null, id).run()
    
    // 如果更新成功，处理图片引用状态
    if (success) {
      // 如果封面图片发生了变化，更新相关图片的引用状态
      if (originalArticle && originalArticle.cover_image !== cover_image) {
        // 取消旧图片的引用状态
        if (originalArticle.cover_image) {
          await updateImageReferenceStatus(c, originalArticle.cover_image, false);
        }
        // 设置新图片的引用状态
        if (cover_image) {
          await updateImageReferenceStatus(c, cover_image, true);
        }
      }
      return c.json({ success: true, message: '文章编辑成功' })
    } else {
      return c.json({ success: false, message: '文章不存在' }, 404)
    }
  } catch (error: any) {
    console.error('Error editing article:', error)
    return c.json({ success: false, message: '编辑文章失败: ' + (error.message || '未知错误') })
  }
})

// 删除文章
articlesRouter.delete('/delete/:id', authMiddleware, requireAdmin, async (c) => {
  try {
    const id = c.req.param('id')
    
    const user = c.get('user')
    if (!user) {
      return c.json({ success: false, message: '用户未登录' }, 401)
    }
    
    const { success } = await c.env.DB.prepare('DELETE FROM Articles WHERE id = ?').bind(id).run()
    
    if (success) {
      return c.json({ success: true, message: '文章删除成功' })
    } else {
      return c.json({ success: false, message: '文章不存在' }, 404)
    }
  } catch (error: any) {
    console.error('Error deleting article:', error)
    return c.json({ success: false, message: '删除文章失败: ' + (error.message || '未知错误') })
  }
})

// 更新图片引用状态的辅助函数
async function updateImageReferenceStatus(c: any, imageObjectKey: string, isReferenced: boolean) {
  try {
    // 更新图片的引用状态
    await c.env.DB.prepare(`
      UPDATE R2Images 
      SET is_referenced = ?, usage_count = (
        SELECT COUNT(*) FROM ImageUsage WHERE image_id = (
          SELECT id FROM R2Images WHERE object_key = ?
        )
      )
      WHERE object_key = ?
    `).bind(isReferenced, imageObjectKey, imageObjectKey).run();
  } catch (error) {
    console.error('Error updating image reference status:', error);
  }
}

// 更新图片使用记录的辅助函数
async function updateImageUsageRecord(c: any, imageObjectKey: string, usedInType: string, usedInId: string | number, add: boolean) {
  try {
    // 获取图片ID
    const image = await c.env.DB.prepare(`
      SELECT id FROM R2Images WHERE object_key = ?
    `).bind(imageObjectKey).first();
    
    if (!image) return;
    
    if (add) {
      // 添加使用记录
      await c.env.DB.prepare(`
        INSERT OR IGNORE INTO ImageUsage (image_id, used_in_type, used_in_id)
        VALUES (?, ?, ?)
      `).bind(image.id, usedInType, usedInId).run();
    } else {
      // 删除使用记录
      await c.env.DB.prepare(`
        DELETE FROM ImageUsage 
        WHERE image_id = ? AND used_in_type = ? AND used_in_id = ?
      `).bind(image.id, usedInType, usedInId).run();
    }
    
    // 更新图片的引用状态和使用计数
    await c.env.DB.prepare(`
      UPDATE R2Images 
      SET is_referenced = (
        SELECT CASE WHEN COUNT(*) > 0 THEN 1 ELSE 0 END 
        FROM ImageUsage 
        WHERE image_id = ?
      ),
      usage_count = (
        SELECT COUNT(*) 
        FROM ImageUsage 
        WHERE image_id = ?
      )
      WHERE id = ?
    `).bind(image.id, image.id, image.id).run();
  } catch (error: any) {
    console.error('Error updating image usage record:', error);
    // 不抛出错误，避免影响主流程
    // 记录所有类型的错误，但不中断主流程
  }
}

export { updateImageUsageRecord };
export default articlesRouter