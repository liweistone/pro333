import { Hono } from 'hono';
import { authMiddleware, requireRole, requireAdmin } from '../middleware/auth';
import type { Bindings, Variables } from '../types';
import { updateImageUsageRecord } from './articles'; // 导入图片引用更新函数

const presetRoutes = new Hono<{ Bindings: Bindings; Variables: Variables }>();

// 获取预设分类列表 (对象格式)
presetRoutes.get('/categories', async (c) => {
  try {
    const { results } = await c.env.DB.prepare(
      "SELECT * FROM categories ORDER BY name"
    ).all();
    
    // 转换为指定格式: { [id]: name }
    const categories: { [key: string]: string } = {};
    results.forEach((category: any) => {
      categories[category.id] = category.name;
    });
    
    c.header('Content-Type', 'application/json; charset=utf-8');
    return c.json(categories);
  } catch (error: any) {
    console.error('Error fetching categories:', error);
    return c.json({ error: '获取分类失败: ' + (error.message || '未知错误') }, 500);
  }
});

// 检查预设分类表结构
presetRoutes.get('/categories/table-info', async (c) => {
  try {
    // 获取表结构信息
    const tableInfo = await c.env.DB.prepare(
      "PRAGMA table_info(categories)"
    ).all();
    
    // 获取记录数
    const countResult = await c.env.DB.prepare(
      "SELECT COUNT(*) as count FROM categories"
    ).first();
    
    return c.json({ 
      tableInfo: tableInfo.results, 
      recordCount: countResult.count 
    });
  } catch (error: any) {
    console.error('Error checking table structure:', error);
    return c.json({ error: '检查表结构失败: ' + (error.message || '未知错误') }, 500);
  }
});

// 更新预设分类表结构
presetRoutes.post('/categories/update-table', authMiddleware, requireAdmin, async (c) => {
  try {
    // 检查是否已存在description字段
    const tableInfo = await c.env.DB.prepare(
      "PRAGMA table_info(categories)"
    ).all();
    
    const hasDescriptionColumn = tableInfo.results.some((column: any) => column.name === 'description');
    const hasParentIdColumn = tableInfo.results.some((column: any) => column.name === 'parent_id');
    
    // 添加缺失的字段
    if (!hasDescriptionColumn) {
      await c.env.DB.prepare(
        "ALTER TABLE categories ADD COLUMN description TEXT"
      ).run();
      console.log('Added description column to categories table');
    }
    
    if (!hasParentIdColumn) {
      await c.env.DB.prepare(
        "ALTER TABLE categories ADD COLUMN parent_id TEXT"
      ).run();
      console.log('Added parent_id column to categories table');
    }
    
    return c.json({ 
      success: true, 
      message: '表结构更新成功',
      addedColumns: {
        description: !hasDescriptionColumn,
        parent_id: !hasParentIdColumn
      }
    });
  } catch (error: any) {
    console.error('Error updating table structure:', error);
    return c.json({ error: '更新表结构失败: ' + (error.message || '未知错误') }, 500);
  }
});

// 获取预设分类列表
presetRoutes.get('/categories/list', authMiddleware, requireAdmin, async (c) => {
  console.log('获取预设分类列表路由被调用');
  try {
    // 确保用户信息被正确处理
    const user = c.get('user');
    console.log('当前用户信息:', user);
    
    // 首先检查表是否存在
    try {
      console.log('检查categories表是否存在');
      const tableCheck = await c.env.DB.prepare(
        "SELECT name FROM sqlite_master WHERE type='table' AND name='categories'"
      ).first();
      console.log('表检查结果:', tableCheck);
      
      if (!tableCheck) {
        console.log('categories表不存在');
        return c.json({ success: false, message: '分类表不存在' }, 500);
      }
    } catch (tableError: any) {
      console.error('检查表是否存在时出错:', tableError);
      return c.json({ success: false, message: '检查表是否存在时出错: ' + (tableError.message || '未知错误') }, 500);
    }
    
    // 查询所有字段，包括parent_id以支持层级显示
    console.log('准备执行完整数据库查询');
    const result = await c.env.DB.prepare(
      "SELECT id, name, description, parent_id, created_at, updated_at FROM categories ORDER BY name"
    ).all();
    
    console.log('完整查询结果:', result);
    const { results } = result;
    
    c.header('Content-Type', 'application/json; charset=utf-8');
    return c.json({ success: true, data: results });
  } catch (error: any) {
    console.error('Error fetching categories:', error);
    console.error('Error stack:', error.stack);
    return c.json({ success: false, message: '获取分类失败: ' + (error.message || '未知错误') }, 500);
  }
});

// 获取单个预设分类
presetRoutes.get('/categories/:id', authMiddleware, requireAdmin, async (c) => {
  try {
    const categoryId = c.req.param('id');
    const category = await c.env.DB.prepare(
      "SELECT * FROM categories WHERE id = ?"
    ).bind(categoryId).first();
    
    if (category) {
      return c.json({ success: true, data: category });
    } else {
      return c.json({ success: false, message: '分类不存在' }, 404);
    }
  } catch (error: any) {
    console.error('Error fetching category:', error);
    return c.json({ success: false, message: '获取分类失败: ' + (error.message || '未知错误') }, 500);
  }
});

// 创建预设分类
presetRoutes.post('/categories', authMiddleware, requireAdmin, async (c) => {
  try {
    console.log('开始处理创建分类请求');
    const requestData = await c.req.json();
    console.log('请求数据:', requestData);
    
    const { name, description, parent_id } = requestData;
    
    if (!name) {
      console.log('分类名称缺失');
      return c.json({ success: false, error: '分类名称是必需的' }, 400);
    }
    
    // 使用统一的ID生成方式（与预设表保持一致，使用文本类型ID）
    const id = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
    console.log('生成的分类ID:', id);
    
    // 检查表结构，确定是否包含parent_id列
    console.log('检查categories表结构');
    let hasParentIdColumn = false;
    try {
      const tableInfo = await c.env.DB.prepare(
        "PRAGMA table_info(categories)"
      ).all();
      console.log('表结构信息:', tableInfo);
      
      // 检查是否存在parent_id列
      hasParentIdColumn = tableInfo.results.some((column: any) => column.name === 'parent_id');
      console.log('是否存在parent_id列:', hasParentIdColumn);
    } catch (schemaError: any) {
      console.error('检查表结构时出错:', schemaError);
      return c.json({ success: false, error: '检查表结构时出错: ' + schemaError.message }, 500);
    }
    
    console.log('准备执行数据库插入操作');
    let stmt;
    let bindParams;
    
    const now = Math.floor(Date.now() / 1000);
    
    if (hasParentIdColumn) {
      // 如果存在parent_id列，则包含在插入语句中
      stmt = c.env.DB.prepare(
        "INSERT INTO categories (id, name, description, parent_id, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)"
      );
      bindParams = [id, name, description || null, parent_id || null, now, now];
    } else {
      // 如果不存在parent_id列，则不包含在插入语句中
      stmt = c.env.DB.prepare(
        "INSERT INTO categories (id, name, description, created_at, updated_at) VALUES (?, ?, ?, ?, ?)"
      );
      bindParams = [id, name, description || null, now, now];
    }
    
    console.log('准备插入的数据:', bindParams);
    const result = await stmt.bind(...bindParams).run();
    
    console.log('数据库插入结果:', result);
    const { success } = result;
    
    if (success) {
      console.log('分类创建成功');
      // 返回与获取分类列表时一致的数据结构
      const categoryData = { 
        id: id, 
        name: name, 
        description: description || null,
        parent_id: parent_id || null,
        created_at: now,
        updated_at: now
      };
      
      return c.json({ 
        success: true, 
        data: categoryData,
        message: '分类创建成功' 
      }, 201);
    } else {
      console.log('分类创建失败');
      return c.json({ success: false, error: '创建分类失败' }, 500);
    }
  } catch (error: any) {
    console.error('创建分类时发生错误:', error);
    console.error('错误堆栈:', error.stack);
    return c.json({ success: false, error: '创建分类失败: ' + (error.message || '未知错误') }, 500);
  }
});

// 更新预设分类
presetRoutes.put('/categories/:id', authMiddleware, requireAdmin, async (c) => {
  const categoryId = c.req.param('id');
  const { name, description, parent_id } = await c.req.json();
  const now = Math.floor(Date.now() / 1000);
  
  if (!name) {
    return c.json({ success: false, error: '分类名称是必需的' }, 400);
  }
  
  try {
    const { success } = await c.env.DB.prepare(
      "UPDATE categories SET name = ?, description = ?, parent_id = ?, updated_at = ? WHERE id = ?"
    ).bind(name, description || null, parent_id || null, now, categoryId).run();
    
    if (success) {
      // 获取更新后的分类数据
      const updatedCategory = await c.env.DB.prepare(
        "SELECT * FROM categories WHERE id = ?"
      ).bind(categoryId).first();
      
      return c.json({ 
        success: true, 
        data: updatedCategory,
        message: '分类更新成功' 
      });
    } else {
      return c.json({ success: false, error: '更新分类失败' }, 500);
    }
  } catch (error: any) {
    console.error('更新分类时发生错误:', error);
    return c.json({ success: false, error: '更新分类失败: ' + (error.message || '未知错误') }, 500);
  }
});

// 删除预设分类
presetRoutes.delete('/categories/:id', authMiddleware, requireAdmin, async (c) => {
  const categoryId = c.req.param('id');
  
  try {
    console.log('开始删除分类，ID:', categoryId);
    
    // 检查是否有预设使用此分类
    const presetCountResult = await c.env.DB.prepare(
      "SELECT COUNT(*) as count FROM presets WHERE category_id = ?"
    ).bind(categoryId).first();
    
    console.log('检查预设数量结果:', presetCountResult);
    
    if (presetCountResult && presetCountResult.count > 0) {
      return c.json({ success: false, error: `无法删除分类，还有 ${presetCountResult.count} 个预设使用此分类` }, 400);
    }
    
    // 执行删除操作
    const deleteResult = await c.env.DB.prepare(
      "DELETE FROM categories WHERE id = ?"
    ).bind(categoryId).run();
    
    console.log('删除分类结果:', deleteResult);
    
    if (deleteResult.success) {
      return c.json({ success: true, message: '分类删除成功' });
    } else {
      return c.json({ success: false, error: '删除分类失败' }, 500);
    }
  } catch (error: any) {
    console.error('删除分类时发生错误:', error);
    // 检查是否是外键约束错误
    if (error.message && error.message.includes('FOREIGN KEY constraint failed')) {
      return c.json({ success: false, error: '删除分类失败: 存在关联数据未删除，请先删除使用此分类的所有预设' }, 500);
    }
    return c.json({ success: false, error: '删除分类失败: ' + (error.message || '未知错误') }, 500);
  }
});

// 获取预设列表 (带排序和过滤)
presetRoutes.get('/', async (c) => {
  const { 
    category_id, 
    sort = 'newest', 
    page = '1', 
    limit = '20'
  } = c.req.query();
  
  const user = c.get('user');
  const pageNum = parseInt(page);
  const limitNum = parseInt(limit);
  const offset = (pageNum - 1) * limitNum;
  
  // 构建查询条件和排序
  let whereConditions: string[] = [];
  let queryParams: any[] = [];
  
  if (category_id) {
    whereConditions.push("category_id = ?");
    queryParams.push(category_id);
  }
  
  // 根据用户权限添加可见性条件
  if (user) {
    if (user.role === 'admin' || user.role === 'superadmin') {
      // 管理员可以看到所有预设
    } else {
      whereConditions.push(`
        (visibility = 'public' OR 
         visibility = 'authenticated' OR 
         EXISTS (
           SELECT 1 FROM preset_access_levels pal 
           WHERE pal.preset_id = presets.id AND pal.membership_level = ?
         ))
      `);
      queryParams.push(user.membership_level || 'basic');
    }
  } else {
    whereConditions.push("visibility = 'public'");
  }
  
  // 构建排序条件
  let orderBy = "created_at DESC";
  switch (sort) {
    case 'popular':
      orderBy = "use_count DESC";
      break;
    case 'most_viewed':
      orderBy = "view_count DESC";
      break;
    case 'most_favorited':
      orderBy = "favorite_count DESC";
      break;
    case 'newest':
    default:
      orderBy = "created_at DESC";
  }
  
  const whereClause = whereConditions.length > 0 
    ? `WHERE ${whereConditions.join(' AND ')}` 
    : '';
  
  // 获取总数
  const countQuery = `SELECT COUNT(*) as total FROM presets ${whereClause}`;
  const countResult = await c.env.DB.prepare(countQuery).bind(...queryParams).first();
  const total = countResult.total;
  
  // 添加分页参数到查询参数
  queryParams.push(limitNum, offset);
  
  const { results } = await c.env.DB.prepare(`
    SELECT * FROM presets 
    ${whereClause}
    ORDER BY ${orderBy}
    LIMIT ? OFFSET ?
  `).bind(...queryParams).all();
  
  // 处理image字段，确保返回的是完整的URL
  const presetsWithImageUrl = results.map((preset: any) => ({
    ...preset,
    image: preset.image ? 
      (preset.image.startsWith('/api/images/public/') ? preset.image : `/api/images/public/${preset.image}`) 
      : null
  }));
  
  // 获取所有分类用于输出（包含完整信息，包括parent_id）
  const categoryResults = await c.env.DB.prepare(
    "SELECT id, name, parent_id FROM categories ORDER BY name"
  ).all();
  
  // 转换分类为指定格式: { [id]: { id, name, parent_id } }
  const categories: { [key: string]: any } = {};
  categoryResults.results.forEach((category: any) => {
    categories[category.id] = category;
  });
  
  // 计算分页信息
  const totalPages = Math.ceil(total / limitNum);
  const pagination = {
    currentPage: pageNum,
    totalPages: totalPages,
    total: total,
    limit: limitNum
  };
  
  // 返回指定格式的数据
  c.header('Content-Type', 'application/json; charset=utf-8');
  return c.json({
    categories: categories,
    data: presetsWithImageUrl,
    presets: presetsWithImageUrl,  // 为了兼容前端代码，同时返回presets字段
    pagination: pagination,
    current_category: category_id || "",
    total: total  // 添加总数量字段
  });
});

// 获取单个预设详情
presetRoutes.get('/:id', async (c) => {
  const presetId = c.req.param('id');
  const user = c.get('user');
  
  // 检查权限
  const preset = await c.env.DB.prepare(
    "SELECT * FROM presets WHERE id = ?"
  ).bind(presetId).first();
  
  if (!preset) {
    return c.json({ error: '预设不存在' }, 404);
  }
  
  // 处理image字段，确保返回的是完整的URL
  const presetWithImageUrl = {
    ...preset,
    image: preset.image ? 
      (preset.image.startsWith('/api/images/public/') ? preset.image : `/api/images/public/${preset.image}`) 
      : null
  };
  
  // 权限验证
  if (preset.visibility !== 'public') {
    if (!user) {
      return c.json({ error: '需要登录访问' }, 401);
    }
    
    if (user.role !== 'admin' && user.role !== 'superadmin') {
      if (preset.visibility === 'authenticated') {
        // 已登录用户可访问
      } else {
        // 检查用户级别是否有权限
        const hasAccess = await c.env.DB.prepare(
          `SELECT 1 FROM preset_access_levels 
           WHERE preset_id = ? AND membership_level = ?`
        ).bind(presetId, user.membership_level || 'basic').first();
        
        if (!hasAccess) {
          return c.json({ error: '您没有权限访问此预设' }, 403);
        }
      }
    }
  }
  
  // 增加阅读计数
  await c.env.DB.prepare(
    "UPDATE presets SET view_count = view_count + 1 WHERE id = ?"
  ).bind(presetId).run();
  
  // 检查用户是否已收藏
  let isFavorited = false;
  if (user) {
    const favorite = await c.env.DB.prepare(
      "SELECT 1 FROM user_favorite_presets WHERE user_id = ? AND preset_id = ?"
    ).bind(user.id, presetId).first();
    
    isFavorited = !!favorite;
  }
  
  c.header('Content-Type', 'application/json; charset=utf-8');
  return c.json({ ...presetWithImageUrl, is_favorited: isFavorited });
});

// 获取预设相关效果图
presetRoutes.get('/:id/effect-images', async (c) => {
  const presetId = c.req.param('id');
  
  try {
    // 检查预设是否存在
    const preset = await c.env.DB.prepare(
      "SELECT id FROM presets WHERE id = ?"
    ).bind(presetId).first();
    
    if (!preset) {
      return c.json({ error: '预设不存在' }, 404);
    }
    
    // 查询与该预设关联的效果图
    // 这里我们假设效果图存储在ImageUsage表中，关联类型为'preset_effect'
    const { results } = await c.env.DB.prepare(`
      SELECT r.object_key, r.original_name, r.mime_type, r.size, r.uploaded_at
      FROM ImageUsage iu
      JOIN R2Images r ON iu.image_id = r.id
      WHERE iu.used_in_type = 'preset_effect' AND iu.used_in_id = ?
      ORDER BY iu.used_at DESC
    `).bind(presetId).all();
    
    // 处理图片URL，确保返回的是完整的URL
    const effectImages = results.map((image: any) => ({
      ...image,
      url: `/api/images/public/${image.object_key}`
    }));
    
    return c.json({ 
      success: true,
      images: effectImages,
      count: effectImages.length
    });
  } catch (error: any) {
    console.error('获取预设效果图失败:', error);
    return c.json({ error: '获取预设效果图失败: ' + (error.message || '未知错误') }, 500);
  }
});

// 创建预设 (需要管理员权限)
presetRoutes.post('/', authMiddleware, requireAdmin, async (c) => {
  const { 
    title, 
    category_id, 
    description, 
    positive, 
    negative, 
    image, 
    effect_images = [], // 新增效果图字段
    visibility = 'public'
  } = await c.req.json();
  
  if (!title || !category_id || !positive) {
    return c.json({ success: false, error: '标题、分类ID和positive字段是必需的' }, 400);
  }
  
  const id = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
  const now = Math.floor(Date.now() / 1000);
  
  // 处理可能为undefined的字段，将其转换为null
  const safeDescription = description || null;
  const safeNegative = negative || null;
  const safeImage = image || null;
  
  const insertResult = await c.env.DB.prepare(
    `INSERT INTO presets 
     (id, title, category_id, description, positive, negative, image, 
      visibility, created_at, updated_at) 
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).bind(
    id, title, category_id, safeDescription, positive, safeNegative, safeImage,
    visibility, now, now
  ).run();
  
  if (insertResult.success) {
    // 如果有封面图片，更新图片的引用状态
    if (safeImage) {
      await updateImageUsageRecord(c, safeImage, 'preset', id, true);
    }
    
    // 如果有效果图，更新效果图的引用状态
    if (Array.isArray(effect_images) && effect_images.length > 0) {
      for (const imageKey of effect_images) {
        await updateImageUsageRecord(c, imageKey, 'preset_effect', id, true);
      }
    }
    
    // 返回与更新预设时一致的数据结构
    const presetData = {
      id,
      title,
      category_id,
      description: safeDescription,
      positive,
      negative: safeNegative,
      image: safeImage,
      effect_images: effect_images || [],
      visibility,
      created_at: now,
      updated_at: now
    };
    
    return c.json({ 
      success: true,
      data: presetData,
      message: '预设创建成功' 
    }, 201);
  } else {
    return c.json({ success: false, error: '创建预设失败' }, 500);
  }
});

// 更新预设 (需要管理员权限)
presetRoutes.put('/:id', authMiddleware, requireAdmin, async (c) => {
  const presetId = c.req.param('id');
  const updates = await c.req.json();
  const now = Math.floor(Date.now() / 1000);
  
  // 先获取原始预设信息，以便检查图片变化
  const originalPreset = await c.env.DB.prepare(
    'SELECT image FROM presets WHERE id = ?'
  ).bind(presetId).first();
  
  // 构建更新字段
  const updateFields: string[] = [];
  const updateValues: any[] = [];
  
  // 只有在字段存在时才更新
  Object.keys(updates).forEach(key => {
    // 排除effect_images字段，因为它不是预设表的直接字段
    if (key !== 'id' && key !== 'effect_images' && updates[key] !== undefined) {
      updateFields.push(`${key} = ?`);
      updateValues.push(updates[key]);
    }
  });
  
  updateFields.push('updated_at = ?');
  updateValues.push(now);
  
  updateValues.push(presetId);
  
  const { success } = await c.env.DB.prepare(
    `UPDATE presets SET ${updateFields.join(', ')} WHERE id = ?`
  ).bind(...updateValues).run();
  
  // 如果更新成功，处理图片引用状态
  if (success) {
    // 如果封面图片发生了变化，更新相关图片的引用状态
    if (originalPreset && originalPreset.image !== updates.image) {
      // 取消旧图片的引用状态
      if (originalPreset.image) {
        await updateImageUsageRecord(c, originalPreset.image, 'preset', presetId, false);
      }
      // 设置新图片的引用状态
      if (updates.image) {
        await updateImageUsageRecord(c, updates.image, 'preset', presetId, true);
      }
    }
    
    // 如果有效果图更新，处理效果图的引用状态
    if (updates.effect_images !== undefined) {
      // 先删除所有现有的效果图关联
      await c.env.DB.prepare(
        "DELETE FROM ImageUsage WHERE used_in_type = 'preset_effect' AND used_in_id = ?"
      ).bind(presetId).run();
      
      // 添加新的效果图关联
      if (Array.isArray(updates.effect_images) && updates.effect_images.length > 0) {
        for (const imageKey of updates.effect_images) {
          await updateImageUsageRecord(c, imageKey, 'preset_effect', presetId, true);
        }
      }
    }
    
    // 获取更新后的预设数据
    const updatedPreset = await c.env.DB.prepare(
      "SELECT * FROM presets WHERE id = ?"
    ).bind(presetId).first();
    
    return c.json({ 
      success: true,
      data: updatedPreset,
      message: '预设更新成功' 
    });
  } else {
    return c.json({ success: false, error: '更新预设失败' }, 500);
  }
});

// 删除预设 (需要管理员权限)
presetRoutes.delete('/:id', authMiddleware, requireAdmin, async (c) => {
  const presetId = c.req.param('id');
  
  try {
    console.log('开始删除预设，ID:', presetId);
    
    // 先获取预设信息，用于取消图片引用
    const preset = await c.env.DB.prepare(
      'SELECT image FROM presets WHERE id = ?'
    ).bind(presetId).first();
    
    console.log('预设信息:', preset);
    
    // 检查预设是否存在
    const presetExists = await c.env.DB.prepare(
      "SELECT COUNT(*) as count FROM presets WHERE id = ?"
    ).bind(presetId).first();
    console.log('预设存在状态:', presetExists);
    
    if (!presetExists || presetExists.count === 0) {
      return c.json({ success: false, error: '预设不存在' }, 404);
    }
    
    // 使用批量SQL命令一次性删除所有关联数据和预设本身
    console.log('准备执行批量删除操作');
    
    // 构建批量删除SQL
    const batchStatements = [
      c.env.DB.prepare("DELETE FROM user_favorite_presets WHERE preset_id = ?").bind(presetId),
      c.env.DB.prepare("DELETE FROM preset_access_levels WHERE preset_id = ?").bind(presetId),
      c.env.DB.prepare("DELETE FROM ImageUsage WHERE used_in_type = 'preset' AND used_in_id = ?").bind(presetId),
      c.env.DB.prepare("DELETE FROM ImageUsage WHERE used_in_type = 'preset_effect' AND used_in_id = ?").bind(presetId),
      c.env.DB.prepare("DELETE FROM presets WHERE id = ?").bind(presetId)
    ];
    
    // 执行批量操作
    console.log('执行批量删除操作');
    const batchResults = await c.env.DB.batch(batchStatements);
    
    console.log('批量删除结果:', batchResults);
    
    // 检查预设删除是否成功（最后一个操作是删除预设本身）
    const deleteResult = batchResults[batchResults.length - 1];
    
    if (deleteResult.success) {
      console.log('预设删除成功');
      // 如果预设有封面图片，取消图片引用状态
      if (preset && preset.image) {
        console.log('取消图片引用状态:', preset.image);
        try {
          // 使用更安全的方式调用updateImageUsageRecord
          await updateImageUsageRecord(c, preset.image, 'preset', presetId, false);
        } catch (imageError: any) {
          console.error('取消图片引用状态时出错:', imageError);
          // 即使图片引用状态更新失败，也不应该影响预设删除的成功状态
          // 记录错误但不中断流程
        }
      }
      return c.json({ success: true, message: '预设删除成功' });
    } else {
      console.log('预设删除失败');
      // 检查是否有外键约束错误的详细信息
      try {
        // 尝试单独删除预设，以获取更详细的错误信息
        const singleDeleteResult = await c.env.DB.prepare("DELETE FROM presets WHERE id = ?").bind(presetId).run();
        console.log('单独删除预设结果:', singleDeleteResult);
        
        if (singleDeleteResult.success) {
          return c.json({ success: true, message: '预设删除成功' });
        }
      } catch (singleDeleteError: any) {
        console.error('单独删除预设时出错:', singleDeleteError);
        // 检查是否是外键约束错误
        if (singleDeleteError.message && singleDeleteError.message.includes('FOREIGN KEY constraint failed')) {
          return c.json({ success: false, error: '删除预设失败: 存在关联数据未删除，请联系管理员' }, 500);
        }
      }
      
      return c.json({ success: false, error: '删除预设失败' }, 500);
    }
  } catch (error: any) {
    console.error('删除预设时发生错误:', error);
    // 检查是否是外键约束错误
    if (error.message && error.message.includes('FOREIGN KEY constraint failed')) {
      return c.json({ success: false, error: '删除预设失败: 存在关联数据未删除，请联系管理员' }, 500);
    }
    // 检查是否是产品相关的错误信息（可能是代码混淆）
    if (error.message && error.message.includes('产品')) {
      return c.json({ success: false, error: '删除预设失败: 代码逻辑错误，请联系管理员' }, 500);
    }
    return c.json({ success: false, error: '删除预设失败: ' + (error.message || '未知错误') }, 500);
  }
});

// 记录预设使用
presetRoutes.post('/:id/use', async (c) => {
  const presetId = c.req.param('id');
  const now = Math.floor(Date.now() / 1000);
  
  const { success } = await c.env.DB.prepare(
    "UPDATE presets SET use_count = use_count + 1, last_used_at = ? WHERE id = ?"
  ).bind(now, presetId).run();
  
  if (success) {
    return c.json({ message: '使用记录已更新' });
  } else {
    return c.json({ error: '更新使用记录失败' }, 500);
  }
});

// 收藏预设
presetRoutes.post('/:id/favorite', authMiddleware, async (c) => {
  const presetId = c.req.param('id');
  const user = c.get('user');
  
  if (!user) {
    return c.json({ error: '需要登录才能操作' }, 401);
  }
  
  // 检查预设是否存在
  const preset = await c.env.DB.prepare(
    "SELECT 1 FROM presets WHERE id = ?"
  ).bind(presetId).first();
  
  if (!preset) {
    return c.json({ error: '预设不存在' }, 404);
  }
  
  // 添加收藏
  const { success } = await c.env.DB.prepare(
    "INSERT OR IGNORE INTO user_favorite_presets (user_id, preset_id) VALUES (?, ?)"
  ).bind(user.id, presetId).run();
  
  if (success) {
    // 更新收藏计数
    await c.env.DB.prepare(
      "UPDATE presets SET favorite_count = favorite_count + 1 WHERE id = ?"
    ).bind(presetId).run();
    
    return c.json({ message: '已添加到收藏' });
  } else {
    return c.json({ error: '收藏失败' }, 500);
  }
});

// 取消收藏
presetRoutes.delete('/:id/favorite', authMiddleware, async (c) => {
  const presetId = c.req.param('id');
  const user = c.get('user');
  
  if (!user) {
    return c.json({ error: '需要登录才能操作' }, 401);
  }
  
  const { success } = await c.env.DB.prepare(
    "DELETE FROM user_favorite_presets WHERE user_id = ? AND preset_id = ?"
  ).bind(user.id, presetId).run();
  
  if (success) {
    // 更新收藏计数
    await c.env.DB.prepare(
      "UPDATE presets SET favorite_count = favorite_count - 1 WHERE id = ?"
    ).bind(presetId).run();
    
    return c.json({ message: '已取消收藏' });
  } else {
    return c.json({ error: '取消收藏失败' }, 500);
  }
});

// 获取用户收藏的预设
presetRoutes.get('/user/favorites', authMiddleware, async (c) => {
  const user = c.get('user');
  const { page = '1', limit = '20' } = c.req.query();
  const offset = (parseInt(page) - 1) * parseInt(limit);
  
  if (!user) {
    return c.json({ error: '需要登录才能查看收藏' }, 401);
  }
  
  const { results } = await c.env.DB.prepare(`
    SELECT p.*, ufp.created_at as favorited_at 
    FROM presets p
    INNER JOIN user_favorite_presets ufp ON p.id = ufp.preset_id
    WHERE ufp.user_id = ?
    ORDER BY ufp.created_at DESC
    LIMIT ? OFFSET ?
  `).bind(user.id, parseInt(limit), offset).all();
  
  // 处理image字段，确保返回的是完整的URL
  const presetsWithImageUrl = results.map((preset: any) => ({
    ...preset,
    image: preset.image ? `/api/images/public/${preset.image}` : null
  }));
  
  // 获取所有分类用于输出
  const categoryResults = await c.env.DB.prepare(
    "SELECT * FROM categories ORDER BY name"
  ).all();
  
  // 转换分类为指定格式: { [id]: name }
  const categories: { [key: string]: string } = {};
  categoryResults.results.forEach((category: any) => {
    categories[category.id] = category.name;
  });
  
  // 返回指定格式的数据
  c.header('Content-Type', 'application/json; charset=utf-8');
  return c.json({
    categories: categories,
    presets: presetsWithImageUrl,
    current_category: ""
  });
});

export default presetRoutes;