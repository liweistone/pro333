import { Hono } from 'hono';
import { sign, decode, verify } from 'hono/jwt';
import { authMiddleware, requireRole } from '../middleware/auth';
import type { Bindings, Variables, User } from '../types';

// 使用 Web Crypto API 进行密码哈希
async function hashPassword(password: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(password);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

// 验证密码
async function verifyPassword(storedHash: string, password: string): Promise<boolean> {
  const hash = await hashPassword(password);
  console.log(`验证密码 - 存储的哈希: ${storedHash}, 计算的哈希: ${hash}`);
  return hash === storedHash;
}

const authRoutes = new Hono<{ Bindings: Bindings; Variables: Variables }>();

// 用户注册
authRoutes.post('/register', async (c) => {
  const { username, email, password } = await c.req.json();
  
  // 简单验证
  if (!username || !email || !password) {
    return c.json({ error: '用户名、邮箱和密码都是必需的' }, 400);
  }
  
  // 检查用户是否已存在
  const existingUser = await c.env.DB.prepare(
    'SELECT id FROM Users WHERE username = ? OR email = ?'
  ).bind(username, email).first();
  
  if (existingUser) {
    return c.json({ error: '用户名或邮箱已存在' }, 400);
  }
  
  // 对密码进行哈希处理
  const password_hash = await hashPassword(password);
  console.log('Generated password hash:', password_hash);
  
  // 创建新用户
  const { success } = await c.env.DB.prepare(
    'INSERT INTO Users (username, email, password_hash, role) VALUES (?, ?, ?, ?)'
  ).bind(username, email, password_hash, 'user').run();
  
  if (success) {
    return c.json({ message: '用户注册成功' }, 201);
  } else {
    return c.json({ error: '注册失败' }, 500);
  }
});

// 用户登录
authRoutes.post('/login', async (c) => {
  try {
    const { username, password } = await c.req.json();
    
    if (!username || !password) {
      return c.json({ error: '用户名和密码都是必需的' }, 400);
    }
    
    console.log('Attempting to login user:', username);
    
    // 查找用户
    const user = await c.env.DB.prepare(
      'SELECT id, username, email, role, membership_level, password_hash FROM Users WHERE username = ?'
    ).bind(username).first();
    
    if (!user) {
      console.log('User not found:', username);
      return c.json({ error: '用户名或密码错误' }, 401);
    }
    
    console.log('Found user:', user);
    console.log('Stored password hash:', user.password_hash);
    
    // 验证密码
    const isValid = await verifyPassword(user.password_hash, password);
    console.log('Password validation result:', isValid);
    
    if (!isValid) {
      return c.json({ error: '用户名或密码错误' }, 401);
    }
    
    // 更新最后登录时间
    await c.env.DB.prepare(
      'UPDATE Users SET last_login = CURRENT_TIMESTAMP WHERE id = ?'
    ).bind(user.id).run();
    
    // 检查JWT_SECRET是否存在
    if (!c.env.JWT_SECRET) {
      console.error('JWT_SECRET未配置');
      return c.json({ error: '服务器配置错误：JWT_SECRET未设置' }, 500);
    }
    
    // 生成 JWT 令牌
    const payload = {
      id: user.id,
      username: user.username,
      email: user.email,
      role: user.role || 'user',
      membership_level: user.membership_level || 'basic',
      exp: Math.floor(Date.now() / 1000) + 60 * 60 * 24 * 7 // 7天过期
    };
    
    console.log('JWT_SECRET used for signing:', c.env.JWT_SECRET);
    
    try {
      const token = await sign(payload, c.env.JWT_SECRET);
      console.log('Generated token length:', token.length);
      
      return c.json({ 
        token, 
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          role: user.role || 'user',
          membership_level: user.membership_level || 'basic'
        } 
      });
    } catch (error) {
      console.error('JWT signing error:', error);
      return c.json({ error: '令牌生成失败' }, 500);
    }
  } catch (error) {
    console.error('Login error:', error);
    return c.json({ error: '登录过程中出现错误' }, 500);
  }
});

// 用户登出
authRoutes.post('/logout', authMiddleware, async (c) => {
  // 在实际应用中，可能需要将令牌加入黑名单
  // 这里我们只是返回成功消息
  return c.json({ message: '登出成功' });
});

// 刷新令牌
authRoutes.post('/refresh', authMiddleware, async (c) => {
  try {
    const user = c.get('user');
    
    // 检查用户是否存在
    if (!user) {
      return c.json({ error: '用户未认证' }, 401);
    }
    
    console.log('刷新令牌路由被调用，当前用户:', user);
    
    // 检查JWT_SECRET是否存在
    if (!c.env.JWT_SECRET) {
      console.error('JWT_SECRET未配置');
      return c.json({ error: '服务器配置错误：JWT_SECRET未设置' }, 500);
    }
    
    // 生成新的 JWT 令牌
    const payload = {
      id: user.id,
      username: user.username,
      email: user.email,
      role: user.role || 'user',
      membership_level: user.membership_level || 'basic',
      exp: Math.floor(Date.now() / 1000) + 60 * 60 * 24 * 7 // 7天过期
    };
    
    console.log('JWT_SECRET used for signing:', c.env.JWT_SECRET);
    
    try {
      const token = await sign(payload, c.env.JWT_SECRET);
      console.log('Generated refresh token length:', token.length);
      
      return c.json({ 
        token, 
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          role: user.role || 'user',
          membership_level: user.membership_level || 'basic'
        } 
      });
    } catch (error) {
      console.error('JWT signing error:', error);
      return c.json({ error: '令牌生成失败' }, 500);
    }
  } catch (error) {
    console.error('Refresh token error:', error);
    return c.json({ error: '刷新令牌过程中出现错误' }, 500);
  }
});

// 获取当前用户信息
authRoutes.get('/me', authMiddleware, async (c) => {
  const user = c.get('user');
  return c.json({ user });
});

// 获取用户列表 (需要管理员权限)
authRoutes.get('/users', authMiddleware, requireRole(['admin', 'superadmin']), async (c) => {
  const { page = '1', limit = '10' } = c.req.query();
  const offset = (parseInt(page) - 1) * parseInt(limit);
  
  // 先查询总数
  const countResult = await c.env.DB.prepare(
    'SELECT COUNT(*) as total FROM Users'
  ).first();
  
  const total = countResult.total;
  const totalPages = Math.ceil(total / parseInt(limit));
  
  const { results } = await c.env.DB.prepare(
    'SELECT id, username, email, role, membership_level, created_at, last_login, is_active FROM Users ORDER BY created_at DESC LIMIT ? OFFSET ?'
  ).bind(parseInt(limit), offset).all();
  
  c.header('Content-Type', 'application/json; charset=utf-8');
  return c.json({
    data: results,
    total: total,
    page: parseInt(page),
    pages: totalPages
  });
});

// 获取单个用户信息 (需要管理员权限)
authRoutes.get('/users/:id', authMiddleware, requireRole(['admin', 'superadmin']), async (c) => {
  const userId = c.req.param('id');
  
  const user = await c.env.DB.prepare(
    'SELECT id, username, email, role, membership_level, created_at, last_login, is_active, bio, profile_image FROM Users WHERE id = ?'
  ).bind(userId).first();
  
  if (!user) {
    return c.json({ error: '用户不存在' }, 404);
  }
  
  c.header('Content-Type', 'application/json; charset=utf-8');
  return c.json({ data: user });
});

// 创建用户 (需要管理员权限)
authRoutes.post('/users', authMiddleware, requireRole(['admin', 'superadmin']), async (c) => {
  const { username, email, password, role, membership_level, is_active } = await c.req.json();
  
  // 简单验证
  if (!username || !email || !password) {
    return c.json({ error: '用户名、邮箱和密码都是必需的' }, 400);
  }
  
  // 检查用户是否已存在
  const existingUser = await c.env.DB.prepare(
    'SELECT id FROM Users WHERE username = ? OR email = ?'
  ).bind(username, email).first();
  
  if (existingUser) {
    return c.json({ error: '用户名或邮箱已存在' }, 400);
  }
  
  // 验证角色
  const validRoles = ['user', 'admin', 'superadmin'];
  if (role && !validRoles.includes(role)) {
    return c.json({ error: '无效的角色' }, 400);
  }
  
  // 对密码进行哈希处理
  const password_hash = await hashPassword(password);
  console.log('Generated password hash:', password_hash);
  
  // 创建新用户
  const { success } = await c.env.DB.prepare(
    'INSERT INTO Users (username, email, password_hash, role, membership_level, is_active) VALUES (?, ?, ?, ?, ?, ?)'
  ).bind(
    username, 
    email, 
    password_hash, 
    role || 'user',
    membership_level || 'basic',
    is_active !== undefined ? (is_active ? 1 : 0) : 1
  ).run();
  
  if (success) {
    return c.json({ message: '用户创建成功' }, 201);
  } else {
    return c.json({ error: '创建用户失败' }, 500);
  }
});

// 更新用户信息 (需要管理员权限)
authRoutes.put('/users/:id', authMiddleware, requireRole(['admin', 'superadmin']), async (c) => {
  const userId = c.req.param('id');
  const { username, email, password, role, membership_level, is_active, bio, profile_image } = await c.req.json();
  
  console.log('更新用户请求 - 用户ID:', userId, '请求数据:', { username, email, password, role, membership_level, is_active, bio, profile_image });
  
  // 检查用户是否存在
  const existingUser = await c.env.DB.prepare(
    'SELECT id FROM Users WHERE id = ?'
  ).bind(userId).first();
  
  if (!existingUser) {
    console.log('更新用户失败 - 用户不存在:', userId);
    return c.json({ error: '用户不存在' }, 404);
  }
  
  // 构建更新语句
  const updates = [];
  const values = [];
  
  if (username !== undefined) {
    // 检查用户名是否已存在（排除当前用户）
    const duplicateUser = await c.env.DB.prepare(
      'SELECT id FROM Users WHERE username = ? AND id != ?'
    ).bind(username, userId).first();
    
    if (duplicateUser) {
      console.log('更新用户失败 - 用户名已存在:', username);
      return c.json({ error: '用户名已存在' }, 400);
    }
    updates.push('username = ?');
    values.push(username);
  }
  
  if (email !== undefined) {
    // 检查邮箱是否已存在（排除当前用户）
    const duplicateUser = await c.env.DB.prepare(
      'SELECT id FROM Users WHERE email = ? AND id != ?'
    ).bind(email, userId).first();
    
    if (duplicateUser) {
      console.log('更新用户失败 - 邮箱已存在:', email);
      return c.json({ error: '邮箱已存在' }, 400);
    }
    updates.push('email = ?');
    values.push(email);
  }
  
  if (password !== undefined && password !== '') {
    const password_hash = await hashPassword(password);
    updates.push('password_hash = ?');
    values.push(password_hash);
    console.log('更新用户密码 - 已生成新密码哈希');
  }
  
  if (role !== undefined) {
    // 验证角色
    const validRoles = ['user', 'admin', 'superadmin'];
    if (!validRoles.includes(role)) {
      console.log('更新用户失败 - 无效的角色:', role);
      return c.json({ error: '无效的角色' }, 400);
    }
    updates.push('role = ?');
    values.push(role);
  }
  
  if (membership_level !== undefined) {
    updates.push('membership_level = ?');
    values.push(membership_level);
  }
  
  if (is_active !== undefined) {
    updates.push('is_active = ?');
    values.push(is_active ? 1 : 0);
  }
  
  if (bio !== undefined) {
    updates.push('bio = ?');
    values.push(bio);
  }
  
  if (profile_image !== undefined) {
    updates.push('profile_image = ?');
    values.push(profile_image);
  }
  
  // 如果没有要更新的字段，返回成功消息
  if (updates.length === 0) {
    console.log('更新用户 - 无更新内容');
    return c.json({ message: '无更新内容' }, 200);
  }
  
  values.push(userId);
  
  console.log('执行用户更新 - SQL:', `UPDATE Users SET ${updates.join(', ')} WHERE id = ?`, '参数:', values);
  
  const { success } = await c.env.DB.prepare(
    `UPDATE Users SET ${updates.join(', ')} WHERE id = ?`
  ).bind(...values).run();
  
  if (success) {
    console.log('用户信息更新成功 - 用户ID:', userId);
    return c.json({ message: '用户信息更新成功' }, 200);
  } else {
    console.log('更新用户信息失败 - 用户ID:', userId);
    return c.json({ error: '更新用户信息失败' }, 500);
  }
});

// 删除用户 (需要超级管理员权限)
authRoutes.delete('/users/:id', authMiddleware, requireRole('superadmin'), async (c) => {
  const userId = c.req.param('id');
  
  // 检查用户是否存在
  const existingUser = await c.env.DB.prepare(
    'SELECT id FROM Users WHERE id = ?'
  ).bind(userId).first();
  
  if (!existingUser) {
    return c.json({ error: '用户不存在' }, 404);
  }
  
  // 防止用户删除自己
  const currentUser = c.get('user');
  if (currentUser && currentUser.id.toString() === userId) {
    return c.json({ error: '不能删除当前登录用户' }, 400);
  }
  
  // 删除用户相关数据
  // 删除用户的收藏
  await c.env.DB.prepare(
    'DELETE FROM UserFavorites WHERE user_id = ?'
  ).bind(userId).run();
  
  // 删除用户的评论
  await c.env.DB.prepare(
    'DELETE FROM Comments WHERE user_id = ?'
  ).bind(userId).run();
  
  // 删除用户的留言
  await c.env.DB.prepare(
    'DELETE FROM Guestbook WHERE user_id = ?'
  ).bind(userId).run();
  
  // 删除用户的会话
  await c.env.DB.prepare(
    'DELETE FROM UserSessions WHERE user_id = ?'
  ).bind(userId).run();
  
  // 删除用户的预设收藏
  await c.env.DB.prepare(
    'DELETE FROM user_favorite_presets WHERE user_id = ?'
  ).bind(userId).run();
  
  // 删除用户的文章阅读记录
  await c.env.DB.prepare(
    'DELETE FROM ArticleViews WHERE user_id = ?'
  ).bind(userId).run();
  
  // 删除用户的产品查看记录
  await c.env.DB.prepare(
    'DELETE FROM ProductViews WHERE user_id = ?'
  ).bind(userId).run();
  
  // 最后删除用户
  const { success } = await c.env.DB.prepare(
    'DELETE FROM Users WHERE id = ?'
  ).bind(userId).run();
  
  if (success) {
    return c.json({ message: '用户删除成功' });
  } else {
    return c.json({ error: '删除用户失败' }, 500);
  }
});

// 更新用户角色 (需要超级管理员权限)
authRoutes.put('/users/:id/role', authMiddleware, requireRole('superadmin'), async (c) => {
  const userId = c.req.param('id');
  const { role } = await c.req.json();
  
  if (!role) {
    return c.json({ error: '角色是必需的' }, 400);
  }
  
  // 验证角色是否有效
  const validRoles = ['user', 'admin', 'superadmin'];
  if (!validRoles.includes(role)) {
    return c.json({ error: '无效的角色' }, 400);
  }
  
  const { success } = await c.env.DB.prepare(
    'UPDATE Users SET role = ? WHERE id = ?'
  ).bind(role, userId).run();
  
  if (success) {
    return c.json({ message: '用户角色更新成功' });
  } else {
    return c.json({ error: '更新用户角色失败' }, 500);
  }
});

// 启用/禁用用户 (需要管理员权限)
authRoutes.put('/users/:id/status', authMiddleware, requireRole('admin'), async (c) => {
  const userId = c.req.param('id');
  const { is_active } = await c.req.json();
  
  if (is_active === undefined) {
    return c.json({ error: '状态是必需的' }, 400);
  }
  
  const { success } = await c.env.DB.prepare(
    'UPDATE Users SET is_active = ? WHERE id = ?'
  ).bind(is_active ? 1 : 0, userId).run();
  
  if (success) {
    return c.json({ message: `用户已${is_active ? '启用' : '禁用'}` });
  } else {
    return c.json({ error: '更新用户状态失败' }, 500);
  }
});

export default authRoutes;