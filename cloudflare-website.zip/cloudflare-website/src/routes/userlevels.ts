import { Hono } from 'hono';
import { authMiddleware, requireRole } from '../middleware/auth';
import type { Bindings, Variables } from '../types';

const userLevelRoutes = new Hono<{ Bindings: Bindings; Variables: Variables }>();

// 获取所有用户级别
userLevelRoutes.get('/', async (c) => {
  const { results } = await c.env.DB.prepare(
    "SELECT * FROM UserLevels ORDER BY min_points ASC"
  ).all();
  
  return c.json(results);
});

// 创建用户级别 (需要超级管理员权限)
userLevelRoutes.post('/', authMiddleware, requireRole('superadmin'), async (c) => {
  const { level_name, display_name, min_points, content_access } = await c.req.json();
  
  if (!level_name || !display_name || min_points === undefined || !content_access) {
    return c.json({ error: '所有字段都是必需的' }, 400);
  }
  
  const { success } = await c.env.DB.prepare(
    `INSERT INTO UserLevels (level_name, display_name, min_points, content_access)
     VALUES (?, ?, ?, ?)`
  ).bind(level_name, display_name, min_points, JSON.stringify(content_access)).run();
  
  if (success) {
    return c.json({ message: '用户级别创建成功' }, 201);
  } else {
    return c.json({ error: '创建用户级别失败' }, 500);
  }
});

// 更新用户级别 (需要超级管理员权限)
userLevelRoutes.put('/:level', authMiddleware, requireRole('superadmin'), async (c) => {
  const levelName = c.req.param('level');
  const updates = await c.req.json();
  
  // 构建更新字段
  const updateFields: string[] = [];
  const updateValues: any[] = [];
  
  Object.keys(updates).forEach(key => {
    if (key !== 'level_name') {
      updateFields.push(`${key} = ?`);
      updateValues.push(key === 'content_access' ? JSON.stringify(updates[key]) : updates[key]);
    }
  });
  
  if (updateFields.length === 0) {
    return c.json({ error: '没有提供要更新的字段' }, 400);
  }
  
  updateValues.push(levelName);
  
  const { success } = await c.env.DB.prepare(
    `UPDATE UserLevels SET ${updateFields.join(', ')} WHERE level_name = ?`
  ).bind(...updateValues).run();
  
  if (success) {
    return c.json({ message: '用户级别更新成功' });
  } else {
    return c.json({ error: '更新用户级别失败' }, 500);
  }
});

// 删除用户级别 (需要超级管理员权限)
userLevelRoutes.delete('/:level', authMiddleware, requireRole('superadmin'), async (c) => {
  const levelName = c.req.param('level');
  
  // 检查是否有用户使用此级别
  const userCount = await c.env.DB.prepare(
    "SELECT COUNT(*) as count FROM Users WHERE membership_level = ?"
  ).bind(levelName).first();
  
  if (userCount.count > 0) {
    return c.json({ error: '无法删除正在使用的用户级别' }, 400);
  }
  
  const { success } = await c.env.DB.prepare(
    "DELETE FROM UserLevels WHERE level_name = ?"
  ).bind(levelName).run();
  
  if (success) {
    return c.json({ message: '用户级别删除成功' });
  } else {
    return c.json({ error: '删除用户级别失败' }, 500);
  }
});

// 为用户分配级别 (需要管理员权限)
userLevelRoutes.post('/assign', authMiddleware, requireRole('admin'), async (c) => {
  const { user_id, level_name } = await c.req.json();
  
  if (!user_id || !level_name) {
    return c.json({ error: '用户ID和级别名称都是必需的' }, 400);
  }
  
  // 检查级别是否存在
  const levelExists = await c.env.DB.prepare(
    "SELECT 1 FROM UserLevels WHERE level_name = ?"
  ).bind(level_name).first();
  
  if (!levelExists) {
    return c.json({ error: '指定的用户级别不存在' }, 404);
  }
  
  const { success } = await c.env.DB.prepare(
    "UPDATE Users SET membership_level = ? WHERE id = ?"
  ).bind(level_name, user_id).run();
  
  if (success) {
    return c.json({ message: '用户级别分配成功' });
  } else {
    return c.json({ error: '分配用户级别失败' }, 500);
  }
});

export default userLevelRoutes;