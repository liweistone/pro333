import { Hono } from 'hono';
import { authMiddleware } from '../middleware/auth';
import { getRunningHubConfig } from '../utils/ai-config';
import { shouldAddWatermark, addWatermark } from '../utils/image-processing';
import type { Bindings, Variables } from '../types';

// 日志工具函数
const logInfo = (message: string, data?: any) => {
  console.log(`[TEXT-TO-IMAGE-INFO] ${new Date().toISOString()} - ${message}`, data ? JSON.stringify(data) : '');
};

const logError = (message: string, error?: any) => {
  console.error(`[TEXT-TO-IMAGE-ERROR] ${new Date().toISOString()} - ${message}`, error);
};

const logDebug = (message: string, data?: any) => {
  console.debug(`[TEXT-TO-IMAGE-DEBUG] ${new Date().toISOString()} - ${message}`, data ? JSON.stringify(data) : '');
};

const textToImageRoutes = new Hono<{ Bindings: Bindings; Variables: Variables }>();

// 创建文生图任务
textToImageRoutes.post('/generate', authMiddleware, async (c) => {
  logInfo('[TEXT-TO-IMAGE-CREATE] 开始创建文生图任务');
  try {
    // 获取请求参数
    const body = await c.req.json();
    logDebug('[TEXT-TO-IMAGE-CREATE] 接收到的请求参数', body);
    const { prompt, width = '864', height = '1360', amount = '1' } = body;

    // 参数验证
    if (!prompt || typeof prompt !== 'string') {
      return c.json({ error: '提示词是必需的' }, 400);
    }

    console.log('[TEXT-TO-IMAGE-CREATE] 文生图任务请求:', { prompt });

    // 准备API请求参数
    const apiUrl = 'https://www.runninghub.cn/task/openapi/ai-app/run';

    // 获取文生图应用的RunningHub配置
    const { apiKey, webappId } = getRunningHubConfig(c.env, 'text-to-image');

    const requestBody = {
      webappId: webappId,
      apiKey: apiKey,
      nodeInfoList: [
        {
          nodeId: "6",
          fieldName: "text",
          fieldValue: prompt,
          description: "提示词"
        },
        {
          nodeId: "58",
          fieldName: "width",
          fieldValue: width,
          description: "宽"
        },
        {
          nodeId: "58",
          fieldName: "height",
          fieldValue: height,
          description: "高"
        },
        {
          nodeId: "88",
          fieldName: "amount",
          fieldValue: amount,
          description: "生成张数"
        }
      ]
    };

    console.log('[TEXT-TO-IMAGE-CREATE] 发送到RunningHub API的请求:', JSON.stringify(requestBody, null, 2));

    // 调用RunningHub文生图API
    logInfo('[TEXT-TO-IMAGE-CREATE] 开始调用RunningHub文生图API');
    logDebug('[TEXT-TO-IMAGE-CREATE] API请求详情', {
      url: apiUrl,
      headers: {
        'Content-Type': 'application/json'
      },
      body: requestBody
    });

    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(requestBody)
    });

    logDebug('[TEXT-TO-IMAGE-CREATE] API响应状态', { 
      status: response.status, 
      statusText: response.statusText 
    });

    if (!response.ok) {
      const errorText = await response.text();
      logError('[TEXT-TO-IMAGE-CREATE] 文生图API调用失败', { 
        status: response.status, 
        statusText: response.statusText, 
        errorText: errorText 
      });
      
      return c.json({ error: `文生图API调用失败: ${errorText}` }, 500);
    }

    const result: any = await response.json();
    
    // 保存任务信息到数据库
    const user = c.get('user');
    if (user) {
      try {
        const { success } = await c.env.DB.prepare(
          'INSERT INTO text_to_image_tasks (user_id, task_id, prompt, status, created_at) VALUES (?, ?, ?, ?, ?)'
        ).bind(
          user.id,
          result.data.taskId,
          prompt,
          'RUNNING',
          new Date().toISOString()
        ).run();
        
        if (!success) {
          logError('[TEXT-TO-IMAGE-CREATE] 保存任务信息到数据库失败');
        }
      } catch (dbError) {
        logError('[TEXT-TO-IMAGE-CREATE] 数据库操作错误', dbError);
      }
    }
    
    // 返回任务ID
    return c.json({
      success: true,
      task_id: result.data.taskId,
      message: '文生图任务已创建'
    });
  } catch (error) {
    logError('[TEXT-TO-IMAGE-CREATE] 创建文生图任务错误', error);
    return c.json({ error: '创建文生图任务失败: ' + (error as Error).message }, 500);
  }
});

// 查询任务状态
textToImageRoutes.get('/status/:taskId', authMiddleware, async (c) => {
  logInfo('[TEXT-TO-IMAGE-STATUS] 开始查询文生图任务状态');
  try {
    const taskId = c.req.param('taskId');
    logDebug('[TEXT-TO-IMAGE-STATUS] 查询的任务ID', { taskId });
    
    if (!taskId) {
      return c.json({ error: '任务ID是必需的' }, 400);
    }

    // 准备API请求参数
    const apiUrl = 'https://www.runninghub.cn/task/openapi/outputs';

    // 获取文生图应用的RunningHub配置
    const { apiKey } = getRunningHubConfig(c.env, 'text-to-image');

    const requestBody = {
      apiKey: apiKey,
      taskId: taskId
    };

    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(requestBody)
    });

    const result: any = await response.json();
    console.log('[TEXT-TO-IMAGE-STATUS] RunningHub API响应:', JSON.stringify(result, null, 2));

    if (!response.ok) {
      const errorText = await response.text();
      console.error('[TEXT-TO-IMAGE-STATUS] 查询任务状态失败:', errorText);
      
      return c.json({ error: `查询任务状态失败: ${errorText}` }, 500);
    }

    // 更新数据库中的任务状态
    const user = c.get('user');
    if (user) {
      try {
        // 先检查任务是否存在
        const task = await c.env.DB.prepare(
          'SELECT id FROM text_to_image_tasks WHERE user_id = ? AND task_id = ?'
        ).bind(user.id, taskId).first();
        
        if (task) {
          // 特殊处理：如果返回的是数组格式，说明任务已经完成并且直接返回了结果
          if (Array.isArray(result.data)) {
            console.log('[TEXT-TO-IMAGE-STATUS] 检测到任务已完成并返回了结果数组');
            // 处理图片URL
            const imageUrls = result.data.map((item: any) => ({
              url: item.fileUrl || item.url || '',
              type: item.fileType || item.type || 'image/png',
              costTime: item.taskCostTime || item.costTime || 0
            }));
            
            // 将图片URL转换为JSON字符串
            const imageUrlsJson = JSON.stringify(imageUrls);
            
            // 更新任务状态和图片URL
            const taskStatus = 'SUCCESS';
            console.log('[TEXT-TO-IMAGE-STATUS] 更新数据库中的任务状态和图片URL:', { taskStatus, imageUrlsJson });
            const { success } = await c.env.DB.prepare(
              'UPDATE text_to_image_tasks SET status = ?, finished_at = ?, image_urls = ? WHERE user_id = ? AND task_id = ?'
            ).bind(
              taskStatus,
              new Date().toISOString(),
              imageUrlsJson,
              user.id,
              taskId
            ).run();
            
            if (!success) {
              logError('[TEXT-TO-IMAGE-STATUS] 更新任务状态和图片URL到数据库失败');
            }
          } else {
            // 更新任务状态
            // 确保正确处理RunningHub返回的状态
            const taskStatus = result.data || 'UNKNOWN';
            console.log('[TEXT-TO-IMAGE-STATUS] 更新数据库中的任务状态:', taskStatus);
            const { success } = await c.env.DB.prepare(
              'UPDATE text_to_image_tasks SET status = ? WHERE user_id = ? AND task_id = ?'
            ).bind(
              taskStatus, // RunningHub返回的状态
              user.id,
              taskId
            ).run();
            
            if (!success) {
              logError('[TEXT-TO-IMAGE-STATUS] 更新任务状态到数据库失败');
            }
          }
        }
      } catch (dbError) {
        logError('[TEXT-TO-IMAGE-STATUS] 数据库操作错误', dbError);
      }
    }
    
    // 返回任务状态
    // 根据基本文生图程序开发测试.txt，RunningHub API在查询任务状态时返回 {"code": 0, "msg": "success", "data": "SUCCESS"}
    // 我们需要确保正确处理这种格式
    const taskStatus = result.data || result.task_status || 'UNKNOWN';
    console.log('[TEXT-TO-IMAGE-STATUS] 解析后的任务状态:', taskStatus);
    
    // 特殊处理：如果返回的是数组格式，说明任务已经完成并且直接返回了结果
    if (Array.isArray(taskStatus)) {
      console.log('[TEXT-TO-IMAGE-STATUS] 检测到任务已完成并返回了结果数组，直接返回结果');
      // 直接返回结果而不是继续轮询
      return c.json({
        success: true,
        task_status: taskStatus,
        message: '任务已完成'
      });
    }
    
    // 增强状态处理，确保能正确识别所有成功状态
    const successStatuses = ['SUCCESS', 'SUCCEEDED', 'COMPLETED', 'DONE'];
    const normalizedStatus = typeof taskStatus === 'string' ? taskStatus.toUpperCase() : 'UNKNOWN';
    console.log('[TEXT-TO-IMAGE-STATUS] 标准化后的任务状态:', normalizedStatus);
    
    // 确保返回的状态是字符串类型
    const responseStatus = typeof taskStatus === 'string' ? taskStatus : JSON.stringify(taskStatus);
    
    return c.json({
      success: true,
      task_status: responseStatus,
      message: '任务状态查询成功'
    });
  } catch (error) {
    logError('[TEXT-TO-IMAGE-STATUS] 查询任务状态错误', error);
    return c.json({ error: '查询任务状态失败: ' + (error as Error).message }, 500);
  }
});

// 获取生成结果
textToImageRoutes.get('/result/:taskId', authMiddleware, async (c) => {
  logInfo('[TEXT-TO-IMAGE-RESULT] 开始获取文生图结果');
  try {
    const taskId = c.req.param('taskId');
    logDebug('[TEXT-TO-IMAGE-RESULT] 获取结果的任务ID', { taskId });
    
    if (!taskId) {
      return c.json({ error: '任务ID是必需的' }, 400);
    }

    // 准备API请求参数
    const apiUrl = 'https://www.runninghub.cn/task/openapi/outputs';

    // 获取文生图应用的RunningHub配置
    const { apiKey } = getRunningHubConfig(c.env, 'text-to-image');

    const requestBody = {
      apiKey: apiKey,
      taskId: taskId
    };

    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(requestBody)
    });

    const result: any = await response.json();
    console.log('[TEXT-TO-IMAGE-RESULT] RunningHub API响应:', JSON.stringify(result, null, 2));

    if (!response.ok) {
      const errorText = await response.text();
      console.error('[TEXT-TO-IMAGE-RESULT] 获取任务结果失败:', errorText);
      
      return c.json({ error: `获取任务结果失败: ${errorText}` }, 500);
    }

    // 检查任务是否成功
    // 根据基本文生图程序开发测试.txt，RunningHub API返回格式为 {"code": 0, "msg": "success", "data": [...]}
    if (result.code !== 0) {
      console.error('[TEXT-TO-IMAGE-RESULT] 文生图任务失败:', result.msg || '未知错误');
      return c.json({ 
        success: false,
        message: result.msg || '文生图任务执行失败'
      });
    }
    
    // 处理图片URL
    let imageUrls = [];
    
    console.log('[TEXT-TO-IMAGE-RESULT] 处理前的原始数据:', result);
    
    if (result.data && Array.isArray(result.data)) {
      imageUrls = result.data.map((item: any, index: number) => {
        console.log(`[TEXT-TO-IMAGE-RESULT] 处理第${index}个图片项:`, item);
        return {
          url: item.fileUrl || item.url || '',
          type: item.fileType || item.type || 'image/png',
          costTime: item.taskCostTime || item.costTime || 0
        };
      });
    } else if (result.data && typeof result.data === 'object') {
      // 处理单个图片对象的情况
      console.log('[TEXT-TO-IMAGE-RESULT] 处理单个图片对象:', result.data);
      imageUrls = [{
        url: result.data.fileUrl || result.data.url || '',
        type: result.data.fileType || result.data.type || 'image/png',
        costTime: result.data.taskCostTime || result.data.costTime || 0
      }];
    }
    
    console.log('[TEXT-TO-IMAGE-RESULT] 从API接收到的图片信息:', {
      imageUrls: imageUrls,
      data: result.data
    });
    
    // 如果任务成功完成，将图片下载并保存到R2存储
    if (imageUrls.length > 0) {
      try {
        const r2ImageUrls = [];
        // 为每张图片生成R2存储key并保存
        for (let i = 0; i < imageUrls.length; i++) {
          const imageUrl = imageUrls[i].url;
          console.log(`[TEXT-TO-IMAGE-RESULT] 准备下载并存储第${i}张图片:`, imageUrl);
          
          // 检查URL是否有效
          if (!imageUrl || imageUrl.trim() === '') {
            console.error(`[TEXT-TO-IMAGE-RESULT] 第${i}张图片URL无效:`, imageUrl);
            continue;
          }
          
          const imageKey = await downloadAndStoreImage(c, imageUrl, `${taskId}-${i}`);
          console.log(`[TEXT-TO-IMAGE-RESULT] 第${i}张图片存储成功，key:`, imageKey);
          
          // 更新图片URL为R2中的URL
          const r2Url = `/api/text-to-image/image/${encodeURIComponent(imageKey.split('/').pop() || '')}`;
          console.log(`[TEXT-TO-IMAGE-RESULT] 第${i}张图片R2访问URL:`, r2Url);
          r2ImageUrls.push(r2Url);
        }
        imageUrls = r2ImageUrls;
        console.log('[TEXT-TO-IMAGE-RESULT] 所有图片R2 URL:', imageUrls);
      } catch (error) {
        console.error('[TEXT-TO-IMAGE-RESULT] 保存图片到R2失败:', error);
        // 如果保存失败，仍然使用原始URL
      }
    }
    
    // 更新数据库中的任务状态为成功
    const user = c.get('user');
    if (user) {
      try {
        // 将图片URL转换为JSON字符串保存到数据库
        const imageUrlsJson = JSON.stringify(imageUrls);
        console.log('[TEXT-TO-IMAGE-RESULT] 准备保存到数据库的图片URL JSON:', imageUrlsJson);
        // 更新任务状态和图片URL
        const { success } = await c.env.DB.prepare(
          'UPDATE text_to_image_tasks SET status = ?, finished_at = ?, image_urls = ? WHERE user_id = ? AND task_id = ?'
        ).bind(
          'SUCCESS',
          new Date().toISOString(),
          imageUrlsJson,
          user.id,
          taskId
        ).run();
        
        if (!success) {
          logError('[TEXT-TO-IMAGE-RESULT] 更新任务状态到数据库失败');
        } else {
          console.log('[TEXT-TO-IMAGE-RESULT] 成功更新任务状态和图片URL到数据库');
        }
      } catch (dbError) {
        logError('[TEXT-TO-IMAGE-RESULT] 数据库操作错误', dbError);
      }
    }
    
    // 返回任务结果
    console.log('[TEXT-TO-IMAGE-RESULT] 最终返回的图片URLs:', imageUrls);
    return c.json({
      success: true,
      image_urls: imageUrls,
      message: '任务结果获取成功'
    });
  } catch (error) {
    logError('[TEXT-TO-IMAGE-RESULT] 获取任务结果错误', error);
    return c.json({ error: '获取任务结果失败: ' + (error as Error).message }, 500);
  }
});

// 下载图片并存储到R2
async function downloadAndStoreImage(c: any, imageUrl: string, taskId: string): Promise<string> {
  try {
    console.log('[TEXT-TO-IMAGE-RESULT] 开始下载图片:', imageUrl);
    
    // 检查URL是否有效
    if (!imageUrl || imageUrl.trim() === '') {
      throw new Error('图片URL为空');
    }
    
    // 下载图片
    const response = await fetch(imageUrl);
    console.log('[TEXT-TO-IMAGE-RESULT] 图片下载响应状态:', response.status);
    
    if (!response.ok) {
      throw new Error(`下载图片失败: ${response.status} ${response.statusText}`);
    }
    
    // 检查响应内容类型
    const contentType = response.headers.get('content-type');
    console.log('[TEXT-TO-IMAGE-RESULT] 图片内容类型:', contentType);
    
    // 获取图片数据
    const imageBuffer = await response.arrayBuffer();
    console.log('[TEXT-TO-IMAGE-RESULT] 图片数据大小:', imageBuffer.byteLength);
    
    // 生成R2存储key
    const timestamp = Date.now();
    const imageKey = `text-to-image/results/${timestamp}-${taskId}.png`;
    console.log('[TEXT-TO-IMAGE-RESULT] 生成R2存储key:', imageKey);
    
    // 确定内容类型
    const finalContentType = contentType && contentType.startsWith('image/') ? contentType : 'image/png';
    
    // 上传到R2
    await c.env.MY_BUCKET.put(imageKey, imageBuffer, {
      httpMetadata: {
        contentType: finalContentType,
      },
    });
    
    console.log('[TEXT-TO-IMAGE-RESULT] 图片上传到R2成功');
    return imageKey;
  } catch (error) {
    console.error('[TEXT-TO-IMAGE-RESULT] 下载并存储图片失败:', error);
    throw error;
  }
}

// 获取用户历史记录
textToImageRoutes.get('/history', authMiddleware, async (c) => {
  logInfo('[TEXT-TO-IMAGE-HISTORY] 开始获取用户历史记录');
  try {
    const user = c.get('user');
    if (!user) {
      return c.json({ error: '用户未登录' }, 401);
    }
    
    // 自动清理超过13天的历史记录
    try {
      await cleanupOldHistoryRecords(c);
    } catch (cleanupError) {
      logError('[TEXT-TO-IMAGE-HISTORY] 自动清理历史记录失败', cleanupError);
      // 不中断主要功能，继续执行
    }
    
    // 获取分页参数
    const { page = '1', limit = '20' } = c.req.query();
    const pageNum = parseInt(page);
    const limitNum = parseInt(limit);
    
    // 验证分页参数
    if (isNaN(pageNum) || pageNum < 1) {
      return c.json({ error: '无效的页码' }, 400);
    }
    
    if (isNaN(limitNum) || limitNum < 1 || limitNum > 100) {
      return c.json({ error: '无效的每页数量，每页数量应在1-100之间' }, 400);
    }
    
    // 计算偏移量
    const offset = (pageNum - 1) * limitNum;
    
    // 查询用户的历史记录
    const { results } = await c.env.DB.prepare(
      'SELECT id, user_id, task_id, prompt, status, created_at, finished_at, image_urls FROM text_to_image_tasks WHERE user_id = ? ORDER BY created_at DESC LIMIT ? OFFSET ?'
    ).bind(user.id, limitNum, offset).all();
    
    // 查询总数
    const { count } = await c.env.DB.prepare(
      'SELECT COUNT(*) as count FROM text_to_image_tasks WHERE user_id = ?'
    ).bind(user.id).first();
    
    // 计算总页数
    const totalPages = Math.ceil(count / limitNum);
    
    return c.json({
      success: true,
      data: results,
      pagination: {
        currentPage: pageNum,
        totalPages: totalPages,
        total: count,
        limit: limitNum
      },
      message: '历史记录获取成功（系统已自动清理超过13天的历史记录）'
    });
  } catch (error) {
    logError('[TEXT-TO-IMAGE-HISTORY] 获取历史记录错误', error);
    return c.json({ error: '获取历史记录失败: ' + (error as Error).message }, 500);
  }
});

// 自动清理超过13天的历史记录
async function cleanupOldHistoryRecords(c: any) {
  try {
    logInfo('[TEXT-TO-IMAGE-CLEANUP] 开始清理超过13天的历史记录');
    
    // 计算13天前的时间
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - 13);
    const cutoffDateString = cutoffDate.toISOString();
    
    // 删除超过13天的历史记录
    const result = await c.env.DB.prepare(
      'DELETE FROM text_to_image_tasks WHERE created_at < ?'
    ).bind(cutoffDateString).run();
    
    logInfo('[TEXT-TO-IMAGE-CLEANUP] 清理完成', { 
      deletedCount: result.meta?.changes || 0,
      cutoffDate: cutoffDateString 
    });
    
    return result;
  } catch (error) {
    logError('[TEXT-TO-IMAGE-CLEANUP] 清理历史记录错误', error);
    throw error;
  }
}

// 删除历史记录项
textToImageRoutes.delete('/history/:id', authMiddleware, async (c) => {
  logInfo('[TEXT-TO-IMAGE-DELETE-HISTORY] 开始删除历史记录项');
  try {
    const id = c.req.param('id');
    const user = c.get('user');
    
    if (!id) {
      return c.json({ error: '历史记录ID是必需的' }, 400);
    }
    
    // 检查历史记录是否存在且属于当前用户
    const historyItem = await c.env.DB.prepare(
      'SELECT id FROM text_to_image_tasks WHERE id = ? AND user_id = ?'
    ).bind(id, user!.id).first();
    
    if (!historyItem) {
      return c.json({ error: '历史记录不存在或无权限删除' }, 404);
    }
    
    // 删除历史记录
    const { success } = await c.env.DB.prepare(
      'DELETE FROM text_to_image_tasks WHERE id = ? AND user_id = ?'
    ).bind(id, user!.id).run();
    
    if (success) {
      return c.json({ 
        success: true,
        message: '历史记录删除成功'
      });
    } else {
      return c.json({ error: '删除历史记录失败' }, 500);
    }
  } catch (error) {
    logError('[TEXT-TO-IMAGE-DELETE-HISTORY] 删除历史记录错误', error);
    return c.json({ error: '删除历史记录失败: ' + (error as Error).message }, 500);
  }
});

// 为用户端提供图片访问服务
textToImageRoutes.get('/image/:key', async (c) => {
  try {
    const key = c.req.param('key');
    // 获取用户信息（如果已认证）
    const user = c.get('user');
    
    if (!key) {
      return c.json({ error: '文件路径不能为空' }, 400);
    }
    
    // 从R2获取对象
    const object = await c.env.MY_BUCKET.get(`text-to-image/results/${decodeURIComponent(key)}`);
    
    if (!object) {
      return c.json({ error: '文件不存在' }, 404);
    }

    // 检查用户等级，决定是否需要添加水印
    const shouldAddWatermarkFlag = await shouldAddWatermark(user, c.env.DB);

    // 如果需要添加水印，则处理图片
    if (shouldAddWatermarkFlag) {
      // 使用Cloudflare Images API添加水印
      try {
        const imageStream = object.body;
        // 实际添加水印
        const watermarkText = '© AI文生图平台';
        const watermarkedResponse = await addWatermark(
            imageStream, 
            watermarkText, 
            { 
                position: 'bottom-right',
                fontSize: 20,
                fontColor: 'rgba(255, 255, 255, 0.7)',
                opacity: 0.7
            },
            c.env
        );
        
        // 设置响应头
        const headers = new Headers();
        object.writeHttpMetadata(headers);
        headers.set('etag', object.httpEtag);
        
        // 复制水印响应的头部
        for (const [key, value] of watermarkedResponse.headers.entries()) {
            headers.set(key, value);
        }
        
        return new Response(watermarkedResponse.body, {
          headers
        });
      } catch (watermarkError) {
        console.error('添加水印失败:', watermarkError);
        // 如果水印添加失败，返回原始图像
        // 设置响应头
        const headers = new Headers();
        object.writeHttpMetadata(headers);
        headers.set('etag', object.httpEtag);
        
        return new Response(object.body, {
          headers
        });
      }
    } else {
      // 不添加水印，直接返回原图
      // 设置响应头
      const headers = new Headers();
      object.writeHttpMetadata(headers);
      headers.set('etag', object.httpEtag);
      
      // 返回文件内容
      return new Response(object.body, {
        headers
      });
    }
  } catch (error) {
    console.error('获取图片失败:', error);
    return c.json({ error: '获取图片失败: ' + (error as Error).message }, 500);
  }
});

export default textToImageRoutes;