import { Hono } from 'hono';
import { sign, verify } from 'hono/jwt';
import { authMiddleware } from '../middleware/auth';
import { getAliyunConfig } from '../utils/ai-config';
import { shouldAddWatermark, addWatermark } from '../utils/image-processing';
import type { Bindings, Variables } from '../types';

// 日志工具函数
const logInfo = (message: string, data?: any) => {
  console.log(`[AI-TRYON-INFO] ${new Date().toISOString()} - ${message}`, data ? JSON.stringify(data) : '');
};

const logError = (message: string, error?: any) => {
  console.error(`[AI-TRYON-ERROR] ${new Date().toISOString()} - ${message}`, error);
};

const logDebug = (message: string, data?: any) => {
  console.debug(`[AI-TRYON-DEBUG] ${new Date().toISOString()} - ${message}`, data ? JSON.stringify(data) : '');
};

// 添加API调用日志函数
const logApiCall = async (url: string, options: any, response: Response, body?: any) => {
  console.log('[AI-API-CALL]', {
    timestamp: new Date().toISOString(),
    url,
    method: options.method,
    status: response.status,
    requestBody: options.body ? JSON.parse(options.body) : undefined,
    responseBody: body,
    headers: Object.fromEntries(response.headers)
  });
};

const aiTryonRoutes = new Hono<{ Bindings: Bindings; Variables: Variables }>();

// 创建试衣任务
aiTryonRoutes.post('/create', authMiddleware, async (c) => {
  logInfo('[AI-TRYON-CREATE] 开始创建AI试衣任务');
  try {
    // 获取请求参数
    const body = await c.req.json();
    logDebug('[AI-TRYON-CREATE] 接收到的请求参数', body);
    const {
      model_image_url,
      top_garment_url,
      bottom_garment_url,
      resolution = -1,
      restore_face = true,
      image_count = 1  // 添加图片数量参数，默认为1
    } = body;

    // 参数验证
    if (!model_image_url || typeof model_image_url !== 'string') {
      return c.json({ error: '模特图片URL是必需的' }, 400);
    }

    if (!top_garment_url && !bottom_garment_url) {
      return c.json({ error: '至少需要提供上装或下装图片URL' }, 400);
    }

    console.log('[AI-TRYON-CREATE] AI试衣任务请求:', {
      model_image_url,
      top_garment_url,
      bottom_garment_url,
      resolution,
      restore_face,
      image_count
    });

    // 获取AI试衣应用的阿里云配置
    const { apiKey } = getAliyunConfig(c.env, 'general');
    if (!apiKey || apiKey === 'YOUR_DASHSCOPE_API_KEY_HERE' || apiKey.startsWith('sk-') === false) {
      return c.json({ 
        error: '阿里云百炼API密钥未正确配置，请在wrangler.toml文件中设置有效的DASHSCOPE_API_KEY' 
      }, 500);
    }

    // 处理分辨率参数
    // 前端传递的是倍数（-1, 1.5, 2, 2.5, 3），需要转换为API期望的具体分辨率值
    let actualResolution = resolution;
    if (typeof resolution === 'string') {
      actualResolution = parseInt(resolution);
    }
    
    // 根据阿里云API文档，分辨率应该是具体的数值
    // -1: 保持原图尺寸
    // 1024: 576x1024 分辨率
    // 1280: 720x1280 分辨率
    if (typeof actualResolution === 'number') {
      if (actualResolution === -1) {
        // 保持原图尺寸，无需转换
        actualResolution = -1;
      } else if (actualResolution === 1.5) {
        // 1.5倍对应 1024 (576x1024)
        actualResolution = 1024;
      } else if (actualResolution === 2 || actualResolution === 2.5 || actualResolution === 3) {
        // 2倍及以上对应 1280 (720x1280)
        actualResolution = 1280;
      } else if (actualResolution > 0 && actualResolution < 10) {
        // 其他倍数也映射到支持的分辨率
        actualResolution = actualResolution <= 1.5 ? 1024 : 1280;
      }
      // 如果已经是具体的分辨率值（1024, 1280等），则保持不变
    }

    // 确保人脸策略参数是布尔值
    let actualRestoreFace = restore_face;
    if (typeof restore_face === 'string') {
      actualRestoreFace = restore_face === 'true';
    }

    // 验证图片数量参数
    let actualImageCount = image_count;
    if (typeof image_count === 'string') {
      actualImageCount = parseInt(image_count);
    }
    
    // 确保图片数量在有效范围内（1-4）
    if (actualImageCount < 1 || actualImageCount > 4) {
      actualImageCount = 1;
    }

    // 准备API请求参数
    const apiUrl = 'https://dashscope.aliyuncs.com/api/v1/services/aigc/image2image/image-synthesis';

    // 根据服装类型确定传递哪些参数
    const input: any = {
      person_image_url: model_image_url
    };

    // 根据图库类型确定服装参数
    // 如果是dresses类型，只传入top_garment_url（连衣裙/连体服）
    // 如果是tops类型，只传入top_garment_url（上装）
    // 如果是bottoms类型，只传入bottom_garment_url（下装）
    if (top_garment_url && bottom_garment_url) {
      // 上下装组合试穿
      input.top_garment_url = top_garment_url;
      input.bottom_garment_url = bottom_garment_url;
    } else if (top_garment_url) {
      // 只有上装或连衣裙
      input.top_garment_url = top_garment_url;
    } else if (bottom_garment_url) {
      // 只有下装
      input.bottom_garment_url = bottom_garment_url;
    }

    const requestBody = {
      model: 'aitryon-plus',
      input: input,
      parameters: {
        resolution: actualResolution,
        restore_face: actualRestoreFace,
        image_count: actualImageCount  // 添加图片数量参数
      }
    };

    console.log('[AI-TRYON-CREATE] 发送到阿里云API的请求:', JSON.stringify(requestBody, null, 2));

    // 调用阿里云AI试衣API
    logInfo('[AI-TRYON-CREATE] 开始调用阿里云AI试衣API');
    logDebug('[AI-TRYON-CREATE] API请求详情', {
      url: apiUrl,
      headers: {
        'Content-Type': 'application/json',
        'X-DashScope-Async': 'enable'
      },
      body: requestBody
    });
    
    // 增强重试机制，专门处理下载超时问题
    let retryCount = 0;
    const maxRetries = 5; // 增加重试次数
    let lastError: any = null;
    
    while (retryCount <= maxRetries) {
      let timeoutId: any = null;
      try {
        // 为每次请求创建新的AbortController
        const controller = new AbortController();
        // 设置更长的超时时间（30秒）
        timeoutId = setTimeout(() => controller.abort(), 30000);
        
        const response = await fetch(apiUrl, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiKey}`,
            'X-DashScope-Async': 'enable',
            // 添加更多有助于API访问的头部
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
          },
          body: JSON.stringify(requestBody),
          signal: controller.signal
        });
        
        if (timeoutId) {
          clearTimeout(timeoutId);
        }
        
        logDebug('[AI-TRYON-CREATE] API响应状态', { 
          status: response.status, 
          statusText: response.statusText 
        });

        if (!response.ok) {
          const errorText = await response.text();
          logError('[AI-TRYON-CREATE] AI试衣API调用失败', { 
            status: response.status, 
            statusText: response.statusText, 
            errorText: errorText 
          });
          
          // 如果是API密钥错误，返回更友好的提示
          if (errorText.includes('InvalidApiKey')) {
            return c.json({ 
              error: '阿里云百炼API密钥无效，请检查wrangler.toml文件中的DASHSCOPE_API_KEY配置' 
            }, 500);
          }
          
          // 如果是数据检查超时错误，返回更具体的提示
          if (errorText.includes('Download the media resource timed out') || errorText.includes('timed out during the data inspection process')) {
            logError('[AI-TRYON-CREATE] AI服务下载图片超时，可能是临时URL过期或网络问题');
            // 增加重试延迟，使用指数退避
            retryCount++;
            if (retryCount <= maxRetries) {
              const delay = Math.pow(2, retryCount) * 3000; // 指数退避，基础延迟3秒
              logInfo(`[AI-TRYON-CREATE] 第${retryCount}次重试，等待${delay/1000}秒后重试`);
              await new Promise(resolve => setTimeout(resolve, delay));
              continue;
            }
            return c.json({ 
              error: `AI服务下载图片超时，请稍后重试` 
            }, 500);
          }
          
          // 如果是参数错误，返回更具体的提示
          if (errorText.includes('InvalidParameter') || errorText.includes('InvalidInput')) {
            logError('[AI-TRYON-CREATE] 参数错误', { errorText });
            return c.json({ 
              error: `参数错误: ${errorText}` 
            }, 400);
          }
          
          // 如果是URL错误，返回更具体的提示
          if (errorText.includes('InvalidURL')) {
            logError('[AI-TRYON-CREATE] 图片URL无效', { errorText });
            return c.json({ 
              error: `图片URL无效，请检查图片是否可访问` 
            }, 400);
          }
          
          // 如果是模特图错误
          if (errorText.includes('InvalidPerson')) {
            logError('[AI-TRYON-CREATE] 模特图不合规', { errorText });
            return c.json({ 
              error: `模特图不合规: ${errorText}` 
            }, 400);
          }
          
          // 如果是服饰图错误
          if (errorText.includes('InvalidGarment')) {
            logError('[AI-TRYON-CREATE] 缺少服饰图片', { errorText });
            return c.json({ 
              error: `缺少服饰图片: ${errorText}` 
            }, 400);
          }
          
          // 如果是图片尺寸错误
          if (errorText.includes('InvalidInputLength')) {
            logError('[AI-TRYON-CREATE] 图片尺寸或文件大小不符合要求', { errorText });
            return c.json({ 
              error: `图片尺寸或文件大小不符合要求: ${errorText}` 
            }, 400);
          }
          
          return c.json({ error: `AI试衣API调用失败: ${errorText}` }, 500);
        }

        const result: any = await response.json();
        
        // 返回任务ID
        return c.json({
          success: true,
          task_id: result.output.task_id,
          message: '试衣任务已创建',
          image_count: actualImageCount
        });
      } catch (error: any) {
        if (timeoutId) {
          clearTimeout(timeoutId); // 确保清除超时
        }
        lastError = error;
        logError(`[AI-TRYON-CREATE] 第${retryCount + 1}次调用阿里云API失败`, error);
        
        // 检查是否是SSL协议错误或网络错误
        if (error instanceof TypeError && (error.message.includes('fetch failed') || error.message.includes('SSL') || error.message.includes('ECONNRESET') || error.message.includes('ECONNREFUSED'))) {
          logError('[AI-TRYON-CREATE] 网络连接问题，可能是SSL协议错误');
          retryCount++;
          if (retryCount <= maxRetries) {
            const delay = Math.pow(2, retryCount) * 4000; // 对于网络错误使用更长的延迟
            logInfo(`[AI-TRYON-CREATE] 第${retryCount}次重试，等待${delay/1000}秒后重试`);
            await new Promise(resolve => setTimeout(resolve, delay));
            continue;
          }
        } else if (error.name === 'AbortError') {
          // 处理超时错误
          logError('[AI-TRYON-CREATE] 请求超时');
          retryCount++;
          if (retryCount <= maxRetries) {
            const delay = Math.pow(2, retryCount) * 3000;
            logInfo(`[AI-TRYON-CREATE] 第${retryCount}次重试，等待${delay/1000}秒后重试`);
            await new Promise(resolve => setTimeout(resolve, delay));
            continue;
          }
        } else {
          retryCount++;
          if (retryCount <= maxRetries) {
            const delay = Math.pow(2, retryCount) * 3000; // 指数退避，基础延迟3秒
            logInfo(`[AI-TRYON-CREATE] 第${retryCount}次重试，等待${delay/1000}秒后重试`);
            await new Promise(resolve => setTimeout(resolve, delay));
            continue;
          }
        }
      }
    }
    
    // 如果重试次数用完仍然失败
    throw new Error(`创建试衣任务失败: ${lastError?.message || '未知错误'}`);
  } catch (error) {
    logError('[AI-TRYON-CREATE] 创建试衣任务错误', error);
    return c.json({ error: '创建试衣任务失败: ' + (error as Error).message }, 500);
  }
});

// 查询任务状态
aiTryonRoutes.get('/status/:taskId', authMiddleware, async (c) => {
  logInfo('[AI-TRYON-STATUS] 开始查询AI试衣任务状态');
  try {
    const taskId = c.req.param('taskId');
    logDebug('[AI-TRYON-STATUS] 查询的任务ID', { taskId });
    
    if (!taskId) {
      return c.json({ error: '任务ID是必需的' }, 400);
    }

    // 获取AI试衣应用的阿里云配置
    const { apiKey } = getAliyunConfig(c.env, 'general');
    if (!apiKey || apiKey === 'YOUR_DASHSCOPE_API_KEY_HERE' || apiKey.startsWith('sk-') === false) {
      return c.json({ 
        error: '阿里云百炼API密钥未正确配置，请在wrangler.toml文件中设置有效的DASHSCOPE_API_KEY' 
      }, 500);
    }

    // 调用阿里云API查询任务状态
    const apiUrl = `https://dashscope.aliyuncs.com/api/v1/tasks/${taskId}`;

    const response = await fetch(apiUrl, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${apiKey}`
      }
    });

    // 记录API调用日志
    const result: any = await response.json();
    await logApiCall(apiUrl, { method: 'GET', headers: { 'Authorization': `Bearer ${apiKey}` } }, response, result);

    if (!response.ok) {
      const errorText = await response.text();
      console.error('[AI-TRYON-STATUS] 查询任务状态失败:', errorText);
      
      // 如果是API密钥错误，返回更友好的提示
      if (errorText.includes('InvalidApiKey')) {
        return c.json({ 
          error: '阿里云百炼API密钥无效，请检查wrangler.toml文件中的DASHSCOPE_API_KEY配置' 
        }, 500);
      }
      
      return c.json({ error: `查询任务状态失败: ${errorText}` }, 500);
    }

    // 检查任务是否失败
    if (result.output.task_status === 'FAILED') {
      console.error('[AI-TRYON-STATUS] AI试衣任务失败:', result.output.message || '未知错误');
      return c.json({ 
        success: true,
        task_status: 'FAILED',
        message: result.output.message || '试衣任务执行失败'
      });
    }
    
    // 处理图片URL，确保使用HTTPS
    let imageUrls = [];
    
    // 检查是否有多张图片
    // 首先检查多张图片的情况（优先检查数组）
    if (result.output.image_urls && Array.isArray(result.output.image_urls)) {
      // 多张图片的情况
      imageUrls = result.output.image_urls.map((url: string) => {
        if (url.startsWith('http://')) {
          return url.replace('http://', 'https://');
        } else if (url.startsWith('//')) {
          return 'https:' + url;
        }
        return url;
      });
    } 
    // 然后检查单张图片的情况
    else if (result.output.image_url) {
      // 单张图片的情况
      let imageUrl = result.output.image_url;
      if (imageUrl) {
        // 确保URL使用HTTPS协议
        if (imageUrl.startsWith('http://')) {
          imageUrl = imageUrl.replace('http://', 'https://');
        }
        // 处理其他可能的HTTP链接
        else if (imageUrl.startsWith('//')) {
          imageUrl = 'https:' + imageUrl;
        }
      }
      imageUrls.push(imageUrl);
    }
    // 检查是否在usage字段中有image_count信息
    else if (result.usage && result.usage.image_count && result.output.image_url) {
      // 如果usage中指定了图片数量，但只返回了一张图片URL，可能需要特殊处理
      // 这种情况下，我们仍然只有一张图片
      let imageUrl = result.output.image_url;
      if (imageUrl) {
        // 确保URL使用HTTPS协议
        if (imageUrl.startsWith('http://')) {
          imageUrl = imageUrl.replace('http://', 'https://');
        }
        // 处理其他可能的HTTP链接
        else if (imageUrl.startsWith('//')) {
          imageUrl = 'https:' + imageUrl;
        }
      }
      imageUrls.push(imageUrl);
    }
    
    console.log('[AI-TRYON-STATUS] 从阿里云API接收到的图片信息:', {
      imageUrls: imageUrls,
      usage: result.usage,
      output: result.output
    });
    
    // 如果任务成功完成，将图片保存到R2存储
    if (result.output.task_status === 'SUCCEEDED' && imageUrls.length > 0) {
      try {
        const r2ImageUrls = [];
        // 为每张图片生成R2存储key并保存
        for (let i = 0; i < imageUrls.length; i++) {
          const imageUrl = imageUrls[i];
          const imageKey = await downloadAndStoreImage(c, imageUrl, `${taskId}-${i}`);
          // 更新图片URL为R2中的URL
          r2ImageUrls.push(`/api/ai-tryon/result/${encodeURIComponent(imageKey.split('/').pop() || '')}`);
        }
        imageUrls = r2ImageUrls;
      } catch (error) {
        console.error('[AI-TRYON-STATUS] 保存图片到R2失败:', error);
        // 如果保存失败，仍然使用原始URL
      }
    }
    
    // 返回任务状态
    return c.json({
      success: true,
      task_status: result.output.task_status,
      image_urls: imageUrls,  // 返回图片URL数组
      usage: result.usage,    // 返回usage信息
      message: '任务状态查询成功'
    });
  } catch (error) {
    logError('[AI-TRYON-STATUS] 查询任务状态错误', error);
    return c.json({ error: '查询任务状态失败: ' + (error as Error).message }, 500);
  }
});

// 下载图片并存储到R2
async function downloadAndStoreImage(c: any, imageUrl: string, taskId: string): Promise<string> {
  try {
    // 下载图片
    const response = await fetch(imageUrl);
    if (!response.ok) {
      throw new Error(`下载图片失败: ${response.status} ${response.statusText}`);
    }
    
    // 获取图片数据
    const imageBuffer = await response.arrayBuffer();
    
    // 生成R2存储key
    const imageKey = `ai-tryon/results/${Date.now()}-${taskId}.jpg`;
    
    // 上传到R2
    await c.env.MY_BUCKET.put(imageKey, imageBuffer, {
      httpMetadata: {
        contentType: 'image/jpeg',
      },
    });
    
    return imageKey;
  } catch (error) {
    console.error('下载并存储图片失败:', error);
    throw error;
  }
}

// 获取图库图片列表（包括预设图片和用户上传图片）
aiTryonRoutes.get('/gallery/:type', async (c) => {
  logInfo('开始获取图库图片列表');
  try {
    const user = c.get('user');
    const type = c.req.param('type'); // models, tops, bottoms, dresses
    logDebug('请求的图库类型', { type });
    
    // 获取分页参数
    const { page = '1', limit = '20' } = c.req.query();
    const pageNum = parseInt(page);
    const limitNum = parseInt(limit);
    logDebug('分页参数', { page: pageNum, limit: limitNum });
    
    // 验证分页参数
    if (isNaN(pageNum) || pageNum < 1) {
      return c.json({ error: '无效的页码' }, 400);
    }
    
    if (isNaN(limitNum) || limitNum < 1 || limitNum > 100) {
      return c.json({ error: '无效的每页数量，每页数量应在1-100之间' }, 400);
    }
    
    // 验证类型参数
    const validTypes = ['models', 'tops', 'bottoms', 'dresses'];
    if (!validTypes.includes(type)) {
      return c.json({ error: '无效的图库类型' }, 400);
    }
    
    const images = [];
    
    // 获取预设图片（所有人都可以访问）
    const presetPrefix = `ai-tryon/${type}/`;
    const presetListing = await c.env.MY_BUCKET.list({
      prefix: presetPrefix,
      delimiter: '/'
    });
    
    // 处理预设图片
    for (const object of presetListing.objects) {
      if (object.key === presetPrefix) continue;
      
      const name = object.key.substring(presetPrefix.length);
      images.push({
        key: object.key,
        name: name,
        size: object.size,
        uploadedAt: object.uploaded.toISOString(),
        url: `/api/ai-tryon/image/${encodeURIComponent(object.key)}`,
        type: 'preset'
      });
    }
    
    // 如果用户已登录，获取用户上传的图片
    if (user) {
      const userPrefix = `ai-tryon/user-${user.id}/uploads/${type}/`;
      const userListing = await c.env.MY_BUCKET.list({
        prefix: userPrefix,
        delimiter: '/'
      });
      
      // 处理用户上传的图片
      for (const object of userListing.objects) {
        if (object.key === userPrefix) continue;
        
        const name = object.key.substring(userPrefix.length);
        // 从完整的key中提取文件名部分，保持原有的目录结构信息
        const filename = object.key.split('/').pop() || '';
        images.push({
          key: object.key,  // 使用完整key，以便生成稳定URL时能正确找到文件
          name: name,
          size: object.size,
          uploadedAt: object.uploaded.toISOString(),
          url: `/api/ai-tryon/user-image/${user.id}/${encodeURIComponent(filename)}`,
          type: 'user',
          userId: user.id,  // 添加用户ID字段
          filename: filename  // 添加文件名字段，用于生成稳定URL
        });
      }
    }
    
    // 按上传时间排序，最新的在前
    images.sort((a, b) => {
      return new Date(b.uploadedAt).getTime() - new Date(a.uploadedAt).getTime();
    });
    
    // 实现分页
    const total = images.length;
    const offset = (pageNum - 1) * limitNum;
    const paginatedImages = images.slice(offset, offset + limitNum);
    
    // 计算分页信息
    const totalPages = Math.ceil(total / limitNum);
    
    return c.json({
      success: true,
      data: paginatedImages,
      pagination: {
        currentPage: pageNum,
        totalPages: totalPages,
        total: total,
        limit: limitNum
      },
      message: '图库列表获取成功'
    });
  } catch (error) {
    logError('获取图库列表失败', error);
    return c.json({ error: '获取图库列表失败: ' + (error as Error).message }, 500);
  }
});

// 为用户端提供图片访问服务
aiTryonRoutes.get('/image/:key', async (c) => {
  try {
    const key = c.req.param('key');
    
    if (!key) {
      return c.json({ error: '文件路径不能为空' }, 400);
    }
    
    // 从R2获取对象
    const object = await c.env.MY_BUCKET.get(decodeURIComponent(key));
    
    if (!object) {
      return c.json({ error: '文件不存在' }, 404);
    }
    
    // 设置响应头
    const headers = new Headers();
    object.writeHttpMetadata(headers);
    headers.set('etag', object.httpEtag);
    
    // 返回文件内容
    return new Response(object.body, {
      headers
    });
  } catch (error) {
    console.error('获取图片失败:', error);
    return c.json({ error: '获取图片失败: ' + (error as Error).message }, 500);
  }
});

// 为用户端提供用户上传图片访问服务
aiTryonRoutes.get('/user-image/:userId/:filename', authMiddleware, async (c) => {
  try {
    const userId = c.req.param('userId');
    const filename = c.req.param('filename');
    const currentUser = c.get('user');
    
    if (!currentUser) {
      return c.json({ error: '用户未登录' }, 401);
    }
    
    // 验证用户权限（用户只能访问自己上传的图片）
    if (currentUser.id.toString() !== userId) {
      return c.json({ error: '无权访问此图片' }, 403);
    }
    
    if (!filename) {
      return c.json({ error: '文件名不能为空' }, 400);
    }
    
    // 为了向后兼容，我们需要尝试不同的key格式
    // 首先尝试完整的路径（包含类型目录）
    let object = null;
    const types = ['models', 'tops', 'bottoms', 'dresses'];
    
    for (const type of types) {
      const key = `ai-tryon/user-${userId}/uploads/${type}/${filename}`;
      object = await c.env.MY_BUCKET.get(key);
      if (object) {
        break;
      }
    }
    
    // 如果没找到，再尝试不包含类型目录的路径（向后兼容）
    if (!object) {
      const key = `ai-tryon/user-${userId}/uploads/${filename}`;
      object = await c.env.MY_BUCKET.get(key);
    }
    
    if (!object) {
      return c.json({ error: '文件不存在' }, 404);
    }
    
    // 设置响应头
    const headers = new Headers();
    object.writeHttpMetadata(headers);
    headers.set('etag', object.httpEtag);
    
    // 返回文件内容
    return new Response(object.body, {
      headers
    });
  } catch (error) {
    console.error('获取用户图片失败:', error);
    return c.json({ error: '获取用户图片失败: ' + (error as Error).message }, 500);
  }
});

// 用户上传图片
aiTryonRoutes.post('/upload', authMiddleware, async (c) => {
  logInfo('开始上传图片');
  try {
    const user = c.get('user');
    if (!user) {
      logError('用户未登录');
      return c.json({ error: '用户未登录' }, 401);
    }
    
    const formData = await c.req.parseBody();
    const file = formData.file as File;
    const type = formData.type as string; // models, tops, bottoms, dresses
    
    if (!file) {
      return c.json({ error: '没有上传文件' }, 400);
    }
    
    if (!type || !['models', 'tops', 'bottoms', 'dresses'].includes(type)) {
      return c.json({ error: '无效的图片类型' }, 400);
    }
    
    // 检查文件大小（限制为5MB）
    if (file.size > 5 * 1024 * 1024) {
      return c.json({ error: '文件大小不能超过5MB' }, 400);
    }
    
    // 检查文件类型
    const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    if (!allowedTypes.includes(file.type)) {
      return c.json({ error: '只允许上传JPEG、PNG、GIF或WebP格式的图片' }, 400);
    }
    
    // 生成R2存储key
    const key = `ai-tryon/user-${user.id}/uploads/${type}/${Date.now()}-${file.name}`;
    
    // 上传到R2
    await c.env.MY_BUCKET.put(key, file.stream(), {
      httpMetadata: {
        contentType: file.type,
      },
    });
    
    return c.json({
      success: true,
      message: '图片上传成功',
      key: key
    });
  } catch (error) {
    logError('上传图片失败', error);
    return c.json({ error: '上传图片失败: ' + (error as Error).message }, 500);
  }
});

// 为用户端提供试衣结果图片访问服务
aiTryonRoutes.get('/result/:key', async (c) => {
  try {
    const key = c.req.param('key');
    
    if (!key) {
      return c.json({ error: '文件路径不能为空' }, 400);
    }
    
    // 从R2获取对象
    const object = await c.env.MY_BUCKET.get(`ai-tryon/results/${decodeURIComponent(key)}`);
    
    if (!object) {
      return c.json({ error: '文件不存在' }, 404);
    }
    
    // 设置响应头
    const headers = new Headers();
    object.writeHttpMetadata(headers);
    headers.set('etag', object.httpEtag);
    
    // 返回文件内容
    return new Response(object.body, {
      headers
    });
  } catch (error) {
    console.error('获取试衣结果图片失败:', error);
    return c.json({ error: '获取试衣结果图片失败: ' + (error as Error).message }, 500);
  }
});

// 为AI服务提供临时公开访问URL
aiTryonRoutes.get('/temp-public-url/:key', authMiddleware, async (c) => {
  try {
    const key = c.req.param('key');
    const user = c.get('user');
    
    console.log('生成预设图片临时URL，用户:', user, 'key:', key);
    
    if (!user) {
      return c.json({ error: '用户未登录' }, 401);
    }
    
    if (!key) {
      return c.json({ error: '文件路径不能为空' }, 400);
    }
    
    const decodedKey = decodeURIComponent(key);
    
    console.log('解码后的key:', decodedKey);
    
    // 检查文件是否存在
    const object = await c.env.MY_BUCKET.get(decodedKey);
    if (!object) {
      console.log('预设图片文件不存在，key:', decodedKey);
      return c.json({ error: '文件不存在' }, 404);
    }
    
    console.log('预设图片文件存在，大小:', object.size);
    
    // 生成一个临时的公开访问URL（使用JWT令牌）
    // 增加有效期到2小时（7200秒），确保AI服务有足够时间下载
    const payload = {
      key: decodedKey,
      exp: Math.floor(Date.now() / 1000) + 7200 // 2小时过期
    };
    
    const tempToken = await sign(payload, c.env.JWT_SECRET);
    // 使用主应用中的临时访问端点
    const url = `${new URL(c.req.url).origin}/api/ai-tryon/temp-access/${tempToken}`;
    
    console.log('生成的临时URL:', url);
    
    return c.json({
      success: true,
      url: url,
      expiresAt: new Date(Date.now() + 7200 * 1000).toISOString()
    });
  } catch (error) {
    console.error('生成临时公开URL失败:', error);
    return c.json({ error: '生成临时公开URL失败: ' + (error as Error).message }, 500);
  }
});

// 为AI服务提供更稳定的临时公开访问URL（直接基于文件key）
aiTryonRoutes.get('/stable-temp-public-url/:key', authMiddleware, async (c) => {
  try {
    const key = c.req.param('key');
    const user = c.get('user');
    
    console.log('[STABLE-TEMP-URL] 生成预设图片稳定临时URL，用户:', user?.id, 'key:', key);
    
    if (!user) {
      return c.json({ error: '用户未登录' }, 401);
    }
    
    if (!key) {
      return c.json({ error: '文件路径不能为空' }, 400);
    }
    
    const decodedKey = decodeURIComponent(key);
    
    console.log('[STABLE-TEMP-URL] 解码后的key:', decodedKey);
    
    // 检查文件是否存在
    const object = await c.env.MY_BUCKET.get(decodedKey);
    if (!object) {
      console.log('[STABLE-TEMP-URL] 预设图片文件不存在，key:', decodedKey);
      return c.json({ error: '文件不存在' }, 404);
    }
    
    console.log('[STABLE-TEMP-URL] 预设图片文件存在，大小:', object.size);
    
    // 生成直接访问URL，避免JWT令牌问题
    // 延长有效期到48小时（172800秒），确保AI服务有足够时间下载
    const expiresAt = Date.now() + 172800 * 1000; // 48小时
    // 对key进行URL编码以确保路径中的斜杠被正确处理
    const encodedKey = encodeURIComponent(decodedKey);
    const url = `${new URL(c.req.url).origin}/api/ai-tryon/direct-image/${encodedKey}`;
    
    console.log('[STABLE-TEMP-URL] 生成的稳定临时URL:', url);
    
    return c.json({
      success: true,
      url: url,
      expiresAt: new Date(expiresAt).toISOString()
    });
  } catch (error) {
    console.error('[STABLE-TEMP-URL] 生成稳定临时公开URL失败:', error);
    return c.json({ error: '生成稳定临时公开URL失败: ' + (error as Error).message }, 500);
  }
});

// 为AI服务提供用户上传图片的临时公开访问URL
aiTryonRoutes.get('/temp-public-user-url/:userId/:filename', authMiddleware, async (c) => {
  try {
    const userId = c.req.param('userId');
    const filename = c.req.param('filename');
    const currentUser = c.get('user');
    
    console.log('生成用户图片临时URL，当前用户:', currentUser, 'userId:', userId, 'filename:', filename);
    
    if (!currentUser) {
      console.log('用户未登录');
      return c.json({ error: '用户未登录' }, 401);
    }
    
    // 验证用户权限（用户只能访问自己上传的图片）
    // 添加类型转换以确保比较正确
    const currentUserId = currentUser.id.toString();
    console.log(`权限验证: 当前用户ID=${currentUserId}, 请求用户ID=${userId}`);
    if (currentUserId !== userId) {
      console.log(`权限验证失败: 当前用户ID=${currentUserId}, 请求用户ID=${userId}`);
      return c.json({ error: '无权访问此图片' }, 403);
    }
    
    if (!filename) {
      console.log('文件名为空');
      return c.json({ error: '文件名不能为空' }, 400);
    }
    
    // 为了向后兼容，我们需要尝试不同的key格式
    // 首先尝试完整的路径（包含类型目录）
    let object = null;
    let actualKey = '';
    const types = ['models', 'tops', 'bottoms', 'dresses'];
    
    for (const type of types) {
      const key = `ai-tryon/user-${userId}/uploads/${type}/${filename}`;
      console.log('尝试查找文件:', key);
      object = await c.env.MY_BUCKET.get(key);
      if (object) {
        actualKey = key;
        console.log('找到文件:', key);
        break;
      }
    }
    
    // 如果没找到，再尝试不包含类型目录的路径（向后兼容）
    if (!object) {
      const key = `ai-tryon/user-${userId}/uploads/${filename}`;
      console.log('尝试查找文件（向后兼容）:', key);
      object = await c.env.MY_BUCKET.get(key);
      if (object) {
        actualKey = key;
        console.log('找到文件（向后兼容）:', key);
      }
    }
    
    if (!object) {
      console.log('用户上传的图片文件不存在');
      return c.json({ error: '文件不存在' }, 404);
    }
    
    console.log('用户上传的图片文件存在，大小:', object.size);
    
    // 生成一个临时的公开访问URL（使用JWT令牌）
    // 增加有效期到2小时（7200秒），确保AI服务有足够时间下载
    const payload = {
      key: actualKey,
      exp: Math.floor(Date.now() / 1000) + 7200 // 2小时过期
    };
    
    const tempToken = await sign(payload, c.env.JWT_SECRET);
    // 使用主应用中的临时访问端点
    const url = `${new URL(c.req.url).origin}/api/ai-tryon/temp-access/${tempToken}`;
    
    console.log('生成的临时URL:', url);
    
    return c.json({
      success: true,
      url: url,
      expiresAt: new Date(Date.now() + 7200 * 1000).toISOString()
    });
  } catch (error) {
    console.error('生成用户图片临时公开URL失败:', error);
    return c.json({ error: '生成用户图片临时公开URL失败: ' + (error as Error).message }, 500);
  }
});

// 为AI服务提供用户上传图片的更稳定临时公开访问URL
aiTryonRoutes.get('/stable-temp-public-user-url/:userId/:key', authMiddleware, async (c) => {
  try {
    const userId = c.req.param('userId');
    const key = c.req.param('key');
    const currentUser = c.get('user');
    
    console.log('[STABLE-TEMP-USER-URL] 生成用户图片稳定临时URL，当前用户:', currentUser?.id, 'userId:', userId, 'key:', key);
    
    if (!currentUser) {
      console.log('[STABLE-TEMP-USER-URL] 用户未登录');
      return c.json({ error: '用户未登录' }, 401);
    }
    
    // 验证用户权限（用户只能访问自己上传的图片）
    const currentUserId = currentUser.id.toString();
    console.log(`[STABLE-TEMP-USER-URL] 权限验证: 当前用户ID=${currentUserId}, 请求用户ID=${userId}`);
    if (currentUserId !== userId) {
      console.log(`[STABLE-TEMP-USER-URL] 权限验证失败: 当前用户ID=${currentUserId}, 请求用户ID=${userId}`);
      return c.json({ error: '无权访问此图片' }, 403);
    }
    
    if (!key) {
      console.log('[STABLE-TEMP-USER-URL] 文件key为空');
      return c.json({ error: '文件key不能为空' }, 400);
    }
    
    // 解码key
    const decodedKey = decodeURIComponent(key);
    console.log('[STABLE-TEMP-USER-URL] 解码后的key:', decodedKey);
    
    // 直接使用解码后的完整key查找文件
    const object = await c.env.MY_BUCKET.get(decodedKey);
    
    if (!object) {
      console.log('[STABLE-TEMP-USER-URL] 用户上传的图片文件不存在', { key: decodedKey });
      return c.json({ error: '文件不存在' }, 404);
    }
    
    console.log('[STABLE-TEMP-USER-URL] 用户上传的图片文件存在，大小:', object.size);
    
    // 生成直接访问URL，避免JWT令牌问题
    // 延长有效期到48小时，确保AI服务有足够时间下载
    const expiresAt = Date.now() + 172800 * 1000; // 48小时
    // 对actualKey进行编码以确保URL安全
    const encodedKey = encodeURIComponent(decodedKey);
    const url = `${new URL(c.req.url).origin}/api/ai-tryon/direct-image/${encodedKey}`;
    
    console.log('[STABLE-TEMP-USER-URL] 生成的稳定临时URL:', url);
    
    return c.json({
      success: true,
      url: url,
      expiresAt: new Date(expiresAt).toISOString()
    });
  } catch (error) {
    console.error('[STABLE-TEMP-USER-URL] 生成用户图片稳定临时公开URL失败:', error);
    return c.json({ error: '生成用户图片稳定临时公开URL失败: ' + (error as Error).message }, 500);
  }
});

// 添加直接图片访问端点（无需认证，专为AI服务设计）
aiTryonRoutes.get('/direct-image/:key', async (c) => {
  try {
    const key = c.req.param('key');
    // 获取用户信息（如果已认证）
    const user = c.get('user');
    
    console.log('[DIRECT-IMAGE] 直接图片访问端点被调用', { key });
    
    if (!key) {
      console.log('[DIRECT-IMAGE] 文件key不能为空');
      return c.json({ error: '文件key不能为空' }, 400);
    }
    
    const decodedKey = decodeURIComponent(key);
    console.log('[DIRECT-IMAGE] 解码后的key:', decodedKey);
    
    // 从R2获取对象
    const object = await c.env.MY_BUCKET.get(decodedKey);
    
    if (!object) {
      console.log('[DIRECT-IMAGE] 文件不存在', { key: decodedKey });
      return c.json({ error: '文件不存在' }, 404);
    }
    
    console.log('[DIRECT-IMAGE] 文件获取成功', { 
      key: decodedKey, 
      size: object.size,
      uploaded: object.uploaded,
      httpEtag: object.httpEtag
    });

    // 检查用户等级，决定是否需要添加水印
    const shouldAddWatermarkFlag = await shouldAddWatermark(user, c.env.DB);

    // 如果需要添加水印，则处理图片
    if (shouldAddWatermarkFlag) {
      // 使用Cloudflare Images API添加水印
      try {
        const imageStream = object.body;
        // 实际添加水印
        const watermarkText = '© AI试衣平台';
        const watermarkedResponse = await addWatermark(
            imageStream, 
            watermarkText, 
            { 
                position: 'bottom-right',
                fontSize: 20,
                fontColor: 'rgba(255, 255, 255, 0.7)',
                opacity: 0.7
            },
            c.env
        );
        
        // 设置响应头，专门为阿里云试衣API优化
        const headers = new Headers();
        object.writeHttpMetadata(headers);
        headers.set('etag', object.httpEtag);
        
        // 专门为阿里云试衣API设置的头部
        headers.set('Access-Control-Allow-Origin', '*');
        headers.set('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS');
        headers.set('Access-Control-Allow-Headers', '*');
        headers.set('Access-Control-Max-Age', '86400'); // 24小时
        
        // 增强的缓存控制，提高访问速度
        headers.set('Cache-Control', 'public, max-age=172800, immutable'); // 48小时缓存，标记为不可变
        
        // 设置内容安全策略，允许阿里云服务访问
        headers.set('Content-Security-Policy', 'default-src * data: blob: http: https:; img-src * data: blob: http: https:; connect-src *');
        
        // 设置其他有助于阿里云访问的头部
        headers.set('Timing-Allow-Origin', '*');
        headers.set('X-Content-Type-Options', 'nosniff');
        headers.set('X-Frame-Options', 'DENY');
        
        // 添加阿里云服务友好的头部
        headers.set('Accept-Ranges', 'bytes');
        
        // 对于图片文件，确保Content-Type正确设置
        if (!headers.has('Content-Type')) {
          const lowerKey = decodedKey.toLowerCase();
          if (lowerKey.endsWith('.jpg') || lowerKey.endsWith('.jpeg')) {
            headers.set('Content-Type', 'image/jpeg');
          } else if (lowerKey.endsWith('.png')) {
            headers.set('Content-Type', 'image/png');
          } else if (lowerKey.endsWith('.gif')) {
            headers.set('Content-Type', 'image/gif');
          } else if (lowerKey.endsWith('.webp')) {
            headers.set('Content-Type', 'image/webp');
          } else {
            // 默认设置为jpeg
            headers.set('Content-Type', 'image/jpeg');
          }
        }
        
        // 添加一些额外的头部来改善阿里云服务的访问体验
        headers.set('X-Robots-Tag', 'noindex, nofollow');
        headers.set('X-XSS-Protection', '1; mode=block');
        
        console.log('[DIRECT-IMAGE] 返回响应头:');
        for (const [headerKey, value] of headers.entries()) {
          console.log(`${headerKey}: ${value}`);
        }
        
        // 复制水印响应的头部
        for (const [key, value] of watermarkedResponse.headers.entries()) {
            headers.set(key, value);
        }
        
        // 返回水印图片
        return new Response(watermarkedResponse.body, {
          headers
        });
      } catch (watermarkError) {
        console.error('[DIRECT-IMAGE] 添加水印失败:', watermarkError);
        // 如果水印添加失败，返回原始图像
        
        // 设置响应头，专门为阿里云试衣API优化
        const headers = new Headers();
        object.writeHttpMetadata(headers);
        headers.set('etag', object.httpEtag);
        
        // 专门为阿里云试衣API设置的头部
        headers.set('Access-Control-Allow-Origin', '*');
        headers.set('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS');
        headers.set('Access-Control-Allow-Headers', '*');
        headers.set('Access-Control-Max-Age', '86400'); // 24小时
        
        // 增强的缓存控制，提高访问速度
        headers.set('Cache-Control', 'public, max-age=172800, immutable'); // 48小时缓存，标记为不可变
        
        // 设置内容安全策略，允许阿里云服务访问
        headers.set('Content-Security-Policy', 'default-src * data: blob: http: https:; img-src * data: blob: http: https:; connect-src *');
        
        // 设置其他有助于阿里云访问的头部
        headers.set('Timing-Allow-Origin', '*');
        headers.set('X-Content-Type-Options', 'nosniff');
        headers.set('X-Frame-Options', 'DENY');
        
        // 添加阿里云服务友好的头部
        headers.set('Accept-Ranges', 'bytes');
        
        // 对于图片文件，确保Content-Type正确设置
        if (!headers.has('Content-Type')) {
          const lowerKey = decodedKey.toLowerCase();
          if (lowerKey.endsWith('.jpg') || lowerKey.endsWith('.jpeg')) {
            headers.set('Content-Type', 'image/jpeg');
          } else if (lowerKey.endsWith('.png')) {
            headers.set('Content-Type', 'image/png');
          } else if (lowerKey.endsWith('.gif')) {
            headers.set('Content-Type', 'image/gif');
          } else if (lowerKey.endsWith('.webp')) {
            headers.set('Content-Type', 'image/webp');
          } else {
            // 默认设置为jpeg
            headers.set('Content-Type', 'image/jpeg');
          }
        }
        
        // 添加一些额外的头部来改善阿里云服务的访问体验
        headers.set('X-Robots-Tag', 'noindex, nofollow');
        headers.set('X-XSS-Protection', '1; mode=block');
        
        console.log('[DIRECT-IMAGE] 返回响应头:');
        for (const [headerKey, value] of headers.entries()) {
          console.log(`${headerKey}: ${value}`);
        }
        
        // 返回文件内容
        return new Response(object.body, {
          headers
        });
      }
    } else {
      // 不添加水印，直接返回原图
      // 设置响应头，专门为阿里云试衣API优化
      const headers = new Headers();
      object.writeHttpMetadata(headers);
      headers.set('etag', object.httpEtag);
      
      // 专门为阿里云试衣API设置的头部
      headers.set('Access-Control-Allow-Origin', '*');
      headers.set('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS');
      headers.set('Access-Control-Allow-Headers', '*');
      headers.set('Access-Control-Max-Age', '86400'); // 24小时
      
      // 增强的缓存控制，提高访问速度
      headers.set('Cache-Control', 'public, max-age=172800, immutable'); // 48小时缓存，标记为不可变
      
      // 设置内容安全策略，允许阿里云服务访问
      headers.set('Content-Security-Policy', 'default-src * data: blob: http: https:; img-src * data: blob: http: https:; connect-src *');
      
      // 设置其他有助于阿里云访问的头部
      headers.set('Timing-Allow-Origin', '*');
      headers.set('X-Content-Type-Options', 'nosniff');
      headers.set('X-Frame-Options', 'DENY');
      
      // 添加阿里云服务友好的头部
      headers.set('Accept-Ranges', 'bytes');
      
      // 对于图片文件，确保Content-Type正确设置
      if (!headers.has('Content-Type')) {
        const lowerKey = decodedKey.toLowerCase();
        if (lowerKey.endsWith('.jpg') || lowerKey.endsWith('.jpeg')) {
          headers.set('Content-Type', 'image/jpeg');
        } else if (lowerKey.endsWith('.png')) {
          headers.set('Content-Type', 'image/png');
        } else if (lowerKey.endsWith('.gif')) {
          headers.set('Content-Type', 'image/gif');
        } else if (lowerKey.endsWith('.webp')) {
          headers.set('Content-Type', 'image/webp');
        } else {
          // 默认设置为jpeg
          headers.set('Content-Type', 'image/jpeg');
        }
      }
      
      // 添加一些额外的头部来改善阿里云服务的访问体验
      headers.set('X-Robots-Tag', 'noindex, nofollow');
      headers.set('X-XSS-Protection', '1; mode=block');
      
      console.log('[DIRECT-IMAGE] 返回响应头:');
      for (const [headerKey, value] of headers.entries()) {
        console.log(`${headerKey}: ${value}`);
      }
      
      // 返回文件内容
      return new Response(object.body, {
        headers
      });
    }
  } catch (error) {
    console.error('[DIRECT-IMAGE] 直接图片访问失败:', error);
    return c.json({ error: '图片访问失败: ' + (error as Error).message }, 500);
  }
});

// 临时访问端点（无需认证）
// 注意：此端点已移至主应用文件(src/index.ts)中，以避免认证中间件的影响

export default aiTryonRoutes;