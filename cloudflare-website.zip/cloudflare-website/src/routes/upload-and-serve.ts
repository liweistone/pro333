import { Hono } from 'hono';
import { authMiddleware } from '../middleware/auth';
import type { Bindings, Variables } from '../types';

const uploadRoutes = new Hono<{ Bindings: Bindings; Variables: Variables }>();

// 上传用户图片并生成专用访问URL
uploadRoutes.post('/upload-for-ai-tryon', authMiddleware, async (c) => {
  try {
    const user = c.get('user');
    if (!user) {
      return c.json({ error: '用户未登录' }, 401);
    }
    
    const formData = await c.req.parseBody();
    const file = formData.file as File;
    
    if (!file) {
      return c.json({ error: '没有上传文件' }, 400);
    }
    
    // 检查文件大小（限制为5MB）
    if (file.size > 5 * 1024 * 1024) {
      return c.json({ error: '文件大小不能超过5MB' }, 400);
    }
    
    // 检查文件类型
    const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    if (!allowedTypes.includes(file.type)) {
      return c.json({ error: '只允许上传JPEG、PNG、GIF或WebP格式的图片' }, 400);
    }
    
    // 生成R2存储key
    const timestamp = Date.now();
    const randomString = Math.random().toString(36).substring(2, 15);
    const fileExtension = file.name.split('.').pop() || 'png';
    const key = `ai-tryon/user-uploads/${user.id}/${timestamp}-${randomString}.${fileExtension}`;
    
    // 上传到R2
    await c.env.MY_BUCKET.put(key, file.stream(), {
      httpMetadata: {
        contentType: file.type,
      },
    });
    
    // 生成专用访问URL（为阿里云试衣API优化）
    const publicUrl = `${new URL(c.req.url).origin}/api/upload/public-image/${key}`;
    
    return c.json({
      success: true,
      message: '图片上传成功',
      key: key,
      public_url: publicUrl
    });
  } catch (error) {
    console.error('上传图片失败:', error);
    return c.json({ error: '上传图片失败: ' + (error as Error).message }, 500);
  }
});

// 为阿里云试衣API提供专门优化的图片访问端点
uploadRoutes.get('/public-image/*', async (c) => {
  try {
    // 从路径中提取key
    const path = c.req.path;
    let key = path.replace('/api/upload/public-image/', '');
    
    // 如果key仍然包含通配符，我们需要更精确地提取
    if (key.includes('*') || key.trim() === '') {
      // 尝试从参数中获取key
      const fullPath = c.req.url;
      const url = new URL(fullPath);
      const pathname = url.pathname;
      const keyStartIndex = pathname.indexOf('/public-image/') + '/public-image/'.length;
      if (keyStartIndex > '/public-image/'.length - 1) {
        const extractedKey = pathname.substring(keyStartIndex);
        if (extractedKey) {
          key = extractedKey;
        }
      }
    }
    
    console.log('阿里云试衣API专用图片访问端点被调用，key:', key);
    
    if (!key) {
      return c.json({ error: '文件key不能为空' }, 400);
    }
    
    // 从R2获取对象
    const object = await c.env.MY_BUCKET.get(key);
    
    if (!object) {
      console.log('文件不存在，key:', key);
      return c.json({ error: '文件不存在' }, 404);
    }
    
    console.log('文件获取成功，大小:', object.size);
    
    // 设置响应头，专门为阿里云试衣API优化
    const headers = new Headers();
    object.writeHttpMetadata(headers);
    headers.set('etag', object.httpEtag);
    
    // 专门为阿里云试衣API设置的头部
    headers.set('Access-Control-Allow-Origin', '*');
    headers.set('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS');
    headers.set('Access-Control-Allow-Headers', '*');
    headers.set('Access-Control-Max-Age', '86400'); // 24小时
    
    // 设置缓存控制，提高访问速度
    headers.set('Cache-Control', 'public, max-age=7200'); // 2小时缓存
    
    // 设置内容安全策略，允许阿里云服务访问
    headers.set('Content-Security-Policy', 'default-src * data: blob: http: https:; img-src * data: blob: http: https:; connect-src *');
    
    // 设置其他有助于阿里云访问的头部
    headers.set('Timing-Allow-Origin', '*');
    
    // 对于图片文件，确保Content-Type正确设置
    if (!headers.has('Content-Type')) {
      const lowerKey = key.toLowerCase();
      if (lowerKey.endsWith('.jpg') || lowerKey.endsWith('.jpeg')) {
        headers.set('Content-Type', 'image/jpeg');
      } else if (lowerKey.endsWith('.png')) {
        headers.set('Content-Type', 'image/png');
      } else if (lowerKey.endsWith('.gif')) {
        headers.set('Content-Type', 'image/gif');
      } else if (lowerKey.endsWith('.webp')) {
        headers.set('Content-Type', 'image/webp');
      }
    }
    
    console.log('返回响应头:');
    for (const [headerKey, value] of headers.entries()) {
      console.log(`${headerKey}: ${value}`);
    }
    
    // 返回文件内容
    return new Response(object.body, {
      headers
    });
  } catch (error) {
    console.error('阿里云试衣API图片访问失败:', error);
    return c.json({ error: '图片访问失败: ' + (error as Error).message }, 500);
  }
});

export default uploadRoutes;