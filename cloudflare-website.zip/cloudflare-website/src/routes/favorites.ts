import { Hono } from 'hono';
import { authMiddleware } from '../middleware/auth';
import type { Bindings, Variables } from '../types';

const favoriteRoutes = new Hono<{ Bindings: Bindings; Variables: Variables }>();

// 添加收藏（文章/产品/预设）
favoriteRoutes.post('/', authMiddleware, async (c) => {
  const { item_type, item_id } = await c.req.json();
  const user = c.get('user');
  
  if (!user) {
    return c.json({ error: '需要登录才能收藏' }, 401);
  }
  
  if (!item_type || !item_id) {
    return c.json({ error: 'item_type 和 item_id 是必需的' }, 400);
  }
  
  // 验证项目是否存在
  let itemExists = false;
  if (item_type === 'article') {
    itemExists = await c.env.DB.prepare(
      "SELECT 1 FROM Articles WHERE id = ?"
    ).bind(item_id).first();
  } else if (item_type === 'product') {
    itemExists = await c.env.DB.prepare(
      "SELECT 1 FROM Products WHERE id = ?"
    ).bind(item_id).first();
  } else if (item_type === 'preset') {
    itemExists = await c.env.DB.prepare(
      "SELECT 1 FROM presets WHERE id = ?"
    ).bind(item_id).first();
  }
  
  if (!itemExists) {
    return c.json({ error: '收藏的项目不存在' }, 404);
  }
  
  // 添加收藏
  const { success } = await c.env.DB.prepare(
    "INSERT OR IGNORE INTO UserFavorites (user_id, item_type, item_id) VALUES (?, ?, ?)"
  ).bind(user.id, item_type, item_id).run();
  
  if (success) {
    // 更新收藏计数
    if (item_type === 'article') {
      await c.env.DB.prepare(
        "UPDATE Articles SET favorite_count = favorite_count + 1 WHERE id = ?"
      ).bind(item_id).run();
    } else if (item_type === 'product') {
      await c.env.DB.prepare(
        "UPDATE Products SET favorite_count = favorite_count + 1 WHERE id = ?"
      ).bind(item_id).run();
    } else if (item_type === 'preset') {
      await c.env.DB.prepare(
        "UPDATE presets SET favorite_count = favorite_count + 1 WHERE id = ?"
      ).bind(item_id).run();
    }
    
    return c.json({ message: '已添加到收藏' });
  } else {
    return c.json({ error: '收藏失败' }, 500);
  }
});

// 移除收藏（文章/产品/预设）
favoriteRoutes.delete('/:type/:id', authMiddleware, async (c) => {
  const itemType = c.req.param('type');
  const itemId = c.req.param('id');
  const user = c.get('user');
  
  if (!user) {
    return c.json({ error: '需要登录才能取消收藏' }, 401);
  }
  
  if (!['article', 'product', 'preset'].includes(itemType)) {
    return c.json({ error: 'item_type 无效' }, 400);
  }
  
  const { success } = await c.env.DB.prepare(
    "DELETE FROM UserFavorites WHERE user_id = ? AND item_type = ? AND item_id = ?"
  ).bind(user.id, itemType, itemId).run();
  
  if (success) {
    // 更新收藏计数
    if (itemType === 'article') {
      await c.env.DB.prepare(
        "UPDATE Articles SET favorite_count = favorite_count - 1 WHERE id = ?"
      ).bind(itemId).run();
    } else if (itemType === 'product') {
      await c.env.DB.prepare(
        "UPDATE Products SET favorite_count = favorite_count - 1 WHERE id = ?"
      ).bind(itemId).run();
    } else if (itemType === 'preset') {
      await c.env.DB.prepare(
        "UPDATE presets SET favorite_count = favorite_count - 1 WHERE id = ?"
      ).bind(itemId).run();
    }
    
    return c.json({ message: '已取消收藏' });
  } else {
    return c.json({ error: '取消收藏失败' }, 500);
  }
});

// 获取用户收藏
favoriteRoutes.get('/', authMiddleware, async (c) => {
  const user = c.get('user');
  const { page = '1', limit = '20' } = c.req.query();
  const offset = (parseInt(page) - 1) * parseInt(limit);
  
  if (!user) {
    return c.json({ error: '需要登录才能查看收藏' }, 401);
  }
  
  const { results } = await c.env.DB.prepare(`
    SELECT uf.*, 
           a.title as article_title, 
           a.cover_image as article_image,
           p.name as product_name,
           p.cover_image as product_image,
           pr.title as preset_title,
           pr.image as preset_image
    FROM UserFavorites uf
    LEFT JOIN Articles a ON uf.item_type = 'article' AND uf.item_id = a.id
    LEFT JOIN Products p ON uf.item_type = 'product' AND uf.item_id = p.id
    LEFT JOIN presets pr ON uf.item_type = 'preset' AND uf.item_id = pr.id
    WHERE uf.user_id = ?
    ORDER BY uf.created_at DESC
    LIMIT ? OFFSET ?
  `).bind(user.id, parseInt(limit), offset).all();
  
  return c.json(results);
});

// 获取特定类型收藏统计
favoriteRoutes.get('/stats', authMiddleware, async (c) => {
  const user = c.get('user');
  
  if (!user) {
    return c.json({ error: '需要登录才能查看统计' }, 401);
  }
  
  const stats = await c.env.DB.prepare(`
    SELECT item_type, COUNT(*) as count
    FROM UserFavorites
    WHERE user_id = ?
    GROUP BY item_type
  `).bind(user.id).all();
  
  return c.json(stats.results);
});

export default favoriteRoutes;