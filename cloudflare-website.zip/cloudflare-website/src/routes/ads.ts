import { Hono } from 'hono';
import { authMiddleware, requireRole } from '../middleware/auth';
import type { Bindings, Variables } from '../types';

const adRoutes = new Hono<{ Bindings: Bindings; Variables: Variables }>();

// 获取ComfyUI插件端广告列表
adRoutes.get('/', async (c) => {
  try {
    const { limit } = c.req.query();
    
    const limitValue = limit ? parseInt(limit) : 10;
    
    const { results } = await c.env.DB.prepare(`
      SELECT * FROM ads 
      WHERE is_active = 1
      ORDER BY priority DESC, created_at DESC
      LIMIT ?
    `).bind(limitValue).all();
    
    return c.json({ success: true, data: results });
  } catch (error: any) {
    console.error('Error fetching ads:', error);
    return c.json({ success: false, error: '获取广告失败: ' + (error.message || '未知错误') }, 500);
  }
});

// 创建ComfyUI插件端广告 (需要管理员权限)
adRoutes.post('/', authMiddleware, requireRole(['admin', 'superadmin']), async (c) => {
  try {
    const { 
      title, 
      image_url, 
      link_url, 
      description, 
      priority = 0,
      is_active = 1
    } = await c.req.json();
    
    if (!title || !image_url || !link_url) {
      return c.json({ success: false, error: '标题、图片URL和链接URL都是必需的' }, 400);
    }
    
    const id = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
    const now = Math.floor(Date.now() / 1000);
    
    const { success } = await c.env.DB.prepare(
      `INSERT INTO ads 
       (id, title, image_url, link_url, description, priority, is_active, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).bind(id, title, image_url, link_url, description, priority, is_active, now, now).run();
    
    if (success) {
      return c.json({ id, message: '广告创建成功' }, 201);
    } else {
      return c.json({ success: false, error: '创建广告失败' }, 500);
    }
  } catch (error: any) {
    console.error('创建广告失败:', error);
    return c.json({ success: false, error: '创建广告失败: ' + (error.message || '未知错误') }, 500);
  }
});

// 更新ComfyUI插件端广告 (需要管理员权限)
adRoutes.put('/:id', authMiddleware, requireRole(['admin', 'superadmin']), async (c) => {
  try {
    const adId = c.req.param('id');
    
    // 验证广告ID
    if (!adId || adId === 'null' || adId === 'undefined') {
      return c.json({ success: false, error: '广告ID无效' }, 400);
    }
    
    const updates = await c.req.json();
    const now = Math.floor(Date.now() / 1000);
    
    // 构建更新字段
    const updateFields: string[] = [];
    const updateValues: any[] = [];
    
    Object.keys(updates).forEach(key => {
      if (key !== 'id') {
        updateFields.push(`${key} = ?`);
        updateValues.push(updates[key]);
      }
    });
    
    updateFields.push('updated_at = ?');
    updateValues.push(now);
    
    updateValues.push(adId);
    
    const { success } = await c.env.DB.prepare(
      `UPDATE ads SET ${updateFields.join(', ')} WHERE id = ?`
    ).bind(...updateValues).run();
    
    if (success) {
      return c.json({ success: true, message: '广告更新成功' });
    } else {
      return c.json({ success: false, error: '更新广告失败' }, 500);
    }
  } catch (error: any) {
    console.error('更新广告失败:', error);
    return c.json({ success: false, error: '更新广告失败: ' + (error.message || '未知错误') }, 500);
  }
});

// 删除ComfyUI插件端广告 (需要管理员权限)
adRoutes.delete('/:id', authMiddleware, requireRole(['admin', 'superadmin']), async (c) => {
  try {
    const adId = c.req.param('id');
    
    // 验证广告ID
    if (!adId || adId === 'null' || adId === 'undefined') {
      return c.json({ success: false, error: '广告ID无效' }, 400);
    }
    
    // 检查广告是否存在
    const existingAd = await c.env.DB.prepare(
      "SELECT id FROM ads WHERE id = ?"
    ).bind(adId).first();
    
    if (!existingAd) {
      return c.json({ success: false, error: '广告不存在' }, 404);
    }
    
    const { success } = await c.env.DB.prepare(
      "DELETE FROM ads WHERE id = ?"
    ).bind(adId).run();
    
    if (success) {
      return c.json({ success: true, message: '广告删除成功' });
    } else {
      return c.json({ success: false, error: '删除广告失败' }, 500);
    }
  } catch (error: any) {
    console.error('删除广告失败:', error);
    return c.json({ success: false, error: '删除广告失败: ' + (error.message || '未知错误') }, 500);
  }
});

// 获取单个ComfyUI插件端广告详情
adRoutes.get('/:id', async (c) => {
  try {
    const adId = c.req.param('id');
    
    // 验证广告ID
    if (!adId || adId === 'null' || adId === 'undefined') {
      return c.json({ success: false, error: '广告ID无效' }, 400);
    }
    
    const ad = await c.env.DB.prepare(`
      SELECT * FROM ads WHERE id = ?
    `).bind(adId).first();
    
    if (!ad) {
      return c.json({ success: false, error: '广告不存在' }, 404);
    }
    
    return c.json({ success: true, data: ad });
  } catch (error: any) {
    console.error('获取广告详情失败:', error);
    return c.json({ success: false, error: '获取广告详情失败: ' + (error.message || '未知错误') }, 500);
  }
});

export default adRoutes;