import { Hono } from 'hono';
import { authMiddleware, requireRole } from '../middleware/auth';
import type { Bindings, Variables } from '../types';
import { updateImageUsageRecord } from './articles'; // 导入图片引用更新函数

const adRoutes = new Hono<{ Bindings: Bindings; Variables: Variables }>();

// 获取网站首页广告列表
adRoutes.get('/', async (c) => {
  try {
    const { limit } = c.req.query();
    
    const limitValue = limit ? parseInt(limit) : 10;
    
    const { results } = await c.env.DB.prepare(`
      SELECT * FROM Advertisements 
      WHERE is_active = 1
      ORDER BY sort_order ASC
      LIMIT ?
    `).bind(limitValue).all();
    
    // 处理image_url字段，确保返回的是完整的URL
    const adsWithImageUrl = results.map((ad: any) => ({
      ...ad,
      image_url: ad.image_url ? `/api/images/public/${ad.image_url}` : null
    }));
    
    return c.json({ success: true, data: adsWithImageUrl });
  } catch (error: any) {
    console.error('Error fetching advertisements:', error);
    return c.json({ success: false, error: '获取广告失败: ' + (error.message || '未知错误') }, 500);
  }
});

// 创建网站首页广告 (需要管理员权限)
adRoutes.post('/', authMiddleware, requireRole(['admin', 'superadmin']), async (c) => {
  try {
    const { 
      title, 
      image_url, 
      link_url, 
      description, 
      sort_order = 0,
      is_active = 1
    } = await c.req.json();
    
    if (!title || !image_url) {
      return c.json({ success: false, error: '标题和图片URL是必需的' }, 400);
    }
    
    const { success } = await c.env.DB.prepare(
      `INSERT INTO Advertisements 
       (title, image_url, link_url, description, sort_order, is_active)
       VALUES (?, ?, ?, ?, ?, ?)`
    ).bind(title, image_url, link_url, description, sort_order, is_active).run();
    
    if (success) {
      // 如果有图片，更新图片的引用状态
      if (image_url) {
        // 获取新插入的广告ID
        const adId = (await c.env.DB.prepare('SELECT last_insert_rowid() as id').first()).id;
        await updateImageUsageRecord(c, image_url, 'advertisement', adId.toString(), true);
      }
      
      return c.json({ success: true, message: '广告创建成功' }, 201);
    } else {
      return c.json({ success: false, error: '创建广告失败' }, 500);
    }
  } catch (error: any) {
    console.error('创建广告失败:', error);
    return c.json({ success: false, error: '创建广告失败: ' + (error.message || '未知错误') }, 500);
  }
});

// 更新网站首页广告 (需要管理员权限)
adRoutes.put('/:id', authMiddleware, requireRole(['admin', 'superadmin']), async (c) => {
  try {
    const adId = c.req.param('id');
    
    // 验证广告ID
    if (!adId || adId === 'null' || adId === 'undefined') {
      return c.json({ success: false, error: '广告ID无效' }, 400);
    }
    
    const updates = await c.req.json();
    
    // 先获取原始广告信息，以便检查图片变化
    const originalAd = await c.env.DB.prepare(
      'SELECT image_url FROM Advertisements WHERE id = ?'
    ).bind(adId).first();
    
    // 检查广告是否存在
    if (!originalAd) {
      return c.json({ success: false, error: '广告不存在' }, 404);
    }
    
    // 构建更新字段
    const updateFields: string[] = [];
    const updateValues: any[] = [];
    
    Object.keys(updates).forEach(key => {
      if (key !== 'id') {
        updateFields.push(`${key} = ?`);
        updateValues.push(updates[key]);
      }
    });
    
    updateValues.push(adId);
    
    const { success } = await c.env.DB.prepare(
      `UPDATE Advertisements SET ${updateFields.join(', ')} WHERE id = ?`
    ).bind(...updateValues).run();
    
    if (success) {
      // 如果图片发生了变化，更新相关图片的引用状态
      if (originalAd && originalAd.image_url !== updates.image_url) {
        // 取消旧图片的引用状态
        if (originalAd.image_url) {
          await updateImageUsageRecord(c, originalAd.image_url, 'advertisement', adId, false);
        }
        // 设置新图片的引用状态
        if (updates.image_url) {
          await updateImageUsageRecord(c, updates.image_url, 'advertisement', adId, true);
        }
      }
      
      return c.json({ success: true, message: '广告更新成功' });
    } else {
      return c.json({ success: false, error: '更新广告失败' }, 500);
    }
  } catch (error: any) {
    console.error('更新广告失败:', error);
    return c.json({ success: false, error: '更新广告失败: ' + (error.message || '未知错误') }, 500);
  }
});

// 删除网站首页广告 (需要管理员权限)
adRoutes.delete('/:id', authMiddleware, requireRole(['admin', 'superadmin']), async (c) => {
  try {
    const adId = c.req.param('id');
    
    // 验证广告ID
    if (!adId || adId === 'null' || adId === 'undefined') {
      return c.json({ success: false, error: '广告ID无效' }, 400);
    }
    
    // 先获取广告信息，用于取消图片引用
    const ad = await c.env.DB.prepare(
      'SELECT image_url FROM Advertisements WHERE id = ?'
    ).bind(adId).first();
    
    // 检查广告是否存在
    if (!ad) {
      return c.json({ success: false, error: '广告不存在' }, 404);
    }
    
    const { success } = await c.env.DB.prepare(
      "DELETE FROM Advertisements WHERE id = ?"
    ).bind(adId).run();
    
    if (success) {
      // 如果广告有图片，取消图片引用状态
      if (ad && ad.image_url) {
        await updateImageUsageRecord(c, ad.image_url, 'advertisement', adId, false);
      }
      
      return c.json({ success: true, message: '广告删除成功' });
    } else {
      return c.json({ success: false, error: '删除广告失败' }, 500);
    }
  } catch (error: any) {
    console.error('删除广告失败:', error);
    return c.json({ success: false, error: '删除广告失败: ' + (error.message || '未知错误') }, 500);
  }
});

// 获取单个网站首页广告详情
adRoutes.get('/:id', async (c) => {
  try {
    const adId = c.req.param('id');
    
    // 验证广告ID
    if (!adId || adId === 'null' || adId === 'undefined') {
      return c.json({ success: false, error: '广告ID无效' }, 400);
    }
    
    const ad = await c.env.DB.prepare(`
      SELECT * FROM Advertisements WHERE id = ?
    `).bind(adId).first();
    
    if (!ad) {
      return c.json({ success: false, error: '广告不存在' }, 404);
    }
    
    // 处理image_url字段，确保返回的是完整的URL
    const adWithImageUrl = {
      ...ad,
      image_url: ad.image_url ? `/api/images/public/${ad.image_url}` : null
    };
    
    return c.json({ success: true, data: adWithImageUrl });
  } catch (error: any) {
    console.error('获取广告详情失败:', error);
    return c.json({ success: false, error: '获取广告详情失败: ' + (error.message || '未知错误') }, 500);
  }
});

export default adRoutes;