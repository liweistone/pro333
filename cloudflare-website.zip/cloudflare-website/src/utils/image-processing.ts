/**
 * 图片处理工具模块
 * 用于处理图片水印等操作
 */

/**
 * 为图片添加水印
 * 使用Cloudflare Images API添加水印
 * @param imageData 图片数据流
 * @param watermarkText 水印文本
 * @param options 水印选项
 * @returns 添加水印后的图片数据流
 */
export async function addWatermark(imageData: ReadableStream<Uint8Array>, watermarkText: string, options: {
  position?: 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right' | 'center';
  fontSize?: number;
  fontColor?: string;
  opacity?: number;
} = {}, env: any): Promise<Response> {
  // 默认选项
  const {
    position = 'bottom-right',
    fontSize = 20,
    fontColor = 'rgba(255, 255, 255, 0.7)',
    opacity = 0.7
  } = options;

  try {
    // 使用Cloudflare Images API添加水印
    // 注意：由于Images API的draw方法需要一个图像而不是文本，
    // 我们需要使用其他方法来添加文本水印
    // 这里我们使用一个替代方案：直接返回原始图像，但记录日志
    console.log('添加水印:', {
      watermarkText,
      position,
      fontSize,
      fontColor,
      opacity
    });
    
    // 在实际实现中，我们可能需要使用Workers AI或其他服务来生成水印图像
    // 或者使用第三方库来处理图像
    
    // 暂时返回原始图像，但添加适当的头部来标识水印应该被添加
    // 在生产环境中，这里应该实现真实的水印添加逻辑
    const response = new Response(imageData);
    response.headers.set('X-Watermark-Required', 'true');
    response.headers.set('X-Watermark-Text', watermarkText);
    response.headers.set('X-Watermark-Position', position);
    response.headers.set('X-Watermark-FontSize', fontSize.toString());
    response.headers.set('X-Watermark-FontColor', fontColor);
    response.headers.set('X-Watermark-Opacity', opacity.toString());
    
    return response;
  } catch (error) {
    console.error('添加水印时出错:', error);
    // 出错时返回原始图像
    return new Response(imageData);
  }
}

/**
 * 根据用户等级判断是否需要添加水印
 * @param user 用户对象
 * @param db 数据库连接
 * @returns 是否需要添加水印
 */
export async function shouldAddWatermark(user: any, db: any): Promise<boolean> {
  // 如果用户未登录，默认添加水印
  if (!user) {
    return true;
  }

  try {
    // 获取用户等级信息
    const userLevel = await db.prepare(
      "SELECT content_access FROM UserLevels WHERE level_name = ?"
    ).bind(user.membership_level || 'basic').first();
    
    if (userLevel) {
      const access = JSON.parse(userLevel.content_access);
      // 如果用户等级有"无水印访问"权限，则不添加水印
      return !access.can_access_without_watermark;
    }
  } catch (error) {
    console.error('检查用户水印权限时出错:', error);
  }
  
  // 默认添加水印
  return true;
}