/**
 * AI应用配置管理模块
 * 用于管理不同AI应用的API密钥和WebApp ID配置
 */

// AI应用类型枚举
export type AIAppType = 
  | 'text-to-image'
  | 'text-to-video'
  | 'image-repair'
  | 'image-upscale'
  | 'face-swap'

  | 'general'; // 通用配置

// RunningHub配置接口
export interface RunningHubConfig {
  apiKey: string;
  webappId: string;
}

// 阿里云配置接口
export interface AliyunConfig {
  apiKey: string;
}

/**
 * 获取RunningHub配置
 * @param env 环境变量对象
 * @param appType AI应用类型
 * @returns RunningHub配置
 */
export function getRunningHubConfig(env: any, appType: AIAppType = 'general'): RunningHubConfig {
  // 使用通用API Key作为默认值
  const apiKey = env.RUNNINGHUB_API_KEY || '75faa4e0296945e796c3914bd95e3e52';
  
  let webappId: string;
  
  // 根据应用类型选择对应的WebApp ID
  switch (appType) {
    case 'text-to-image':
      webappId = env.TEXT_TO_IMAGE_RUNNINGHUB_WEBAPP_ID || env.RUNNINGHUB_WEBAPP_ID || '1877265245566922753';
      break;
      
    case 'text-to-video':
      webappId = env.TEXT_TO_VIDEO_RUNNINGHUB_WEBAPP_ID || env.RUNNINGHUB_WEBAPP_ID || '1877265245566922753';
      break;
      
    case 'image-repair':
      webappId = env.IMAGE_REPAIR_RUNNINGHUB_WEBAPP_ID || env.RUNNINGHUB_WEBAPP_ID || '1877265245566922753';
      break;
      
    case 'image-upscale':
      webappId = env.IMAGE_UPSCALE_RUNNINGHUB_WEBAPP_ID || env.RUNNINGHUB_WEBAPP_ID || '1877265245566922753';
      break;
      
    case 'face-swap':
      webappId = env.FACE_SWAP_RUNNINGHUB_WEBAPP_ID || env.RUNNINGHUB_WEBAPP_ID || '1877265245566922753';
      break;
      

    case 'general':
    default:
      // 使用通用WebApp ID作为默认值
      webappId = env.RUNNINGHUB_WEBAPP_ID || '1877265245566922753';
      break;
  }
  
  return { apiKey, webappId };
}

/**
 * 获取阿里云配置
 * @param env 环境变量对象
 * @param appType AI应用类型
 * @returns 阿里云配置
 */
export function getAliyunConfig(env: any, appType: AIAppType = 'general'): AliyunConfig {
  let apiKey: string;
  
  // 根据应用类型选择对应的环境变量
  switch (appType) {
    case 'text-to-image':
      apiKey = env.TEXT_TO_IMAGE_DASHSCOPE_API_KEY || env.DASHSCOPE_API_KEY || '';
      break;
      
    case 'text-to-video':
      apiKey = env.TEXT_TO_VIDEO_DASHSCOPE_API_KEY || env.DASHSCOPE_API_KEY || '';
      break;
      
    case 'image-repair':
      apiKey = env.IMAGE_REPAIR_DASHSCOPE_API_KEY || env.DASHSCOPE_API_KEY || '';
      break;
      
    case 'image-upscale':
      apiKey = env.IMAGE_UPSCALE_DASHSCOPE_API_KEY || env.DASHSCOPE_API_KEY || '';
      break;
      
    case 'face-swap':
      apiKey = env.FACE_SWAP_DASHSCOPE_API_KEY || env.DASHSCOPE_API_KEY || '';
      break;
      
    case 'general':
    default:
      // 使用通用配置作为默认值
      apiKey = env.DASHSCOPE_API_KEY || '';
      break;
  }
  
  return { apiKey };
}

/**
 * 获取AI应用配置
 * @param env 环境变量对象
 * @param appType AI应用类型
 * @param platform AI平台类型
 * @returns 对应平台的配置
 */
export function getAIConfig(env: any, appType: AIAppType = 'general', platform: 'runninghub' | 'aliyun' = 'runninghub') {
  switch (platform) {
    case 'runninghub':
      return getRunningHubConfig(env, appType);
    case 'aliyun':
      return getAliyunConfig(env, appType);
    default:
      throw new Error(`Unsupported AI platform: ${platform}`);
  }
}