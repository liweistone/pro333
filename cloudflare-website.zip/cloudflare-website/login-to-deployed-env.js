// 登录并保存部署环境的JWT令牌到文件
const fs = require('fs');

// 用户登录凭据（使用默认的管理员账户）
const USER_CREDENTIALS = {
  username: 'admin',  // 默认管理员用户名
  password: 'admin'   // 默认管理员密码
};

async function loginAndSaveToken() {
  console.log('=== 登录部署环境并保存JWT令牌 ===\n');
  
  try {
    // 发送登录请求
    console.log('正在登录...');
    const response = await fetch('https://aideator.top/api/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(USER_CREDENTIALS)
    });
    
    console.log('登录响应状态:', response.status);
    
    if (!response.ok) {
      const errorText = await response.text();
      console.error('登录失败:', errorText);
      process.exit(1);
    }
    
    const data = await response.json();
    console.log('登录成功!');
    console.log('用户信息:', data.user);
    
    // 保存JWT令牌到文件
    if (data.token) {
      fs.writeFileSync('./jwt-token-deployed.txt', data.token);
      console.log('JWT令牌已保存到 jwt-token-deployed.txt 文件');
      console.log('令牌:', data.token.substring(0, 20) + '...' + data.token.substring(data.token.length - 20));
    } else {
      console.error('响应中没有找到JWT令牌');
      process.exit(1);
    }
    
    console.log('\n=== 登录完成 ===');
    
  } catch (error) {
    console.error('登录过程中发生错误:', error.message);
    console.error('错误堆栈:', error.stack);
  }
}

// 运行登录
loginAndSaveToken();