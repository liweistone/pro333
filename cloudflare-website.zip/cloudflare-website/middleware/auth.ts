import { createMiddleware } from 'hono/factory';
import { verify } from 'hono/jwt';

// JWT认证中间件
export const authMiddleware = createMiddleware(async (c, next) => {
  const authHeader = c.req.header('Authorization');
  
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return c.json({ error: '缺少访问令牌' }, 401);
  }
  
  const token = authHeader.substring(7); // 移除 'Bearer ' 前缀
  
  try {
    // 验证JWT令牌
    console.log('JWT_SECRET used for verification:', c.env.JWT_SECRET);
    const payload = await verify(token, c.env.JWT_SECRET);
    
    // 设置用户信息
    c.set('user', {
      id: payload.id,
      username: payload.username,
      email: payload.email,
      role: payload.role,
      membership_level: payload.membership_level
    });
    
    await next();
  } catch (error) {
    console.error('JWT verification error:', error);
    return c.json({ error: '无效的访问令牌' }, 401);
  }
});

// 角色权限检查中间件
export const requireRole = (roles: string | string[]) => {
  return createMiddleware(async (c, next) => {
    const user = c.get('user');
    
    if (!user) {
      return c.json({ error: '需要登录' }, 401);
    }
    
    const allowedRoles = Array.isArray(roles) ? roles : [roles];
    
    if (!allowedRoles.includes(user.role)) {
      return c.json({ error: '权限不足' }, 403);
    }
    
    await next();
  });
};

// 管理员权限检查中间件
export const requireAdmin = createMiddleware(async (c, next) => {
  const user = c.get('user');
  
  if (!user) {
    return c.json({ error: '需要登录' }, 401);
  }
  
  if (user.role !== 'admin' && user.role !== 'superadmin') {
    return c.json({ error: '需要管理员权限' }, 403);
  }
  
  await next();
});